package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/google/uuid"
)

// EngagementClient handles communication with the Engagement Service
type EngagementClient struct {
	baseURL string
	client  *http.Client
}

// NewEngagementClient creates a new engagement client
func NewEngagementClient(baseURL string) *EngagementClient {
	return &EngagementClient{
		baseURL: baseURL,
		client:  &http.Client{Timeout: 10 * time.Second},
	}
}

// BatchLikeStatusRequest represents a batch like status request
type BatchLikeStatusRequest struct {
	UserID  string   `json:"user_id"`
	EchoIDs []string `json:"echo_ids"`
}

// BatchLikeStatusResponse represents a batch like status response
type BatchLikeStatusResponse struct {
	LikeStatus map[string]bool `json:"like_status"` // echo_id -> is_liked
}

// GetBatchLikeStatus retrieves like status for multiple echoes
func (c *EngagementClient) GetBatchLikeStatus(userID uuid.UUID, echoIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if len(echoIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	// Convert UUIDs to strings
	echoIDStrs := make([]string, len(echoIDs))
	for i, id := range echoIDs {
		echoIDStrs[i] = id.String()
	}

	reqBody := BatchLikeStatusRequest{
		UserID:  userID.String(),
		EchoIDs: echoIDStrs,
	}

	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	url := fmt.Sprintf("%s/api/internal/likes/batch-status", c.baseURL)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call engagement service: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("engagement service returned status %d: %s", resp.StatusCode, string(body))
	}

	// Parse response
	var apiResp struct {
		Success bool                    `json:"success"`
		Data    BatchLikeStatusResponse `json:"data"`
	}

	if err := json.Unmarshal(body, &apiResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %w", err)
	}

	if !apiResp.Success {
		return nil, fmt.Errorf("engagement service returned success=false")
	}

	// Convert back to UUID map
	result := make(map[uuid.UUID]bool)
	for echoIDStr, isLiked := range apiResp.Data.LikeStatus {
		echoID, err := uuid.Parse(echoIDStr)
		if err == nil {
			result[echoID] = isLiked
		}
	}

	return result, nil
}

// InteractionClient handles communication with the Interaction Service
type InteractionClient struct {
	baseURL string
	client  *http.Client
}

// NewInteractionClient creates a new interaction client
func NewInteractionClient(baseURL string) *InteractionClient {
	return &InteractionClient{
		baseURL: baseURL,
		client:  &http.Client{Timeout: 10 * time.Second},
	}
}

// BatchFollowStatusRequest represents a batch follow status request
type BatchFollowStatusRequest struct {
	FollowerID string   `json:"follower_id"`
	UserIDs    []string `json:"user_ids"`
}

// BatchFollowStatusResponse represents a batch follow status response
type BatchFollowStatusResponse struct {
	FollowStatus map[string]bool `json:"follow_status"` // user_id -> is_followed
}

// GetBatchFollowStatus retrieves follow status for multiple users
func (c *InteractionClient) GetBatchFollowStatus(followerID uuid.UUID, userIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if len(userIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	// Convert UUIDs to strings
	userIDStrs := make([]string, len(userIDs))
	for i, id := range userIDs {
		userIDStrs[i] = id.String()
	}

	reqBody := BatchFollowStatusRequest{
		FollowerID: followerID.String(),
		UserIDs:    userIDStrs,
	}

	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	url := fmt.Sprintf("%s/api/internal/follows/batch-status", c.baseURL)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call interaction service: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("interaction service returned status %d: %s", resp.StatusCode, string(body))
	}

	// Parse response
	var apiResp struct {
		Success bool                      `json:"success"`
		Data    BatchFollowStatusResponse `json:"data"`
	}

	if err := json.Unmarshal(body, &apiResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %w", err)
	}

	if !apiResp.Success {
		return nil, fmt.Errorf("interaction service returned success=false")
	}

	// Convert back to UUID map
	result := make(map[uuid.UUID]bool)
	for userIDStr, isFollowed := range apiResp.Data.FollowStatus {
		userID, err := uuid.Parse(userIDStr)
		if err == nil {
			result[userID] = isFollowed
		}
	}

	return result, nil
}
