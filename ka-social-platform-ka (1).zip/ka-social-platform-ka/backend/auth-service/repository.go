package main

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/redis/go-redis/v9"
)

// Repository handles database operations for auth
type Repository struct {
	db    *sqlx.DB
	redis *redis.Client
}

// NewRepository creates a new repository
func NewRepository(db *sqlx.DB, redis *redis.Client) *Repository {
	return &Repository{
		db:    db,
		redis: redis,
	}
}

// CreateUser creates a new user
func (r *Repository) CreateUser(user *models.User) error {
	query := `
		INSERT INTO users (id, username, email, phone, password_hash, display_name, language)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
		RETURNING created_at, updated_at
	`

	err := r.db.QueryRow(
		query,
		user.ID,
		user.Username,
		user.Email,
		user.Phone,
		user.PasswordHash,
		user.DisplayName,
		user.Language,
	).Scan(&user.CreatedAt, &user.UpdatedAt)

	if err != nil {
		return fmt.Errorf("failed to create user: %w", err)
	}

	// Create default notification settings for the user
	_, err = r.db.Exec(`
		INSERT INTO notification_settings (user_id)
		VALUES ($1)
	`, user.ID)
	if err != nil {
		return fmt.Errorf("failed to create notification settings: %w", err)
	}

	return nil
}

// GetUserByEmail gets a user by email
func (r *Repository) GetUserByEmail(email string) (*models.User, error) {
	var user models.User
	query := `
		SELECT id, username, email, phone, password_hash, display_name, bio,
		       profile_picture_url, cover_story_url, cover_story_type, location, 
		       website, is_verified, is_premium, language, created_at, updated_at
		FROM users
		WHERE email = $1
	`

	err := r.db.Get(&user, query, email)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	return &user, nil
}

// GetUserByUsername gets a user by username
func (r *Repository) GetUserByUsername(username string) (*models.User, error) {
	var user models.User
	query := `
		SELECT id, username, email, phone, password_hash, display_name, bio,
		       profile_picture_url, cover_story_url, cover_story_type, location, 
		       website, is_verified, is_premium, language, created_at, updated_at
		FROM users
		WHERE username = $1
	`

	err := r.db.Get(&user, query, username)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	return &user, nil
}

// GetUserByID gets a user by ID
func (r *Repository) GetUserByID(userID uuid.UUID) (*models.User, error) {
	var user models.User
	query := `
		SELECT id, username, email, phone, password_hash, display_name, bio,
		       profile_picture_url, cover_story_url, cover_story_type, location, 
		       website, is_verified, is_premium, language, created_at, updated_at
		FROM users
		WHERE id = $1
	`

	err := r.db.Get(&user, query, userID)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	return &user, nil
}

// SaveRefreshToken saves a refresh token to the database
func (r *Repository) SaveRefreshToken(userID uuid.UUID, tokenHash string, expiresAt time.Time) error {
	query := `
		INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
		VALUES ($1, $2, $3)
	`

	_, err := r.db.Exec(query, userID, tokenHash, expiresAt)
	if err != nil {
		return fmt.Errorf("failed to save refresh token: %w", err)
	}

	return nil
}

// ValidateRefreshToken validates a refresh token
func (r *Repository) ValidateRefreshToken(tokenHash string) (uuid.UUID, error) {
	var userID uuid.UUID
	var expiresAt time.Time
	var isRevoked bool

	query := `
		SELECT user_id, expires_at, is_revoked
		FROM refresh_tokens
		WHERE token_hash = $1
	`

	err := r.db.QueryRow(query, tokenHash).Scan(&userID, &expiresAt, &isRevoked)
	if err == sql.ErrNoRows {
		return uuid.Nil, fmt.Errorf("token not found")
	}
	if err != nil {
		return uuid.Nil, fmt.Errorf("failed to validate token: %w", err)
	}

	if isRevoked {
		return uuid.Nil, fmt.Errorf("token has been revoked")
	}

	if time.Now().After(expiresAt) {
		return uuid.Nil, fmt.Errorf("token has expired")
	}

	return userID, nil
}

// RevokeRefreshToken revokes a refresh token
func (r *Repository) RevokeRefreshToken(tokenHash string) error {
	query := `
		UPDATE refresh_tokens
		SET is_revoked = true, revoked_at = CURRENT_TIMESTAMP
		WHERE token_hash = $1
	`

	_, err := r.db.Exec(query, tokenHash)
	if err != nil {
		return fmt.Errorf("failed to revoke token: %w", err)
	}

	return nil
}

// RevokeAllUserTokens revokes all refresh tokens for a user
func (r *Repository) RevokeAllUserTokens(userID uuid.UUID) error {
	query := `
		UPDATE refresh_tokens
		SET is_revoked = true, revoked_at = CURRENT_TIMESTAMP
		WHERE user_id = $1 AND is_revoked = false
	`

	_, err := r.db.Exec(query, userID)
	if err != nil {
		return fmt.Errorf("failed to revoke all tokens: %w", err)
	}

	return nil
}

// BlacklistToken adds a token to the Redis blacklist
func (r *Repository) BlacklistToken(token string, expiry time.Duration) error {
	ctx := context.Background()
	return r.redis.Set(ctx, "blacklist:"+token, "1", expiry).Err()
}

// IsTokenBlacklisted checks if a token is blacklisted
func (r *Repository) IsTokenBlacklisted(token string) bool {
	ctx := context.Background()
	exists, err := r.redis.Exists(ctx, "blacklist:"+token).Result()
	return err == nil && exists > 0
}
