package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/database"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"
)

func main() {
	// Get environment variables
	port := getEnv("PORT", "8004")
	redisHost := getEnv("REDIS_HOST", "localhost")
	redisPort := getEnv("REDIS_PORT", "6379")
	redisPassword := getEnv("REDIS_PASSWORD", "")
	jwtSecret := getEnv("JWT_SECRET", "your-super-secret-jwt-key-change-in-production")
	natsURL := getEnv("NATS_URL", "nats://localhost:4222")
	interactionServiceURL := getEnv("INTERACTION_SERVICE_URL", "http://localhost:8005")
	contentServiceURL := getEnv("CONTENT_SERVICE_URL", "http://localhost:8003")

	// Initialize Redis connection
	redisClient, err := database.NewRedisConnection(database.RedisConfig{
		Host:     redisHost,
		Port:     redisPort,
		Password: redisPassword,
		DB:       0,
	})
	if err != nil {
		log.Fatalf("Failed to connect to Redis: %v", err)
	}
	defer redisClient.Close()

	// Create config
	config := &Config{
		Redis:                 redisClient,
		JWTSecret:             jwtSecret,
		InteractionServiceURL: interactionServiceURL,
		ContentServiceURL:     contentServiceURL,
	}

	// Initialize repositories and handlers
	repo := NewRepository(redisClient)
	handler := NewHandler(repo, config)

	// Initialize NATS consumer for feed events
	consumer, err := NewNATSConsumer(natsURL, repo, interactionServiceURL)
	if err != nil {
		log.Fatalf("Failed to initialize NATS consumer: %v", err)
	}
	defer consumer.Close()

	// Start consuming echo events
	if err := consumer.Start(); err != nil {
		log.Fatalf("Failed to start NATS consumer: %v", err)
	}

	// Initialize Trust & Safety consumer (using the same NATS connection)
	tsConsumer := trustsafety.NewEventConsumer(consumer.GetConn(), redisClient, "feed-service")
	if err := tsConsumer.Start(); err != nil {
		log.Fatalf("Failed to start Trust & Safety consumer: %v", err)
	}

	// Create Trust & Safety client for handler
	config.TrustSafetyClient = trustsafety.NewClient(redisClient, interactionServiceURL)

	// Initialize Gin router
	router := gin.Default()

	// Add middleware
	router.Use(middleware.CORSMiddleware())
	router.Use(middleware.LoggerMiddleware())

	// Setup routes
	SetupRoutes(router, handler, jwtSecret)

	// Health check endpoint
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"status":  "ok",
			"service": "feed-service",
		})
	})

	// Start server
	log.Printf("Feed service starting on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}

func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}
