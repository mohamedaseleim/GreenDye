# Ka Platform - API Specification

## API Overview

Base URL: `https://api.ka.social/v1`

All API requests require authentication (except auth endpoints) via Bearer token:
```
Authorization: Bearer <access_token>
```

## Service Endpoints

Ka Platform uses a microservices architecture. Here's which service handles which endpoints:

**Authentication Service** (Port 8001):
- `/api/auth/*` - Registration, login, token refresh, logout

**User Service** (Port 8002):
- `/api/profile/*` - Current user's profile management
- `/api/users/*` - Public user profiles, search

**Interaction Service** (Port 8005):
- `/api/users/:id/follow` - Follow/unfollow operations
- `/api/users/:id/followers` - Follower lists
- `/api/users/:id/following` - Following lists

**Content Service** (Port 8003):
- `/api/echoes/*` - Short-form posts (future)
- `/api/stories/*` - Long-form posts (future)

**Feed Service** (Port 8004):
- `/api/feed/*` - Timeline generation (future)

**Messaging Service** (Port 8006):
- `/api/messages/*` - Direct messaging (future)

**Notification Service** (Port 8007):
- `/api/notifications/*` - Notifications (future)

**Discovery Service** (Port 8008):
- `/api/discover/*` - Trending topics, recommendations (future)

## Response Format

### Success Response
```json
{
  "success": true,
  "data": { },
  "message": "Operation successful"
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": { }
  }
}
```

### Pagination
```json
{
  "success": true,
  "data": {
    "items": [...],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 100,
      "total_pages": 5,
      "next_cursor": "abc123"
    }
  }
}
```

## Authentication Endpoints

### Register New User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "SecurePass123!",
  "display_name": "John Doe",
  "phone": "+1234567890" // optional
}

Response 201:
{
  "success": true,
  "data": {
    "user_id": "uuid",
    "username": "john_doe",
    "email": "john@example.com",
    "verification_required": true
  },
  "message": "Account created. Please verify your email."
}
```

### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "SecurePass123!"
}

Response 200:
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "username": "john_doe",
      "display_name": "John Doe",
      "profile_picture_url": "https://..."
    },
    "access_token": "eyJhbGc...",
    "refresh_token": "eyJhbGc...",
    "expires_in": 900
  }
}
```

### Refresh Token
```http
POST /api/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGc..."
}

Response 200:
{
  "success": true,
  "data": {
    "access_token": "eyJhbGc...",
    "expires_in": 900
  }
}
```

### Logout
```http
POST /api/auth/logout
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "message": "Logged out successfully"
}
```

## User Endpoints

### Get Current User Profile (Private)
```http
GET /api/profile/me
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "id": "uuid",
    "username": "john_doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "display_name": "John Doe",
    "bio": "Software engineer and coffee enthusiast",
    "profile_picture_url": "https://...",
    "cover_story_url": "https://...",
    "cover_story_type": "slideshow",
    "location": "Cairo, Egypt",
    "website": "https://johndoe.com",
    "is_verified": false,
    "is_premium": false,
    "language": "en",
    "created_at": "2023-01-01T00:00:00Z",
    "updated_at": "2024-01-15T10:30:00Z"
  },
  "message": "Profile retrieved successfully"
}
```

### Update Current User Profile (Private)
```http
PUT /api/profile/me
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "display_name": "John M. Doe",
  "bio": "Updated bio",
  "location": "Alexandria, Egypt",
  "website": "https://newsite.com"
}

Response 200:
{
  "success": true,
  "data": { /* updated user object */ },
  "message": "Profile updated successfully"
}
```

### Get User Profile by Username (Public)
```http
GET /api/users/:username

Response 200:
{
  "success": true,
  "data": {
    "id": "uuid",
    "username": "john_doe",
    "display_name": "John Doe",
    "bio": "Software engineer and coffee enthusiast",
    "profile_picture_url": "https://...",
    "cover_story_url": "https://...",
    "cover_story_type": "slideshow",
    "location": "Cairo, Egypt",
    "website": "https://johndoe.com",
    "is_verified": false,
    "is_premium": false,
    "follower_count": 1234,
    "following_count": 567,
    "echo_count": 89,
    "story_count": 45,
    "top_echo": {
      "id": "uuid",
      "content": "This is my most popular echo!",
      "like_count": 500,
      "created_at": "2024-01-15T10:30:00Z"
    },
    "is_following": false,
    "is_followed_by": false,
    "created_at": "2023-01-01T00:00:00Z"
  },
  "message": "Profile retrieved successfully"
}
```

### Get User Profile by ID (Public)
```http
GET /api/users/id/:id

Response 200:
{
  "success": true,
  "data": { /* same as get by username */ },
  "message": "Profile retrieved successfully"
}
```

### Follow User
```http
POST /api/users/:id/follow
Authorization: Bearer <access_token>

Response 200 (First time following):
{
  "success": true,
  "data": {
    "following": true,
    "already_following": false
  },
  "message": "Successfully followed user"
}

Response 200 (Already following - idempotent):
{
  "success": true,
  "data": {
    "following": true,
    "already_following": true
  },
  "message": "Successfully followed user"
}

Response 400 (Cannot follow yourself):
{
  "success": false,
  "error": {
    "code": "INVALID_ACTION",
    "message": "Cannot follow yourself"
  }
}

Response 404 (User not found):
{
  "success": false,
  "error": {
    "code": "USER_NOT_FOUND",
    "message": "Target user not found"
  }
}

Note: This endpoint is idempotent. Calling it multiple times has the same effect as calling it once.
The follower/following counts are automatically updated in the User Service.
```

### Unfollow User
```http
DELETE /api/users/:id/follow
Authorization: Bearer <access_token>

Response 200 (Was following):
{
  "success": true,
  "data": {
    "following": false,
    "was_following": true
  },
  "message": "Successfully unfollowed user"
}

Response 200 (Wasn't following - idempotent):
{
  "success": true,
  "data": {
    "following": false,
    "was_following": false
  },
  "message": "Successfully unfollowed user"
}

Note: This endpoint is idempotent. Calling it multiple times has the same effect as calling it once.
The follower/following counts are automatically updated in the User Service.
```

### Get Followers
```http
GET /api/users/:id/followers?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "ce831e8d-713a-412a-89ae-3efa4cb60727",
        "username": "alice",
        "display_name": "Alice Smith",
        "profile_picture_url": null,
        "is_verified": false
      },
      {
        "id": "f80696a0-cba8-46cb-94e4-de07d528a404",
        "username": "bob",
        "display_name": "Bob Johnson",
        "is_verified": false
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 2,
      "total_pages": 1
    }
  }
}

Query Parameters:
- page: Page number (default: 1)
- per_page: Results per page (default: 20, max: 100)

Note: Results are ordered by follow date (most recent first).
```

### Get Following
```http
GET /api/users/:id/following?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "f80696a0-cba8-46cb-94e4-de07d528a404",
        "username": "bob",
        "display_name": "Bob Johnson",
        "is_verified": false
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 1,
      "total_pages": 1
    }
  }
}

Query Parameters:
- page: Page number (default: 1)
- per_page: Results per page (default: 20, max: 100)

Note: Results are ordered by follow date (most recent first).
```

### Search Users (Public)
```http
GET /api/users/search?q=john&page=1&per_page=20

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "uuid",
        "username": "john_doe",
        "display_name": "John Doe",
        "bio": "Software engineer",
        "profile_picture_url": "https://...",
        "is_verified": false,
        "is_premium": false,
        "created_at": "2023-01-01T00:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 42,
      "total_pages": 3
    }
  }
}
```

## Echo Endpoints (Short Posts)

### Create Echo
```http
POST /api/echoes
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "content": "This is my first echo! #excited",
  "media_urls": ["https://..."],
  "visibility": "public",
  "mentions": ["uuid1", "uuid2"]
}

Response 201:
{
  "success": true,
  "data": {
    "id": "uuid",
    "user_id": "uuid",
    "content": "This is my first echo! #excited",
    "media_urls": ["https://..."],
    "hashtags": ["excited"],
    "mentions": ["uuid1", "uuid2"],
    "visibility": "public",
    "like_count": 0,
    "comment_count": 0,
    "share_count": 0,
    "created_at": "2024-01-15T10:30:00Z"
  },
  "message": "Echo created successfully"
}
```

### Get Echo
```http
GET /api/echoes/:echo_id
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "id": "uuid",
    "user": {
      "id": "uuid",
      "username": "john_doe",
      "display_name": "John Doe",
      "profile_picture_url": "https://...",
      "is_verified": false
    },
    "content": "This is my first echo! #excited",
    "media_urls": ["https://..."],
    "hashtags": ["excited"],
    "mentions": [],
    "visibility": "public",
    "like_count": 42,
    "comment_count": 5,
    "share_count": 3,
    "is_liked": false,
    "is_bookmarked": false,
    "created_at": "2024-01-15T10:30:00Z"
  }
}
```

### Delete Echo
```http
DELETE /api/echoes/:echo_id
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "message": "Echo deleted successfully"
}
```

## Story Endpoints (Long Posts)

### Create Story
```http
POST /api/stories
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "title": "My Journey to Egypt",
  "content": "Long form content with details...",
  "photo_album": ["url1", "url2", "url3"],
  "tagged_users": ["uuid1", "uuid2"],
  "visibility": "friends"
}

Response 201:
{
  "success": true,
  "data": {
    "id": "uuid",
    "user_id": "uuid",
    "title": "My Journey to Egypt",
    "content": "Long form content with details...",
    "photo_album": ["url1", "url2", "url3"],
    "tagged_users": ["uuid1", "uuid2"],
    "visibility": "friends",
    "like_count": 0,
    "comment_count": 0,
    "created_at": "2024-01-15T10:30:00Z"
  },
  "message": "Story created successfully"
}
```

### Get Story
```http
GET /api/stories/:story_id
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "id": "uuid",
    "user": { /* user object */ },
    "title": "My Journey to Egypt",
    "content": "Long form content with details...",
    "photo_album": ["url1", "url2", "url3"],
    "tagged_users": [ /* array of user objects */ ],
    "visibility": "friends",
    "like_count": 25,
    "comment_count": 8,
    "is_liked": true,
    "is_bookmarked": false,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-01-15T10:30:00Z"
  }
}
```

### Update Story
```http
PUT /api/stories/:story_id
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "title": "Updated title",
  "content": "Updated content..."
}

Response 200:
{
  "success": true,
  "data": { /* updated story object */ },
  "message": "Story updated successfully"
}
```

### Delete Story
```http
DELETE /api/stories/:story_id
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "message": "Story deleted successfully"
}
```

## Feed Endpoints

### Get For You Feed
```http
GET /api/feed/for-you?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "type": "echo",
        "post": { /* echo object */ },
        "reason": "trending"
      },
      {
        "type": "story",
        "post": { /* story object */ },
        "reason": "from_following"
      }
    ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get Inner Circle Feed
```http
GET /api/feed/inner-circle?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [ /* array of posts from mutual follows */ ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get World Feed
```http
GET /api/feed/world?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [ /* array of trending and public posts */ ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get User Timeline
```http
GET /api/users/:user_id/timeline?type=echoes&page=1&per_page=20
Authorization: Bearer <access_token>

Query Parameters:
- type: "echoes" or "stories" or "all" (default: "all")
- page: page number (default: 1)
- per_page: items per page (default: 20)

Response 200:
{
  "success": true,
  "data": {
    "items": [ /* array of user's posts */ ],
    "pagination": { /* pagination info */ }
  }
}
```

## Interaction Endpoints

### Like Post
```http
POST /api/posts/:post_id/like
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "is_liked": true,
    "like_count": 43
  },
  "message": "Post liked"
}
```

### Unlike Post
```http
DELETE /api/posts/:post_id/like
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "is_liked": false,
    "like_count": 42
  },
  "message": "Post unliked"
}
```

### Add Comment
```http
POST /api/posts/:post_id/comments
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "content": "Great post!",
  "parent_comment_id": "uuid" // optional, for replies
}

Response 201:
{
  "success": true,
  "data": {
    "id": "uuid",
    "post_id": "uuid",
    "user": { /* user object */ },
    "content": "Great post!",
    "parent_comment_id": null,
    "like_count": 0,
    "reply_count": 0,
    "created_at": "2024-01-15T10:30:00Z"
  },
  "message": "Comment added"
}
```

### Get Comments
```http
GET /api/posts/:post_id/comments?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "uuid",
        "user": { /* user object */ },
        "content": "Great post!",
        "like_count": 5,
        "reply_count": 2,
        "is_liked": false,
        "created_at": "2024-01-15T10:30:00Z"
      }
    ],
    "pagination": { /* pagination info */ }
  }
}
```

### Share Post
```http
POST /api/posts/:post_id/share
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "comment": "Check this out!" // optional
}

Response 200:
{
  "success": true,
  "data": {
    "share_count": 4
  },
  "message": "Post shared"
}
```

### Bookmark Post
```http
POST /api/posts/:post_id/bookmark
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "is_bookmarked": true
  },
  "message": "Post bookmarked"
}
```

### Get Bookmarks
```http
GET /api/users/:user_id/bookmarks?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [ /* array of bookmarked posts */ ],
    "pagination": { /* pagination info */ }
  }
}
```

## Messaging Endpoints

### Get Inbox
```http
GET /api/messages/inbox?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "conversation_id": "uuid",
        "participant": { /* user object */ },
        "last_message": {
          "id": "uuid",
          "content": "Hey, how are you?",
          "sender_id": "uuid",
          "created_at": "2024-01-15T10:30:00Z",
          "is_read": false
        },
        "unread_count": 3,
        "is_muted": false,
        "updated_at": "2024-01-15T10:30:00Z"
      }
    ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get Message Requests
```http
GET /api/messages/requests?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [ /* similar to inbox */ ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get Conversation Messages
```http
GET /api/conversations/:conversation_id/messages?page=1&per_page=50
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "uuid",
        "conversation_id": "uuid",
        "sender": { /* user object */ },
        "content": "Hey, how are you?",
        "encrypted_content": "base64...", // for E2EE
        "message_type": "text", // text, voice, image, video
        "media_url": null,
        "is_read": true,
        "created_at": "2024-01-15T10:30:00Z"
      }
    ],
    "pagination": { /* pagination info */ }
  }
}
```

### Send Message
```http
POST /api/conversations/:conversation_id/messages
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "content": "Hello!",
  "encrypted_content": "base64...", // for E2EE
  "message_type": "text",
  "media_url": null
}

Response 201:
{
  "success": true,
  "data": {
    "id": "uuid",
    "conversation_id": "uuid",
    "sender": { /* user object */ },
    "content": "Hello!",
    "message_type": "text",
    "created_at": "2024-01-15T10:30:00Z"
  },
  "message": "Message sent"
}
```

### Start Conversation
```http
POST /api/conversations
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "participant_id": "uuid",
  "initial_message": "Hi there!"
}

Response 201:
{
  "success": true,
  "data": {
    "conversation_id": "uuid",
    "participant": { /* user object */ },
    "created_at": "2024-01-15T10:30:00Z"
  },
  "message": "Conversation started"
}
```

## Notification Endpoints

### Get Notifications
```http
GET /api/notifications?page=1&per_page=20&filter=unread
Authorization: Bearer <access_token>

Query Parameters:
- filter: "all", "unread", "read" (default: "all")

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "uuid",
        "type": "like", // like, comment, follow, mention, share
        "actor": { /* user object */ },
        "post": { /* post object if applicable */ },
        "content": "John Doe liked your echo",
        "is_read": false,
        "created_at": "2024-01-15T10:30:00Z"
      }
    ],
    "unread_count": 5,
    "pagination": { /* pagination info */ }
  }
}
```

### Mark Notification as Read
```http
PUT /api/notifications/:notification_id/read
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "message": "Notification marked as read"
}
```

### Mark All Notifications as Read
```http
PUT /api/notifications/read-all
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "message": "All notifications marked as read"
}
```

### Update Notification Settings
```http
PUT /api/notifications/settings
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "push_enabled": true,
  "email_enabled": false,
  "likes_enabled": true,
  "comments_enabled": true,
  "follows_enabled": true,
  "mentions_enabled": true
}

Response 200:
{
  "success": true,
  "data": { /* updated settings */ },
  "message": "Settings updated"
}
```

## Discovery Endpoints

### Get Trending Topics
```http
GET /api/discover/trending?region=global&page=1&per_page=20
Authorization: Bearer <access_token>

Query Parameters:
- region: "global", "local", or country code (default: "global")

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "hashtag": "TechNews",
        "post_count": 12500,
        "trend_score": 9.5,
        "sample_posts": [ /* array of 3 sample posts */ ]
      }
    ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get Regional Trends
```http
GET /api/discover/regional?location=Cairo&page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "location": "Cairo, Egypt",
    "items": [ /* similar to trending topics */ ],
    "pagination": { /* pagination info */ }
  }
}
```

### Get Suggested Users
```http
GET /api/discover/users?page=1&per_page=20
Authorization: Bearer <access_token>

Response 200:
{
  "success": true,
  "data": {
    "items": [
      {
        "user": { /* user object */ },
        "reason": "popular_in_region", // or "mutual_connections", "similar_interests"
        "mutual_followers": 5
      }
    ],
    "pagination": { /* pagination info */ }
  }
}
```

### Search
```http
GET /api/search?q=keyword&type=all&page=1&per_page=20
Authorization: Bearer <access_token>

Query Parameters:
- q: search query (required)
- type: "all", "users", "echoes", "stories", "hashtags" (default: "all")

Response 200:
{
  "success": true,
  "data": {
    "users": [ /* array of user objects */ ],
    "echoes": [ /* array of echo objects */ ],
    "stories": [ /* array of story objects */ ],
    "hashtags": [ /* array of hashtag objects */ ],
    "pagination": { /* pagination info */ }
  }
}
```

## Media Upload Endpoint

### Upload Media
```http
POST /api/upload
Authorization: Bearer <access_token>
Content-Type: multipart/form-data

Form Data:
- file: (binary)
- type: "profile_picture", "cover_story", "post_media", "message_media"
- compress: true/false (default: true for mobile optimization)

Response 200:
{
  "success": true,
  "data": {
    "url": "https://cdn.ka.social/media/uuid.jpg",
    "thumbnail_url": "https://cdn.ka.social/media/uuid_thumb.jpg",
    "type": "image",
    "size": 1024000,
    "dimensions": {
      "width": 1920,
      "height": 1080
    }
  },
  "message": "Media uploaded successfully"
}
```

## WebSocket Endpoints

### Real-time Messaging
```
WS /ws/messages
Authorization: Bearer <access_token>

Client -> Server (Send Message):
{
  "type": "message",
  "conversation_id": "uuid",
  "content": "Hello!",
  "encrypted_content": "base64..."
}

Server -> Client (Receive Message):
{
  "type": "message",
  "message": { /* message object */ }
}

Server -> Client (Typing Indicator):
{
  "type": "typing",
  "conversation_id": "uuid",
  "user_id": "uuid",
  "is_typing": true
}

Server -> Client (Read Receipt):
{
  "type": "read_receipt",
  "conversation_id": "uuid",
  "message_id": "uuid"
}
```

### Real-time Notifications
```
WS /ws/notifications
Authorization: Bearer <access_token>

Server -> Client:
{
  "type": "notification",
  "notification": { /* notification object */ }
}
```

## Error Codes

| Code | Description |
|------|-------------|
| `AUTH_INVALID_CREDENTIALS` | Invalid email or password |
| `AUTH_TOKEN_EXPIRED` | Access token has expired |
| `AUTH_TOKEN_INVALID` | Invalid or malformed token |
| `USER_NOT_FOUND` | User does not exist |
| `USER_ALREADY_EXISTS` | Username or email already taken |
| `POST_NOT_FOUND` | Post does not exist |
| `PERMISSION_DENIED` | User doesn't have permission |
| `INVALID_INPUT` | Validation error in request body |
| `RATE_LIMIT_EXCEEDED` | Too many requests |
| `SERVER_ERROR` | Internal server error |
| `SERVICE_UNAVAILABLE` | Service temporarily unavailable |

## Rate Limits

| Endpoint Type | Limit |
|--------------|-------|
| Authentication | 5 requests / minute |
| Read Operations | 100 requests / minute |
| Write Operations | 50 requests / minute |
| Media Upload | 10 requests / minute |
| Search | 30 requests / minute |

Rate limit headers included in responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1705320600
```

## API Versioning

- Current version: `v1`
- Version specified in URL: `/v1/...`
- Deprecated versions supported for 6 months
- Breaking changes will result in new version

## SDK Support (Future)

Official SDKs planned for:
- JavaScript/TypeScript
- Python
- Go
- Swift (iOS)
- Kotlin (Android)
- Dart (Flutter)
