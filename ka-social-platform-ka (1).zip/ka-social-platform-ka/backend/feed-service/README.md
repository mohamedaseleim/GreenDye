# Feed Service

The Feed Service is responsible for generating personalized timelines and feeds for users. It implements a fan-out-on-write architecture for optimal read performance.

## Architecture

The Feed Service uses an event-driven architecture:

1. **NATS Consumer**: Subscribes to `echo.created` and `echo.deleted` events from the Content Service
2. **Fan-Out Logic**: When an echo is created, fetches the author's followers and adds the echo to each follower's timeline in Redis
3. **Redis Timelines**: Stores timeline data using sorted sets for efficient chronological ordering
4. **Caching Layer**: Caches hydrated echo objects to minimize calls to the Content Service

## Redis Schema

### Timelines
- `timeline:home:{userId}` - Sorted set of echo IDs for user's home feed (people they follow)
- `timeline:foryou:{userId}` - Sorted set of echo IDs for algorithmic feed (future use)

### Echo Cache
- `echo:details:{echoId}` - Cached echo object with 5-minute TTL

## API Endpoints

### GET /api/v1/feed/home
Get the authenticated user's home timeline.

**Authentication**: Required (JWT)

**Query Parameters**:
- `page` (optional): Page number (default: 1)
- `per_page` (optional): Items per page (default: 20, max: 100)

**Response**:
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "uuid",
        "user_id": "uuid",
        "content": "Echo content",
        "media_urls": [],
        "hashtags": [],
        "mentions": [],
        "visibility": "public",
        "like_count": 0,
        "comment_count": 0,
        "share_count": 0,
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 100,
      "total_pages": 5
    }
  }
}
```

## Event Consumption

### echo.created
When an echo is created, the Feed Service:
1. Fetches all followers of the echo author from the Interaction Service
2. Adds the echo ID to each follower's `timeline:home:{userId}` in Redis
3. Limits each timeline to 1000 most recent items

### echo.deleted
When an echo is deleted, the Feed Service:
1. Fetches all followers of the echo author
2. Removes the echo ID from each follower's timeline

## Performance Optimizations

1. **Fan-Out on Write**: Pre-compute timelines when echoes are created (write amplification for read performance)
2. **Batch Hydration**: Use Content Service's batch endpoint to fetch multiple echoes in a single request
3. **Multi-Layer Caching**: Cache hydrated echoes in Redis with 5-minute TTL
4. **Sorted Sets**: Use Redis sorted sets with timestamps for efficient chronological ordering
5. **Timeline Limits**: Keep only the latest 1000 items per timeline to prevent unbounded growth

## Dependencies

- **Redis**: Timeline storage and echo caching
- **NATS**: Event consumption (echo.created, echo.deleted)
- **Interaction Service**: Fetch followers list
- **Content Service**: Batch fetch echo details

## Environment Variables

- `PORT`: Service port (default: 8004)
- `REDIS_HOST`: Redis hostname (default: localhost)
- `REDIS_PORT`: Redis port (default: 6379)
- `REDIS_PASSWORD`: Redis password
- `JWT_SECRET`: JWT secret for authentication
- `NATS_URL`: NATS server URL (default: nats://localhost:4222)
- `INTERACTION_SERVICE_URL`: Interaction Service URL (default: http://localhost:8005)
- `CONTENT_SERVICE_URL`: Content Service URL (default: http://localhost:8003)

## Running Locally

```bash
# Start dependencies
cd ../../infrastructure/docker
docker-compose up -d postgres redis scylla nats

# Run the service
cd ../../backend/feed-service
go run .
```

## Performance Goals

- **Sub-100ms response time** for GET /api/v1/feed/home
- **Horizontal scalability** through NATS consumer groups
- **High availability** through Redis clustering
