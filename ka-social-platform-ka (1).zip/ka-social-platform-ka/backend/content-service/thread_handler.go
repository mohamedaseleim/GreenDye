package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"
)

// EchoWithContext represents an echo with viewer context
type EchoWithContext struct {
	models.Echo
	IsLikedByViewer    bool         `json:"is_liked_by_viewer"`
	Author             AuthorInfo   `json:"author"`
	Status             string       `json:"status,omitempty"` // "deleted" for deleted echoes
}

// AuthorInfo represents author information with follow status
type AuthorInfo struct {
	UserID             uuid.UUID `json:"user_id"`
	IsFollowedByViewer bool      `json:"is_followed_by_viewer"`
}

// ThreadResponse represents a conversation thread response
type ThreadResponse struct {
	Ancestors  []EchoWithContext `json:"ancestors"`
	Focus      EchoWithContext   `json:"focus"`
	Replies    []EchoWithContext `json:"replies"`
	NextCursor string            `json:"next_cursor,omitempty"`
}

// RepliesResponse represents paginated replies response
type RepliesResponse struct {
	Replies    []EchoWithContext `json:"replies"`
	NextCursor string            `json:"next_cursor,omitempty"`
}

// Cursor represents pagination cursor for replies
type Cursor struct {
	Timestamp time.Time `json:"ts"`
	EchoID    uuid.UUID `json:"id"`
}

// EncodeCursor encodes a cursor to base64
func EncodeCursor(c Cursor) string {
	data, _ := json.Marshal(c)
	return base64.URLEncoding.EncodeToString(data)
}

// DecodeCursor decodes a cursor from base64
func DecodeCursor(encoded string) (*Cursor, error) {
	data, err := base64.URLEncoding.DecodeString(encoded)
	if err != nil {
		return nil, err
	}
	var c Cursor
	if err := json.Unmarshal(data, &c); err != nil {
		return nil, err
	}
	return &c, nil
}

// GetThread handles GET /api/v1/echoes/:echoId/thread
func (h *Handler) GetThread(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse echo ID from URL
	echoIDStr := c.Param("echoId")
	focusEchoID, err := uuid.Parse(echoIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID",
			nil,
		))
		return
	}

	ctx := context.Background()

	// Get the focus echo
	focusEcho, err := h.repo.GetEchoByID(focusEchoID)
	if err != nil {
		log.Printf("Error retrieving focus echo: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to retrieve echo",
			nil,
		))
		return
	}

	if focusEcho == nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"ECHO_NOT_FOUND",
			"Echo not found",
			nil,
		))
		return
	}

	// Get ancestors (walk up the parent chain)
	ancestors := []models.Echo{}
	currentEchoID := focusEcho.ParentEchoID
	maxDepth := 10 // Prevent infinite loops
	depth := 0

	for currentEchoID != nil && depth < maxDepth {
		parentEcho, err := h.repo.GetEchoByID(*currentEchoID)
		if err != nil {
			log.Printf("Error retrieving parent echo %s: %v", currentEchoID, err)
			break
		}
		if parentEcho == nil {
			// Parent echo was deleted - add placeholder
			ancestors = append([]models.Echo{{
				ID:     *currentEchoID,
				UserID: uuid.Nil, // Placeholder
			}}, ancestors...)
			break
		}
		ancestors = append([]models.Echo{*parentEcho}, ancestors...)
		currentEchoID = parentEcho.ParentEchoID
		depth++
	}

	// Get direct replies (first page)
	limit := 20
	replies, err := h.repo.GetReplies(focusEchoID, nil, limit+1) // Fetch one extra to check if there are more
	if err != nil {
		log.Printf("Error retrieving replies: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to retrieve replies",
			nil,
		))
		return
	}

	// Check if there are more replies
	var nextCursor string
	if len(replies) > limit {
		// There are more replies
		lastReply := replies[limit-1]
		cursor := Cursor{
			Timestamp: lastReply.CreatedAt,
			EchoID:    lastReply.ID,
		}
		nextCursor = EncodeCursor(cursor)
		replies = replies[:limit] // Trim to limit
	}

	// Filter blocked/deleted echoes and enrich with context
	allEchoes := append(append(ancestors, *focusEcho), replies...)
	enrichedEchoes, err := h.enrichEchoesWithContext(ctx, userID, allEchoes)
	if err != nil {
		log.Printf("Error enriching echoes: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to enrich echo data",
			nil,
		))
		return
	}

	// Split enriched echoes back into ancestors, focus, and replies
	ancestorCount := len(ancestors)
	enrichedAncestors := enrichedEchoes[:ancestorCount]
	enrichedFocus := enrichedEchoes[ancestorCount]
	enrichedReplies := enrichedEchoes[ancestorCount+1:]

	response := ThreadResponse{
		Ancestors:  enrichedAncestors,
		Focus:      enrichedFocus,
		Replies:    enrichedReplies,
		NextCursor: nextCursor,
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		response,
		"Thread retrieved successfully",
	))
}

// GetReplies handles GET /api/v1/echoes/:echoId/replies
func (h *Handler) GetReplies(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse echo ID from URL
	echoIDStr := c.Param("echoId")
	echoID, err := uuid.Parse(echoIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID",
			nil,
		))
		return
	}

	// Parse query parameters
	cursorStr := c.Query("cursor")
	limitStr := c.DefaultQuery("limit", "20")
	limit, err := strconv.Atoi(limitStr)
	if err != nil || limit < 1 || limit > 100 {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_LIMIT",
			"Limit must be between 1 and 100",
			nil,
		))
		return
	}

	// Decode cursor if provided
	var cursor *Cursor
	if cursorStr != "" {
		cursor, err = DecodeCursor(cursorStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"INVALID_CURSOR",
				"Invalid cursor format",
				nil,
			))
			return
		}
	}

	ctx := context.Background()

	// Get replies
	replies, err := h.repo.GetReplies(echoID, cursor, limit+1) // Fetch one extra to check if there are more
	if err != nil {
		log.Printf("Error retrieving replies: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to retrieve replies",
			nil,
		))
		return
	}

	// Check if there are more replies
	var nextCursor string
	if len(replies) > limit {
		// There are more replies
		lastReply := replies[limit-1]
		nextCursor = EncodeCursor(Cursor{
			Timestamp: lastReply.CreatedAt,
			EchoID:    lastReply.ID,
		})
		replies = replies[:limit] // Trim to limit
	}

	// Enrich with context
	enrichedReplies, err := h.enrichEchoesWithContext(ctx, userID, replies)
	if err != nil {
		log.Printf("Error enriching replies: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to enrich reply data",
			nil,
		))
		return
	}

	response := RepliesResponse{
		Replies:    enrichedReplies,
		NextCursor: nextCursor,
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		response,
		"Replies retrieved successfully",
	))
}

// enrichEchoesWithContext enriches echoes with viewer context
func (h *Handler) enrichEchoesWithContext(ctx context.Context, viewerID uuid.UUID, echoes []models.Echo) ([]EchoWithContext, error) {
	if len(echoes) == 0 {
		return []EchoWithContext{}, nil
	}

	// Initialize Trust & Safety client
	tsClient := trustsafety.NewClient(h.config.Redis, getEnv("INTERACTION_SERVICE_URL", "http://localhost:8005"))

	// Collect all echo IDs and author IDs
	echoIDs := make([]uuid.UUID, 0, len(echoes))
	authorIDs := make([]uuid.UUID, 0, len(echoes))
	authorIDSet := make(map[uuid.UUID]bool)

	for _, echo := range echoes {
		echoIDs = append(echoIDs, echo.ID)
		if !authorIDSet[echo.UserID] && echo.UserID != uuid.Nil { // Skip placeholder echoes
			authorIDs = append(authorIDs, echo.UserID)
			authorIDSet[echo.UserID] = true
		}
	}

	// Batch fetch like status from Engagement Service
	likeStatus := make(map[uuid.UUID]bool)
	if h.config.EngagementClient != nil && len(echoIDs) > 0 {
		var err error
		likeStatus, err = h.config.EngagementClient.GetBatchLikeStatus(viewerID, echoIDs)
		if err != nil {
			log.Printf("Warning: Failed to fetch like status: %v", err)
			// Continue without like status
		}
	}

	// Batch fetch follow status from Interaction Service
	followStatus := make(map[uuid.UUID]bool)
	if h.config.InteractionClient != nil && len(authorIDs) > 0 {
		var err error
		followStatus, err = h.config.InteractionClient.GetBatchFollowStatus(viewerID, authorIDs)
		if err != nil {
			log.Printf("Warning: Failed to fetch follow status: %v", err)
			// Continue without follow status
		}
	}

	// Build enriched echoes and filter blocked users
	enrichedEchoes := make([]EchoWithContext, 0, len(echoes))
	for _, echo := range echoes {
		// Check if this is a deleted placeholder
		if echo.UserID == uuid.Nil {
			enrichedEchoes = append(enrichedEchoes, EchoWithContext{
				Echo: models.Echo{
					ID: echo.ID,
				},
				Status: "deleted",
				Author: AuthorInfo{
					UserID:             uuid.Nil,
					IsFollowedByViewer: false,
				},
			})
			continue
		}

		// Check if user is blocked
		isBlocked, err := tsClient.IsBlocked(ctx, viewerID, echo.UserID)
		if err != nil {
			log.Printf("Warning: Failed to check block status for user %s: %v", echo.UserID, err)
		}
		if isBlocked {
			// Return placeholder for blocked user
			enrichedEchoes = append(enrichedEchoes, EchoWithContext{
				Echo: models.Echo{
					ID: echo.ID,
				},
				Status: "blocked",
				Author: AuthorInfo{
					UserID:             uuid.Nil,
					IsFollowedByViewer: false,
				},
			})
			continue
		}

		// Hydrate media attachments
		if len(echo.MediaAttachments) > 0 && h.config.MediaClient != nil {
			hydratedAttachments, err := h.config.MediaClient.HydrateMediaAttachments(echo.MediaAttachments)
			if err != nil {
				log.Printf("Warning: Failed to hydrate media for echo %s: %v", echo.ID, err)
			} else {
				echo.MediaAttachments = hydratedAttachments
			}
		}

		enrichedEchoes = append(enrichedEchoes, EchoWithContext{
			Echo:               echo,
			IsLikedByViewer:    likeStatus[echo.ID],
			Author: AuthorInfo{
				UserID:             echo.UserID,
				IsFollowedByViewer: followStatus[echo.UserID],
			},
		})
	}

	return enrichedEchoes, nil
}
