#!/bin/bash

# Ka+ Billing Service Test Script
# This script tests the billing service endpoints

set -e

BASE_URL="http://localhost:8009"
JWT_TOKEN=""

echo "🧪 Ka+ Billing Service Test Script"
echo "===================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

# Test 1: Health Check
echo "Test 1: Health Check"
echo "---------------------"
HEALTH_RESPONSE=$(curl -s "$BASE_URL/health")
if echo "$HEALTH_RESPONSE" | grep -q "ok"; then
    print_success "Health check passed"
    echo "$HEALTH_RESPONSE" | jq '.'
else
    print_error "Health check failed"
    echo "$HEALTH_RESPONSE"
fi
echo ""

# Test 2: Get Entitlements (internal endpoint)
echo "Test 2: Get User Entitlements (Internal)"
echo "----------------------------------------"
TEST_USER_ID="550e8400-e29b-41d4-a716-446655440000"
print_info "Testing with user ID: $TEST_USER_ID"
ENTITLEMENTS_RESPONSE=$(curl -s "$BASE_URL/api/internal/billing/entitlements/$TEST_USER_ID")
echo "$ENTITLEMENTS_RESPONSE" | jq '.'
echo ""

# Test 3: Create Checkout Session (requires JWT)
echo "Test 3: Create Checkout Session"
echo "--------------------------------"
if [ -z "$JWT_TOKEN" ]; then
    print_info "Skipping (requires valid JWT token)"
    print_info "Set JWT_TOKEN environment variable to test:"
    print_info "export JWT_TOKEN=<your_jwt_token>"
else
    CHECKOUT_RESPONSE=$(curl -s -X POST "$BASE_URL/api/v1/billing/checkout" \
        -H "Authorization: Bearer $JWT_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "user_id": "550e8400-e29b-41d4-a716-446655440000",
            "success_url": "http://localhost:3000/success",
            "cancel_url": "http://localhost:3000/cancel"
        }')
    
    if echo "$CHECKOUT_RESPONSE" | grep -q "session_url"; then
        print_success "Checkout session created"
        echo "$CHECKOUT_RESPONSE" | jq '.'
    else
        print_error "Checkout session creation failed"
        echo "$CHECKOUT_RESPONSE" | jq '.'
    fi
fi
echo ""

# Test 4: Get Subscription (requires JWT)
echo "Test 4: Get User Subscription"
echo "------------------------------"
if [ -z "$JWT_TOKEN" ]; then
    print_info "Skipping (requires valid JWT token)"
    print_info "Set JWT_TOKEN environment variable to test"
else
    SUBSCRIPTION_RESPONSE=$(curl -s "$BASE_URL/api/v1/billing/subscription" \
        -H "Authorization: Bearer $JWT_TOKEN")
    echo "$SUBSCRIPTION_RESPONSE" | jq '.'
fi
echo ""

# Test 5: Webhook Endpoint (public)
echo "Test 5: Webhook Endpoint"
echo "------------------------"
print_info "Webhook endpoint is public but requires Stripe signature"
print_info "Use Stripe CLI to test webhooks:"
print_info "  stripe listen --forward-to localhost:8009/api/v1/billing/webhook"
print_info "  stripe trigger customer.subscription.created"
echo ""

echo "===================================="
echo "Test suite complete!"
echo ""
print_info "To fully test the billing service:"
echo "1. Set up Stripe test keys in environment"
echo "2. Login to get JWT token: export JWT_TOKEN=<token>"
echo "3. Run this script again: ./test_billing.sh"
echo "4. Use Stripe CLI to test webhooks"
echo ""
