# Getting Started with Ka Social Platform

Welcome to the Ka platform development! This guide will help you set up your development environment and get the platform running locally.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Project Structure](#project-structure)
3. [Quick Start](#quick-start)
4. [Detailed Setup](#detailed-setup)
5. [Development Workflow](#development-workflow)
6. [Testing](#testing)
7. [Troubleshooting](#troubleshooting)

## Prerequisites

Before you begin, ensure you have the following installed:

### Required

- **Go 1.21+**: [Download](https://golang.org/dl/)
- **Docker**: [Download](https://www.docker.com/get-started)
- **Docker Compose**: Usually included with Docker Desktop
- **Git**: [Download](https://git-scm.com/downloads)

### Optional (for mobile development)

- **Flutter 3.13+**: [Install Guide](https://flutter.dev/docs/get-started/install)
- **Android Studio** or **Xcode**: For mobile app testing

### Verify Installation

```bash
# Check Go
go version

# Check Docker
docker --version
docker-compose --version

# Check Flutter (optional)
flutter --version
```

## Project Structure

```
ka-social-platform/
├── backend/                    # Go microservices
│   ├── auth-service/          # ✅ Implemented
│   ├── user-service/          # 🚧 To be implemented
│   ├── content-service/       # 🚧 To be implemented
│   ├── feed-service/          # 🚧 To be implemented
│   ├── interaction-service/   # 🚧 To be implemented
│   ├── messaging-service/     # 🚧 To be implemented
│   ├── notification-service/  # 🚧 To be implemented
│   ├── discovery-service/     # 🚧 To be implemented
│   └── shared/                # ✅ Common utilities
├── frontend/                   # Flutter mobile app (to be implemented)
├── infrastructure/             # Docker & deployment configs
│   ├── docker/                # ✅ Docker Compose setup
│   ├── kubernetes/            # 🚧 K8s configs (future)
│   └── scripts/               # ✅ Helper scripts
├── docs/                       # ✅ Documentation
└── README.md                   # ✅ Project overview
```

## Quick Start

The fastest way to get started:

### 1. Clone the Repository

```bash
git clone https://github.com/mohamedaseleim/ka-social-platform.git
cd ka-social-platform
```

### 2. Start Infrastructure Services

```bash
cd infrastructure/docker
docker-compose up -d postgres redis scylla
```

### 3. Wait for Services to Be Ready

```bash
# This may take 1-2 minutes, especially for ScyllaDB
docker-compose ps

# Wait until all services show "healthy"
```

### 4. Initialize ScyllaDB

```bash
cd ../scripts
./init-scylla.sh
```

### 5. Start the Auth Service

Since auth service is implemented, you can start it:

```bash
# Option 1: Using Docker Compose (recommended)
cd ../docker
docker-compose up -d auth-service

# Option 2: Run locally (for development)
cd ../../backend/auth-service
go run *.go
```

### 6. Test the Auth Service

```bash
# Health check
curl http://localhost:8001/health

# Register a test user
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "TestPass123!",
    "display_name": "Test User"
  }'

# Login
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPass123!"
  }'
```

## Detailed Setup

### Step 1: Set Up the Backend

#### 1.1 Install Go Dependencies

```bash
cd backend/shared
go mod download

cd ../auth-service
go mod download
```

#### 1.2 Configure Environment Variables

Create a `.env` file in `infrastructure/docker/`:

```bash
# Database
DB_PASSWORD=your_secure_password
REDIS_PASSWORD=your_redis_password

# JWT
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRY=900
REFRESH_TOKEN_EXPIRY=604800
```

**Important:** Never commit the `.env` file to version control!

### Step 2: Understand the Services

#### Infrastructure Services

**PostgreSQL (Port 5432)**
- Primary relational database
- Stores: Users, relationships, settings, tokens
- Access: `psql -h localhost -U ka_user -d ka_db`

**Redis (Port 6379)**
- Caching layer
- Stores: Sessions, cached profiles, hot content
- Access: `redis-cli -h localhost -p 6379`

**ScyllaDB (Port 9042)**
- NoSQL database
- Stores: Posts, timelines, messages, notifications
- Access: `cqlsh localhost 9042`

#### Application Services

**Auth Service (Port 8001)** ✅
- User registration
- Login/logout
- JWT token management
- Password reset (to be implemented)

**Other Services (Ports 8002-8008)** 🚧
- To be implemented following the same pattern

### Step 3: Database Management

#### PostgreSQL

```bash
# Connect to PostgreSQL
docker-compose exec postgres psql -U ka_user -d ka_db

# Common operations
\dt                    # List tables
\d users               # Describe users table
SELECT * FROM users;   # Query users
```

#### ScyllaDB

```bash
# Connect to ScyllaDB
docker-compose exec scylla cqlsh

# Common operations
DESCRIBE KEYSPACES;           # List keyspaces
USE ka_content;               # Switch keyspace
DESCRIBE TABLES;              # List tables
SELECT * FROM echoes LIMIT 5; # Query echoes
```

#### Redis

```bash
# Connect to Redis
docker-compose exec redis redis-cli -a ka_redis_password

# Common operations
KEYS *                        # List all keys
GET user:profile:uuid         # Get a value
FLUSHALL                      # Clear all data (careful!)
```

## Development Workflow

### Running a Service Locally

For active development, run services locally instead of in Docker:

```bash
# Terminal 1: Infrastructure services
cd infrastructure/docker
docker-compose up postgres redis scylla

# Terminal 2: Auth service
cd backend/auth-service
go run *.go

# Terminal 3: Test requests
curl http://localhost:8001/health
```

### Making Changes

1. Edit code in your IDE
2. Service will need to be restarted (Go doesn't have hot reload by default)
3. Test your changes
4. Commit and push

### Adding a New Service

Follow this pattern (using user-service as an example):

```bash
# 1. Create service directory
mkdir backend/user-service
cd backend/user-service

# 2. Initialize Go module
go mod init github.com/mohamedaseleim/ka-social-platform/backend/user-service

# 3. Add shared module dependency
go mod edit -replace github.com/mohamedaseleim/ka-social-platform/backend/shared=../shared
go get github.com/mohamedaseleim/ka-social-platform/backend/shared

# 4. Create main files (following auth-service pattern)
touch main.go config.go repository.go handler.go routes.go Dockerfile

# 5. Implement the service following existing patterns

# 6. Add to docker-compose.yml
# (Copy auth-service section and modify ports/names)

# 7. Test locally
go run *.go

# 8. Test with Docker
docker-compose build user-service
docker-compose up user-service
```

## Testing

### Unit Tests

```bash
# Test shared utilities
cd backend/shared
go test -v ./...

# Test a specific service
cd backend/auth-service
go test -v ./...
```

### Integration Tests

```bash
# Start infrastructure
cd infrastructure/docker
docker-compose up -d postgres redis scylla

# Run integration tests (to be implemented)
cd backend/auth-service
go test -v -tags=integration ./...
```

### Manual API Testing

Use curl, Postman, or any HTTP client:

```bash
# Example: Full auth flow
# 1. Register
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"TestPass123!"}'

# 2. Login (save the tokens)
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"TestPass123!"}'

# 3. Use access token for protected endpoints
TOKEN="your_access_token_here"
curl -X POST http://localhost:8001/api/auth/logout \
  -H "Authorization: Bearer $TOKEN"
```

## Troubleshooting

### Common Issues

#### 1. "Connection refused" when starting services

**Problem:** Infrastructure services aren't ready yet.

**Solution:**
```bash
# Check service health
docker-compose ps

# Wait for all services to be "healthy"
# ScyllaDB can take 2-3 minutes on first start
```

#### 2. ScyllaDB initialization fails

**Problem:** ScyllaDB wasn't fully ready when init script ran.

**Solution:**
```bash
# Check ScyllaDB status
docker-compose exec scylla nodetool status

# Wait a bit more, then re-run init script
cd infrastructure/scripts
./init-scylla.sh
```

#### 3. "Go module not found" errors

**Problem:** Module dependencies not properly set up.

**Solution:**
```bash
# Re-download dependencies
cd backend/auth-service
go mod download
go mod tidy
```

#### 4. Docker out of resources

**Problem:** Docker doesn't have enough memory/CPU.

**Solution:**
- Open Docker Desktop → Settings → Resources
- Increase Memory to at least 4GB
- Increase CPUs to at least 2
- Restart Docker

#### 5. Port already in use

**Problem:** Another service is using the same port.

**Solution:**
```bash
# Find what's using the port (example for 8001)
lsof -i :8001

# Kill the process or change the port in docker-compose.yml
```

### Getting Help

If you encounter issues:

1. Check the service logs:
   ```bash
   docker-compose logs -f service-name
   ```

2. Check the documentation:
   - [Architecture](docs/ARCHITECTURE.md)
   - [API Specification](docs/API_SPEC.md)
   - [Roadmap](docs/ROADMAP.md)

3. Open an issue on GitHub with:
   - Error message
   - Steps to reproduce
   - Your environment (OS, Docker version, Go version)

## Next Steps

Now that you have the basic setup running:

1. **Explore the Code**: Look at auth-service implementation
2. **Read the Docs**: Review ARCHITECTURE.md and API_SPEC.md
3. **Implement a Service**: Try creating user-service following the pattern
4. **Add Tests**: Write unit and integration tests
5. **Contribute**: See CONTRIBUTING.md for guidelines

## Useful Commands

```bash
# View all running containers
docker-compose ps

# View logs
docker-compose logs -f [service-name]

# Restart a service
docker-compose restart [service-name]

# Rebuild a service
docker-compose build [service-name]

# Stop all services
docker-compose down

# Stop and remove volumes (clean slate)
docker-compose down -v

# Run a command in a container
docker-compose exec [service-name] [command]

# Access PostgreSQL
docker-compose exec postgres psql -U ka_user -d ka_db

# Access ScyllaDB
docker-compose exec scylla cqlsh

# Access Redis
docker-compose exec redis redis-cli -a ka_redis_password
```

## Resources

- [Go Documentation](https://golang.org/doc/)
- [Gin Web Framework](https://gin-gonic.com/docs/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [ScyllaDB Documentation](https://docs.scylladb.com/)
- [Redis Documentation](https://redis.io/documentation)
- [Docker Documentation](https://docs.docker.com/)
- [Flutter Documentation](https://flutter.dev/docs)

---

**Ready to build the next generation of social platforms? Let's go! 🚀**
