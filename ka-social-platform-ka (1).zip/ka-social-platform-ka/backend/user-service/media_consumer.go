package main

import (
	"encoding/json"
	"log"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
)

// MediaProcessedEvent represents a completed media processing event
type MediaProcessedEvent struct {
	ObjectKey   string `json:"object_key"`
	UserID      string `json:"user_id"`
	OriginalURL string `json:"original_url"`
	MediumURL   string `json:"medium_url"`
	ThumbURL    string `json:"thumb_url"`
	ProcessedAt int64  `json:"processed_at"`
}

// MediaConsumer handles media.processed events
type MediaConsumer struct {
	natsConn *nats.Conn
	repo     *Repository
}

// NewMediaConsumer creates a new media consumer
func NewMediaConsumer(natsConn *nats.Conn, repo *Repository) *MediaConsumer {
	return &MediaConsumer{
		natsConn: natsConn,
		repo:     repo,
	}
}

// Start begins consuming media.processed events
func (c *MediaConsumer) Start() error {
	_, err := c.natsConn.Subscribe("media.processed", func(msg *nats.Msg) {
		var event MediaProcessedEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("Failed to unmarshal media.processed event: %v", err)
			return
		}

		log.Printf("Received media.processed event for user: %s", event.UserID)

		// Parse user ID
		userID, err := uuid.Parse(event.UserID)
		if err != nil {
			log.Printf("Invalid user ID in media.processed event: %v", err)
			return
		}

		// Update user profile with processed image URLs
		if err := c.repo.UpdateUserAvatar(userID, event.OriginalURL, event.MediumURL, event.ThumbURL); err != nil {
			log.Printf("Failed to update user avatar URLs: %v", err)
			return
		}

		log.Printf("Successfully updated avatar URLs for user: %s", event.UserID)
	})

	if err != nil {
		return err
	}

	log.Println("Media consumer started, listening for media.processed events")
	return nil
}
