# Ka Mobile App - Flutter

The mobile application for Ka social platform, built with Flutter for iOS and Android.

## Features

### Core Features (Phase 1 MVP)

- **Unified Feed with Filter Lenses**
  - 🎯 For You: Personalized feed
  - 👤 Inner Circle: Friends and family
  - 🌐 The World: Trending and public content

- **Two Content Types**
  - 🔊 Echoes: Quick thoughts and updates (like tweets)
  - 📖 Stories: Long-form content with photo albums (like Facebook posts)

- **User Profiles (Digital Ka)**
  - Dynamic cover story (video or photo slideshow)
  - Profile with online "pulse" effect
  - Top Echo showcase
  - Separate tabs for Echoes and Stories

- **Secure Messaging**
  - End-to-End Encryption (E2EE)
  - Smart inbox (Inner Circle vs. Message Requests)
  - Voice notes with "raise to listen"
  - Rich media sharing

- **Discovery**
  - Regional trending topics
  - Global trends
  - User recommendations
  - Content search

- **Interactions**
  - Likes, comments, shares
  - Bookmarks
  - Real-time notifications

### Technical Features

- **RTL Support**: Full support for Arabic and other RTL languages
- **Offline Mode**: Cache recent content for offline viewing
- **Low Bandwidth Optimization**: Optimized for 2G/3G networks
- **Adaptive UI**: Works on various screen sizes and devices
- **Dark Mode**: System-aware dark mode (Phase 1.1)

## Project Structure

```
ka_app/
├── lib/
│   ├── main.dart              # App entry point
│   ├── config/                # App configuration
│   │   ├── routes.dart        # Route definitions
│   │   ├── theme.dart         # App theme
│   │   └── constants.dart     # Constants
│   ├── models/                # Data models
│   │   ├── user.dart
│   │   ├── echo.dart
│   │   ├── story.dart
│   │   └── ...
│   ├── services/              # API and business logic
│   │   ├── api/
│   │   │   ├── auth_service.dart
│   │   │   ├── user_service.dart
│   │   │   ├── content_service.dart
│   │   │   └── ...
│   │   ├── storage/
│   │   │   └── secure_storage.dart
│   │   └── messaging/
│   │       └── encryption_service.dart
│   ├── providers/             # State management (Provider/BLoC)
│   │   ├── auth_provider.dart
│   │   ├── user_provider.dart
│   │   ├── feed_provider.dart
│   │   └── ...
│   ├── screens/               # UI screens
│   │   ├── auth/
│   │   │   ├── login_screen.dart
│   │   │   └── register_screen.dart
│   │   ├── home/
│   │   │   ├── home_screen.dart
│   │   │   └── feed_widget.dart
│   │   ├── profile/
│   │   │   ├── profile_screen.dart
│   │   │   └── edit_profile_screen.dart
│   │   ├── create/
│   │   │   ├── create_intent_screen.dart
│   │   │   ├── create_echo_screen.dart
│   │   │   └── create_story_screen.dart
│   │   ├── discover/
│   │   │   └── discover_screen.dart
│   │   ├── messages/
│   │   │   ├── inbox_screen.dart
│   │   │   └── conversation_screen.dart
│   │   └── notifications/
│   │       └── notifications_screen.dart
│   ├── widgets/               # Reusable widgets
│   │   ├── common/
│   │   │   ├── ka_button.dart
│   │   │   ├── ka_text_field.dart
│   │   │   └── loading_indicator.dart
│   │   ├── feed/
│   │   │   ├── echo_card.dart
│   │   │   ├── story_card.dart
│   │   │   └── filter_lens_bar.dart
│   │   └── profile/
│   │       ├── cover_story_widget.dart
│   │       └── top_echo_widget.dart
│   └── utils/                 # Utility functions
│       ├── validators.dart
│       ├── formatters.dart
│       └── helpers.dart
├── assets/                    # Images, fonts, etc.
│   ├── images/
│   ├── icons/
│   └── fonts/
├── test/                      # Unit and widget tests
├── integration_test/          # Integration tests
├── pubspec.yaml               # Dependencies
└── README.md
```

## Prerequisites

- Flutter SDK 3.13 or higher
- Dart SDK 3.0 or higher
- Android Studio (for Android development)
- Xcode (for iOS development, macOS only)
- VS Code or Android Studio with Flutter plugins

## Installation

### 1. Install Flutter

Follow the official Flutter installation guide for your OS:
- [Windows](https://flutter.dev/docs/get-started/install/windows)
- [macOS](https://flutter.dev/docs/get-started/install/macos)
- [Linux](https://flutter.dev/docs/get-started/install/linux)

### 2. Verify Installation

```bash
flutter doctor
```

Fix any issues reported by `flutter doctor`.

### 3. Clone and Setup

```bash
cd ka-social-platform/frontend/ka_app

# Get dependencies
flutter pub get

# Run code generation (if using freezed, json_serializable)
flutter pub run build_runner build --delete-conflicting-outputs
```

## Running the App

### Development Mode

```bash
# Run on connected device/emulator
flutter run

# Run with specific device
flutter devices
flutter run -d <device-id>

# Run with hot reload enabled (default)
flutter run --hot
```

### Build for Production

#### Android

```bash
# Build APK
flutter build apk --release

# Build App Bundle (for Play Store)
flutter build appbundle --release
```

#### iOS

```bash
# Build IPA
flutter build ios --release

# Or build with Xcode
open ios/Runner.xcworkspace
```

## Configuration

### API Base URL

Edit `lib/config/constants.dart`:

```dart
class ApiConstants {
  // Development
  static const String baseUrl = 'http://localhost:8001';
  
  // Production
  // static const String baseUrl = 'https://api.ka.social';
}
```

### App Environment

You can create different environment configurations:

```bash
# Development
flutter run --dart-define=ENV=dev

# Staging
flutter run --dart-define=ENV=staging

# Production
flutter run --dart-define=ENV=prod
```

## State Management

The app uses **Provider** for state management (can be switched to BLoC or Riverpod).

Example:

```dart
// providers/auth_provider.dart
class AuthProvider extends ChangeNotifier {
  User? _user;
  bool _isLoading = false;
  
  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _user != null;
  
  Future<void> login(String email, String password) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final response = await AuthService.login(email, password);
      _user = response.user;
      await SecureStorage.saveTokens(
        response.accessToken,
        response.refreshToken,
      );
    } catch (e) {
      // Handle error
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
```

## Testing

### Unit Tests

```bash
# Run all tests
flutter test

# Run specific test file
flutter test test/models/user_test.dart

# Run with coverage
flutter test --coverage
```

### Widget Tests

```dart
testWidgets('Echo card displays user information', (WidgetTester tester) async {
  final echo = Echo(id: '1', content: 'Test echo', ...);
  
  await tester.pumpWidget(
    MaterialApp(home: EchoCard(echo: echo)),
  );
  
  expect(find.text('Test echo'), findsOneWidget);
});
```

### Integration Tests

```bash
# Run integration tests
flutter drive --driver=test_driver/integration_test.dart \
  --target=integration_test/app_test.dart
```

## Key Dependencies

Add these to `pubspec.yaml`:

```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # State Management
  provider: ^6.0.0
  
  # Networking
  http: ^1.0.0
  dio: ^5.0.0
  
  # JSON Serialization
  json_annotation: ^4.8.0
  
  # Secure Storage
  flutter_secure_storage: ^9.0.0
  
  # Local Database
  sqflite: ^2.3.0
  
  # UI Components
  cached_network_image: ^3.3.0
  image_picker: ^1.0.0
  video_player: ^2.8.0
  
  # Internationalization
  flutter_localizations:
    sdk: flutter
  intl: ^0.18.0
  
  # Encryption (for E2EE messaging)
  encrypt: ^5.0.0
  
  # Push Notifications
  firebase_messaging: ^14.0.0
  
  # Real-time Communication
  web_socket_channel: ^2.4.0
  
  # Utilities
  uuid: ^4.0.0
  timeago: ^3.6.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0
  build_runner: ^2.4.0
  json_serializable: ^6.7.0
```

## RTL Support

The app supports RTL languages out of the box:

```dart
MaterialApp(
  supportedLocales: [
    const Locale('en', 'US'),
    const Locale('ar', 'EG'),
    const Locale('fr', 'FR'),
  ],
  localizationsDelegates: [
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ],
  // ...
)
```

## Performance Optimization

### Image Caching

```dart
CachedNetworkImage(
  imageUrl: user.profilePictureUrl,
  placeholder: (context, url) => CircularProgressIndicator(),
  errorWidget: (context, url, error) => Icon(Icons.error),
  cacheManager: CustomCacheManager(), // Optimized for low bandwidth
)
```

### Lazy Loading

```dart
ListView.builder(
  itemCount: posts.length,
  itemBuilder: (context, index) {
    if (index >= posts.length - 5) {
      // Load more when near the end
      _loadMorePosts();
    }
    return PostCard(post: posts[index]);
  },
)
```

### Offline Support

```dart
// Cache posts locally
await DatabaseService.cachePosts(posts);

// Load from cache when offline
final cachedPosts = await DatabaseService.getCachedPosts();
```

## Troubleshooting

### Common Issues

#### 1. Flutter not found

```bash
# Add Flutter to PATH
export PATH="$PATH:`pwd`/flutter/bin"
```

#### 2. Android license not accepted

```bash
flutter doctor --android-licenses
```

#### 3. iOS CocoaPods issues

```bash
cd ios
pod deintegrate
pod install
cd ..
flutter run
```

#### 4. Build errors after dependency update

```bash
flutter clean
flutter pub get
flutter run
```

## CI/CD

GitHub Actions workflow example:

```yaml
name: Flutter CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.13.0'
      - run: flutter pub get
      - run: flutter test
      - run: flutter build apk
```

## Contributing

See [../docs/CONTRIBUTING.md](../docs/CONTRIBUTING.md) for guidelines.

## Resources

- [Flutter Documentation](https://flutter.dev/docs)
- [Dart Documentation](https://dart.dev/guides)
- [Material Design](https://material.io/design)
- [Provider Package](https://pub.dev/packages/provider)
- [Dio Package](https://pub.dev/packages/dio)

## Next Steps

1. **Initialize Flutter Project**
   ```bash
   flutter create --org social.ka ka_app
   ```

2. **Set Up Project Structure**
   - Create directories as shown above
   - Add dependencies to pubspec.yaml

3. **Implement Authentication Flow**
   - Login screen
   - Register screen
   - Token management

4. **Build Core Screens**
   - Home screen with feed
   - Profile screen
   - Create post screen

5. **Add State Management**
   - Set up providers
   - Connect to backend APIs

6. **Implement Real-time Features**
   - WebSocket connection
   - Push notifications

7. **Add Tests**
   - Unit tests for models and services
   - Widget tests for UI components
   - Integration tests for user flows

---

**Ready to build an amazing mobile experience? Let's create Ka! 📱**
