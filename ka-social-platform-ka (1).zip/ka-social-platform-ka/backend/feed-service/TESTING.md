# Feed Service Testing Guide

This document describes how to test the Feed Service implementation.

## Prerequisites

1. All infrastructure services must be running (PostgreSQL, Redis, ScyllaDB, NATS)
2. Content Service must be running (publishes events)
3. Interaction Service must be running (provides followers list)
4. Feed Service must be running (consumes events and serves feed)

## Architecture Flow

```
1. User A creates an echo
   ↓
2. Content Service saves echo and publishes echo.created to NATS
   ↓
3. Feed Service consumes echo.created event
   ↓
4. Feed Service calls Interaction Service to get User A's followers
   ↓
5. Feed Service adds echo_id to each follower's Redis timeline
   ↓
6. User B (follower of User A) requests home feed
   ↓
7. Feed Service gets echo IDs from Redis
   ↓
8. Feed Service checks cache for echo details
   ↓
9. Feed Service calls Content Service batch endpoint for uncached echoes
   ↓
10. Feed Service caches and returns hydrated echoes
```

## Manual Testing Steps

### Setup

1. Start infrastructure:
```bash
cd infrastructure/docker
docker-compose up -d postgres redis scylla nats
```

2. Start services:
```bash
# Terminal 1 - Content Service
cd backend/content-service
go run .

# Terminal 2 - Interaction Service
cd backend/interaction-service
go run .

# Terminal 3 - Feed Service
cd backend/feed-service
go run .
```

### Test Case 1: Follow a User

1. Create User A (via Auth Service)
2. Create User B (via Auth Service)
3. User B follows User A:
```bash
curl -X POST http://localhost:8005/api/users/{userA_id}/follow \
  -H "Authorization: Bearer {userB_token}"
```

Expected: Follow relationship created in PostgreSQL

### Test Case 2: Create Echo and Verify Fan-Out

1. User A creates an echo:
```bash
curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Authorization: Bearer {userA_token}" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Hello from User A!",
    "visibility": "public"
  }'
```

Expected output:
- Content Service returns created echo
- Content Service publishes echo.created to NATS
- Feed Service logs: "Fan-out complete for echo {id}: added to X follower timelines"

2. Verify Redis timeline:
```bash
# Connect to Redis
docker exec -it ka-redis redis-cli -a ka_redis_password

# Check User B's timeline
ZREVRANGE timeline:home:{userB_id} 0 -1
```

Expected: Echo ID appears in User B's timeline

### Test Case 3: Get Home Feed

1. User B requests home feed:
```bash
curl http://localhost:8004/api/v1/feed/home \
  -H "Authorization: Bearer {userB_token}"
```

Expected output:
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "echo_id",
        "user_id": "userA_id",
        "content": "Hello from User A!",
        "visibility": "public",
        "created_at": "2024-01-01T00:00:00Z",
        ...
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 1,
      "total_pages": 1
    }
  }
}
```

### Test Case 4: Verify Caching

1. Request the same feed again:
```bash
curl http://localhost:8004/api/v1/feed/home \
  -H "Authorization: Bearer {userB_token}"
```

Expected:
- Response time < 50ms (cached)
- Feed Service logs: "Cache hit for echo {id}"

2. Check Redis cache:
```bash
# Connect to Redis
docker exec -it ka-redis redis-cli -a ka_redis_password

# Check cached echo
GET echo:details:{echo_id}
```

Expected: JSON representation of the echo

### Test Case 5: Delete Echo and Verify Removal

1. User A deletes the echo:
```bash
curl -X DELETE http://localhost:8003/api/v1/echoes/{echo_id} \
  -H "Authorization: Bearer {userA_token}"
```

Expected:
- Content Service publishes echo.deleted to NATS
- Feed Service logs: "Fan-out delete complete for echo {id}: removed from X follower timelines"

2. Verify removal from Redis:
```bash
# Connect to Redis
docker exec -it ka-redis redis-cli -a ka_redis_password

# Check User B's timeline
ZREVRANGE timeline:home:{userB_id} 0 -1
```

Expected: Echo ID is removed from timeline

3. User B requests home feed:
```bash
curl http://localhost:8004/api/v1/feed/home \
  -H "Authorization: Bearer {userB_token}"
```

Expected: Empty feed or feed without the deleted echo

### Test Case 6: Batch Endpoint Performance

1. Create multiple echoes (10-20)
2. Measure feed request time:
```bash
time curl http://localhost:8004/api/v1/feed/home \
  -H "Authorization: Bearer {userB_token}"
```

Expected: Response time < 100ms

## Performance Benchmarks

| Operation | Target | Expected |
|-----------|--------|----------|
| Echo creation | < 50ms | Event published |
| Fan-out processing | < 100ms per follower | Timeline updated |
| Home feed (cold cache) | < 100ms | Batch fetch from Content Service |
| Home feed (warm cache) | < 20ms | Served from Redis cache |
| Timeline size limit | 1000 items | Oldest items trimmed |

## Monitoring

### NATS Monitoring
```bash
curl http://localhost:8222/varz
```

Check:
- Message count
- Subscription count
- Error rate

### Redis Monitoring
```bash
docker exec -it ka-redis redis-cli -a ka_redis_password INFO stats
```

Check:
- Total commands processed
- Keyspace hits/misses
- Memory usage

## Common Issues

### Issue: Feed Service not receiving events
**Solution**: Check NATS connection and subscription logs

### Issue: Timeline empty after echo creation
**Solution**: Verify follow relationship exists in PostgreSQL

### Issue: Slow feed response
**Solution**: Check cache hit rate and Content Service performance

### Issue: Echoes missing from feed
**Solution**: Verify echo still exists in ScyllaDB (not deleted)

## Cleanup

```bash
# Clear Redis timelines
docker exec -it ka-redis redis-cli -a ka_redis_password FLUSHDB

# Reset test data
docker-compose down -v
```
