package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"github.com/meilisearch/meilisearch-go"
)

func main() {
	// Load configuration
	config := LoadConfig()

	// Initialize Redis client
	redisClient := redis.NewClient(&redis.Options{
		Addr:     fmt.Sprintf("%s:%s", config.RedisHost, config.RedisPort),
		Password: config.RedisPassword,
		DB:       0,
	})

	ctx := context.Background()
	if err := redisClient.Ping(ctx).Err(); err != nil {
		log.Fatalf("Failed to connect to Redis: %v", err)
	}
	log.Println("Successfully connected to Redis")

	// Initialize Meilisearch client
	meiliClient := meilisearch.NewClient(meilisearch.ClientConfig{
		Host:   config.MeilisearchHost,
		APIKey: config.MeilisearchAPIKey,
	})
	log.Println("Meilisearch client initialized")

	// Initialize search indexes
	searchService := NewSearchService(meiliClient)
	if err := searchService.InitializeIndexes(); err != nil {
		log.Printf("Warning: Failed to initialize search indexes: %v", err)
	}

	// Initialize trending service
	trendingService := NewTrendingService(redisClient)

	// Initialize NATS consumer
	consumer, err := NewNATSConsumer(config.NATSUrl, searchService, trendingService)
	if err != nil {
		log.Fatalf("Failed to create NATS consumer: %v", err)
	}
	defer consumer.Close()

	// Start consuming events
	if err := consumer.Start(); err != nil {
		log.Fatalf("Failed to start NATS consumer: %v", err)
	}

	// Initialize Trust & Safety consumer
	// Note: We need to convert redis/v8 to redis/v9 client for trustsafety package
	// For now, we'll skip this and log a warning
	log.Println("Warning: Discovery Service Trust & Safety integration requires Redis v9 client migration")
	// TODO: Migrate to github.com/redis/go-redis/v9 and enable Trust & Safety

	// Initialize handler
	handler := NewHandler(searchService, trendingService, config)

	// Setup router
	router := gin.Default()
	SetupRoutes(router, handler, config)

	// Start HTTP server
	srv := &http.Server{
		Addr:    ":" + config.Port,
		Handler: router,
	}

	// Graceful shutdown
	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Failed to start server: %v", err)
		}
	}()

	log.Printf("Discovery Service started on port %s", config.Port)

	// Wait for interrupt signal
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("Shutting down server...")

	// Graceful shutdown with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		log.Fatal("Server forced to shutdown:", err)
	}

	log.Println("Server exited")
}
