package main

import (
	"github.com/nats-io/nats.go"
	"github.com/redis/go-redis/v9"
)

// Config holds the configuration for the media service
type Config struct {
	Port               string
	MinIOEndpoint      string
	MinIOAccessKey     string
	MinIOSecretKey     string
	MinIOBucket        string
	MinIOUseSSL        bool
	CDNHost            string
	NATSUrl            string
	NATSConn           *nats.Conn
	Redis              *redis.Client
	JWTSecret          string
	PresignedURLExpiry int // in seconds
}
