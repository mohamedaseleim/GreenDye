package main

import (
	"context"
	"fmt"
	"net/url"
	"time"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

// StorageService handles MinIO operations
type StorageService struct {
	client             *minio.Client
	bucket             string
	cdnHost            string
	presignedURLExpiry time.Duration
}

// NewStorageService creates a new storage service
func NewStorageService(config *Config) (*StorageService, error) {
	// Initialize MinIO client
	minioClient, err := minio.New(config.MinIOEndpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.MinIOAccessKey, config.MinIOSecretKey, ""),
		Secure: config.MinIOUseSSL,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create MinIO client: %w", err)
	}

	// Ensure bucket exists
	ctx := context.Background()
	exists, err := minioClient.BucketExists(ctx, config.MinIOBucket)
	if err != nil {
		return nil, fmt.Errorf("failed to check bucket existence: %w", err)
	}
	if !exists {
		err = minioClient.MakeBucket(ctx, config.MinIOBucket, minio.MakeBucketOptions{})
		if err != nil {
			return nil, fmt.Errorf("failed to create bucket: %w", err)
		}
	}

	return &StorageService{
		client:             minioClient,
		bucket:             config.MinIOBucket,
		cdnHost:            config.CDNHost,
		presignedURLExpiry: time.Duration(config.PresignedURLExpiry) * time.Second,
	}, nil
}

// GeneratePresignedUploadURL generates a presigned URL for direct upload to MinIO
func (s *StorageService) GeneratePresignedUploadURL(objectKey string, contentType string) (string, error) {
	ctx := context.Background()

	// Set request parameters for presigned URL
	reqParams := make(url.Values)
	if contentType != "" {
		reqParams.Set("response-content-type", contentType)
	}

	// Generate presigned PUT URL
	presignedURL, err := s.client.PresignedPutObject(ctx, s.bucket, objectKey, s.presignedURLExpiry)
	if err != nil {
		return "", fmt.Errorf("failed to generate presigned URL: %w", err)
	}

	return presignedURL.String(), nil
}

// GetObjectURL returns the CDN URL for an object
func (s *StorageService) GetObjectURL(objectKey string) string {
	if s.cdnHost != "" {
		return fmt.Sprintf("%s/%s/%s", s.cdnHost, s.bucket, objectKey)
	}
	// Fallback to MinIO direct URL
	return fmt.Sprintf("https://%s/%s/%s", s.client.EndpointURL().Host, s.bucket, objectKey)
}

// GetObject retrieves an object from storage
func (s *StorageService) GetObject(objectKey string) (*minio.Object, error) {
	ctx := context.Background()
	object, err := s.client.GetObject(ctx, s.bucket, objectKey, minio.GetObjectOptions{})
	if err != nil {
		return nil, fmt.Errorf("failed to get object: %w", err)
	}
	return object, nil
}

// PutObject uploads an object to storage
func (s *StorageService) PutObject(objectKey string, data []byte, contentType string) error {
	ctx := context.Background()
	reader := &bytesReader{data: data}
	_, err := s.client.PutObject(ctx, s.bucket, objectKey, reader, int64(len(data)), minio.PutObjectOptions{
		ContentType: contentType,
	})
	if err != nil {
		return fmt.Errorf("failed to put object: %w", err)
	}
	return nil
}

// ObjectExists checks if an object exists in storage
func (s *StorageService) ObjectExists(objectKey string) (bool, error) {
	ctx := context.Background()
	_, err := s.client.StatObject(ctx, s.bucket, objectKey, minio.StatObjectOptions{})
	if err != nil {
		errResponse := minio.ToErrorResponse(err)
		if errResponse.Code == "NoSuchKey" {
			return false, nil
		}
		return false, fmt.Errorf("failed to check object existence: %w", err)
	}
	return true, nil
}

// ValidateMediaOwnership checks if a media key belongs to a specific user
func (s *StorageService) ValidateMediaOwnership(mediaKey string, userID string) (bool, error) {
	// Media keys are structured as: uploads/{user_id}/{uuid}.{ext}
	// or processed/{thumb|medium}_{uuid}.webp
	// We need to check if the key starts with the user's prefix or is derived from their upload
	
	expectedPrefix := fmt.Sprintf("uploads/%s/", userID)
	if len(mediaKey) >= len(expectedPrefix) && mediaKey[:len(expectedPrefix)] == expectedPrefix {
		return true, nil
	}
	
	// Also check if it's a processed image (processed/thumb_* or processed/medium_*)
	// These are derived from user uploads, we'll be more lenient here
	if len(mediaKey) > 10 && (mediaKey[:10] == "processed/" || mediaKey[:9] == "uploads/") {
		// Check if the object exists
		exists, err := s.ObjectExists(mediaKey)
		if err != nil {
			return false, err
		}
		return exists, nil
	}
	
	return false, nil
}

// bytesReader wraps []byte to implement io.Reader
type bytesReader struct {
	data   []byte
	offset int
}

func (r *bytesReader) Read(p []byte) (n int, err error) {
	if r.offset >= len(r.data) {
		return 0, nil
	}
	n = copy(p, r.data[r.offset:])
	r.offset += n
	return n, nil
}
