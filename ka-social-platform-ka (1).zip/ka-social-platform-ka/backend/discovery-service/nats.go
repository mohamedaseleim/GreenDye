package main

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
)

// NATSConsumer handles consuming events from NATS
type NATSConsumer struct {
	conn            *nats.Conn
	searchService   *SearchService
	trendingService *TrendingService
}

// Event structures for different event types
type UserCreatedEvent struct {
	UserID            string  `json:"user_id"`
	Username          string  `json:"username"`
	DisplayName       *string `json:"display_name"`
	Bio               *string `json:"bio"`
	ProfilePictureURL *string `json:"profile_picture_url"`
	IsVerified        bool    `json:"is_verified"`
	Timestamp         string  `json:"timestamp"`
}

type UserUpdatedEvent struct {
	UserID            string  `json:"user_id"`
	Username          string  `json:"username"`
	DisplayName       *string `json:"display_name"`
	Bio               *string `json:"bio"`
	ProfilePictureURL *string `json:"profile_picture_url"`
	IsVerified        bool    `json:"is_verified"`
	FollowerCount     int     `json:"follower_count"`
	Timestamp         string  `json:"timestamp"`
}

type EchoCreatedEvent struct {
	EchoID       string   `json:"echo_id"`
	UserID       string   `json:"user_id"`
	Content      string   `json:"content"`
	Hashtags     []string `json:"hashtags"`
	LikesCount   int      `json:"likes_count"`
	Visibility   string   `json:"visibility"`
	Timestamp    string   `json:"timestamp"`
	ParentEchoID *string  `json:"parent_echo_id,omitempty"`
}

type EchoUpdatedEvent struct {
	EchoID     string `json:"echo_id"`
	LikesCount int    `json:"likes_count"`
	Timestamp  string `json:"timestamp"`
}

type EchoDeletedEvent struct {
	EchoID    string `json:"echo_id"`
	UserID    string `json:"user_id"`
	Timestamp string `json:"timestamp"`
}

// NewNATSConsumer creates a new NATS consumer
func NewNATSConsumer(natsURL string, searchService *SearchService, trendingService *TrendingService) (*NATSConsumer, error) {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to NATS: %w", err)
	}

	log.Printf("Successfully connected to NATS at %s", natsURL)
	return &NATSConsumer{
		conn:            nc,
		searchService:   searchService,
		trendingService: trendingService,
	}, nil
}

// Start begins consuming events from NATS
func (nc *NATSConsumer) Start() error {
	// Subscribe to user.created events
	_, err := nc.conn.Subscribe("user.created", func(msg *nats.Msg) {
		nc.handleUserCreated(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.created: %w", err)
	}

	// Subscribe to user.updated events
	_, err = nc.conn.Subscribe("user.updated", func(msg *nats.Msg) {
		nc.handleUserUpdated(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.updated: %w", err)
	}

	// Subscribe to echo.created events
	_, err = nc.conn.Subscribe("echo.created", func(msg *nats.Msg) {
		nc.handleEchoCreated(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to echo.created: %w", err)
	}

	// Subscribe to echo.updated events
	_, err = nc.conn.Subscribe("echo.updated", func(msg *nats.Msg) {
		nc.handleEchoUpdated(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to echo.updated: %w", err)
	}

	// Subscribe to echo.deleted events
	_, err = nc.conn.Subscribe("echo.deleted", func(msg *nats.Msg) {
		nc.handleEchoDeleted(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to echo.deleted: %w", err)
	}

	log.Println("NATS consumer started, subscribed to user and echo events")
	return nil
}

// handleUserCreated processes user.created events
func (nc *NATSConsumer) handleUserCreated(data []byte) {
	var event UserCreatedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling user.created event: %v", err)
		return
	}

	timestamp, err := time.Parse(time.RFC3339, event.Timestamp)
	if err != nil {
		timestamp = time.Now()
	}

	userDoc := UserDocument{
		ID:          event.UserID,
		Username:    event.Username,
		DisplayName: safeStringPtr(event.DisplayName),
		Bio:         safeStringPtr(event.Bio),
		FollowerCount: 0,
		IsVerified:  event.IsVerified,
		ProfilePictureURL: safeStringPtr(event.ProfilePictureURL),
		CreatedAt:   timestamp.Unix(),
	}

	if err := nc.searchService.IndexUser(userDoc); err != nil {
		log.Printf("Error indexing user: %v", err)
	}
}

// handleUserUpdated processes user.updated events
func (nc *NATSConsumer) handleUserUpdated(data []byte) {
	var event UserUpdatedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling user.updated event: %v", err)
		return
	}

	timestamp, err := time.Parse(time.RFC3339, event.Timestamp)
	if err != nil {
		timestamp = time.Now()
	}

	userDoc := UserDocument{
		ID:          event.UserID,
		Username:    event.Username,
		DisplayName: safeStringPtr(event.DisplayName),
		Bio:         safeStringPtr(event.Bio),
		FollowerCount: event.FollowerCount,
		IsVerified:  event.IsVerified,
		ProfilePictureURL: safeStringPtr(event.ProfilePictureURL),
		CreatedAt:   timestamp.Unix(),
	}

	if err := nc.searchService.IndexUser(userDoc); err != nil {
		log.Printf("Error indexing user: %v", err)
	}
}

// handleEchoCreated processes echo.created events
func (nc *NATSConsumer) handleEchoCreated(data []byte) {
	var event EchoCreatedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling echo.created event: %v", err)
		return
	}

	timestamp, err := time.Parse(time.RFC3339, event.Timestamp)
	if err != nil {
		timestamp = time.Now()
	}

	// Extract hashtags from content if not already provided
	hashtags := event.Hashtags
	if len(hashtags) == 0 {
		hashtags = ExtractHashtags(event.Content)
	}

	// Update trending hashtags
	if len(hashtags) > 0 {
		if err := nc.trendingService.IncrementHashtags(hashtags); err != nil {
			log.Printf("Error updating trending hashtags: %v", err)
		}
	}

	echoDoc := EchoDocument{
		ID:         event.EchoID,
		UserID:     event.UserID,
		Content:    event.Content,
		Hashtags:   hashtags,
		LikesCount: event.LikesCount,
		CreatedAt:  timestamp.Unix(),
		Visibility: event.Visibility,
	}

	if err := nc.searchService.IndexEcho(echoDoc); err != nil {
		log.Printf("Error indexing echo: %v", err)
	}
}

// handleEchoUpdated processes echo.updated events
func (nc *NATSConsumer) handleEchoUpdated(data []byte) {
	var event EchoUpdatedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling echo.updated event: %v", err)
		return
	}

	echoID, err := uuid.Parse(event.EchoID)
	if err != nil {
		log.Printf("Error parsing echo ID: %v", err)
		return
	}

	if err := nc.searchService.UpdateEchoLikesCount(echoID, event.LikesCount); err != nil {
		log.Printf("Error updating echo likes count: %v", err)
	}
}

// handleEchoDeleted processes echo.deleted events
func (nc *NATSConsumer) handleEchoDeleted(data []byte) {
	var event EchoDeletedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling echo.deleted event: %v", err)
		return
	}

	echoID, err := uuid.Parse(event.EchoID)
	if err != nil {
		log.Printf("Error parsing echo ID: %v", err)
		return
	}

	if err := nc.searchService.DeleteEcho(echoID); err != nil {
		log.Printf("Error deleting echo from index: %v", err)
	}
}

// Close closes the NATS connection
func (nc *NATSConsumer) Close() {
	if nc.conn != nil {
		nc.conn.Close()
	}
}

// GetConn returns the NATS connection
func (nc *NATSConsumer) GetConn() *nats.Conn {
	return nc.conn
}

// Helper function to safely convert pointer to string
func safeStringPtr(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}
