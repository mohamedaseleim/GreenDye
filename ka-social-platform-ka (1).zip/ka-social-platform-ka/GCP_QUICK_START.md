# Ka Platform - GCP Quick Start (15 Minutes)

Fast-track guide to deploy Ka Platform on Google Cloud Platform.

## Prerequisites Checklist

- [ ] Google Cloud account with billing enabled
- [ ] `gcloud` CLI installed ([Install](https://cloud.google.com/sdk/docs/install))
- [ ] `terraform` installed ([Install](https://developer.hashicorp.com/terraform/downloads))
- [ ] `kubectl` installed ([Install](https://kubernetes.io/docs/tasks/tools/))

## One-Command Deployment

```bash
# Clone repository
git clone https://github.com/mohamedaseleim/ka-social-platform.git
cd ka-social-platform

# Run automated deployment
chmod +x infrastructure/scripts/deploy-gcp.sh
./infrastructure/scripts/deploy-gcp.sh
```

The script will:
1. ✅ Verify prerequisites
2. ✅ Configure GCP project
3. ✅ Enable required APIs
4. ✅ Deploy infrastructure with Terraform
5. ✅ Install Argo CD
6. ✅ Deploy Ka Platform
7. ✅ Deploy monitoring stack

**Time**: ~15-20 minutes  
**Cost**: ~$500/month (production) or ~$150/month (dev)

---

## Manual Deployment (Step by Step)

### 1. Set Up GCP Project (2 min)

```bash
# Login
gcloud auth login

# Create project
export PROJECT_ID="ka-platform-prod"
gcloud projects create $PROJECT_ID
gcloud config set project $PROJECT_ID

# Enable billing (required)
# Visit: https://console.cloud.google.com/billing/linkedaccount?project=$PROJECT_ID

# Enable APIs
gcloud services enable compute.googleapis.com container.googleapis.com
```

### 2. Deploy Infrastructure (10 min)

```bash
# Configure Terraform
cd terraform/gcp
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars - MUST set:
# - project_id = "your-project-id"
# - db_password = "your-secure-password"

# Deploy
terraform init
terraform apply -auto-approve

# Configure kubectl
eval $(terraform output -raw kubeconfig_command)
kubectl get nodes
```

### 3. Install Argo CD (3 min)

```bash
cd ../..  # Back to repo root

# Install Argo CD
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for ready
kubectl wait --for=condition=available --timeout=300s deployment/argocd-server -n argocd

# Get password
kubectl -n argocd get secret argocd-initial-admin-secret \
  -o jsonpath="{.data.password}" | base64 -d && echo
```

### 4. Configure Secrets (2 min)

```bash
# Generate secrets
echo "JWT Secret: $(openssl rand -base64 32)"
echo "DB Password: $(openssl rand -base64 16)"
echo "Redis Password: $(openssl rand -base64 16)"

# Update charts/ka-platform/values.yaml with generated secrets
nano charts/ka-platform/values.yaml
```

### 5. Deploy Application (5 min)

```bash
# Deploy Ka Platform
kubectl apply -f infrastructure/argocd/ka-platform-application.yaml

# Watch deployment
kubectl get pods -n ka-platform -w
# Wait for all pods to be Running

# Deploy monitoring
kubectl apply -f infrastructure/observability/prometheus/
kubectl apply -f infrastructure/observability/grafana/
kubectl apply -f infrastructure/observability/loki/
```

---

## Verify Deployment

```bash
# Check all pods are running
kubectl get pods -n ka-platform

# Test API endpoints
kubectl port-forward -n ka-platform svc/auth-service 8001:8001 &
curl http://localhost:8001/health
# Expected: {"status":"ok"}

# Access Grafana
kubectl port-forward -n ka-platform svc/grafana 3000:3000 &
# Open: http://localhost:3000
# Username: admin
# Password: kubectl get secret grafana-secrets -n ka-platform -o jsonpath="{.data.admin-password}" | base64 -d
```

---

## Access Your Application

### Development (Port Forwarding)

```bash
# API Services
kubectl port-forward -n ka-platform svc/auth-service 8001:8001 &
kubectl port-forward -n ka-platform svc/user-service 8002:8002 &
kubectl port-forward -n ka-platform svc/content-service 8003:8003 &

# Dashboards
kubectl port-forward -n ka-platform svc/grafana 3000:3000 &
kubectl port-forward -n argocd svc/argocd-server 8080:443 &

# Test
curl http://localhost:8001/health
```

### Production (with DNS)

1. Get ingress IP:
   ```bash
   cd terraform/gcp
   terraform output ingress_ip
   ```

2. Configure DNS A records:
   ```
   api.yourdomain.com → <INGRESS_IP>
   ```

3. Set up SSL (see GOOGLE_CLOUD_DEPLOYMENT.md)

---

## Common Commands

### View Status
```bash
# Cluster nodes
kubectl get nodes

# All pods
kubectl get pods -n ka-platform

# Argo CD sync status
kubectl get application -n argocd

# Service endpoints
kubectl get svc -n ka-platform
kubectl get ingress -n ka-platform
```

### View Logs
```bash
# Specific service
kubectl logs -n ka-platform deployment/auth-service -f

# All API services
kubectl logs -n ka-platform -l component=api -f --max-log-requests=10
```

### Scale Services
```bash
# Manual scaling
kubectl scale deployment/auth-service -n ka-platform --replicas=5

# View autoscaling
kubectl get hpa -n ka-platform
```

### Update Configuration
```bash
# Edit values
nano charts/ka-platform/values.yaml

# Commit and push (Argo CD auto-syncs)
git add charts/ka-platform/values.yaml
git commit -m "Update configuration"
git push

# Or force sync immediately
kubectl patch application ka-platform -n argocd \
  --type merge -p '{"operation":{"sync":{}}}'
```

---

## Troubleshooting

### Pods not starting
```bash
# Check pod status
kubectl describe pod <pod-name> -n ka-platform

# Check logs
kubectl logs <pod-name> -n ka-platform

# Check node resources
kubectl describe nodes
```

### Database connection issues
```bash
# Check database pod
kubectl get pods -n ka-platform | grep postgres

# Test connection
kubectl run -it --rm psql-test --image=postgres:15 -n ka-platform -- \
  psql -h postgres-service -U ka_user -d ka_db
```

### Argo CD not syncing
```bash
# Check application
kubectl get application ka-platform -n argocd -o yaml

# Force sync
kubectl patch application ka-platform -n argocd \
  --type merge -p '{"operation":{"sync":{}}}'

# Check logs
kubectl logs -n argocd deployment/argocd-application-controller
```

---

## Cost Optimization

### Development Setup (~$150/month)
```hcl
# terraform/gcp/terraform.tfvars
node_machine_type   = "e2-standard-2"
node_count_per_zone = 1
use_managed_databases = false
```

### Production Setup (~$500/month)
```hcl
# terraform/gcp/terraform.tfvars
node_machine_type   = "e2-standard-4"
node_count_per_zone = 1
max_node_count      = 3
use_managed_databases = true
```

### Further Optimization
- Use committed use discounts (up to 57% off)
- Use preemptible VMs for dev/staging
- Scale down during off-peak hours
- Enable autoscaling to scale to zero when idle

---

## Cleanup

**⚠️ WARNING: This deletes everything!**

```bash
# Delete Kubernetes resources
kubectl delete namespace ka-platform
kubectl delete namespace argocd

# Destroy infrastructure
cd terraform/gcp
terraform destroy -auto-approve

# Delete project (optional)
gcloud projects delete $PROJECT_ID
```

---

## Next Steps

1. ✅ **Deploy Complete** - Your platform is running!
2. 🔧 **Configure DNS** - Point your domain to the ingress IP
3. 🔒 **Set up SSL** - Use cert-manager for HTTPS
4. 📊 **Set up Alerts** - Configure Prometheus alerts
5. 💾 **Enable Backups** - Configure database backups
6. 🧪 **Load Testing** - Test under expected load
7. 📱 **Deploy Frontend** - Deploy Flutter app

---

## Resources

- **Full Guide**: [GOOGLE_CLOUD_DEPLOYMENT.md](./GOOGLE_CLOUD_DEPLOYMENT.md)
- **Deployment Checklist**: [DEPLOYMENT_CHECKLIST.md](./DEPLOYMENT_CHECKLIST.md)
- **Platform Guide**: [PLATFORM_ENGINEERING.md](./PLATFORM_ENGINEERING.md)
- **Architecture**: [ARCHITECTURE_DIAGRAM.md](./ARCHITECTURE_DIAGRAM.md)

---

## Support

Having issues? Check:
1. [Troubleshooting section in full guide](./GOOGLE_CLOUD_DEPLOYMENT.md#troubleshooting)
2. [Deployment checklist](./DEPLOYMENT_CHECKLIST.md)
3. Pod logs: `kubectl logs <pod-name> -n ka-platform`
4. Argo CD UI: `kubectl port-forward -n argocd svc/argocd-server 8080:443`

---

**Quick Start Version**: 1.0.0  
**Last Updated**: 2024
