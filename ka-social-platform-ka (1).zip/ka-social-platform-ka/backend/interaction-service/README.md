# Interaction Service

The Interaction Service is responsible for managing the social graph and user interactions in the Ka platform.

## Current Features

### Social Graph Management
- **Follow/Unfollow**: Create and remove follow relationships between users
- **Followers List**: Query a user's followers with pagination
- **Following List**: Query users a user is following with pagination
- **Idempotent Operations**: All state-changing endpoints are idempotent

### Denormalized Count Management
- Automatically updates `follower_count` and `following_count` in the User Service
- Uses synchronous HTTP calls to maintain consistency
- Graceful degradation if User Service is unavailable

## API Endpoints

All endpoints require authentication via Bearer token.

### Follow User
```
POST /api/users/:id/follow
```
Create a follow relationship. Idempotent - safe to call multiple times.

### Unfollow User
```
DELETE /api/users/:id/follow
```
Remove a follow relationship. Idempotent - safe to call multiple times.

### Get Followers
```
GET /api/users/:id/followers?page=1&per_page=20
```
Retrieve a paginated list of a user's followers.

### Get Following
```
GET /api/users/:id/following?page=1&per_page=20
```
Retrieve a paginated list of users a user is following.

## Database Schema

The Interaction Service uses the `follows` table in PostgreSQL:

```sql
CREATE TABLE follows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    follower_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    following_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(follower_id, following_id)
);
```

The UNIQUE constraint on `(follower_id, following_id)` ensures that:
- A user can only follow another user once
- Follow operations are idempotent at the database level

## Inter-Service Communication

The Interaction Service communicates with the User Service to maintain denormalized counts:

```
Interaction Service          User Service
        |                          |
        | POST /api/internal/      |
        | follow-counts            |
        |------------------------->|
        |                          |
        |    Update counts in      |
        |    users table           |
        |                          |
        |<-------------------------|
        |      200 OK              |
```

**Payload**:
```json
{
  "follower_user_id": "uuid",
  "following_user_id": "uuid",
  "action": "follow" | "unfollow"
}
```

### Current Approach: Synchronous
- Provides strong consistency
- Simple to implement and debug
- User waits for both operations to complete

### Future Approach: Event-Driven
- See `docs/ARCHITECTURE.md` for discussion of migration to Kafka/RabbitMQ
- Would provide better resilience and scalability
- Planned for Phase 2 when user base exceeds 100,000 users

## Running the Service

### Local Development
```bash
PORT=8005 \
DB_HOST=localhost \
DB_PORT=5432 \
DB_USER=ka_user \
DB_PASSWORD=ka_password \
DB_NAME=ka_db \
REDIS_HOST=localhost \
REDIS_PORT=6379 \
REDIS_PASSWORD=ka_redis_password \
JWT_SECRET=your-super-secret-jwt-key \
USER_SERVICE_URL=http://localhost:8002 \
go run *.go
```

### Docker
```bash
docker-compose up interaction-service
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Service port | `8005` |
| `DB_HOST` | PostgreSQL host | `localhost` |
| `DB_PORT` | PostgreSQL port | `5432` |
| `DB_USER` | Database user | `ka_user` |
| `DB_PASSWORD` | Database password | `ka_password` |
| `DB_NAME` | Database name | `ka_db` |
| `REDIS_HOST` | Redis host | `localhost` |
| `REDIS_PORT` | Redis port | `6379` |
| `REDIS_PASSWORD` | Redis password | `` |
| `JWT_SECRET` | JWT signing secret | Required |
| `USER_SERVICE_URL` | User Service URL for internal calls | `http://localhost:8002` |

## Testing

### Manual Testing with curl

1. Register and login to get a token:
```bash
TOKEN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"Password123!"}' \
  | jq -r '.data.access_token')
```

2. Follow a user:
```bash
curl -X POST http://localhost:8005/api/users/{user_id}/follow \
  -H "Authorization: Bearer $TOKEN"
```

3. Get followers:
```bash
curl http://localhost:8005/api/users/{user_id}/followers \
  -H "Authorization: Bearer $TOKEN"
```

4. Unfollow a user:
```bash
curl -X DELETE http://localhost:8005/api/users/{user_id}/follow \
  -H "Authorization: Bearer $TOKEN"
```

## Future Features

- Like/unlike posts
- Comment on posts
- Share/repost content
- Bookmark posts
- Report content
- Interaction analytics

## Dependencies

- **Gin**: Web framework
- **PostgreSQL**: Relational database for social graph
- **Redis**: Caching layer (planned for interaction counts)
- **jmoiron/sqlx**: SQL extensions for Go
- **google/uuid**: UUID generation
- **shared**: Internal shared library with middleware, models, and utilities

## Architecture Decisions

### Why PostgreSQL for Social Graph?
- ACID guarantees for critical relationships
- Strong referential integrity with foreign keys
- Efficient indexed queries for followers/following
- Can migrate to graph database (Neo4j) if needed at scale

### Why Synchronous Calls?
- Simplicity for MVP
- Strong consistency for user-facing counts
- Easy to debug and reason about
- Plan to migrate to events at scale (see ARCHITECTURE.md)

### Why Idempotency?
- Mobile apps may retry failed requests
- Network issues can cause duplicate requests
- Provides better user experience (no "already following" errors)
- Simplifies client-side code

## Related Documentation

- [Architecture Documentation](../../docs/ARCHITECTURE.md) - Inter-service communication patterns
- [API Specification](../../docs/API_SPEC.md) - Complete API documentation
- [User Service README](../user-service/README.md) - Profile and user management
