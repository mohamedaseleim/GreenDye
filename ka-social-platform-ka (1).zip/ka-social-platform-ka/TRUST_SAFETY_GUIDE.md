# Trust & Safety System Guide

## Overview

Ka platform implements a high-performance, event-driven Trust & Safety system for managing user relationships (blocks and mutes) with eventual consistency and cache-based enforcement.

## Quick Start

### Block a User

```bash
# User A blocks User B
curl -X POST http://localhost:8005/api/users/{user_b_id}/block \
  -H "Authorization: Bearer {jwt_token}"
```

**What happens:**
1. Block relationship created in PostgreSQL
2. All follow relationships severed (both directions)
3. `user.blocked` event published to NATS
4. Cache invalidated across all services (<100ms)
5. User B's content hidden from User A (and vice versa)

### Mute a User

```bash
# User A mutes User B
curl -X POST http://localhost:8005/api/users/{user_b_id}/mute \
  -H "Authorization: Bearer {jwt_token}"
```

**What happens:**
1. Mute relationship created in PostgreSQL
2. Follow relationships remain intact
3. `user.muted` event published to NATS
4. Cache invalidated across all services (<100ms)
5. User B's echoes hidden from User A's timeline
6. User B is unaware of being muted

## Block vs Mute

### Blocking (Two-Way Action)

**User Experience:**
- Neither user can see the other's content, profiles, or search results
- All existing follow relationships are severed (both directions)
- Blocked user cannot interact with blocker's content (no likes, comments, shares)
- Blocked user is not notified
- Block status is enforced bidirectionally

**Use Cases:**
- Harassment or abuse
- Unwanted contact
- Privacy protection
- Safety concerns

**Technical Details:**
- Database: `blocks` table with unique constraint on (blocker_id, blocked_id)
- Events: `user.blocked`, `user.unblocked`
- Cache Key: `block:{user1_id}:{user2_id}` (both directions)
- Enforcement: Feed, User, Content, Discovery, Engagement services

### Muting (One-Way Action)

**User Experience:**
- Muter no longer sees muted user's Echoes or Re-Echoes in home timeline
- Muted user is unaware they've been muted
- Muted user can still see muter's content and interact with it
- Follow relationship remains intact
- Mute only affects home feed visibility

**Use Cases:**
- Reduce noise without unfollowing
- Temporarily hide someone's content
- Manage timeline quality
- Avoid confrontation

**Technical Details:**
- Database: `mutes` table with unique constraint on (muter_id, muted_id)
- Events: `user.muted`, `user.unmuted`
- Cache Key: `mute:{muter_id}:{muted_id}` (one direction)
- Enforcement: Feed service only

## Architecture

### Event-Driven Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    User Action (Block/Mute)                  │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│              Interaction Service                             │
│  1. Validate user exists                                     │
│  2. Create/delete relationship in PostgreSQL                 │
│  3. Publish NATS event (user.blocked/muted)                  │
│  4. Return success response                                  │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                      NATS Broker                             │
│  Subject: user.blocked, user.unblocked,                      │
│           user.muted, user.unmuted                           │
└────────────────────────┬────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┬─────────────┐
        ▼                ▼                ▼             ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│Feed Service │  │User Service │  │Content Svc  │  │Engagement   │
│             │  │             │  │             │  │Service      │
│1. Consume   │  │1. Consume   │  │1. Consume   │  │1. Consume   │
│   event     │  │   event     │  │   event     │  │   event     │
│2. Invalidate│  │2. Invalidate│  │2. Invalidate│  │2. Invalidate│
│   Redis     │  │   Redis     │  │   Redis     │  │   Redis     │
│   cache     │  │   cache     │  │   cache     │  │   cache     │
└─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘
```

### Cache-First Performance

```
┌─────────────────────────────────────────────────────────────┐
│         User Request (Feed, Profile, Search, etc.)           │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   Service (Feed/User/etc.)                   │
│  1. Check if User A is blocked by User B?                    │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│              Trust & Safety Client                           │
└────────────────────────┬────────────────────────────────────┘
                         │
           Cache Hit? ───┼─── Cache Miss
                  Yes    │      No
                         │
        ┌────────────────┴────────────────┐
        ▼                                  ▼
┌─────────────┐                  ┌─────────────────────┐
│Redis Cache  │                  │Interaction Service  │
│<1ms lookup  │                  │<50ms HTTP call      │
│Return value │                  │Query PostgreSQL     │
│             │                  │Return + Cache result│
└─────────────┘                  └─────────────────────┘
        │                                  │
        └──────────────┬───────────────────┘
                       │
                       ▼
            ┌─────────────────────┐
            │Filter Content        │
            │Return to User        │
            └─────────────────────┘
```

## API Reference

### Public Endpoints (Authenticated)

All endpoints require JWT authentication via `Authorization: Bearer {token}` header.

#### POST /api/users/:id/block

Block a user. Returns 200 if successful or already blocked.

**Request:**
```bash
curl -X POST http://localhost:8005/api/users/550e8400-e29b-41d4-a716-446655440000/block \
  -H "Authorization: Bearer eyJhbGc..."
```

**Response:**
```json
{
  "success": true,
  "data": {
    "blocking": true,
    "already_blocking": false
  },
  "message": "Successfully blocked user"
}
```

#### DELETE /api/users/:id/block

Unblock a user. Returns 200 if successful or already unblocked.

**Request:**
```bash
curl -X DELETE http://localhost:8005/api/users/550e8400-e29b-41d4-a716-446655440000/block \
  -H "Authorization: Bearer eyJhbGc..."
```

**Response:**
```json
{
  "success": true,
  "data": {
    "blocking": false,
    "was_blocking": true
  },
  "message": "Successfully unblocked user"
}
```

#### GET /api/users/blocked

List users you have blocked (paginated).

**Request:**
```bash
curl http://localhost:8005/api/users/blocked?page=1&per_page=20 \
  -H "Authorization: Bearer eyJhbGc..."
```

**Response:**
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "username": "johndoe",
        "display_name": "John Doe",
        "profile_picture_url": "https://...",
        "is_verified": false
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 5,
      "total_pages": 1
    }
  }
}
```

#### POST /api/users/:id/mute

Mute a user. Returns 200 if successful or already muted.

**Request:**
```bash
curl -X POST http://localhost:8005/api/users/550e8400-e29b-41d4-a716-446655440000/mute \
  -H "Authorization: Bearer eyJhbGc..."
```

**Response:**
```json
{
  "success": true,
  "data": {
    "muting": true,
    "already_muting": false
  },
  "message": "Successfully muted user"
}
```

#### DELETE /api/users/:id/mute

Unmute a user. Returns 200 if successful or already unmuted.

**Request:**
```bash
curl -X DELETE http://localhost:8005/api/users/550e8400-e29b-41d4-a716-446655440000/mute \
  -H "Authorization: Bearer eyJhbGc..."
```

**Response:**
```json
{
  "success": true,
  "data": {
    "muting": false,
    "was_muting": true
  },
  "message": "Successfully unmuted user"
}
```

#### GET /api/users/muted

List users you have muted (paginated).

**Request:**
```bash
curl http://localhost:8005/api/users/muted?page=1&per_page=20 \
  -H "Authorization: Bearer eyJhbGc..."
```

**Response:**
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "username": "janedoe",
        "display_name": "Jane Doe",
        "profile_picture_url": "https://...",
        "is_verified": true
      }
    ],
    "pagination": {
      "page": 1,
      "per_page": 20,
      "total": 12,
      "total_pages": 1
    }
  }
}
```

### Internal Endpoints (No Auth)

These endpoints are for service-to-service communication within the VPC. They should not be exposed to the public internet.

#### GET /api/internal/block-status

Check if there's a block relationship between two users (bidirectional).

**Request:**
```bash
curl "http://localhost:8005/api/internal/block-status?user1_id=550e8400-e29b-41d4-a716-446655440000&user2_id=660e8400-e29b-41d4-a716-446655440001"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "blocked": true,
    "user1_blocks_user2": false,
    "user2_blocks_user1": true
  },
  "message": "Block status checked successfully"
}
```

#### GET /api/internal/mute-status

Check if user1 is muting user2 (one-directional).

**Request:**
```bash
curl "http://localhost:8005/api/internal/mute-status?muter_id=550e8400-e29b-41d4-a716-446655440000&muted_id=660e8400-e29b-41d4-a716-446655440001"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "muted": true
  },
  "message": "Mute status checked successfully"
}
```

## Integration Guide

### Using the Shared Library

All services should use the shared Trust & Safety library for consistent behavior.

#### 1. Add Import

```go
import "github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"
```

#### 2. Initialize Consumer (Cache Invalidation)

```go
// Initialize Trust & Safety consumer
tsConsumer := trustsafety.NewEventConsumer(natsConn, redisClient, "your-service-name")
if err := tsConsumer.Start(); err != nil {
    log.Printf("Warning: Failed to start Trust & Safety consumer: %v", err)
}
```

This automatically subscribes to `user.blocked`, `user.unblocked`, `user.muted`, `user.unmuted` events and invalidates the Redis cache.

#### 3. Initialize Client (Check Relationships)

```go
// Initialize Trust & Safety client
tsClient := trustsafety.NewClient(redisClient, interactionServiceURL)
```

#### 4. Check Block Status

```go
import "context"

ctx := context.Background()

// Check if there's a block relationship (either direction)
isBlocked, err := tsClient.IsBlocked(ctx, user1ID, user2ID)
if err != nil {
    log.Printf("Error checking block status: %v", err)
    // Fail-open: continue without blocking
} else if isBlocked {
    // Handle blocked relationship (hide content, return 404, etc.)
    return
}
```

#### 5. Check Mute Status

```go
// Check if user1 is muting user2 (one direction)
isMuted, err := tsClient.IsMuted(ctx, muterID, mutedID)
if err != nil {
    log.Printf("Error checking mute status: %v", err)
    // Fail-open: continue without filtering
} else if isMuted {
    // Filter out muted user's content
    continue
}
```

### Service-Specific Integration

#### Feed Service

Filter echoes from blocked and muted users:

```go
func (h *Handler) filterMutedAndBlockedEchoes(ctx context.Context, userID uuid.UUID, echoes []models.Echo) []models.Echo {
    filtered := make([]models.Echo, 0, len(echoes))
    for _, echo := range echoes {
        // Check block (two-way)
        if isBlocked, _ := h.trustSafetyClient.IsBlocked(ctx, userID, echo.UserID); isBlocked {
            continue
        }
        
        // Check mute (one-way)
        if isMuted, _ := h.trustSafetyClient.IsMuted(ctx, userID, echo.UserID); isMuted {
            continue
        }
        
        filtered = append(filtered, echo)
    }
    return filtered
}
```

#### User Service

Hide blocked users from search and profiles:

```go
// Before returning profile
isBlocked, _ := tsClient.IsBlocked(ctx, requesterID, profileUserID)
if isBlocked {
    return http.StatusNotFound, "User not found"
}

// Filter search results
for _, user := range searchResults {
    if isBlocked, _ := tsClient.IsBlocked(ctx, requesterID, user.ID); isBlocked {
        continue // Skip blocked user
    }
    filteredResults = append(filteredResults, user)
}
```

#### Content Service

Prevent blocked users from accessing private content:

```go
// Before returning echo
isBlocked, _ := tsClient.IsBlocked(ctx, requesterID, echo.UserID)
if isBlocked {
    return http.StatusNotFound, "Echo not found"
}
```

#### Engagement Service

Prevent blocked users from liking/commenting:

```go
// Before allowing like
isBlocked, _ := tsClient.IsBlocked(ctx, likerID, echoAuthorID)
if isBlocked {
    return http.StatusForbidden, "Cannot interact with this user's content"
}
```

#### Discovery Service

Filter blocked users from search results:

```go
// Post-process search results
for _, result := range searchResults {
    if isBlocked, _ := tsClient.IsBlocked(ctx, searcherID, result.UserID); isBlocked {
        continue // Skip blocked user
    }
    filteredResults = append(filteredResults, result)
}
```

## Performance Characteristics

### Cache Hit (Hot Path)

- **Latency**: <1ms (Redis lookup)
- **Throughput**: 10,000+ checks/sec per service instance
- **Memory**: ~100 bytes per cached relationship
- **Success Rate**: >90% for active users

### Cache Miss (Cold Path)

- **Latency**: <50ms (HTTP call to Interaction Service)
- **Throughput**: 100+ checks/sec per service instance
- **Database**: Single indexed query to blocks/mutes table
- **Success Rate**: <10% for active users

### Cache Invalidation

- **Event Latency**: <10ms (NATS publish + consume)
- **Propagation Time**: <100ms to all services
- **Throughput**: 1000+ invalidations/sec
- **Consistency**: Eventual (acceptable for Trust & Safety)

### Scalability

- Services scale independently (stateless)
- Redis can be clustered for horizontal scaling
- NATS consumer groups distribute invalidation load
- Each service caches only relationships it's seen recently

## Monitoring

### Key Metrics

**Cache Performance:**
- `trust_safety_cache_hits_total` - Redis cache hits (should be >90%)
- `trust_safety_cache_misses_total` - Redis cache misses (should be <10%)
- `trust_safety_cache_hit_rate` - Hit rate percentage

**Check Performance:**
- `trust_safety_check_duration_seconds` - Latency histogram (p50, p95, p99)
- `trust_safety_check_errors_total` - Error count

**Event Processing:**
- `trust_safety_invalidation_events_total` - NATS events consumed
- `trust_safety_invalidation_duration_seconds` - Invalidation latency
- `trust_safety_invalidation_errors_total` - Invalidation failures

**Content Filtering:**
- `trust_safety_filtered_content_total` - Content filtered due to blocks/mutes
- `trust_safety_filtered_users_total` - Users filtered from search/lists

### Recommended Alerts

1. **Cache Hit Rate < 80%**
   - Indicates cold cache or too short TTL
   - Action: Increase cache TTL or investigate traffic patterns

2. **Check Latency p99 > 100ms**
   - Indicates Interaction Service slowness
   - Action: Scale Interaction Service or optimize database queries

3. **Event Consumer Lag > 10 seconds**
   - Indicates NATS backlog or slow consumers
   - Action: Scale consumer instances or investigate bottlenecks

4. **Invalidation Error Rate > 1%**
   - Indicates Redis issues or network problems
   - Action: Check Redis health and network connectivity

## Testing

### Manual Testing

```bash
# 1. Block a user
USER_A_TOKEN="eyJhbGc..."
USER_B_ID="550e8400-e29b-41d4-a716-446655440000"

curl -X POST http://localhost:8005/api/users/$USER_B_ID/block \
  -H "Authorization: Bearer $USER_A_TOKEN"

# 2. Verify User B's content is hidden from User A's feed
curl http://localhost:8004/api/v1/feed/home \
  -H "Authorization: Bearer $USER_A_TOKEN"
# Should not contain any echoes from User B

# 3. Verify User A cannot see User B's profile
curl http://localhost:8002/api/users/$USER_B_ID \
  -H "Authorization: Bearer $USER_A_TOKEN"
# Should return 404 or "User not found"

# 4. Unblock User B
curl -X DELETE http://localhost:8005/api/users/$USER_B_ID/block \
  -H "Authorization: Bearer $USER_A_TOKEN"

# 5. Verify User B's content reappears (after cache TTL expires)
```

### Automated Testing

See the test files in each service:
- `backend/interaction-service/*_test.go` - Unit tests
- `backend/shared/trustsafety/*_test.go` - Library tests
- Integration tests require full environment (docker-compose)

## Troubleshooting

### Problem: Blocked user's content still visible

**Possible Causes:**
1. Cache not invalidated yet (wait up to 5 minutes for TTL)
2. NATS event not consumed
3. Service not subscribed to events

**Solutions:**
1. Check NATS connection in service logs
2. Verify `trust_safety_invalidation_events_total` metric
3. Manually invalidate cache: `redis-cli DEL "block:user1:user2"`
4. Restart service to reconnect to NATS

### Problem: High cache miss rate

**Possible Causes:**
1. Cache TTL too short (default 5 minutes)
2. Not enough Redis memory
3. High user churn (different users each request)

**Solutions:**
1. Increase cache TTL in `trustsafety.NewCacheManager(redis, 10*time.Minute)`
2. Increase Redis memory allocation
3. Implement cache warming for active users

### Problem: Slow block/mute checks

**Possible Causes:**
1. Interaction Service overloaded
2. PostgreSQL slow queries
3. Network latency

**Solutions:**
1. Scale Interaction Service horizontally
2. Add database indexes (already done)
3. Use connection pooling
4. Implement read replicas for PostgreSQL

### Problem: Cache invalidation not working

**Possible Causes:**
1. Service not subscribed to NATS events
2. Redis connection issues
3. NATS connection dropped

**Solutions:**
1. Check service logs for "Started consuming Trust & Safety events"
2. Verify NATS connection: `nats-cli sub "user.blocked"`
3. Restart services to reconnect
4. Check Redis health: `redis-cli PING`

## Security Considerations

### Privacy

- Block/mute lists are private (only visible to the user who created them)
- Blocked users are not notified
- Muted users are not notified
- Internal endpoints are not exposed to public internet

### Abuse Prevention

- Rate limiting on block/mute actions (TODO: implement)
- Maximum block/mute count per user (TODO: implement limit)
- Audit logging for Trust & Safety review (TODO: implement)
- API endpoints require authentication

### Data Integrity

- Unique constraint on (blocker_id, blocked_id) prevents duplicates
- Foreign key constraints ensure user validity
- Cascade delete removes relationships when user deleted
- Cache invalidation prevents stale data

## Future Enhancements

### Planned Features

1. **Report Content/Users** - Allow users to report abusive content
2. **Automated Abuse Detection** - ML-based toxicity scoring
3. **Safety Mode** - Filter sensitive content automatically
4. **Restricted Mode** - Limit interactions to mutual follows
5. **Block Suggestions** - Suggest blocks based on mutual blocks
6. **Temporary Mutes** - Mute for 24h/7d/30d duration
7. **Keyword Muting** - Hide echoes containing specific words

### Performance Improvements

1. **Bloom Filters** - Negative caching (definitely not blocked/muted)
2. **Batch Check Endpoints** - Check multiple relationships at once
3. **Proactive Cache Warming** - Pre-load relationships for active users
4. **Read-Through Cache** - Interaction Service caches frequently checked relationships

### Analytics

1. **Block/Mute Statistics Dashboard** - Platform-wide metrics
2. **Abuse Pattern Detection** - Identify coordinated harassment
3. **User Safety Score** - Measure user's trust & safety risk
4. **Content Toxicity Scoring** - ML-based content analysis

## Support

For questions or issues related to the Trust & Safety system:

1. Check this guide and ARCHITECTURE.md
2. Review service logs for errors
3. Check NATS and Redis connectivity
4. Verify cache metrics and event consumption
5. Contact the platform team

## References

- [ARCHITECTURE.md](docs/ARCHITECTURE.md) - Full technical architecture
- [API Documentation](backend/interaction-service/README.md) - Interaction Service API
- [Shared Library](backend/shared/trustsafety/) - Trust & Safety library code
