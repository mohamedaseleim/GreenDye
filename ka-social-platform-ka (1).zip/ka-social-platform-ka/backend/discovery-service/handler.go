package main

import (
	"log"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
)

// Handler handles HTTP requests for the discovery service
type Handler struct {
	searchService   *SearchService
	trendingService *TrendingService
	config          *Config
}

// NewHandler creates a new handler
func NewHandler(searchService *SearchService, trendingService *TrendingService, config *Config) *Handler {
	return &Handler{
		searchService:   searchService,
		trendingService: trendingService,
		config:          config,
	}
}

// HealthCheck handles GET /health
func (h *Handler) HealthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":  "healthy",
		"service": "discovery-service",
	})
}

// Search handles GET /api/v1/search
func (h *Handler) Search(c *gin.Context) {
	query := c.Query("q")
	if query == "" {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_QUERY",
			"Query parameter 'q' is required",
			nil,
		))
		return
	}

	limit := 20
	if limitStr := c.Query("limit"); limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 && l <= 100 {
			limit = l
		}
	}

	offset := 0
	if offsetStr := c.Query("offset"); offsetStr != "" {
		if o, err := strconv.Atoi(offsetStr); err == nil && o >= 0 {
			offset = o
		}
	}

	result, err := h.searchService.Search(SearchRequest{
		Query:  query,
		Limit:  limit,
		Offset: offset,
	})
	if err != nil {
		log.Printf("Search error: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SEARCH_ERROR",
			"Failed to perform search",
			nil,
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		result,
		"Search completed successfully",
	))
}

// Suggest handles GET /api/v1/search/suggest
func (h *Handler) Suggest(c *gin.Context) {
	query := c.Query("q")
	if query == "" {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_QUERY",
			"Query parameter 'q' is required",
			nil,
		))
		return
	}

	limit := 5
	if limitStr := c.Query("limit"); limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 && l <= 20 {
			limit = l
		}
	}

	result, err := h.searchService.Autocomplete(AutocompleteRequest{
		Query: query,
		Limit: limit,
	})
	if err != nil {
		log.Printf("Autocomplete error: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"AUTOCOMPLETE_ERROR",
			"Failed to get suggestions",
			nil,
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		result,
		"Suggestions retrieved successfully",
	))
}

// GetTrending handles GET /api/v1/discover/trending
func (h *Handler) GetTrending(c *gin.Context) {
	limit := 10
	if limitStr := c.Query("limit"); limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 && l <= 50 {
			limit = l
		}
	}

	hashtags, err := h.trendingService.GetTrendingHashtags(limit)
	if err != nil {
		log.Printf("Trending hashtags error: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"TRENDING_ERROR",
			"Failed to get trending hashtags",
			nil,
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{"trending_hashtags": hashtags},
		"Trending hashtags retrieved successfully",
	))
}
