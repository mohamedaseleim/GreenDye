package main

import (
	"encoding/json"
	"log"

	"github.com/nats-io/nats.go"
)

// MediaProcessingEvent represents a media processing event
type MediaProcessingEvent struct {
	ObjectKey   string `json:"object_key"`
	UserID      string `json:"user_id"`
	ContentType string `json:"content_type"`
	UploadedAt  int64  `json:"uploaded_at"`
}

// MediaProcessedEvent represents a completed media processing event
type MediaProcessedEvent struct {
	ObjectKey   string `json:"object_key"`
	UserID      string `json:"user_id"`
	OriginalURL string `json:"original_url"`
	MediumURL   string `json:"medium_url"`
	ThumbURL    string `json:"thumb_url"`
	ProcessedAt int64  `json:"processed_at"`
}

// Worker handles background processing of media
type Worker struct {
	natsConn  *nats.Conn
	processor *ImageProcessor
}

// NewWorker creates a new worker
func NewWorker(natsConn *nats.Conn, processor *ImageProcessor) *Worker {
	return &Worker{
		natsConn:  natsConn,
		processor: processor,
	}
}

// Start begins consuming media processing events
func (w *Worker) Start() error {
	// Subscribe to media.processing.required events
	_, err := w.natsConn.Subscribe("media.processing.required", func(msg *nats.Msg) {
		var event MediaProcessingEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("Failed to unmarshal media processing event: %v", err)
			return
		}

		log.Printf("Processing media: %s for user: %s", event.ObjectKey, event.UserID)

		// Process the image
		processed, err := w.processor.ProcessImage(event.ObjectKey)
		if err != nil {
			log.Printf("Failed to process image %s: %v", event.ObjectKey, err)
			return
		}

		log.Printf("Successfully processed image: %s", event.ObjectKey)

		// Publish media.processed event
		processedEvent := MediaProcessedEvent{
			ObjectKey:   event.ObjectKey,
			UserID:      event.UserID,
			OriginalURL: processed.OriginalURL,
			MediumURL:   processed.MediumURL,
			ThumbURL:    processed.ThumbURL,
			ProcessedAt: currentTimestamp(),
		}

		eventData, err := json.Marshal(processedEvent)
		if err != nil {
			log.Printf("Failed to marshal processed event: %v", err)
			return
		}

		if err := w.natsConn.Publish("media.processed", eventData); err != nil {
			log.Printf("Failed to publish media.processed event: %v", err)
			return
		}

		log.Printf("Published media.processed event for: %s", event.ObjectKey)
	})

	if err != nil {
		return err
	}

	log.Println("Worker started, listening for media.processing.required events")
	return nil
}

func currentTimestamp() int64 {
	// Placeholder implementation - will be replaced with time.Now().Unix()
	return 1234567890
}
