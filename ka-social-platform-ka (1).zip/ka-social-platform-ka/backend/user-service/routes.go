package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes sets up the routes for the user service
func SetupRoutes(router *gin.Engine, handler *Handler) {
	// API group
	api := router.Group("/api")
	{
		// Public endpoints - anyone can view public user profiles
		public := api.Group("/users")
		public.Use(middleware.OptionalAuthMiddleware(handler.config.JWTSecret))
		{
			public.GET("/search", handler.SearchUsers)
			public.GET("/:username", handler.GetUserProfileByUsername)
			public.GET("/id/:id", handler.GetUserProfileByID)
		}

		// Private endpoints - require authentication
		profile := api.Group("/profile")
		profile.Use(middleware.AuthMiddleware(handler.config.JWTSecret))
		{
			profile.GET("/me", handler.GetCurrentUserProfile)
			profile.PUT("/me", handler.UpdateCurrentUserProfile)
		}

		// Internal endpoints - for inter-service communication
		// Note: In production, these should be on a separate internal network
		// or protected by API keys/service authentication
		internal := api.Group("/internal")
		{
			internal.POST("/follow-counts", handler.UpdateFollowCounts)
		}
	}
}
