# Ka Platform - Quick Reference Guide

A quick cheat sheet for common tasks and commands.

## 🚀 Quick Start (3 Steps)

```bash
# 1. Start infrastructure
cd infrastructure/docker && docker-compose up -d postgres redis scylla

# 2. Initialize ScyllaDB (wait 2 mins first)
cd ../scripts && ./init-scylla.sh

# 3. Start auth service
cd ../../backend/auth-service && go run *.go
```

## 📋 Common Commands

### Docker Operations

```bash
# View all services
docker-compose ps

# Start all services
docker-compose up -d

# Start specific services
docker-compose up -d postgres redis scylla

# View logs
docker-compose logs -f [service-name]

# Restart a service
docker-compose restart [service-name]

# Stop all services
docker-compose down

# Stop and remove data
docker-compose down -v

# Rebuild a service
docker-compose build [service-name]
```

### Database Access

```bash
# PostgreSQL
docker-compose exec postgres psql -U ka_user -d ka_db
# Or: psql -h localhost -U ka_user -d ka_db

# ScyllaDB
docker-compose exec scylla cqlsh
# Or: cqlsh localhost 9042

# Redis
docker-compose exec redis redis-cli -a ka_redis_password
# Or: redis-cli -h localhost -p 6379 -a ka_redis_password
```

### Backend Development

```bash
# Run a service locally
cd backend/[service-name]
go run *.go

# Build a service
go build -o bin/[service-name] .

# Test a service
go test -v ./...

# Download dependencies
go mod download

# Update dependencies
go mod tidy
```

### API Testing

#### Authentication Service (Port 8001)
```bash
# Health check
curl http://localhost:8001/health

# Register user
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"john","email":"john@example.com","password":"Pass123!","display_name":"John"}'

# Login
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"Pass123!"}'

# Refresh token
curl -X POST http://localhost:8001/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refresh_token":"your_refresh_token"}'

# Logout (requires access token)
curl -X POST http://localhost:8001/api/auth/logout \
  -H "Authorization: Bearer your_access_token"
```

#### User Service (Port 8002)
```bash
# Get user profile by username (public)
curl http://localhost:8002/api/users/john

# Get user profile by ID (public)
curl http://localhost:8002/api/users/id/{user_id}

# Search users (public)
curl "http://localhost:8002/api/users/search?q=john&page=1&per_page=20"

# Get current user profile (private, requires auth)
curl http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer your_access_token"

# Update current user profile (requires auth)
curl -X PUT http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer your_access_token" \
  -H "Content-Type: application/json" \
  -d '{"display_name":"John Doe","bio":"Software engineer"}'
```

#### Interaction Service (Port 8005)
```bash
# Follow a user (idempotent, requires auth)
curl -X POST http://localhost:8005/api/users/{user_id}/follow \
  -H "Authorization: Bearer your_access_token"

# Unfollow a user (idempotent, requires auth)
curl -X DELETE http://localhost:8005/api/users/{user_id}/follow \
  -H "Authorization: Bearer your_access_token"

# Get user's followers (requires auth)
curl "http://localhost:8005/api/users/{user_id}/followers?page=1&per_page=20" \
  -H "Authorization: Bearer your_access_token"

# Get users a user is following (requires auth)
curl "http://localhost:8005/api/users/{user_id}/following?page=1&per_page=20" \
  -H "Authorization: Bearer your_access_token"
```

## 📊 Service Ports

| Service | Port | Status | Description |
|---------|------|--------|-------------|
| PostgreSQL | 5432 | ✅ | Primary database |
| Redis | 6379 | ✅ | Cache layer |
| ScyllaDB | 9042 | ✅ | NoSQL database |
| ScyllaDB REST | 10000 | ✅ | REST API |
| Auth Service | 8001 | ✅ | Authentication & JWT tokens |
| User Service | 8002 | ✅ | User profiles & search |
| Content Service | 8003 | 🚧 | Posts |
| Feed Service | 8004 | 🚧 | Timelines |
| Interaction Service | 8005 | ✅ | Follow/unfollow (social graph) |
| Messaging Service | 8006 | 🚧 | Messages |
| Notification Service | 8007 | 🚧 | Notifications |
| Discovery Service | 8008 | 🚧 | Trending |

## 🗄️ Database Queries

### PostgreSQL

```sql
-- List all tables
\dt

-- View users
SELECT id, username, email, created_at FROM users;

-- Count users
SELECT COUNT(*) FROM users;

-- View follows
SELECT f.follower_id, f.following_id, f.created_at 
FROM follows f;

-- Check refresh tokens
SELECT user_id, expires_at, is_revoked 
FROM refresh_tokens 
WHERE user_id = 'user-uuid';
```

### ScyllaDB

```cql
-- List keyspaces
DESCRIBE KEYSPACES;

-- Use ka_content keyspace
USE ka_content;

-- List tables
DESCRIBE TABLES;

-- View echoes (limit to avoid timeout)
SELECT id, user_id, content, created_at 
FROM echoes 
LIMIT 10;

-- View stories
SELECT id, user_id, title, created_at 
FROM stories 
LIMIT 10;

-- Count posts (may be slow)
SELECT COUNT(*) FROM echoes;
```

### Redis

```bash
# Check if Redis is working
PING

# View all keys
KEYS *

# Get a value
GET key_name

# View session
GET session:user_id

# Check cache
GET user:profile:user_id

# Clear all data (careful!)
FLUSHALL

# Get database size
DBSIZE

# Get key TTL
TTL key_name
```

## 🔧 Troubleshooting

### Service Won't Start

```bash
# Check if port is in use
lsof -i :[port]

# Kill process on port
kill -9 $(lsof -t -i:[port])

# Check service logs
docker-compose logs [service-name]

# Check service status
docker-compose ps [service-name]
```

### Database Connection Issues

```bash
# Check if service is healthy
docker-compose ps

# Wait for health check
watch -n 1 docker-compose ps

# Test PostgreSQL connection
docker-compose exec postgres pg_isready -U ka_user

# Test ScyllaDB connection
docker-compose exec scylla nodetool status

# Test Redis connection
docker-compose exec redis redis-cli -a ka_redis_password ping
```

### Clean Restart

```bash
# Stop everything
docker-compose down -v

# Start infrastructure
docker-compose up -d postgres redis scylla

# Wait for health
sleep 120

# Initialize ScyllaDB
cd ../scripts && ./init-scylla.sh

# Start services
cd ../docker && docker-compose up -d
```

## 📁 Project Structure Quick Reference

```
ka-social-platform/
├── backend/
│   ├── shared/              # Common utilities
│   ├── auth-service/        # ✅ User authentication
│   ├── user-service/        # 🚧 Profiles
│   ├── content-service/     # 🚧 Posts
│   ├── feed-service/        # 🚧 Timeline
│   ├── interaction-service/ # 🚧 Likes/Comments
│   ├── messaging-service/   # 🚧 Messages
│   ├── notification-service/# 🚧 Notifications
│   └── discovery-service/   # 🚧 Trending
├── frontend/
│   └── ka_app/             # 🚧 Flutter app
├── infrastructure/
│   ├── docker/             # ✅ Docker setup
│   ├── kubernetes/         # 🚧 K8s configs
│   └── scripts/            # ✅ Helper scripts
└── docs/                   # ✅ Documentation
```

## 🔑 Environment Variables

### Auth Service

```bash
PORT=8001
DB_HOST=localhost
DB_PORT=5432
DB_USER=ka_user
DB_PASSWORD=ka_password
DB_NAME=ka_db
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=ka_redis_password
JWT_SECRET=your-secret-key
JWT_EXPIRY=900
REFRESH_TOKEN_EXPIRY=604800
```

## 📚 Documentation Quick Links

- [README.md](README.md) - Project overview
- [GETTING_STARTED.md](GETTING_STARTED.md) - Setup guide
- [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) - Status overview
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) - Technical design
- [docs/API_SPEC.md](docs/API_SPEC.md) - API documentation
- [docs/ROADMAP.md](docs/ROADMAP.md) - Development plan
- [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md) - How to contribute
- [backend/README.md](backend/README.md) - Backend guide
- [frontend/README.md](frontend/README.md) - Flutter guide

## 🎯 Common Tasks

### Add a New Service

```bash
# 1. Create directory
mkdir backend/new-service
cd backend/new-service

# 2. Initialize Go module
go mod init github.com/mohamedaseleim/ka-social-platform/backend/new-service

# 3. Add shared dependency
go mod edit -replace github.com/mohamedaseleim/ka-social-platform/backend/shared=../shared
go get github.com/mohamedaseleim/ka-social-platform/backend/shared

# 4. Copy template files from auth-service
cp ../auth-service/{main.go,config.go,repository.go,handler.go,routes.go,Dockerfile} .

# 5. Modify files for your service

# 6. Add to docker-compose.yml

# 7. Test locally
go run *.go
```

### Test the Auth Flow

```bash
# 1. Save this as test-auth.sh
#!/bin/bash

# Register
echo "1. Registering user..."
REGISTER_RESPONSE=$(curl -s -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"TestPass123!","display_name":"Test User"}')
echo $REGISTER_RESPONSE

# Login
echo -e "\n2. Logging in..."
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"TestPass123!"}')
echo $LOGIN_RESPONSE

# Extract access token (requires jq)
ACCESS_TOKEN=$(echo $LOGIN_RESPONSE | jq -r '.data.access_token')
echo -e "\nAccess Token: $ACCESS_TOKEN"

# Logout
echo -e "\n3. Logging out..."
LOGOUT_RESPONSE=$(curl -s -X POST http://localhost:8001/api/auth/logout \
  -H "Authorization: Bearer $ACCESS_TOKEN")
echo $LOGOUT_RESPONSE

# 2. Make executable and run
chmod +x test-auth.sh
./test-auth.sh
```

### View Logs in Real-time

```bash
# All services
docker-compose logs -f

# Specific service with timestamps
docker-compose logs -f --timestamps auth-service

# Last 100 lines
docker-compose logs --tail=100 auth-service

# Follow new logs only
docker-compose logs -f --since 1m
```

## 🔐 Security Notes

### Development Passwords

**⚠️ THESE ARE FOR DEVELOPMENT ONLY!**

- PostgreSQL: `ka_password`
- Redis: `ka_redis_password`
- JWT Secret: `your-super-secret-jwt-key-change-in-production`

### Production Requirements

✅ Use strong, unique passwords
✅ Enable SSL/TLS for all connections
✅ Use environment variables
✅ Never commit secrets to git
✅ Use a secrets management service
✅ Rotate credentials regularly

## 🆘 Need Help?

1. **Check Documentation**
   - Start with GETTING_STARTED.md
   - Check service-specific READMEs

2. **View Logs**
   - `docker-compose logs [service-name]`

3. **Check Service Health**
   - `docker-compose ps`
   - `curl http://localhost:[port]/health`

4. **Common Issues**
   - Port conflicts: Change port in docker-compose.yml
   - Slow startup: Wait for ScyllaDB (2-3 mins)
   - Connection refused: Ensure services are healthy

5. **Open an Issue**
   - GitHub Issues with error details
   - Include logs and environment info

---

**Happy Coding! 🚀**
