package main

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"github.com/lib/pq"
)

// Repository handles database operations for engagements
type Repository struct {
	db *sqlx.DB
}

// NewRepository creates a new repository
func NewRepository(db *sqlx.DB) *Repository {
	return &Repository{db: db}
}

// Like represents a like on an echo
type Like struct {
	ID        uuid.UUID
	UserID    uuid.UUID
	EchoID    uuid.UUID
	CreatedAt time.Time
}

// Notification represents a notification
type Notification struct {
	ID         uuid.UUID
	UserID     uuid.UUID
	Type       string
	ActorID    *uuid.UUID
	EchoID     *uuid.UUID
	Content    string
	IsRead     bool
	CreatedAt  time.Time
	UpdatedAt  time.Time
	ActorIDs   []uuid.UUID
	ActorCount int
}

// LikeEcho creates a like for an echo (idempotent)
func (r *Repository) LikeEcho(userID, echoID uuid.UUID) (bool, error) {
	query := `
		INSERT INTO likes (id, user_id, echo_id, created_at)
		VALUES ($1, $2, $3, $4)
		ON CONFLICT (user_id, echo_id) DO NOTHING
		RETURNING id
	`

	var id uuid.UUID
	err := r.db.QueryRow(query, uuid.New(), userID, echoID, time.Now().UTC()).Scan(&id)
	
	if err == sql.ErrNoRows {
		// Already liked, this is okay (idempotent)
		return false, nil
	}
	
	if err != nil {
		return false, fmt.Errorf("failed to like echo: %w", err)
	}

	return true, nil
}

// UnlikeEcho removes a like from an echo (idempotent)
func (r *Repository) UnlikeEcho(userID, echoID uuid.UUID) (bool, error) {
	query := `DELETE FROM likes WHERE user_id = $1 AND echo_id = $2`
	
	result, err := r.db.Exec(query, userID, echoID)
	if err != nil {
		return false, fmt.Errorf("failed to unlike echo: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return false, fmt.Errorf("failed to get rows affected: %w", err)
	}

	return rowsAffected > 0, nil
}

// IsLiked checks if a user has liked an echo
func (r *Repository) IsLiked(userID, echoID uuid.UUID) (bool, error) {
	query := `SELECT EXISTS(SELECT 1 FROM likes WHERE user_id = $1 AND echo_id = $2)`
	
	var exists bool
	err := r.db.QueryRow(query, userID, echoID).Scan(&exists)
	if err != nil {
		return false, fmt.Errorf("failed to check like status: %w", err)
	}

	return exists, nil
}

// GetBatchLikeStatus checks like status for multiple echoes by a user
func (r *Repository) GetBatchLikeStatus(userID uuid.UUID, echoIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if len(echoIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	// Convert UUIDs to pq.Array for PostgreSQL
	echoIDsArray := make([]interface{}, len(echoIDs))
	for i, id := range echoIDs {
		echoIDsArray[i] = id
	}

	query := `
		SELECT echo_id, true as is_liked
		FROM likes
		WHERE user_id = $1 AND echo_id = ANY($2)
	`
	
	rows, err := r.db.Query(query, userID, pq.Array(echoIDs))
	if err != nil {
		return nil, fmt.Errorf("failed to fetch batch like status: %w", err)
	}
	defer rows.Close()

	result := make(map[uuid.UUID]bool)
	// Initialize all to false
	for _, echoID := range echoIDs {
		result[echoID] = false
	}

	// Set liked ones to true
	for rows.Next() {
		var echoID uuid.UUID
		var isLiked bool
		if err := rows.Scan(&echoID, &isLiked); err != nil {
			return nil, fmt.Errorf("failed to scan like status: %w", err)
		}
		result[echoID] = isLiked
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating like status rows: %w", err)
	}

	return result, nil
}

// GetEchoOwner retrieves the owner of an echo from likes table
// Note: This is a helper method. In production, you'd query the Content Service
func (r *Repository) GetEchoOwner(echoID uuid.UUID) (*uuid.UUID, error) {
	// This is a placeholder - in reality, we'd call Content Service
	// For now, we'll rely on the caller to provide this information
	return nil, nil
}

// CreateNotification creates a new notification
func (r *Repository) CreateNotification(notification *Notification) error {
	query := `
		INSERT INTO notifications (id, user_id, type, actor_id, echo_id, content, is_read, created_at, updated_at, actor_ids, actor_count)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
	`

	// Convert UUID array to string array for pq.Array
	actorIDStrs := make([]string, len(notification.ActorIDs))
	for i, id := range notification.ActorIDs {
		actorIDStrs[i] = id.String()
	}

	_, err := r.db.Exec(
		query,
		notification.ID,
		notification.UserID,
		notification.Type,
		notification.ActorID,
		notification.EchoID,
		notification.Content,
		notification.IsRead,
		notification.CreatedAt,
		notification.UpdatedAt,
		pq.Array(actorIDStrs),
		notification.ActorCount,
	)

	if err != nil {
		return fmt.Errorf("failed to create notification: %w", err)
	}

	return nil
}

// FindUnreadLikeNotification finds an existing unread like notification for the same echo
func (r *Repository) FindUnreadLikeNotification(userID, echoID uuid.UUID) (*Notification, error) {
	query := `
		SELECT id, user_id, type, actor_id, echo_id, content, is_read, created_at, updated_at, actor_ids, actor_count
		FROM notifications
		WHERE user_id = $1 AND echo_id = $2 AND type = 'like' AND is_read = false
		ORDER BY created_at DESC
		LIMIT 1
	`

	notification := &Notification{}
	var actorIDs []string

	err := r.db.QueryRow(query, userID, echoID).Scan(
		&notification.ID,
		&notification.UserID,
		&notification.Type,
		&notification.ActorID,
		&notification.EchoID,
		&notification.Content,
		&notification.IsRead,
		&notification.CreatedAt,
		&notification.UpdatedAt,
		pq.Array(&actorIDs),
		&notification.ActorCount,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	if err != nil {
		return nil, fmt.Errorf("failed to find notification: %w", err)
	}

	// Convert string UUIDs to uuid.UUID
	notification.ActorIDs = make([]uuid.UUID, 0, len(actorIDs))
	for _, idStr := range actorIDs {
		if id, err := uuid.Parse(idStr); err == nil {
			notification.ActorIDs = append(notification.ActorIDs, id)
		}
	}

	return notification, nil
}

// UpdateNotificationActors updates the actors list for an aggregated notification
func (r *Repository) UpdateNotificationActors(notificationID uuid.UUID, actorIDs []uuid.UUID, actorCount int) error {
	query := `
		UPDATE notifications
		SET actor_ids = $1, actor_count = $2, updated_at = $3
		WHERE id = $4
	`

	// Convert UUID array to string array for pq.Array
	actorIDStrs := make([]string, len(actorIDs))
	for i, id := range actorIDs {
		actorIDStrs[i] = id.String()
	}

	_, err := r.db.Exec(query, pq.Array(actorIDStrs), actorCount, time.Now().UTC(), notificationID)
	if err != nil {
		return fmt.Errorf("failed to update notification actors: %w", err)
	}

	return nil
}

// GetUserNotifications retrieves notifications for a user with pagination
func (r *Repository) GetUserNotifications(userID uuid.UUID, limit, offset int) ([]Notification, error) {
	query := `
		SELECT id, user_id, type, actor_id, echo_id, content, is_read, created_at, updated_at, actor_ids, actor_count
		FROM notifications
		WHERE user_id = $1
		ORDER BY created_at DESC
		LIMIT $2 OFFSET $3
	`

	rows, err := r.db.Query(query, userID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to get notifications: %w", err)
	}
	defer rows.Close()

	var notifications []Notification
	for rows.Next() {
		var n Notification
		var actorIDs []string

		err := rows.Scan(
			&n.ID,
			&n.UserID,
			&n.Type,
			&n.ActorID,
			&n.EchoID,
			&n.Content,
			&n.IsRead,
			&n.CreatedAt,
			&n.UpdatedAt,
			pq.Array(&actorIDs),
			&n.ActorCount,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan notification: %w", err)
		}

		// Convert string UUIDs to uuid.UUID
		n.ActorIDs = make([]uuid.UUID, 0, len(actorIDs))
		for _, idStr := range actorIDs {
			if id, err := uuid.Parse(idStr); err == nil {
				n.ActorIDs = append(n.ActorIDs, id)
			}
		}

		notifications = append(notifications, n)
	}

	return notifications, nil
}

// CountUserNotifications counts total notifications for a user
func (r *Repository) CountUserNotifications(userID uuid.UUID) (int64, error) {
	query := `SELECT COUNT(*) FROM notifications WHERE user_id = $1`
	
	var count int64
	err := r.db.QueryRow(query, userID).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("failed to count notifications: %w", err)
	}

	return count, nil
}

// MarkNotificationAsRead marks a notification as read
func (r *Repository) MarkNotificationAsRead(ctx context.Context, notificationID, userID uuid.UUID) error {
	query := `
		UPDATE notifications
		SET is_read = true, updated_at = $1
		WHERE id = $2 AND user_id = $3
	`

	_, err := r.db.ExecContext(ctx, query, time.Now().UTC(), notificationID, userID)
	if err != nil {
		return fmt.Errorf("failed to mark notification as read: %w", err)
	}

	return nil
}
