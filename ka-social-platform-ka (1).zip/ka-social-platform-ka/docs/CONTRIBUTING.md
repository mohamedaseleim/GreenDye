# Contributing to Ka Social Platform

Thank you for your interest in contributing to Ka! We welcome contributions from the community to help build a better social platform for everyone.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Coding Standards](#coding-standards)
- [Testing Guidelines](#testing-guidelines)
- [Pull Request Process](#pull-request-process)
- [Community](#community)

## Code of Conduct

### Our Pledge

We are committed to providing a welcoming and inclusive environment for all contributors, regardless of background, identity, or experience level.

### Our Standards

**Positive behavior includes:**
- Being respectful and considerate
- Welcoming diverse perspectives
- Accepting constructive criticism gracefully
- Focusing on what's best for the community
- Showing empathy towards others

**Unacceptable behavior includes:**
- Harassment, discrimination, or offensive comments
- Personal attacks or trolling
- Publishing others' private information
- Any conduct that would be inappropriate in a professional setting

## Getting Started

### Prerequisites

Before you begin, ensure you have:
- Go 1.21 or higher
- Flutter 3.13 or higher
- Docker and Docker Compose
- Git
- A GitHub account

### Finding Issues to Work On

1. Browse the [Issues](https://github.com/mohamedaseleim/ka-social-platform/issues) page
2. Look for issues labeled:
   - `good first issue` - Great for newcomers
   - `help wanted` - We'd love your help on these
   - `bug` - Bug fixes
   - `enhancement` - New features
3. Comment on the issue to let us know you're working on it

## Development Setup

### 1. Fork and Clone

```bash
# Fork the repository on GitHub, then clone your fork
git clone https://github.com/YOUR_USERNAME/ka-social-platform.git
cd ka-social-platform

# Add upstream remote
git remote add upstream https://github.com/mohamedaseleim/ka-social-platform.git
```

### 2. Start Infrastructure Services

```bash
cd infrastructure/docker
docker-compose up -d
```

### 3. Set Up Backend

```bash
cd backend

# Install dependencies for a specific service
cd auth-service
go mod download

# Run the service
go run main.go
```

### 4. Set Up Frontend

```bash
cd frontend/ka_app

# Get dependencies
flutter pub get

# Run on connected device/emulator
flutter run
```

## How to Contribute

### Reporting Bugs

**Before submitting a bug report:**
1. Check if the bug has already been reported
2. Try to reproduce it with the latest version
3. Collect relevant information (logs, screenshots, steps to reproduce)

**Submitting a bug report:**
- Use the bug report template
- Provide a clear, descriptive title
- Include steps to reproduce
- Describe expected vs. actual behavior
- Add screenshots or error logs if applicable
- Specify your environment (OS, Go version, Flutter version)

### Suggesting Enhancements

**Before submitting an enhancement:**
1. Check if it's already been suggested
2. Consider if it aligns with the project's goals
3. Think about the implementation complexity

**Submitting an enhancement:**
- Use the feature request template
- Explain the problem it solves
- Describe your proposed solution
- Consider alternative solutions
- Add mockups or examples if helpful

### Contributing Code

#### 1. Create a Branch

```bash
# Update your local main branch
git checkout main
git pull upstream main

# Create a new branch
git checkout -b feature/your-feature-name
# or
git checkout -b fix/your-bug-fix
```

#### 2. Make Your Changes

- Follow the [Coding Standards](#coding-standards)
- Write or update tests as needed
- Update documentation if applicable
- Keep commits atomic and well-described

#### 3. Test Your Changes

```bash
# Backend tests
cd backend/service-name
go test ./...

# Frontend tests
cd frontend/ka_app
flutter test
```

#### 4. Commit Your Changes

```bash
git add .
git commit -m "feat: add new feature X"
# or
git commit -m "fix: resolve issue with Y"
```

**Commit Message Format:**
```
<type>: <short description>

<optional longer description>

<optional footer>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

#### 5. Push and Create Pull Request

```bash
git push origin feature/your-feature-name
```

Then create a Pull Request on GitHub.

## Coding Standards

### Go (Backend)

**Style Guide:**
- Follow [Effective Go](https://golang.org/doc/effective_go.html)
- Use `gofmt` for formatting
- Use `golint` for linting
- Keep functions small and focused
- Write descriptive variable names

**Example:**
```go
// Good
func getUserProfile(userID string) (*User, error) {
    // Implementation
}

// Bad
func getup(id string) (*User, error) {
    // Implementation
}
```

**Package Structure:**
```
service-name/
├── main.go
├── handlers/          # HTTP handlers
├── models/            # Data models
├── services/          # Business logic
├── repositories/      # Database access
├── middleware/        # Middleware functions
├── utils/             # Utility functions
└── config/            # Configuration
```

**Error Handling:**
```go
// Always handle errors explicitly
result, err := someFunction()
if err != nil {
    return fmt.Errorf("failed to do something: %w", err)
}
```

### Flutter (Frontend)

**Style Guide:**
- Follow [Effective Dart](https://dart.dev/guides/language/effective-dart)
- Use `flutter format` for formatting
- Use `flutter analyze` for linting
- Follow BLoC or Provider pattern for state management
- Keep widgets small and composable

**Example:**
```dart
// Good
class UserProfileWidget extends StatelessWidget {
  final User user;
  
  const UserProfileWidget({Key? key, required this.user}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(user.displayName),
        subtitle: Text(user.bio),
      ),
    );
  }
}
```

**Folder Structure:**
```
lib/
├── main.dart
├── screens/           # Screen widgets
├── widgets/           # Reusable widgets
├── models/            # Data models
├── services/          # API services
├── providers/         # State management
├── utils/             # Utility functions
└── constants/         # Constants
```

### Database

**SQL (PostgreSQL):**
- Use snake_case for table and column names
- Always include `created_at` and `updated_at` timestamps
- Use UUIDs for primary keys
- Add proper indexes for frequently queried columns

**CQL (ScyllaDB):**
- Design tables for your query patterns
- Use appropriate partition keys
- Consider data distribution
- Keep partition sizes manageable

### API Design

**RESTful Principles:**
- Use nouns for resources, not verbs
- Use HTTP methods correctly (GET, POST, PUT, DELETE)
- Use plural nouns for collections
- Version your API (`/v1/...`)
- Return consistent response formats

**Examples:**
```
GET    /api/users/:id          # Get user
POST   /api/users              # Create user
PUT    /api/users/:id          # Update user
DELETE /api/users/:id          # Delete user
GET    /api/users/:id/posts    # Get user's posts
```

## Testing Guidelines

### Backend Testing

**Unit Tests:**
```go
func TestGetUserProfile(t *testing.T) {
    // Arrange
    userID := "test-user-id"
    expectedUser := &User{ID: userID, Username: "testuser"}
    
    // Act
    result, err := getUserProfile(userID)
    
    // Assert
    assert.NoError(t, err)
    assert.Equal(t, expectedUser.ID, result.ID)
}
```

**Integration Tests:**
- Use Docker containers for test databases
- Test API endpoints end-to-end
- Clean up test data after each test

### Frontend Testing

**Widget Tests:**
```dart
testWidgets('UserProfileWidget displays user information', (WidgetTester tester) async {
  // Arrange
  final user = User(id: '1', displayName: 'Test User', bio: 'Test bio');
  
  // Act
  await tester.pumpWidget(
    MaterialApp(home: UserProfileWidget(user: user)),
  );
  
  // Assert
  expect(find.text('Test User'), findsOneWidget);
  expect(find.text('Test bio'), findsOneWidget);
});
```

### Test Coverage

- Aim for at least 80% code coverage
- Focus on critical paths and edge cases
- Write tests before fixing bugs (TDD for bugs)
- Mock external dependencies

## Pull Request Process

### Before Submitting

- [ ] Code follows the project's coding standards
- [ ] All tests pass (`go test ./...` and `flutter test`)
- [ ] New code has appropriate test coverage
- [ ] Documentation is updated if needed
- [ ] Commit messages follow the convention
- [ ] Branch is up-to-date with main

### PR Description Template

```markdown
## Description
Brief description of what this PR does.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Related Issue
Closes #123

## Testing
Describe how you tested your changes.

## Screenshots (if applicable)
Add screenshots for UI changes.

## Checklist
- [ ] My code follows the project's style guidelines
- [ ] I have performed a self-review of my code
- [ ] I have commented my code where necessary
- [ ] I have updated the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix/feature works
- [ ] New and existing tests pass locally
```

### Review Process

1. **Automated Checks**: CI/CD pipeline runs tests and linters
2. **Code Review**: At least one maintainer reviews the code
3. **Feedback**: Address any comments or requested changes
4. **Approval**: Once approved, a maintainer will merge

### After Merge

- Delete your branch
- Update your local repository
- Check if documentation needs updates
- Consider if release notes should mention your change

## Community

### Communication Channels

- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: General questions and discussions
- **Discord/Slack** (coming soon): Real-time chat with the community

### Getting Help

If you need help:
1. Check the documentation in the `/docs` folder
2. Search existing issues and discussions
3. Ask in GitHub Discussions
4. Reach out in the community chat

### Recognition

We value all contributions! Contributors will be:
- Listed in the project's contributors page
- Mentioned in release notes (for significant contributions)
- Invited to the contributors' community channel

## Additional Resources

- [Architecture Documentation](ARCHITECTURE.md)
- [API Specification](API_SPEC.md)
- [Development Roadmap](ROADMAP.md)
- [Go Documentation](https://golang.org/doc/)
- [Flutter Documentation](https://flutter.dev/docs)
- [Docker Documentation](https://docs.docker.com/)

## Questions?

If you have questions about contributing, feel free to:
- Open an issue with the `question` label
- Ask in GitHub Discussions
- Reach out to the maintainers

Thank you for contributing to Ka! Together, we're building a platform where every voice finds an echo. 🎉
