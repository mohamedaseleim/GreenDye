# Ka Platform - Technical Architecture

## Overview

Ka is built using a **microservices architecture** to ensure scalability, resilience, and maintainability. This document provides a comprehensive overview of the system architecture, technology stack, and design decisions.

## Architecture Principles

1. **Microservices**: Independent, loosely coupled services
2. **Polyglot Persistence**: Right database for each job
3. **API-First Design**: Well-defined REST APIs with clear contracts
4. **Real-time Capable**: WebSocket support for instant updates
5. **Cloud-Native**: Containerized and orchestrated with Kubernetes
6. **Security-First**: E2EE messaging, JWT authentication, data encryption at rest

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Flutter Mobile App                      │
│                 (iOS & Android - RTL Support)                │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      │ HTTPS/WSS
                      │
┌─────────────────────▼───────────────────────────────────────┐
│                     API Gateway / Load Balancer              │
│                    (Nginx / Traefik / Envoy)                 │
└─────┬──────┬──────┬──────┬──────┬──────┬──────┬────────────┘
      │      │      │      │      │      │      │
      │      │      │      │      │      │      │
┌─────▼──┐ ┌─▼────┐ ┌▼────┐ ┌▼────┐ ┌▼───┐ ┌▼──┐ ┌▼──────────┐
│ Auth   │ │ User │ │Feed │ │Cont │ │Int │ │Msg│ │Discovery  │
│Service │ │Service│ │Svc  │ │Svc  │ │Svc │ │Svc│ │Service    │
└───┬────┘ └───┬──┘ └─┬───┘ └─┬───┘ └─┬──┘ └─┬─┘ └─────┬─────┘
    │          │      │       │       │      │         │
    └──────────┴──────┴───────┴───────┴──────┴─────────┘
                      │
    ┌─────────────────┴─────────────────────────────────┐
    │                                                     │
┌───▼──────────┐  ┌──────────┐  ┌──────────────────────▼┐
│  PostgreSQL  │  │  Redis   │  │   ScyllaDB/Cassandra  │
│              │  │ (Cache)  │  │                        │
│ - Users      │  │          │  │ - Posts (Echoes)       │
│ - Relations  │  │- Sessions│  │ - Stories              │
│ - Settings   │  │- Profiles│  │ - Timelines            │
└──────────────┘  └──────────┘  └────────────────────────┘
```

## Microservices Breakdown

### 1. Authentication Service
**Purpose**: Handle user authentication and authorization

**Responsibilities**:
- User registration and email/phone verification
- Login with password
- JWT token generation (access + refresh tokens)
- Token refresh and invalidation
- Password reset flow
- OAuth integration (Google, Facebook, Apple)

**Tech Stack**:
- Language: Go
- Framework: Gin
- Database: PostgreSQL (user credentials)
- Cache: Redis (token blacklist)

**Key Endpoints**:
- `POST /api/auth/register` - Create new account
- `POST /api/auth/login` - Authenticate user
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Invalidate tokens
- `POST /api/auth/forgot-password` - Password reset request
- `POST /api/auth/verify-email` - Verify email address

### 2. User Service
**Purpose**: Manage user profiles and social graph

**Responsibilities**:
- User profile CRUD operations
- Profile picture and cover story management
- Bio, location, website, etc.
- Follow/unfollow operations
- Follower/following lists
- Block/unblock users
- User search

**Tech Stack**:
- Language: Go
- Framework: Gin
- Database: PostgreSQL (profiles, relationships)
- Cache: Redis (hot profiles, follow counts)

**Key Endpoints**:
- `GET /api/profile/me` - Get current user's profile (private)
- `PUT /api/profile/me` - Update current user's profile (private)
- `GET /api/users/:username` - Get public user profile by username
- `GET /api/users/id/:id` - Get public user profile by ID
- `GET /api/users/search` - Search users (public)
- `POST /api/users/:id/follow` - Follow user (future)
- `DELETE /api/users/:id/follow` - Unfollow user (future)
- `GET /api/users/:id/followers` - Get followers (future)
- `GET /api/users/:id/following` - Get following (future)

**Implementation Status**: ✅ Core profile management complete

**Data Separation**:
The User Service shares the `users` table with the Auth Service but focuses on different concerns:
- **Auth Service**: Manages `password_hash`, authentication tokens, verification
- **User Service**: Manages `display_name`, `bio`, `profile_picture_url`, `location`, `website`

**Public vs Private Endpoints**:
- **Private** (`/api/profile/me`): Returns complete profile including email and phone
- **Public** (`/api/users/:username`): Returns public data only, excludes email/phone/password_hash

### 3. Content Service
**Purpose**: Handle creation and management of Echoes and Stories using event-driven architecture

**Responsibilities**:
- Echo (short-form post) creation and deletion
- Event publishing to NATS message broker
- Content validation and persistence
- Hashtag extraction and parsing
- Reply/thread support via parent_echo_id

**Tech Stack**:
- Language: Go
- Framework: Gin
- Database: ScyllaDB (posts, indexed by user_id, timestamp)
- Message Broker: NATS (event publishing)
- Cache: Redis (future: trending hashtags)

**Key Endpoints**:
- `POST /api/v1/echoes` - Create echo (publishes echo.created event)
- `DELETE /api/v1/echoes/:id` - Delete echo (publishes echo.deleted event)
- `POST /api/internal/echoes/batch` - Batch retrieve echoes by IDs (internal use)

**Event Schema**:
- `echo.created`: Published when a new echo is created
  ```json
  {
    "echo_id": "uuid",
    "user_id": "uuid",
    "timestamp": "2024-01-01T00:00:00Z",
    "parent_echo_id": "optional-uuid"
  }
  ```
- `echo.deleted`: Published when an echo is deleted
  ```json
  {
    "echo_id": "uuid",
    "user_id": "uuid",
    "timestamp": "2024-01-01T00:00:00Z"
  }
  ```

**Implementation Status**: ✅ Event-driven content creation complete

**Architectural Benefits**:
- **Fast Write Path**: Users receive immediate response after content is persisted
- **Decoupled Processing**: Feed updates, notifications, and analytics happen asynchronously
- **Scalability**: Event consumers can scale independently
- **Extensibility**: New features can subscribe to events without modifying the content service

### 4. Feed Service
**Purpose**: Generate personalized timelines and feeds using event-driven fan-out architecture

**Responsibilities**:
- Subscribe to echo.created and echo.deleted events from NATS
- Fan-out-on-write: Push echo IDs to all followers' timelines in Redis
- Serve GET /api/v1/feed/home with sub-100ms response time
- Hydrate echo IDs using batch endpoint from Content Service
- Multi-layer caching for optimal performance
- Support for multiple feed types (home, for-you, etc.)

**Tech Stack**:
- Language: Go
- Framework: Gin
- Message Broker: NATS (event consumption)
- Cache: Redis (timeline storage and echo caching)
- Internal APIs: Interaction Service (followers), Content Service (batch echo retrieval)

**Key Endpoints**:
- `GET /api/v1/feed/home` - User's home timeline (paginated)

**Redis Schema**:
- `timeline:home:{userId}` - Sorted set of echo IDs for home feed (people they follow)
- `timeline:foryou:{userId}` - Sorted set for algorithmic feed (future use)
- `echo:details:{echoId}` - Cached echo objects with 5-minute TTL

**Fan-Out Architecture**:
1. **On echo.created**:
   - Fetch author's followers from Interaction Service
   - Add echo_id to each follower's timeline:home:{userId} in Redis
   - Timelines limited to 1000 most recent items
2. **On echo.deleted**:
   - Fetch author's followers from Interaction Service
   - Remove echo_id from each follower's timeline

**Feed Hydration Strategy**:
1. Get echo IDs from Redis sorted set (timeline:home:{userId})
2. Check cache for echo details (echo:details:{echoId})
3. For cache misses, call Content Service batch endpoint
4. Cache fetched echoes with 5-minute TTL
5. Return hydrated echoes in chronological order

**Performance Optimizations**:
- **Fan-Out on Write**: Pre-compute timelines at write time for fast reads
- **Batch Hydration**: Single network call to Content Service for all echoes
- **Two-Layer Caching**: Redis timeline + Redis echo cache
- **Sorted Sets**: Efficient chronological ordering with O(log N) operations
- **Timeline Limits**: Prevent unbounded growth (1000 items max)

**Implementation Status**: ✅ Complete with event-driven fan-out and batch hydration

**Future Enhancements**:
- "For You" algorithmic feed
- "Inner Circle" feed (mutual follows)
- "The World" feed (trending)
- ML-powered recommendations

### 5. Interaction Service
**Purpose**: Handle user interactions with content and manage the social graph

**Responsibilities**:
- Follow/unfollow operations (social graph management)
- Follower/following list queries
- Like/unlike posts (future)
- Comment on posts (future)
- Reply to comments (future)
- Share/repost content (future)
- Bookmark posts (future)
- Report content (future)
- Interaction counters

**Tech Stack**:
- Language: Go
- Framework: Gin
- Database: PostgreSQL (social graph - follows table)
- Database: ScyllaDB (future: interactions, indexed by post_id and user_id)
- Cache: Redis (interaction counts)

**Key Endpoints**:
- `POST /api/users/:id/follow` - Follow user (idempotent)
- `DELETE /api/users/:id/follow` - Unfollow user (idempotent)
- `GET /api/users/:id/followers` - Get user's followers (paginated)
- `GET /api/users/:id/following` - Get users a user follows (paginated)
- `GET /api/internal/users/:id/followers` - Get followers (internal, no auth)
- `GET /api/internal/users/:id/following` - Get following (internal, no auth)
- `POST /api/posts/:id/like` - Like post (future)
- `DELETE /api/posts/:id/like` - Unlike post (future)
- `POST /api/posts/:id/comments` - Add comment (future)
- `GET /api/posts/:id/comments` - Get comments (future)
- `POST /api/posts/:id/share` - Share post (future)
- `GET /api/users/:id/bookmarks` - Get bookmarked posts (future)

**Implementation Status**: ✅ Social graph (follow/unfollow) complete

### 6. Engagement Service
**Purpose**: Handle user interactions and deliver real-time notifications

**Responsibilities**:
- Like/unlike operations on echoes
- Real-time notification generation and delivery
- WebSocket connection management for instant updates
- Notification aggregation to prevent spam
- Event-driven notification processing
- Denormalized count updates in Content Service

**Tech Stack**:
- Language: Go
- Framework: Gin + WebSocket (gorilla/websocket)
- Database: PostgreSQL (likes, notifications)
- Message Broker: NATS (event consumption and publishing)
- Cache: Redis (future: notification caching)

**Key Endpoints**:
- `POST /api/v1/echoes/:id/like` - Like an echo
- `DELETE /api/v1/echoes/:id/like` - Unlike an echo
- `GET /api/v1/notifications` - Get user notifications (paginated)
- `WS /ws/v1/notifications` - WebSocket for real-time notification delivery

**Event Subscriptions**:
- `echo.liked` - Generates like notifications
- `user.followed` - Generates follow notifications

**Event Publications**:
- `echo.liked` - Published when a user likes an echo (for notification generation)

**Real-Time Architecture**:

The Engagement Service implements a sophisticated real-time notification system:

1. **WebSocket Hub**: Manages multiple connections per user
   - Users can connect from multiple devices simultaneously
   - Automatic cleanup on disconnect
   - Heartbeat/ping-pong for connection health
   - Thread-safe connection pool with mutex protection

2. **Event-Driven Flow**:
   ```
   User likes echo → REST API → Store in PostgreSQL
                              → Publish echo.liked event
                              → Update Content Service count
                              ↓
   NATS event → Consumer → Create/update notification
                         → Push to WebSocket if user connected
                         → User receives real-time update
   ```

3. **Notification Aggregation**:
   - When a like notification arrives, check for existing unread like notification for that echo
   - If exists: Update the existing notification with new actor
   - Keep track of up to 3 most recent actors
   - Display: "User1, User2, and 13 others liked your post"
   - Prevents notification spam for popular posts

4. **Denormalized Counts**:
   - Like/unlike operations make internal API call to Content Service
   - Content Service updates `likes_count` field on echo
   - Ensures fast read performance for feed display
   - Atomic operations prevent race conditions

**Connection Management**:

```go
type Hub struct {
    clients    map[uuid.UUID]map[*Client]bool  // User ID → Multiple connections
    register   chan *Client                     // Register new connection
    unregister chan *Client                     // Remove connection
    broadcast  chan *BroadcastMessage           // Send to specific user
}
```

**WebSocket Authentication**:
- JWT token passed as query parameter: `ws://localhost:8007/ws/v1/notifications?token=JWT_TOKEN`
- Token validated before upgrading connection
- User ID extracted from token claims
- Connection registered in hub for that user

**Notification Schema**:

```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL,
    type VARCHAR(50),              -- 'like', 'follow', 'comment', etc.
    actor_id UUID,                 -- Single actor (for compatibility)
    echo_id UUID,                  -- Related echo (for likes/comments)
    content TEXT,                  -- Notification text
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    actor_ids UUID[],              -- Array of actors (for aggregation)
    actor_count INT DEFAULT 1      -- Total actor count
);
```

**Performance Characteristics**:
- **WebSocket Delivery**: <10ms from event to connected user
- **Database Writes**: Single transaction per like/unlike
- **Aggregation**: Single query to find existing notification
- **Scalability**: Multiple instances with NATS consumer groups

**Implementation Status**: ✅ Complete with real-time WebSocket delivery and aggregation

### 7. Messaging Service
**Purpose**: Secure direct messaging between users

**Responsibilities**:
- One-on-one conversations
- Group chats (up to 100 members)
- End-to-End Encryption (E2EE) for Inner Circle
- Message delivery and read receipts
- Voice notes and media sharing
- Smart inbox (separate mutual friends and requests)
- Typing indicators
- Message search

**Tech Stack**:
- Language: Go
- Framework: Gin + WebSockets
- Database: PostgreSQL (conversation metadata)
- Database: ScyllaDB (message history)
- Encryption: Signal Protocol or similar
- Cache: Redis (online status, typing indicators)

**Key Endpoints**:
- `GET /api/messages/inbox` - Get inbox conversations
- `GET /api/messages/requests` - Get message requests
- `GET /api/conversations/:id/messages` - Get messages
- `POST /api/conversations/:id/messages` - Send message
- `WS /ws/messages` - WebSocket for real-time messaging

### 8. Media Service
**Purpose**: Professional-grade media pipeline with secure uploads and background processing

**Responsibilities**:
- Generate presigned URLs for direct-to-storage uploads
- Background image processing and optimization
- Multi-size image generation (thumbnail, medium)
- WebP format conversion for optimal performance
- CDN-ready URL generation
- Event-driven processing pipeline

**Tech Stack**:
- Language: Go
- Framework: Gin
- Storage: MinIO (S3-compatible object storage)
- Image Processing: libvips via bimg
- Message Broker: NATS (event-driven processing)
- Cache: Redis (future: upload tracking)

**Key Endpoints**:
- `POST /api/v1/upload/request` - Get presigned URL for direct upload
- `POST /api/v1/upload/complete` - Notify upload complete, trigger processing

**Architecture Pattern**: Presigned URL Flow
```
Client → Request presigned URL → Media Service
Client → Upload directly to MinIO → Storage
Client → Notify completion → Media Service
Media Service → Publish event → NATS
Worker → Process image → MinIO
Worker → Publish result → NATS
User Service → Update profile → Database
```

**Event Publications**:
- `media.processing.required` - Published when upload is complete
- `media.processed` - Published when processing is complete

**Image Processing Pipeline**:
1. Download original image from MinIO
2. Generate thumbnail (150x150, WebP, 85% quality)
3. Generate medium (600x600, WebP, 85% quality)
4. Upload processed images to MinIO
5. Return CDN-ready URLs

**CDN Integration**:
- Configurable via `CDN_HOST` environment variable
- Seamless switch from MinIO direct URLs to CDN
- Ready for CloudFlare, CloudFront, or any CDN

**Performance Characteristics**:
- **Upload**: No bandwidth consumed by service (direct to MinIO)
- **Processing**: 3-10x faster than ImageMagick using libvips
- **Scalability**: Horizontal scaling with NATS consumer groups
- **Presigned URLs**: 15-minute expiration for security

**Implementation Status**: ✅ Complete with presigned URLs and background processing

### 9. Discovery Service
**Purpose**: Advanced search and content discovery powered by Meilisearch

**Responsibilities**:
- Full-text search across users and echoes
- Intelligent ranking based on engagement metrics
- Type-ahead autocomplete suggestions
- Trending hashtags with 24-hour sliding window
- Event-driven index updates via NATS

**Tech Stack**:
- Language: Go
- Framework: Gin
- Search Engine: Meilisearch (typo-tolerant, fast)
- Message Broker: NATS (event consumption)
- Cache: Redis (trending hashtag tracking)

**Key Endpoints**:
- `GET /api/v1/search?q={query}` - Multi-index search (users & echoes)
- `GET /api/v1/search/suggest?q={prefix}` - Autocomplete suggestions
- `GET /api/v1/discover/trending` - Trending hashtags

**Event Subscriptions**:
- `user.created` - Index new users
- `user.updated` - Update user data (including follower_count)
- `echo.created` - Index new echoes and track hashtags
- `echo.updated` - Update echo likes count
- `echo.deleted` - Remove echoes from index

**Implementation Status**: ✅ Complete with Meilisearch and trending hashtags

## Database Schema Design

### PostgreSQL Schema

#### Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100),
    bio TEXT,
    profile_picture_url TEXT,
    cover_story_url TEXT,
    cover_story_type VARCHAR(10), -- 'image', 'video', 'slideshow'
    location VARCHAR(100),
    website VARCHAR(255),
    is_verified BOOLEAN DEFAULT FALSE,
    is_premium BOOLEAN DEFAULT FALSE,
    language VARCHAR(10) DEFAULT 'en',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
```

#### Follows Table (Social Graph)
```sql
CREATE TABLE follows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    follower_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    following_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(follower_id, following_id)
);

CREATE INDEX idx_follows_follower ON follows(follower_id);
CREATE INDEX idx_follows_following ON follows(following_id);
```

### ScyllaDB/Cassandra Schema

#### Echoes (Short Posts)
```cql
CREATE TABLE echoes (
    id UUID,
    user_id UUID,
    content TEXT,
    media_urls LIST<TEXT>,
    hashtags SET<TEXT>,
    mentions SET<UUID>,
    visibility TEXT, -- 'public', 'friends', 'private'
    like_count INT,
    comment_count INT,
    share_count INT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    PRIMARY KEY (id)
);

CREATE INDEX ON echoes (user_id);
CREATE INDEX ON echoes (created_at);
```

#### Stories (Long Posts)
```cql
CREATE TABLE stories (
    id UUID,
    user_id UUID,
    title TEXT,
    content TEXT,
    photo_album LIST<TEXT>,
    tagged_users SET<UUID>,
    visibility TEXT,
    like_count INT,
    comment_count INT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    PRIMARY KEY (id)
);

CREATE INDEX ON stories (user_id);
CREATE INDEX ON stories (created_at);
```

#### User Timeline (Materialized View)
```cql
CREATE TABLE user_timeline (
    user_id UUID,
    post_id UUID,
    post_type TEXT, -- 'echo' or 'story'
    created_at TIMESTAMP,
    PRIMARY KEY (user_id, created_at, post_id)
) WITH CLUSTERING ORDER BY (created_at DESC);
```

## Security Architecture

### Authentication Flow
1. User logs in with credentials
2. Server validates and returns:
   - Access Token (JWT, 15 min expiry)
   - Refresh Token (JWT, 7 days expiry)
3. Client stores tokens securely (Keychain/Keystore)
4. Client includes access token in Authorization header
5. On access token expiry, use refresh token to get new access token
6. On logout, blacklist refresh token in Redis

### JWT Structure
```json
{
  "sub": "user_id",
  "username": "john_doe",
  "role": "user",
  "is_premium": false,
  "exp": 1234567890,
  "iat": 1234567890
}
```

### End-to-End Encryption (Messaging)
- Uses Signal Protocol or similar
- Keys generated and stored on client devices
- Server only routes encrypted messages
- Optional: backup encrypted keys to server (user opt-in)

## Performance Optimization

### Caching Strategy
1. **User Profiles**: Cache for 5 minutes (Redis)
2. **Feed Results**: Cache for 1 minute per user (Redis)
3. **Interaction Counts**: Cache with write-through (Redis)
4. **Trending Topics**: Cache for 15 minutes (Redis)
5. **Static Assets**: CDN caching (CloudFlare/AWS CloudFront)

### Database Optimization
1. **Read Replicas**: PostgreSQL read replicas for heavy read operations
2. **Connection Pooling**: Limit connections per service
3. **Query Optimization**: Proper indexing, query analysis
4. **Partitioning**: ScyllaDB partitioned by time ranges

### Media Optimization
1. **Image Compression**: Reduce size for 2G/3G networks
2. **Adaptive Streaming**: Multiple quality levels for videos
3. **Lazy Loading**: Load images on-demand
4. **Progressive Images**: Show low-res preview first

## Message Broker Infrastructure

### NATS Configuration

Ka platform uses **NATS** as the message broker for event-driven communication.

**Deployment**:
```yaml
services:
  nats:
    image: nats:2.10-alpine
    command: -js -m 8222
    ports:
      - "4222:4222"  # Client connections
      - "8222:8222"  # HTTP monitoring
      - "6222:6222"  # Cluster connections
```

**Features Enabled**:
- **JetStream**: Persistence and replay capabilities
- **Monitoring**: HTTP endpoint at port 8222 for metrics
- **Clustering**: Support for multi-node NATS clusters (future)

**Event Subjects**:
- `echo.created` - Published when a new echo is created (includes content, hashtags, likes_count)
- `echo.updated` - Published when an echo's likes count changes
- `echo.deleted` - Published when an echo is deleted
- `echo.liked` - Published when a user likes an echo (for notifications)
- `user.created` - Published when a new user registers
- `user.updated` - Published when a user profile is updated (includes follower_count)
- `user.followed` - Published when a user follows another user

**Consumer Groups**:
Each service that subscribes to events uses a consumer group to ensure:
- **Load Balancing**: Multiple instances of a consumer share the load
- **Fault Tolerance**: If one consumer fails, others continue processing
- **Ordered Processing**: Events are processed in order per partition

**Monitoring**:
- NATS monitoring endpoint: `http://nats:8222/varz`
- Metrics: message rate, byte rate, connections, subscriptions
- Health check: `http://nats:8222/healthz`

## Scalability

### Horizontal Scaling
- All services are stateless (except WebSocket connections)
- Can add more service instances behind load balancer
- ScyllaDB scales linearly by adding nodes
- Redis clustering for cache distribution
- **NATS clustering**: Add more NATS nodes for higher throughput

### Load Balancing
- Round-robin for stateless HTTP requests
- Sticky sessions for WebSocket connections
- Health checks for automatic failover
- **Event consumers**: NATS consumer groups automatically load balance

### Auto-Scaling (Kubernetes)
```yaml
# Example HPA configuration
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: feed-service
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: feed-service
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

**Event Consumer Scaling**:
- Feed Service can scale to 10+ instances consuming `echo.created` events
- Each instance processes a subset of events via NATS consumer groups
- Scaling is independent of Content Service instances

## Monitoring & Observability

### Metrics (Prometheus)
- Request rate, latency, error rate per service
- Database query performance
- Cache hit/miss rates
- Message queue depth

### Logging (ELK Stack or Loki)
- Structured JSON logs
- Correlation IDs across services
- Error tracking and alerting

### Tracing (Jaeger or Tempo)
- Distributed tracing across microservices
- Identify bottlenecks and slow queries

### APM (Application Performance Monitoring)
- Real User Monitoring (RUM) in Flutter app
- Backend service performance
- Database slow query logs

## Disaster Recovery

### Backup Strategy
- **PostgreSQL**: Daily full backups, WAL archiving
- **ScyllaDB**: Snapshot backups every 6 hours
- **Redis**: AOF persistence with replication
- **Media Files**: Cross-region replication in S3

### High Availability
- Multi-AZ deployment
- Database replication (master-slave for PostgreSQL)
- ScyllaDB multi-datacenter replication
- Redis Sentinel for automatic failover

## Development Workflow

### Local Development
```bash
# Start all infrastructure services
docker-compose up -d

# Run individual service
cd backend/auth-service
go run main.go

# Run all services
./scripts/run-all-services.sh
```

### Testing
- Unit tests: `go test ./...`
- Integration tests: Docker-based test environment
- E2E tests: Flutter integration tests
- Load testing: k6 or Locust

### CI/CD Pipeline
1. Code push to GitHub
2. Run linters and tests
3. Build Docker images
4. Push to container registry
5. Deploy to staging (auto)
6. Manual approval for production
7. Deploy to production with rolling update
8. Run smoke tests

## Inter-Service Communication

Ka platform uses a **hybrid approach** for inter-service communication, choosing the right pattern based on the use case:

### 1. Event-Driven Architecture (Content Service)

The **Content Service** uses an event-driven architecture with NATS as the message broker. This is our primary pattern for high-throughput, write-heavy operations.

**Architecture**:
```
Content Service → NATS Message Broker → Feed Service Consumer
                                     → Notification Service Consumer
                                     → Analytics Service Consumer
```

**Example: Echo Creation**
1. User creates an echo via Content Service
2. Content Service validates and saves to ScyllaDB
3. Content Service publishes `echo.created` event to NATS
4. Response returned immediately to user (fast!)
5. Downstream services consume event asynchronously:
   - Feed Service updates user timelines
   - Notification Service notifies mentioned users
   - Analytics Service tracks engagement metrics

**Event Subjects**:
- `echo.created` - New echo created
- `echo.deleted` - Echo deleted

**Benefits**:
- **Fast Write Path**: User gets immediate response after persistence
- **Loose Coupling**: Services can evolve independently
- **Resilience**: Services can be temporarily unavailable without data loss
- **Scalability**: Event consumers can scale independently
- **Extensibility**: New features subscribe to events without modifying publishers
- **Eventual Consistency**: Acceptable for social features (feeds may lag by milliseconds)

**Message Broker: NATS**

We chose NATS for its:
- **Performance**: Extremely fast and lightweight (millions of messages/sec)
- **Simplicity**: Easy to set up and operate
- **Go Native**: Excellent Go client library
- **JetStream**: Built-in persistence and replay capabilities
- **Delivery Guarantees**: At-least-once delivery with acknowledgments

**Implementation Status**: ✅ Implemented in Content Service

### 2. Synchronous HTTP Calls (Interaction Service)

The **Interaction Service** uses synchronous HTTP calls for operations that require strong consistency.

**Example: Follow Operation**
1. User A calls Interaction Service to follow User B
2. Interaction Service creates follow relationship in `follows` table
3. Interaction Service makes synchronous HTTP POST to User Service internal endpoint
4. User Service updates denormalized counts (`follower_count`, `following_count`) in `users` table
5. Response returned to user

**Advantages**:
- **Strong Consistency**: Counts are updated immediately
- **Simple to Implement**: No need for message queues or event processors
- **Easy to Debug**: Single request trace through services
- **Transactional Clarity**: Clear success/failure semantics

**Trade-offs**:
- **Tight Coupling**: Services must be available for operations to succeed
- **Latency**: User waits for multiple service calls to complete
- **Cascading Failures**: If User Service is down, follow operations fail

**Current Mitigation**:
- Count updates are logged but don't fail the primary operation
- Counts can be recalculated from the `follows` table if they drift
- Internal endpoints are on separate routes for monitoring

**When to Use Synchronous**:
- User-facing counts that must be immediately consistent
- Operations that require transactional guarantees
- Low-volume endpoints where latency impact is minimal

### 3. Migration Path

We plan to gradually migrate more services to event-driven architecture:

**Phase 1** (Current):
- ✅ Content Service (echo creation/deletion)
- ⏳ Interaction Service (synchronous)
- ⏳ User Service (synchronous)

**Phase 2** (Future):
- Migrate Interaction Service to publish `follow.created` and `follow.removed` events
- Add event consumers in User Service for count updates
- Migrate notification triggers to event-driven model
- Add event consumers in Analytics Service

**Phase 3** (Scale):
- Implement event replay for data consistency recovery
- Add distributed tracing for event flows
- Implement event versioning for schema evolution
- Add monitoring and alerting for event processing lag

**Decision Criteria**:

Use **Event-Driven** when:
- High write throughput is critical
- Eventual consistency is acceptable
- Multiple downstream consumers need the same data
- Operations can be processed asynchronously

Use **Synchronous HTTP** when:
- Strong consistency is required
- Immediate feedback is needed
- Single consumer or simple request-response pattern
- Low volume or infrequent operations

### 3. Feed Service: Fan-Out-On-Write Architecture

The **Feed Service** implements a sophisticated fan-out-on-write pattern for optimal read performance.

**Architecture**:
```
Content Service → NATS (echo.created) → Feed Service Consumer
                                      ↓
                           Interaction Service (get followers)
                                      ↓
                           Redis Timeline Fan-Out
                                      ↓
                  timeline:home:{follower1}, timeline:home:{follower2}, ...
```

**Write Path (echo.created)**:
1. User creates echo in Content Service
2. Content Service publishes echo.created event to NATS
3. Feed Service consumes event
4. Feed Service fetches author's followers from Interaction Service
5. Feed Service adds echo_id to each follower's Redis timeline (fan-out)
6. Each timeline is a sorted set with timestamp scores

**Read Path (GET /api/v1/feed/home)**:
1. User requests home feed
2. Feed Service gets echo IDs from Redis timeline (O(log N))
3. Feed Service checks Redis cache for echo details
4. For cache misses, Feed Service calls Content Service batch endpoint
5. Feed Service caches fetched echoes with 5-minute TTL
6. Return hydrated echoes to user

**Performance Benefits**:
- **Fast Reads**: Timeline already materialized in Redis (~1-5ms)
- **Batch Hydration**: Single call to Content Service (vs N calls)
- **Multi-Layer Cache**: Redis timeline + Redis echo cache
- **Sub-100ms Response Time**: Achieved through pre-computation and caching

**Trade-offs**:
- **Write Amplification**: One echo write → N timeline writes (where N = follower count)
- **Storage Cost**: Each timeline stores up to 1000 echo IDs
- **Eventual Consistency**: Feed updates lag by milliseconds after echo creation

**Scalability**:
- Multiple Feed Service instances can consume events via NATS consumer groups
- Redis can be clustered for horizontal scaling
- Fan-out operations are independent and can be parallelized

**Implementation Status**: ✅ Complete

**Internal APIs**:
- Content Service: `POST /api/internal/echoes/batch` - Batch retrieve echoes
- Interaction Service: `GET /api/internal/users/:id/followers` - Get followers list

## Discovery Service Architecture

### Overview

The Discovery Service provides world-class search and content discovery capabilities powered by Meilisearch and event-driven indexing.

### NATS-to-Meilisearch Indexing Flow

```
Event Publishers              NATS Broker              Discovery Service
     │                             │                           │
     ├─ Auth Service ─────────────►│                           │
     │  (user.created)              │                           │
     │                              ├──────────────────────────►│
     │                              │  user.created             │
     │                              │                           ├─► Meilisearch
     │                              │                           │   Users Index
     ├─ User Service ─────────────►│                           │
     │  (user.updated)              │                           │
     │                              ├──────────────────────────►│
     │                              │  user.updated             │
     │                              │                           ├─► Meilisearch
     │                              │                           │   (update follower_count)
     ├─ Content Service ───────────►│                           │
     │  (echo.created)              │                           │
     │                              ├──────────────────────────►│
     │                              │  echo.created             │
     │                              │                           ├─► Meilisearch
     │                              │                           │   Echoes Index
     │                              │                           ├─► Redis ZSET
     │                              │                           │   (trending hashtags)
     ├─ Content Service ───────────►│                           │
     │  (echo.updated)              │                           │
     │                              ├──────────────────────────►│
     │                              │  echo.updated             │
     │                              │                           ├─► Meilisearch
     │                              │                           │   (update likes_count)
     └─ Content Service ───────────►│                           │
        (echo.deleted)               │                           │
                                    ├──────────────────────────►│
                                    │  echo.deleted             │
                                    │                           ├─► Meilisearch
                                    │                           │   (remove from index)
```

### Meilisearch Configuration

#### Users Index

**Purpose**: Enable fast, typo-tolerant search for user profiles

**Ranking Rules** (in order):
1. Text relevance (words, typo, proximity, attribute)
2. **follower_count:desc** - Users with more followers rank higher
3. Sort order
4. Exactness

**Searchable Attributes**:
- `username` - Primary search field
- `display_name` - Secondary search field
- `bio` - Tertiary search field

**Filterable Attributes**:
- `is_verified` - Filter verified users
- `follower_count` - Range filtering

**Example Search**:
```
Query: "john developer"
Results ranked by:
  1. Text match quality
  2. Follower count (descending)
```

#### Echoes Index

**Purpose**: Enable search across public echoes with engagement-based ranking

**Ranking Rules** (in order):
1. Text relevance (words, typo, proximity, attribute)
2. **likes_count:desc** - More liked echoes rank higher
3. **created_at:desc** - More recent echoes rank higher
4. Sort order
5. Exactness

**Searchable Attributes**:
- `content` - Echo text content
- `hashtags` - Extracted hashtags

**Filterable Attributes**:
- `visibility` - Only "public" echoes are searchable
- `user_id` - Search echoes by specific user
- `hashtags` - Filter by hashtag
- `likes_count` - Range filtering
- `created_at` - Date range filtering

**Example Search**:
```
Query: "#technology AI"
Results ranked by:
  1. Text match quality (hashtag + keyword)
  2. Likes count (descending)
  3. Recency (descending)
```

### Event Processing

#### user.created Event
```json
{
  "user_id": "uuid",
  "username": "johndoe",
  "display_name": "John Doe",
  "bio": "Software Engineer",
  "profile_picture_url": "https://...",
  "is_verified": false,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Processing**:
1. Parse event from NATS
2. Create UserDocument
3. Index in Meilisearch users index
4. Set initial follower_count to 0

#### user.updated Event
```json
{
  "user_id": "uuid",
  "username": "johndoe",
  "display_name": "John Doe",
  "bio": "Senior Software Engineer",
  "profile_picture_url": "https://...",
  "is_verified": true,
  "follower_count": 1234,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Processing**:
1. Parse event from NATS
2. Update UserDocument with new follower_count
3. Re-index in Meilisearch (updates ranking)

**Triggers**:
- Profile updates (UpdateCurrentUserProfile)
- Follow/unfollow operations (UpdateFollowCounts)

#### echo.created Event
```json
{
  "echo_id": "uuid",
  "user_id": "uuid",
  "content": "Hello world! #tech #ai",
  "hashtags": ["tech", "ai"],
  "likes_count": 0,
  "visibility": "public",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Processing**:
1. Parse event from NATS
2. Extract hashtags from content
3. Index echo in Meilisearch
4. Increment hashtag counts in Redis ZSET

#### echo.updated Event
```json
{
  "echo_id": "uuid",
  "likes_count": 42,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Processing**:
1. Parse event from NATS
2. Fetch existing echo document from Meilisearch
3. Update likes_count field
4. Re-index document (updates ranking)

**Triggers**:
- Like/unlike operations in Engagement Service

#### echo.deleted Event
```json
{
  "echo_id": "uuid",
  "user_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Processing**:
1. Parse event from NATS
2. Delete document from Meilisearch echoes index

### Trending Hashtags Algorithm

The Discovery Service implements a Redis-based 24-hour sliding window algorithm for trending hashtags.

**Data Structure**:
```
Redis Key: trending:hashtags
Type: ZSET (Sorted Set)
Members: hashtag names (lowercase)
Scores: occurrence count

Redis Key: trending:hashtag:{tag}:timestamps
Type: ZSET (Sorted Set)
Members: Unix timestamps
Scores: Unix timestamps
TTL: 24 hours
```

**Algorithm**:

1. **Increment**: When an echo is created
   ```
   For each hashtag in echo:
     ZINCRBY trending:hashtags 1 {hashtag}
     ZADD trending:hashtag:{hashtag}:timestamps {now} {now}
     EXPIRE trending:hashtag:{hashtag}:timestamps 86400
   ```

2. **Retrieve**: When trending hashtags are requested
   ```
   Get top N from trending:hashtags
   For each hashtag:
     Count = ZCARD trending:hashtag:{hashtag}:timestamps
     If Count == 0:
       ZREM trending:hashtags {hashtag}
   Return hashtags sorted by count
   ```

3. **Cleanup**: Automatic via Redis TTL
   - Individual timestamp entries expire after 24 hours
   - Periodic cleanup removes hashtags with no recent activity

**Example**:
```
hashtag "tech" mentioned 10 times in last 24h:
  trending:hashtags -> {tech: 10}
  trending:hashtag:tech:timestamps -> {ts1, ts2, ..., ts10}

After 24h, old timestamps expire:
  trending:hashtag:tech:timestamps -> {ts9, ts10}
  ZCARD returns 2

Next request updates:
  trending:hashtags -> {tech: 2}
```

**Performance**:
- **Increment**: O(log N) per hashtag
- **Retrieve**: O(K log N) where K = limit
- **Memory**: O(H × T) where H = unique hashtags, T = timestamps per hashtag

**Benefits**:
- True sliding window (not fixed buckets)
- Automatic decay (old mentions expire)
- Real-time updates
- Efficient queries

### Search API Endpoints

#### GET /api/v1/search

Multi-index search across users and echoes.

**Query Parameters**:
- `q` (required): Search query
- `limit` (optional): Results per index (default: 20, max: 100)
- `offset` (optional): Pagination offset (default: 0)

**Response**:
```json
{
  "success": true,
  "data": {
    "users": [
      {
        "id": "uuid",
        "username": "johndoe",
        "display_name": "John Doe",
        "follower_count": 1234,
        "is_verified": true
      }
    ],
    "echoes": [
      {
        "id": "uuid",
        "content": "Hello world! #tech",
        "likes_count": 42,
        "created_at": 1234567890
      }
    ],
    "hits": 12
  }
}
```

#### GET /api/v1/search/suggest

Type-ahead autocomplete for users.

**Query Parameters**:
- `q` (required): Search prefix
- `limit` (optional): Number of suggestions (default: 5, max: 20)

**Response**:
```json
{
  "success": true,
  "data": {
    "users": [
      {
        "id": "uuid",
        "username": "johndoe",
        "display_name": "John Doe"
      }
    ],
    "echoes": []
  }
}
```

**Performance Target**: <50ms

#### GET /api/v1/discover/trending

Retrieve trending hashtags.

**Query Parameters**:
- `limit` (optional): Number of hashtags (default: 10, max: 50)

**Response**:
```json
{
  "success": true,
  "data": {
    "trending_hashtags": [
      {
        "tag": "tech",
        "count": 1523
      },
      {
        "tag": "ai",
        "count": 987
      }
    ]
  }
}
```

### Performance Characteristics

**Search Response Time**:
- **Users**: <100ms for most queries
- **Echoes**: <100ms for most queries
- **Autocomplete**: <50ms

**Indexing Latency**:
- Event published → Indexed in Meilisearch: <1 second
- Asynchronous, does not block user requests

**Trending Hashtags**:
- Calculation: O(log N) per query
- Response time: <10ms

**Scalability**:
- Meilisearch handles millions of documents
- NATS consumer groups enable horizontal scaling
- Redis ZSET operations are highly efficient

### Service Dependencies

**Required**:
- NATS (event consumption)
- Meilisearch (search engine)
- Redis (trending hashtags)

**Optional**:
- Content Service (for future direct queries)

**Downstream Impact**:
- None (search is read-only, does not affect other services)

### Monitoring

**Key Metrics**:
- Search query latency (p50, p95, p99)
- Autocomplete latency (p50, p95, p99)
- Index update lag (event timestamp → indexed)
- Trending hashtags calculation time
- Meilisearch index size
- Redis memory usage (trending data)

**Health Checks**:
- NATS connection status
- Meilisearch availability
- Redis connection status
- Event processing backlog

### Future Enhancements

**Search**:
- Faceted search (filter by date, user type, etc.)
- Search analytics (popular queries, zero-result queries)
- Personalized search ranking based on user interests
- Multi-language support with language detection

**Trending**:
- Geographic trending (regional hashtags)
- Trending echoes (not just hashtags)
- Trending users (rising stars)
- Custom time windows (1h, 6h, 24h, 7d)

**Performance**:
- Search result caching
- Query suggestion caching
- Pre-computed trending hashtags

## Media Service Architecture

### Presigned URL Flow

The Media Service implements a professional-grade upload strategy using presigned URLs to offload bandwidth from the service and enable direct client-to-storage uploads.

**Why Presigned URLs?**

Benefits:
1. **Scalability**: Service doesn't proxy file data - saves bandwidth and CPU
2. **Performance**: Direct client-to-storage upload is faster
3. **Security**: One-time URLs with expiration (15 minutes)
4. **Reliability**: No service downtime affects uploads
5. **Cost**: Lower data transfer costs for the service

**Upload Flow**:
1. Client requests presigned URL: `POST /api/v1/upload/request`
2. Media Service generates unique object key: `uploads/{user_id}/{uuid}.{ext}`
3. Media Service requests presigned PUT URL from MinIO
4. Client receives presigned URL (valid for 15 minutes)
5. Client uploads file directly to MinIO using HTTP PUT
6. Client notifies completion: `POST /api/v1/upload/complete`
7. Media Service publishes `media.processing.required` event to NATS

### Background Image Processing Pipeline

The Media Service uses a background worker pattern with NATS for asynchronous image processing.

**Processing Workflow**:
1. Worker consumes `media.processing.required` event from NATS
2. Worker downloads original image from MinIO
3. Worker processes image using libvips (bimg):
   - Generate thumbnail: 150x150, crop to square, convert to WebP (85% quality)
   - Generate medium: 600x600, crop to square, convert to WebP (85% quality)
4. Worker uploads processed images to MinIO: `processed/thumb_*.webp`, `processed/medium_*.webp`
5. Worker publishes `media.processed` event with CDN-ready URLs
6. User Service consumes event and updates user profile with new URLs

**Technology**: libvips via bimg
- 3-10x faster than ImageMagick
- Low memory usage (~10MB per operation)
- Multi-threaded processing
- Production-grade (used by millions of websites)

**Image Formats**:
- **Original**: Stored as uploaded (for high-quality display)
- **Medium**: 600x600px WebP (for profile pages, posts)
- **Thumbnail**: 150x150px WebP (for avatars in lists, comments)
- **WebP**: ~30% smaller than JPEG at same quality, supported by all modern browsers

**Processing Time**:
- Small images (<1MB): 100-300ms
- Medium images (1-5MB): 300-800ms
- Large images (5-20MB): 800-2000ms

### CDN-Ready URL Strategy

The Media Service is designed for easy CDN integration in production.

**Development** (Direct MinIO URLs):
```
CDN_HOST="" (not set)
Returns: http://minio:9000/ka-media/uploads/uid/x.jpg
```

**Production** (CDN URLs):
```
CDN_HOST="https://cdn.kaplatform.com"
Returns: https://cdn.kaplatform.com/ka-media/uploads/uid/x.jpg
```

**CDN Integration Options**:
- **CloudFlare**: Point to MinIO origin, set cache rules for /ka-media/*
- **CloudFront (AWS)**: Create distribution with MinIO as custom origin
- **Fastly/Akamai**: Configure edge servers with MinIO as backend

**Caching Strategy**:
- Processed images: `Cache-Control: public, max-age=31536000, immutable` (1 year)
- Original uploads: `Cache-Control: public, max-age=3600` (1 hour)
- Enable Brotli/Gzip compression
- Enable HTTP/2 and HTTP/3

**MinIO Bucket Policy** (Public Read):
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"AWS": ["*"]},
    "Action": ["s3:GetObject"],
    "Resource": ["arn:aws:s3:::ka-media/*"]
  }]
}
```

### Security Considerations

**Presigned URLs**:
- Expire after 15 minutes
- One-time use (can't be reused after upload)
- Scoped to specific object key
- Include signature that can't be forged

**Object Key Validation**:
- Keys include user ID: `uploads/{user_id}/{uuid}.{ext}`
- Service validates key matches authenticated user
- Prevents users from processing other users' uploads

**Content Type Validation**:
- Only image types accepted (jpeg, png, gif, webp)
- Prevents malicious file uploads

**Authentication**:
- All endpoints require valid JWT token
- Token includes user ID and role

### Scalability and Performance

**Horizontal Scaling**:
- Run multiple Media Service instances
- NATS consumer groups distribute work
- No shared state between instances

**Worker Scaling**:
- Workers scaled independently from API
- Each worker processes events from NATS
- CPU-bound workload (more workers = more throughput)

**Example Scaling Configuration**:
```
3x Media Service instances (API endpoints)
5x Media Service instances (Background workers)
4x MinIO nodes (Distributed mode)
3x NATS nodes (Cluster mode)
```

**Performance Targets**:
- Presigned URL generation: <50ms
- Direct upload: Limited by client bandwidth
- Processing event publish: <10ms
- Image processing: <500ms average
- Total time to processed images: <2 seconds

**Monitoring Metrics**:
- Presigned URL requests per second
- Upload notifications per second
- Processing queue depth (NATS)
- Average processing time
- Worker error rate
- MinIO storage usage

### Secure Media Attachment Flow

The Ka platform implements a secure and extensible system for attaching media (images, videos, GIFs) to Echoes with ownership validation and optimized feed hydration.

**Architecture Overview**:
```
Client → Upload Media → Media Service → MinIO Storage
                            ↓
                    Media Key Returned
                            ↓
Client → Create Echo with Media Keys → Content Service
                                            ↓
                                    Validate Ownership → Media Service
                                            ↓
                                    Save to ScyllaDB
                                            ↓
                                    Publish echo.created Event
                                            ↓
Feed Service → Fetch Echoes → Content Service → Hydrate Media URLs → Media Service
                                            ↓
                                    Return Fully Hydrated Echoes
```

#### Media Attachment Model

**Extensible Media Object**:
```json
{
  "media_key": "uploads/{user_id}/{uuid}.jpg",
  "type": "image",
  "alt_text": "A photo of the Nile river at sunset.",
  "url": "https://cdn.kaplatform.com/ka-media/uploads/{user_id}/{uuid}.jpg"
}
```

**Supported Media Types**:
- `image`: JPEG, PNG, GIF, WebP images
- `video`: MP4 videos (future)
- `gif`: Animated GIFs

**Database Schema**:
```cql
CREATE TABLE echoes (
    ...
    media_urls LIST<TEXT>,                          -- Deprecated: backward compatibility
    media_attachments LIST<FROZEN<MAP<TEXT, TEXT>>>, -- New: extensible media objects
    ...
);
```

**Media Attachment Fields**:
- `media_key` (required): Unique identifier for media in storage
- `type` (required): Media type (image, video, gif)
- `alt_text` (optional): Accessibility text description
- `url` (populated by hydration): Full CDN URL for media access

#### Task 1: Secure Media Ownership Validation

**Problem**: Users must only be able to attach media they have uploaded, preventing unauthorized use of other users' media.

**Solution**: The Content Service validates media ownership before creating Echoes.

**Validation Flow**:
1. User creates Echo with `media_attachments` containing media keys
2. Content Service extracts media keys from request
3. Content Service calls Media Service internal endpoint: `POST /api/internal/media/validate`
4. Media Service validates:
   - Media keys exist in storage
   - Media keys belong to the requesting user (via user ID in key path)
5. If validation fails, Echo creation is rejected with error
6. If validation succeeds, Echo is saved to ScyllaDB

**Media Service Validation Endpoint**:
```
POST /api/internal/media/validate
Request Body:
{
  "media_keys": ["uploads/{user_id}/{uuid}.jpg", ...],
  "user_id": "{user_id}"
}

Response:
{
  "success": true,
  "data": {
    "valid": true,
    "message": "All media keys are valid"
  }
}

Error Response:
{
  "success": true,
  "data": {
    "valid": false,
    "message": "Some media keys are invalid or not owned by user",
    "invalid": ["uploads/{other_user_id}/{uuid}.jpg"]
  }
}
```

**Ownership Validation Logic**:
- Media keys follow the pattern: `uploads/{user_id}/{uuid}.{ext}`
- Service checks if the key prefix matches the requesting user's ID
- Also validates processed images: `processed/{thumb|medium}_{uuid}.webp`
- Verifies object exists in MinIO storage

**Security Benefits**:
- Prevents users from attaching media they don't own
- Stops unauthorized sharing of private media
- Prevents spoofing attacks with forged media keys
- Maintains data integrity and user privacy

#### Task 2: Extensible Media Model

**Problem**: Simple media URL lists don't support metadata, accessibility features, or future media types (video, GIFs).

**Solution**: Rich media attachment objects with type discrimination and extensible fields.

**API Request Format**:
```json
POST /api/v1/echoes
{
  "content": "Amazing sunset at the Nile! #travel #egypt",
  "media_attachments": [
    {
      "media_key": "uploads/123e4567-e89b-12d3-a456-426614174000/abc123.jpg",
      "type": "image",
      "alt_text": "A photo of the Nile river at sunset with feluccas sailing."
    },
    {
      "media_key": "uploads/123e4567-e89b-12d3-a456-426614174000/def456.jpg",
      "type": "image",
      "alt_text": "Close-up of Egyptian street food."
    }
  ],
  "visibility": "public"
}
```

**API Response Format** (after hydration):
```json
{
  "success": true,
  "data": {
    "id": "...",
    "content": "Amazing sunset at the Nile! #travel #egypt",
    "media_attachments": [
      {
        "media_key": "uploads/123e4567-e89b-12d3-a456-426614174000/abc123.jpg",
        "type": "image",
        "alt_text": "A photo of the Nile river at sunset with feluccas sailing.",
        "url": "https://cdn.kaplatform.com/ka-media/uploads/123e4567-e89b-12d3-a456-426614174000/abc123.jpg"
      },
      {
        "media_key": "uploads/123e4567-e89b-12d3-a456-426614174000/def456.jpg",
        "type": "image",
        "alt_text": "Close-up of Egyptian street food.",
        "url": "https://cdn.kaplatform.com/ka-media/uploads/123e4567-e89b-12d3-a456-426614174000/def456.jpg"
      }
    ],
    "hashtags": ["travel", "egypt"],
    "like_count": 0,
    "created_at": "2024-01-01T12:00:00Z"
  }
}
```

**Accessibility Support**:
- `alt_text` field provides screen reader support
- Essential for visually impaired users
- Improves SEO for public echoes
- Optional but encouraged for all media

**Future Extensibility**:
- **Video Support**: Add duration, thumbnail_key fields
- **GIF Support**: Add frame_count, loop_count fields
- **Audio Support**: Add duration, waveform_key fields
- **Rich Previews**: Add aspect_ratio, dominant_color fields

**Backward Compatibility**:
- `media_urls` field maintained for legacy clients
- Both fields can coexist during migration
- Content Service handles both formats
- Gradual migration path for existing data

#### Task 3: Optimized Feed Hydration

**Problem**: Feed Service should receive complete Echo objects with resolved media URLs, not just media keys.

**Solution**: Content Service hydrates media URLs when responding to batch requests from Feed Service.

**Feed Hydration Flow**:
```
Feed Service → GET /api/v1/feed/home
    ↓
Get Echo IDs from Redis timeline:home:{userId}
    ↓
Call Content Service: POST /api/internal/echoes/batch
    ↓
Content Service:
  - Fetch Echoes from ScyllaDB
  - Extract media keys from media_attachments
  - Call Media Service: POST /api/internal/media/details
  - Populate URL field in each media attachment
  - Return fully hydrated Echoes
    ↓
Feed Service: Cache and return to client
```

**Media Details Endpoint**:
```
POST /api/internal/media/details
Request Body:
{
  "media_keys": ["uploads/{user_id}/{uuid}.jpg", ...]
}

Response:
{
  "success": true,
  "data": {
    "media": [
      {
        "media_key": "uploads/{user_id}/{uuid}.jpg",
        "url": "https://cdn.kaplatform.com/ka-media/uploads/{user_id}/{uuid}.jpg",
        "exists": true
      }
    ]
  }
}
```

**Hydration Performance**:
- Single batch call to Media Service per feed request
- Media Service returns URLs for all media keys at once
- URLs generated based on CDN_HOST configuration
- Minimal latency added to feed response (<10ms)

**Content Service Batch Endpoint Enhancement**:
```go
// BatchGetEchoes with media hydration
func (h *Handler) BatchGetEchoes(c *gin.Context) {
    // Fetch echoes from ScyllaDB
    echoes := fetchEchoesFromDatabase(echoIDs)
    
    // Hydrate media attachments
    for i := range echoes {
        if len(echoes[i].MediaAttachments) > 0 {
            hydratedAttachments := h.config.MediaClient.HydrateMediaAttachments(
                echoes[i].MediaAttachments
            )
            echoes[i].MediaAttachments = hydratedAttachments
        }
    }
    
    return echoes
}
```

**Benefits**:
- **Simplified Feed Service**: No need to call Media Service separately
- **Centralized Logic**: Echo composition logic in Content Service
- **Better Performance**: Single internal call vs multiple
- **Consistent Responses**: All echoes have complete media information

#### Service Responsibilities

**Media Service**:
- Generate presigned URLs for direct uploads
- Validate media ownership (internal endpoint)
- Provide media details with CDN URLs (internal endpoint)
- Process images in background
- Store media in MinIO
- Manage CDN URL generation

**Content Service**:
- Validate media attachments before creating Echoes
- Store media_attachments in ScyllaDB
- Hydrate media URLs when returning Echoes
- Publish echo.created events with media information
- Maintain Echo data integrity

**Feed Service**:
- Generate personalized timelines
- Call Content Service batch endpoint
- Receive fully hydrated Echoes with media URLs
- Cache complete Echo objects
- Return to clients without additional processing

#### Security Considerations

**Media Ownership**:
- Only media uploaded by user can be attached to their echoes
- Validation occurs server-side before persistence
- Cannot be bypassed by client manipulation
- Prevents cross-user media access

**Internal Endpoints**:
- `/api/internal/*` endpoints have no JWT authentication
- Only accessible within the service mesh/VPC
- Network-level security via firewall rules
- Not exposed to public internet

**Media Key Structure**:
- Keys encode user ID: `uploads/{user_id}/{uuid}.{ext}`
- Cannot be guessed or enumerated
- UUID provides uniqueness and unpredictability
- User ID ensures ownership validation

#### Performance Characteristics

**Media Validation**:
- Validation time: <50ms for up to 10 media keys
- MinIO stat operations: O(1) per key
- Parallelizable for multiple keys
- Cached in Redis for repeated validations (future)

**Media Hydration**:
- URL generation: <5ms (string concatenation)
- Batch retrieval: <10ms for up to 100 media keys
- No database queries required
- CDN URLs cached by clients and CDN

**Echo Creation with Media**:
- Baseline echo creation: ~50ms
- Media validation: +50ms
- Total: ~100ms (still sub-200ms target)
- Async event publishing: no impact on response time

**Feed Hydration**:
- Baseline feed retrieval: ~50ms
- Media hydration: +10ms
- Total: ~60ms (well under 100ms target)
- Single batch call scales to 100+ echoes

#### Error Handling

**Validation Failures**:
- Invalid media keys: Return 400 Bad Request with details
- Ownership mismatch: Return 400 Bad Request with invalid keys list
- Media Service unavailable: Return 500 Internal Server Error
- User retries after checking media upload status

**Hydration Failures**:
- Media Service unavailable: Log warning, return echoes without URLs
- Missing media keys: Skip missing items, return available ones
- Graceful degradation: Feed still works without media URLs
- Client can retry or display error state

**Partial Failures**:
- Some media keys invalid: Reject entire echo creation
- Some media URLs missing: Return echo with partial hydration
- Atomic validation: All or nothing for echo creation
- Best-effort hydration: Return what we can for reads

#### Migration Strategy

**Phase 1: Add Support** (Current)
- Add media_attachments field to Echo model
- Keep media_urls for backward compatibility
- Update Content Service to handle both fields
- Deploy with feature flag disabled

**Phase 2: Enable Validation**
- Enable media ownership validation
- Start using media_attachments in mobile app
- Monitor validation performance and errors
- Keep media_urls populated for legacy clients

**Phase 3: Full Migration**
- Migrate existing echoes to new format
- Backfill media_attachments from media_urls
- Update all clients to use media_attachments
- Monitor metrics and user feedback

**Phase 4: Deprecation**
- Mark media_urls as deprecated
- Remove from API documentation
- Keep in database for data archaeology
- Future: Remove field in major version bump

#### Monitoring and Observability

**Media Service Metrics**:
- `media_validation_requests_total`: Counter of validation requests
- `media_validation_duration_seconds`: Histogram of validation latency
- `media_validation_failures_total`: Counter of failed validations
- `media_details_requests_total`: Counter of detail requests
- `media_hydration_duration_seconds`: Histogram of hydration latency

**Content Service Metrics**:
- `echo_creation_with_media_total`: Counter of echoes with media
- `echo_media_validation_failures_total`: Counter of validation rejections
- `echo_batch_hydration_duration_seconds`: Histogram of hydration time
- `echo_media_keys_per_echo`: Histogram of media count per echo

**Alerts**:
- Media validation failure rate > 5%
- Media Service response time > 100ms
- Media hydration failures > 1%
- Content Service response time > 200ms

#### Testing Strategy

**Unit Tests**:
- Media ownership validation logic
- Media key parsing and validation
- URL generation with/without CDN
- Error handling for invalid inputs

**Integration Tests**:
- End-to-end echo creation with media
- Media validation with Media Service
- Feed hydration with Content Service
- Error scenarios (service down, invalid keys)

**Load Tests**:
- 1000 echoes/sec with 3 media each
- Validation latency under load
- Hydration latency for large feeds
- Service degradation gracefully

**Accessibility Tests**:
- Alt text rendered correctly
- Screen readers can access descriptions
- Missing alt text handled gracefully
- Multi-language alt text support

## Trust & Safety Architecture

### Overview

Ka platform implements a high-performance, event-driven Trust & Safety system for managing user relationships (blocks and mutes) with eventual consistency and cache-based enforcement.

### Core Principles

1. **Event-Driven**: All block/mute actions publish NATS events for cache invalidation
2. **Cache-First**: Each service maintains its own Redis cache for hot relationships
3. **Eventual Consistency**: Cache invalidation happens asynchronously via NATS
4. **Fail-Open**: Services gracefully degrade if Trust & Safety checks fail
5. **High Performance**: Sub-millisecond checks using Redis, avoiding database queries

### Block vs Mute

#### Blocking (Two-Way Action)

**User Experience**: When User A blocks User B:
- Neither can see the other's content, profiles, or search results
- All existing follow relationships are severed (both directions)
- User B cannot interact with User A's content (no likes, comments, shares)
- User B is not notified they've been blocked
- Block status is enforced bidirectionally

**Technical Implementation**:
- Row created in `blocks` table: `(blocker_id, blocked_id)`
- Both follow relationships deleted automatically
- `user.blocked` event published to NATS
- Cache invalidated in all services
- Content filtered in Feed, Discovery, User, Engagement services

#### Muting (One-Way Action)

**User Experience**: When User A mutes User B:
- User A no longer sees User B's Echoes or Re-Echoes in their home timeline
- User B is unaware they've been muted
- User B can still see User A's content and interact with it
- Follow relationship remains intact
- Mute only affects home feed visibility

**Technical Implementation**:
- Row created in `mutes` table: `(muter_id, muted_id)`
- Follow relationships unchanged
- `user.muted` event published to NATS
- Cache invalidated in all services
- Content filtered only in Feed Service

### Database Schema

#### Blocks Table

```sql
CREATE TABLE blocks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    blocker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    blocked_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(blocker_id, blocked_id)
);

CREATE INDEX idx_blocks_blocker ON blocks(blocker_id);
CREATE INDEX idx_blocks_blocked ON blocks(blocked_id);
```

#### Mutes Table

```sql
CREATE TABLE mutes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    muter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    muted_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(muter_id, muted_id)
);

CREATE INDEX idx_mutes_muter ON mutes(muter_id);
CREATE INDEX idx_mutes_muted ON mutes(muted_id);
```

### Interaction Service APIs

#### Public Endpoints (Authenticated)

- `POST /api/users/:id/block` - Block a user
- `DELETE /api/users/:id/block` - Unblock a user
- `GET /api/users/blocked` - List blocked users (paginated)
- `POST /api/users/:id/mute` - Mute a user
- `DELETE /api/users/:id/mute` - Unmute a user
- `GET /api/users/muted` - List muted users (paginated)

#### Internal Endpoints (No Auth)

- `GET /api/internal/block-status?user1_id={uuid}&user2_id={uuid}` - Check block status
- `GET /api/internal/mute-status?muter_id={uuid}&muted_id={uuid}` - Check mute status

### NATS Events

#### user.blocked

Published when User A blocks User B.

```json
{
  "blocker_id": "uuid",
  "blocked_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Actions**:
- Interaction Service deletes follow relationships
- All services invalidate block cache for this pair

#### user.unblocked

Published when User A unblocks User B.

```json
{
  "blocker_id": "uuid",
  "blocked_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Actions**:
- All services invalidate block cache for this pair

#### user.muted

Published when User A mutes User B.

```json
{
  "muter_id": "uuid",
  "muted_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Actions**:
- All services invalidate mute cache for this pair

#### user.unmuted

Published when User A unmutes User B.

```json
{
  "muter_id": "uuid",
  "muted_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

**Actions**:
- All services invalidate mute cache for this pair

### Cache-Based Enforcement

#### Redis Cache Keys

**Block Cache**:
- Key: `block:{user1_id}:{user2_id}`
- Value: `"0"` (not blocked) or `"1"` (blocked)
- TTL: 5 minutes
- Note: Both directions cached for bidirectional enforcement

**Mute Cache**:
- Key: `mute:{muter_id}:{muted_id}`
- Value: `"0"` (not muted) or `"1"` (muted)
- TTL: 5 minutes
- Note: Only one direction cached (muting is one-way)

#### Cache Flow

1. **Check Request**: Service needs to check if User A has blocked/muted User B
2. **Cache Lookup**: Query Redis for `block:A:B` or `mute:A:B`
3. **Cache Hit**: Return cached value immediately (<1ms)
4. **Cache Miss**: Call Interaction Service internal endpoint
5. **Cache Result**: Store result in Redis with 5-minute TTL
6. **Return**: Respond to original request

#### Cache Invalidation Flow

1. **Block/Mute Action**: User performs block/mute in Interaction Service
2. **Database Update**: Row inserted/deleted in PostgreSQL
3. **Event Published**: `user.blocked/muted` event sent to NATS
4. **Event Consumed**: All services consume event via NATS subscriptions
5. **Cache Invalidated**: Each service deletes relevant Redis keys
6. **Next Request**: Cache miss triggers fresh lookup from Interaction Service

### Service-Specific Enforcement

#### Feed Service

**Block Enforcement**:
- Filter out echoes from blocked users (both directions)
- Check: `IsBlocked(currentUserID, echoAuthorID)`
- Applied in: `GetHomeFeed` after echo hydration

**Mute Enforcement**:
- Filter out echoes from muted users (one direction)
- Check: `IsMuted(currentUserID, echoAuthorID)`
- Applied in: `GetHomeFeed` after echo hydration

**Implementation**:
```go
func (h *Handler) filterMutedAndBlockedEchoes(ctx context.Context, userID uuid.UUID, echoes []models.Echo) []models.Echo {
    filtered := make([]models.Echo, 0, len(echoes))
    for _, echo := range echoes {
        // Check block status (two-way)
        if isBlocked, _ := h.trustSafetyClient.IsBlocked(ctx, userID, echo.UserID); isBlocked {
            continue // Skip blocked user's echo
        }
        
        // Check mute status (one-way)
        if isMuted, _ := h.trustSafetyClient.IsMuted(ctx, userID, echo.UserID); isMuted {
            continue // Skip muted user's echo
        }
        
        filtered = append(filtered, echo)
    }
    return filtered
}
```

#### User Service

**Block Enforcement**:
- Hide blocked users from search results
- Hide blocked users from follower/following lists
- Prevent profile access (return 404 or "User not found")

**Implementation**: (To be added)
- Profile endpoint: Check if requester is blocked before returning profile
- Search endpoint: Filter out blocked users from results
- Follower lists: Filter out blocked users

#### Content Service

**Block Enforcement**:
- Prevent blocked users from viewing private echoes
- Filter blocked users from mentions/replies
- Hide blocked users' echoes in batch requests

**Implementation**: (To be added)
- Batch endpoint: Filter out echoes where block relationship exists
- Single echo endpoint: Return 404 if blocked

#### Discovery Service

**Block Enforcement**:
- Filter blocked users from search results
- Filter blocked users' echoes from search results
- Prevent blocked users from appearing in trending/suggestions

**Implementation**: (To be added)
- Search endpoint: Post-filter results to remove blocked users/echoes
- Trending endpoint: Exclude blocked users

#### Engagement Service

**Block Enforcement**:
- Prevent blocked users from liking/commenting
- Hide blocked users from like lists
- Filter blocked users from notifications

**Implementation**: (To be added)
- Like endpoint: Check block status before allowing like
- Notification generation: Don't generate notifications for blocked users

### Performance Characteristics

**Cache Hit (Hot Path)**:
- Latency: <1ms (Redis lookup)
- Throughput: 10,000+ checks/sec per service instance
- Memory: ~100 bytes per cached relationship

**Cache Miss (Cold Path)**:
- Latency: <50ms (HTTP call to Interaction Service)
- Throughput: 100+ checks/sec per service instance
- Database: Single indexed query to blocks/mutes table

**Cache Invalidation**:
- Latency: <10ms (NATS event → Redis delete)
- Propagation time: <100ms to all services
- Eventual consistency: Acceptable for Trust & Safety

**Scalability**:
- Services scale independently
- Redis can be clustered for horizontal scaling
- NATS consumer groups distribute invalidation load
- Each service caches only relationships it's seen recently

### Monitoring & Observability

**Key Metrics**:
- `trust_safety_cache_hits_total` - Redis cache hits
- `trust_safety_cache_misses_total` - Redis cache misses
- `trust_safety_check_duration_seconds` - Latency histogram
- `trust_safety_invalidation_events_total` - NATS events consumed
- `trust_safety_filtered_content_total` - Content filtered due to blocks/mutes

**Alerts**:
- Cache miss rate > 30% (indicates cold cache or too short TTL)
- Check latency p99 > 100ms (indicates Interaction Service slowness)
- Event consumer lag > 10 seconds (indicates NATS backlog)

### Security Considerations

**Privacy**:
- Block/mute lists are private (only visible to the user who created them)
- Blocked users are not notified
- Muted users are not notified
- Internal endpoints are not exposed to public internet

**Abuse Prevention**:
- Rate limiting on block/mute actions (prevent spam)
- Maximum block/mute count per user (e.g., 10,000)
- Audit logging for Trust & Safety review
- API endpoints require authentication

**Data Integrity**:
- Unique constraint on (blocker_id, blocked_id) prevents duplicates
- Foreign key constraints ensure user validity
- Cascade delete removes relationships when user deleted
- Cache invalidation prevents stale data

### Shared Trust & Safety Library

**Location**: `backend/shared/trustsafety/`

**Components**:

1. **CacheManager** (`cache.go`):
   - `IsBlockedCached(user1ID, user2ID)` - Check block cache
   - `IsMutedCached(muterID, mutedID)` - Check mute cache
   - `CacheBlockStatus()` - Store block status
   - `CacheMuteStatus()` - Store mute status
   - `InvalidateBlockCache()` - Clear block cache
   - `InvalidateMuteCache()` - Clear mute cache

2. **EventConsumer** (`consumer.go`):
   - `Start()` - Subscribe to user.blocked/unblocked/muted/unmuted
   - Event handlers automatically invalidate cache
   - Used by all services to consume Trust & Safety events

3. **Client** (`client.go`):
   - `IsBlocked(user1ID, user2ID)` - High-level check with cache fallback
   - `IsMuted(muterID, mutedID)` - High-level check with cache fallback
   - Handles cache misses by calling Interaction Service
   - Updates cache with results

**Usage in Services**:
```go
import "github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"

// Initialize consumer (invalidates cache on events)
tsConsumer := trustsafety.NewEventConsumer(natsConn, redisClient, "service-name")
tsConsumer.Start()

// Initialize client (checks with cache fallback)
tsClient := trustsafety.NewClient(redisClient, interactionServiceURL)

// Check block status
isBlocked, err := tsClient.IsBlocked(ctx, user1ID, user2ID)

// Check mute status
isMuted, err := tsClient.IsMuted(ctx, muterID, mutedID)
```

### Implementation Status

- ✅ Interaction Service: Block/Mute APIs with NATS events
- ✅ Shared Library: Cache manager, event consumer, client
- ✅ Feed Service: Cache invalidation and mute filtering
- ⏳ User Service: Profile and search filtering
- ⏳ Content Service: Batch endpoint filtering
- ⏳ Discovery Service: Search result filtering
- ⏳ Engagement Service: Like/comment prevention

### Future Enhancements

**Trust & Safety**:
- Report content/users
- Automated abuse detection
- Safety mode (filter sensitive content)
- Restricted mode (limit interactions to mutual follows)
- Block suggestions based on mutual blocks
- Mute duration (temporary mutes)
- Keyword muting

**Performance**:
- Bloom filters for negative caching (not blocked/muted)
- Batch check endpoints (check multiple relationships at once)
- Proactive cache warming for active users
- Read-through cache pattern for Interaction Service

**Analytics**:
- Block/mute statistics dashboard
- Abuse pattern detection
- User safety score
- Content toxicity scoring

## Conversation Thread Architecture

### Overview

The Ka platform implements a sophisticated conversation thread system that enables rich, context-aware discussions while maintaining high performance and graceful degradation. The system follows an **Adjacency List** data model for thread relationships and implements cursor-based pagination for replies.

### Data Modeling: Adjacency List vs Materialized Path

#### Our Choice: Adjacency List

We use an **Adjacency List** model where each Echo stores a reference to its parent via `parent_echo_id`:

```cql
CREATE TABLE echoes (
    id UUID PRIMARY KEY,
    user_id UUID,
    content TEXT,
    parent_echo_id UUID,  -- NULL for root echoes, UUID for replies
    ...
);

CREATE INDEX ON echoes (parent_echo_id);
```

**Why Adjacency List?**

1. **Write Simplicity**: Creating a reply only requires inserting one row with parent_echo_id
2. **Storage Efficiency**: Only stores direct parent relationship (O(1) per echo)
3. **Update Flexibility**: Easy to edit or delete individual echoes without affecting the entire path
4. **Query Patterns**: Our read patterns favor:
   - Getting direct replies (simple WHERE parent_echo_id = ?)
   - Walking up the ancestor chain (iterative parent lookups)
   - Most threads are shallow (1-3 levels), making multiple queries acceptable

**Trade-offs**:

✅ **Advantages**:
- Simple writes (single parent reference)
- Easy to maintain referential integrity
- Flexible for editing/deleting nodes
- Natural fit for ScyllaDB's partition model

❌ **Disadvantages**:
- N+1 queries to fetch full ancestor chain
- Cannot easily query "all descendants" without recursive logic
- Depth-first searches require multiple queries

#### Alternative: Materialized Path

A **Materialized Path** model stores the full path from root to current echo:

```cql
CREATE TABLE echoes (
    id UUID PRIMARY KEY,
    user_id UUID,
    content TEXT,
    path TEXT,  -- e.g., "/root-id/parent-id/echo-id"
    ...
);

CREATE INDEX ON echoes (path);
```

**Why We Didn't Choose It**:

While materialized paths enable powerful queries like "get all descendants," they have significant drawbacks:

❌ **Disadvantages**:
- **Complex Writes**: Must update paths of all descendants when an echo is deleted or moved
- **Storage Overhead**: Long paths for deep threads
- **Update Complexity**: Deleting a parent requires rewriting all descendant paths
- **No Native Support**: ScyllaDB doesn't have native path query operators (unlike PostgreSQL's ltree)

✅ **Advantages**:
- Single query for all descendants
- Efficient depth-first traversals
- Easy to find all echoes in a subtree

### Thread API Architecture

#### GET /api/v1/echoes/{echoId}/thread

Returns a complete thread view with three sections:

1. **Ancestors**: Chain from root to focus echo (oldest first)
2. **Focus**: The requested echo
3. **Replies**: Direct replies to focus echo (paginated, newest first)

**Response Structure**:
```json
{
  "success": true,
  "data": {
    "ancestors": [
      {
        "id": "uuid",
        "content": "Root echo",
        "is_liked_by_viewer": true,
        "author": {
          "user_id": "uuid",
          "is_followed_by_viewer": false
        }
      }
    ],
    "focus": {
      "id": "uuid",
      "content": "Focus echo",
      "is_liked_by_viewer": false,
      "author": {
        "user_id": "uuid",
        "is_followed_by_viewer": true
      }
    },
    "replies": [
      {
        "id": "uuid",
        "content": "Reply 1",
        "is_liked_by_viewer": false,
        "author": {
          "user_id": "uuid",
          "is_followed_by_viewer": false
        }
      }
    ],
    "next_cursor": "base64-encoded-cursor"
  }
}
```

**Algorithm**:
1. Fetch focus echo by ID
2. Walk up parent chain (iterative):
   ```go
   currentID := focusEcho.ParentEchoID
   for currentID != nil && depth < maxDepth {
       parent := getEchoByID(currentID)
       ancestors.prepend(parent)
       currentID = parent.ParentEchoID
       depth++
   }
   ```
3. Fetch direct replies (WHERE parent_echo_id = focusID ORDER BY created_at DESC LIMIT 21)
4. Check if more replies exist (fetched 21, return 20 + cursor)
5. Enrich all echoes with context (batch calls to Engagement/Interaction services)
6. Filter blocked/deleted echoes

**Performance**:
- **Ancestor Chain**: O(D) queries where D = depth (typically 1-3)
- **Replies**: O(1) query (indexed by parent_echo_id)
- **Context Enrichment**: 2 batch calls (Engagement + Interaction)
- **Total Time**: ~50-150ms for typical threads

**Depth Limit**: 10 levels to prevent infinite loops and stack overflow

### Context Enrichment

Each echo in the thread is enriched with viewer-specific context:

**Batch Calls**:
1. **Engagement Service**: `POST /api/internal/likes/batch-status`
   - Input: viewer_id, [echo_id_1, echo_id_2, ...]
   - Output: {echo_id: is_liked}
   - Sets `is_liked_by_viewer` for each echo

2. **Interaction Service**: `POST /api/internal/follows/batch-status`
   - Input: follower_id, [user_id_1, user_id_2, ...]
   - Output: {user_id: is_followed}
   - Sets `author.is_followed_by_viewer` for each echo

**Efficiency**:
- Single batch call per service (not N calls)
- Parallelizable (can call both services concurrently)
- Cached in Redis by the services (5-minute TTL)

**Graceful Degradation**:
- If Engagement Service fails → `is_liked_by_viewer = false` for all
- If Interaction Service fails → `is_followed_by_viewer = false` for all
- Thread still returns successfully with partial data

### Cursor-Based Pagination for Replies

#### GET /api/v1/echoes/{echoId}/replies?cursor={cursor}&limit={limit}

Pagination is implemented using **cursor-based** approach (not offset-based) for consistency and performance.

**Cursor Structure**:
```go
type Cursor struct {
    Timestamp time.Time  // created_at of last seen echo
    EchoID    uuid.UUID  // ID of last seen echo (for tie-breaking)
}
```

**Encoding**: Base64-encoded JSON
```
cursor: eyJ0cyI6IjIwMjQtMDEtMDFUMTI6MDA6MDAuMDAwWiIsImlkIjoiMTIzZS00NTY3LWU4OWItMTJkMy1hNDU2LTQyNjYxNDE3NDAwMCJ9
```

**Query**:
```cql
-- First page (no cursor)
SELECT * FROM echoes 
WHERE parent_echo_id = ? 
ORDER BY created_at DESC 
LIMIT ?

-- Subsequent pages (with cursor)
SELECT * FROM echoes 
WHERE parent_echo_id = ? AND created_at < ?
ORDER BY created_at DESC 
LIMIT ?
```

**Algorithm**:
1. Decode cursor (if provided)
2. Fetch limit+1 replies (to check if more exist)
3. If result size > limit:
   - Take first `limit` items
   - Create next_cursor from last item
4. Enrich with context
5. Filter blocked/deleted
6. Return replies + next_cursor

**Why Not Offset-Based?**

Offset-based pagination has critical flaws:

❌ **Problems**:
- **Inconsistency**: If new replies are added, user sees duplicates or skips
- **Performance**: OFFSET N requires scanning N rows (O(N) instead of O(1))
- **No ScyllaDB Support**: ScyllaDB doesn't support efficient OFFSET

✅ **Cursor Advantages**:
- **Consistent**: Always returns items after cursor position
- **Performant**: Uses WHERE clause (indexed) instead of OFFSET
- **Stateless**: Cursor encodes all pagination state
- **Forward-Only**: Natural for infinite scroll UX

### Edge Case Handling

#### Deleted Echoes

When an echo in the ancestor chain has been deleted:

**Response**:
```json
{
  "id": "deleted-echo-uuid",
  "status": "deleted",
  "author": {
    "user_id": "00000000-0000-0000-0000-000000000000",
    "is_followed_by_viewer": false
  }
}
```

**Behavior**:
- Client can still render the thread structure
- Show "This echo has been deleted" placeholder
- Continue walking up the chain (don't break)
- Replies to deleted echo remain accessible

#### Blocked Users

When a user in the thread has blocked the viewer or vice versa:

**Response**:
```json
{
  "id": "blocked-echo-uuid",
  "status": "blocked",
  "author": {
    "user_id": "00000000-0000-0000-0000-000000000000",
    "is_followed_by_viewer": false
  }
}
```

**Filtering**:
- Checked via Trust & Safety client (Redis cache)
- Both directions: viewer blocked author OR author blocked viewer
- Placeholder prevents leaking blocked user info
- Client shows "Content hidden" or similar UI

**Performance**: <1ms per check (Redis cache hit)

### Future Evolution

#### Short-Term Improvements

1. **Parallel Ancestor Fetching**:
   - Currently: Sequential parent lookups (O(D) network calls)
   - Future: Batch fetch by IDs (O(1) network call)
   - Challenge: Need to fetch entire ancestor chain to know all IDs

2. **Reply Counts**:
   - Add `reply_count` field to echoes table
   - Increment on reply creation (via NATS event)
   - Enables "View N more replies" UI

3. **Nested Replies (Expand)**:
   - Endpoint: `GET /api/v1/echoes/{echoId}/replies?expand=1`
   - Returns replies + their first-level sub-replies
   - Reduces number of API calls for deep discussions

#### Long-Term Evolution

1. **Hybrid Model (Adjacency List + Materialized Path)**:
   - Store both `parent_echo_id` and `path`
   - Use adjacency list for writes
   - Use materialized path for complex queries
   - Update paths asynchronously via NATS events

2. **Graph Database (Neo4j) for Threads**:
   - Better for complex graph queries
   - Native support for depth-first/breadth-first traversals
   - "Find all echoes in this subtree" becomes trivial
   - Trade-off: Operational complexity (another database)

3. **Tree Caching in Redis**:
   - Cache entire thread structure in Redis
   - Key: `thread:{root_echo_id}`
   - Invalidate on reply/delete (via NATS)
   - Serve hot threads from cache (O(1))

4. **Denormalized Thread View**:
   - Materialized view for popular threads
   - Pre-computed ancestor chains and reply trees
   - Updated asynchronously
   - Serve from dedicated read replicas

### Monitoring & Observability

**Key Metrics**:
- `thread_fetch_duration_seconds` - P50, P95, P99 latency
- `thread_ancestor_depth_histogram` - Distribution of thread depths
- `thread_replies_count_histogram` - Distribution of reply counts
- `thread_enrichment_failures_total` - Context enrichment errors
- `thread_deleted_echoes_total` - Placeholder usage rate
- `thread_blocked_echoes_total` - Block filtering rate

**Alerts**:
- Thread fetch latency P95 > 200ms
- Enrichment failure rate > 5%
- Ancestor chain depth > 8 (indicates possible cycle)

### Implementation Status

- ✅ **Adjacency List Data Model**: Complete
- ✅ **GET /api/v1/echoes/{echoId}/thread**: Complete
- ✅ **GET /api/v1/echoes/{echoId}/replies**: Complete
- ✅ **Cursor-Based Pagination**: Complete
- ✅ **Context Enrichment (is_liked_by_viewer)**: Complete
- ✅ **Context Enrichment (is_followed_by_viewer)**: Complete
- ✅ **Deleted Echo Placeholders**: Complete
- ✅ **Blocked User Filtering**: Complete
- ✅ **Batch Internal Endpoints**: Complete (Engagement + Interaction services)
- ✅ **Documentation**: Complete

## Ka+ Monetization & Entitlements System

### Overview

Ka+ is the premium subscription tier that unlocks advanced features. The system is built on a **JWT-based entitlements architecture** that ensures:
- **Zero-latency access checks**: Entitlements embedded directly in JWT
- **Stateless feature gating**: No database queries for every request
- **Decoupled services**: Services never call Billing Service for checks
- **Event-driven cache management**: Real-time entitlement updates

### Architecture Principles

1. **Billing Service is Source of Truth**: Only Billing Service manages subscriptions and entitlements
2. **Auth Service Embeds Entitlements**: Login/refresh operations fetch entitlements and embed in JWT
3. **Services Inspect JWT**: All feature checks are local JWT inspections (sub-millisecond)
4. **Event-Driven Invalidation**: Subscription changes trigger NATS events for cache updates

### Billing Service

**Purpose**: Manage subscriptions, payments, and entitlements via Stripe integration

**Responsibilities**:
- Create Stripe Checkout sessions for Ka+ subscription
- Handle Stripe webhooks for subscription lifecycle events
- Grant/revoke entitlements based on subscription status
- Provide internal API for Auth Service to fetch entitlements
- Publish subscription events to NATS
- Cache entitlements in Redis (5-minute TTL)

**Tech Stack**:
- Language: Go
- Framework: Gin
- Database: PostgreSQL (subscriptions, entitlements)
- Cache: Redis (entitlement caching)
- Payment Provider: Stripe
- Message Broker: NATS

**Key Endpoints**:
- `POST /api/v1/billing/checkout` - Create Stripe Checkout session (authenticated)
- `GET /api/v1/billing/subscription` - Get user's subscription (authenticated)
- `POST /api/v1/billing/webhook` - Stripe webhook handler (public)
- `GET /api/internal/billing/entitlements/:userId` - Get user entitlements (internal)

**Database Schema**:
```sql
-- Subscriptions table
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    stripe_customer_id VARCHAR(255) NOT NULL,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    status VARCHAR(50) NOT NULL, -- active, canceled, past_due, trialing
    current_period_start TIMESTAMP NOT NULL,
    current_period_end TIMESTAMP NOT NULL,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    canceled_at TIMESTAMP
);

-- Entitlements table
CREATE TABLE entitlements (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    feature VARCHAR(100) NOT NULL, -- PROFILE_BADGE, EXTENDED_UPLOADS, ADVANCED_ANALYTICS
    granted_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP, -- NULL means no expiration
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, feature)
);
```

**Stripe Integration Flow**:

1. **Checkout Session Creation**:
   ```
   User clicks "Upgrade to Ka+" → Client calls /api/v1/billing/checkout
   → Billing Service creates Stripe Customer (if new)
   → Billing Service creates Checkout Session
   → User redirected to Stripe hosted page
   → User completes payment on Stripe
   ```

2. **Webhook Processing**:
   ```
   Stripe → POST /api/v1/billing/webhook (checkout.session.completed)
   → Billing Service validates signature
   → Extract user_id from session metadata
   
   Stripe → POST /api/v1/billing/webhook (customer.subscription.created)
   → Create subscription in database
   → Grant entitlements: PROFILE_BADGE, EXTENDED_UPLOADS, ADVANCED_ANALYTICS
   → Publish subscription.activated event to NATS
   → Invalidate entitlements cache
   
   Stripe → POST /api/v1/billing/webhook (customer.subscription.updated)
   → Update subscription status
   → Update entitlements based on status
   → Publish subscription.activated or subscription.canceled event
   
   Stripe → POST /api/v1/billing/webhook (customer.subscription.deleted)
   → Mark subscription as canceled
   → Revoke all entitlements
   → Publish subscription.canceled event
   ```

**Event Publications**:
- `subscription.activated` - User subscribed to Ka+
- `subscription.canceled` - User canceled Ka+ subscription

**Implementation Status**: ✅ Complete with Stripe integration

### JWT Entitlements Architecture

**JWT Payload Structure**:
```json
{
  "sub": "user_id",
  "username": "johndoe",
  "role": "user",
  "is_premium": true,
  "entitlements": [
    "PROFILE_BADGE",
    "EXTENDED_UPLOADS",
    "ADVANCED_ANALYTICS"
  ],
  "exp": 1234567890,
  "iat": 1234567890
}
```

**Auth Service Flow**:

1. **Login**:
   ```
   User logs in → Auth Service validates credentials
   → Call Billing Service: GET /api/internal/billing/entitlements/{user_id}
   → Receive entitlements array
   → Generate JWT with entitlements embedded
   → Return JWT to client
   ```

2. **Token Refresh**:
   ```
   Client sends refresh token → Auth Service validates refresh token
   → Call Billing Service: GET /api/internal/billing/entitlements/{user_id}
   → Generate new JWT with updated entitlements
   → Return new JWT to client
   ```

**Entitlement Caching**:
- Billing Service caches entitlements in Redis (5-minute TTL)
- Cache key: `entitlements:{user_id}`
- Cache invalidated on subscription changes
- Auth Service gets sub-50ms response from cache hit

**Implementation Status**: ✅ Complete

### Stateless Feature Gating

**All services perform local JWT inspection**:

```go
// Get entitlements from context (set by auth middleware)
entitlements := utils.GetEntitlementsFromContext(c)

// Check for specific entitlement
if utils.HasEntitlement(entitlements, utils.EntitlementExtendedUploads) {
    // Allow 4 images
} else {
    // Allow 1 image
}
```

**Benefits**:
- **Zero latency**: No network calls, just array lookup
- **Scalable**: No database queries for each feature check
- **Reliable**: Works even if Billing Service is down
- **Simple**: Single function call to check access

**Implementation Status**: ✅ Complete in all services

### Ka+ Premium Features

#### 1. PROFILE_BADGE (User Service)

**Feature**: Visual badge on user profile indicating Ka+ subscription

**Implementation**:
- User Service checks if profile owner has `PROFILE_BADGE` entitlement
- For own profile: Uses entitlements from JWT (instant)
- For other profiles: Calls Billing Service (cacheable)
- Adds `has_ka_plus: true` to UserProfile response

**API Response**:
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "username": "johndoe",
    "display_name": "John Doe",
    "has_ka_plus": true,
    ...
  }
}
```

**Performance**: Sub-1ms for own profile, <50ms for other profiles

**Implementation Status**: ✅ Complete

#### 2. EXTENDED_UPLOADS (Content Service)

**Feature**: Upload 4 images per echo (vs 1 for free users)

**Implementation**:
- Content Service checks `EXTENDED_UPLOADS` entitlement from JWT
- Free users: Limited to 1 image per echo
- Ka+ users: Can attach up to 4 images per echo
- Validation occurs before media ownership check

**Error Response** (free user tries to upload 4 images):
```json
{
  "success": false,
  "error": {
    "code": "MEDIA_LIMIT_EXCEEDED",
    "message": "Too many media attachments. Free users can attach 1 image, Ka+ users can attach 4 images.",
    "details": {
      "max_allowed": 1,
      "provided": 4
    }
  }
}
```

**Performance**: Zero latency (JWT inspection only)

**Implementation Status**: ✅ Complete

#### 3. ADVANCED_ANALYTICS (Engagement Service)

**Feature**: Detailed engagement analytics for echoes

**Implementation**:
- New endpoint: `GET /api/v1/echoes/:echoId/analytics`
- Requires `ADVANCED_ANALYTICS` entitlement
- Returns detailed metrics:
  - Total likes and views
  - Engagement rate
  - Hourly like distribution
  - Daily like distribution (last 7 days)
  - Top likers

**API Response**:
```json
{
  "success": true,
  "data": {
    "echo_id": "uuid",
    "total_likes": 142,
    "total_views": 1420,
    "engagement_rate": 10.0,
    "hourly_likes": {
      "0": 5, "1": 2, "2": 1, "3": 0, ...
    },
    "daily_likes": {
      "2024-01-07": 45,
      "2024-01-06": 32,
      ...
    },
    "top_likers": [
      {"user_id": "uuid", "liked_at": "2024-01-07T12:00:00Z"},
      ...
    ],
    "analytics_period": "last_7_days",
    "generated_at": "2024-01-07T15:30:00Z"
  }
}
```

**Error Response** (non-Ka+ user):
```json
{
  "success": false,
  "error": {
    "code": "ENTITLEMENT_REQUIRED",
    "message": "This feature requires a Ka+ subscription",
    "details": {
      "required_entitlement": "ADVANCED_ANALYTICS",
      "upgrade_url": "/api/v1/billing/checkout"
    }
  }
}
```

**Performance**: ~50-100ms (database query + calculation)

**Implementation Status**: ✅ Complete

### Entitlement Constants

**Available Entitlements**:
```go
const (
    EntitlementProfileBadge      = "PROFILE_BADGE"
    EntitlementExtendedUploads   = "EXTENDED_UPLOADS"
    EntitlementAdvancedAnalytics = "ADVANCED_ANALYTICS"
)
```

**Future Entitlements** (planned):
- `PRIORITY_SUPPORT` - Priority customer support
- `CUSTOM_THEMES` - Custom profile themes
- `AD_FREE` - Ad-free experience
- `VERIFICATION_BADGE` - Expedited verification process
- `BULK_SCHEDULING` - Schedule multiple echoes
- `ADVANCED_SEARCH` - Advanced search filters
- `EXPORT_DATA` - Export analytics data

### Performance Characteristics

**Billing Service**:
- Entitlement fetch (cache hit): <10ms
- Entitlement fetch (cache miss): <50ms
- Stripe Checkout creation: <200ms
- Webhook processing: <100ms

**Auth Service**:
- Login with entitlements fetch: +50ms overhead
- Token refresh with entitlements: +50ms overhead
- JWT generation: <5ms

**Feature Services**:
- Entitlement check: <1ms (JWT inspection)
- No performance degradation vs non-premium features
- No additional database queries

**Scalability**:
- Auth Service: Scales horizontally (stateless)
- Billing Service: Scales horizontally (Redis cache shared)
- Feature checks: Zero additional load (JWT inspection)
- Stripe: Handles millions of transactions per day

### Security Considerations

**JWT Security**:
- Entitlements cannot be forged (signed with secret key)
- Short expiration (15 minutes) ensures fresh entitlements
- Refresh flow re-fetches entitlements from Billing Service
- Even if JWT is stolen, attacker only gets 15 min access

**Stripe Security**:
- Webhook signature validation prevents spoofing
- Customer IDs prevent cross-account access
- PCI compliant payment processing
- Stripe manages sensitive payment data

**Entitlement Verification**:
- All feature checks done server-side
- Client cannot bypass entitlement checks
- JWT inspection is cryptographically secure
- Services fail closed (deny if entitlement missing)

### Monitoring & Observability

**Key Metrics**:
- `billing_subscriptions_total` - Total Ka+ subscriptions
- `billing_checkout_sessions_created_total` - Checkout sessions created
- `billing_webhook_events_total` - Stripe webhooks processed
- `billing_entitlement_fetch_duration_seconds` - Entitlement fetch latency
- `auth_token_generation_with_entitlements_duration` - Login/refresh latency
- `feature_entitlement_checks_total` - Feature checks performed
- `feature_entitlement_denials_total` - Feature access denied

**Alerts**:
- Billing Service down (critical)
- Entitlement fetch latency > 100ms (warning)
- Stripe webhook processing failures (critical)
- Cache miss rate > 50% (warning)
- Subscription churn rate > 10% (warning)

### User Experience Flow

**Upgrading to Ka+**:
1. User clicks "Upgrade to Ka+" in app
2. Client calls: `POST /api/v1/billing/checkout`
   - Receives Stripe Checkout URL
3. User redirected to Stripe (or in-app webview)
4. User completes payment on Stripe
5. Stripe webhook → Billing Service
   - Subscription created
   - Entitlements granted
   - Event published to NATS
6. User redirected to success URL
7. App shows success message
8. **Next login**: User receives JWT with entitlements
9. App shows Ka+ features unlocked

**Using Ka+ Features**:
1. User creates echo with 4 images (was limited to 1)
2. Content Service checks JWT: `EXTENDED_UPLOADS` present → Allow
3. User views their profile → See Ka+ badge
4. User accesses analytics → Engagement Service checks JWT → Allow

**Subscription Cancellation**:
1. User cancels via Stripe customer portal
2. Stripe webhook → Billing Service
   - Subscription marked as `cancel_at_period_end`
   - Entitlements remain until period end
3. At period end → Stripe sends `subscription.deleted`
   - Entitlements revoked
   - Event published to NATS
4. **Next login**: JWT has no entitlements
5. Ka+ features become inaccessible

### Future Enhancements

**Monetization**:
- **Ka+ Annual Plan**: Discounted annual subscription
- **Ka+ Family Plan**: Share subscription with up to 5 users
- **Ka+ Business**: For brands and businesses
- **Pay-per-feature**: À la carte feature purchases
- **Subscription Gifts**: Gift Ka+ to other users

**Entitlements**:
- **Time-limited entitlements**: Trial periods, temporary grants
- **Usage-based entitlements**: API rate limits, storage quotas
- **Feature bundles**: Combine entitlements into packages
- **Referral rewards**: Earn free Ka+ months

**Technical**:
- **Entitlement versioning**: Support multiple entitlement schemas
- **A/B testing**: Feature flags combined with entitlements
- **Revenue analytics**: Subscription metrics dashboard
- **Churn prediction**: ML model to predict cancellations

### Implementation Status Summary

- ✅ **Billing Service**: Complete with Stripe integration
- ✅ **JWT Entitlements**: Complete with Auth Service integration
- ✅ **Profile Badge**: Complete in User Service
- ✅ **Extended Uploads**: Complete in Content Service
- ✅ **Advanced Analytics**: Complete in Engagement Service
- ✅ **Database Schema**: Complete with migrations
- ✅ **NATS Events**: Complete for subscription lifecycle
- ✅ **Redis Caching**: Complete for entitlement caching

## Future Enhancements

### Phase 2 Features
- **Dark Mode**: Theme switching in UI
- **Ka Spaces**: Live audio rooms (like Twitter Spaces)
- ✅ **Advanced Analytics**: Detailed insights for Ka+ users (IMPLEMENTED)
- **Groups/Communities**: Create and join topic-based communities
- **Stories (Instagram-style)**: 24-hour ephemeral content
- **Video Calling**: One-on-one and group video calls
- **Feed Service**: Event-driven feed generation consuming echo.created events
- **Notification Service**: Real-time notifications via event subscriptions

### Technical Improvements
- ✅ **Event-Driven Architecture**: Implemented with NATS for Content Service
- ✅ **Trust & Safety**: Block and Mute with event-driven cache invalidation
- ✅ **Monetization System**: Ka+ subscription with JWT entitlements (IMPLEMENTED)
- **Event-Driven Expansion**: Migrate Interaction Service and other services to NATS
- **Event Replay**: Implement event sourcing for data recovery
- GraphQL API (in addition to REST)
- Elasticsearch for advanced search
- Machine Learning recommendation engine
- CDN for media delivery
- Multi-region deployment with NATS clustering
- Progressive Web App (PWA)
- **Distributed Tracing**: Jaeger or Tempo for event flow visibility

## Conclusion

This architecture is designed to be scalable, maintainable, and performant from day one. The **event-driven Content Service** demonstrates our commitment to building for scale, with NATS providing fast, reliable event distribution. The microservices approach allows independent scaling and development, while the polyglot persistence strategy ensures we use the right tool for each job.

The **Ka+ monetization system** exemplifies our architectural principles: decoupled services, JWT-based stateless access control, and event-driven cache management. This enables zero-latency feature checks while maintaining consistency across services.

**Key Architectural Decisions**:
1. **Event-Driven Content Service**: Fast write path with immediate user feedback
2. **NATS Message Broker**: Lightweight, performant, and Go-native
3. **Hybrid Communication**: Event-driven for write-heavy ops, synchronous for consistency-critical ops
4. **ScyllaDB for Content**: Fast writes and reads at scale
5. **PostgreSQL for Relations**: ACID guarantees for critical relationships
6. **JWT Entitlements**: Stateless, zero-latency feature gating
7. **Stripe Integration**: Professional payment processing

With proper caching, event-driven processing, JWT-based entitlements, and a focus on low-bandwidth support, Ka will deliver an excellent user experience to our target markets in the Arab World, Africa, and Asia. The platform is ready to scale from thousands to millions of users while maintaining fast response times, high availability, and professional-grade monetization.
