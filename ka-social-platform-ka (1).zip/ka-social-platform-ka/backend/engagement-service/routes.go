package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes configures the routes for the engagement service
func SetupRoutes(router *gin.Engine, handler *Handler, jwtSecret string) {
	// API v1 routes
	v1 := router.Group("/api/v1")
	{
		// Like/Unlike endpoints (protected)
		echoes := v1.Group("/echoes")
		echoes.Use(middleware.AuthMiddleware(jwtSecret))
		{
			echoes.POST("/:echoId/like", handler.LikeEcho)
			echoes.DELETE("/:echoId/like", handler.UnlikeEcho)
			echoes.GET("/:echoId/analytics", handler.GetEchoAnalytics) // Ka+ only
		}

		// Notifications endpoints (protected)
		notifications := v1.Group("/notifications")
		notifications.Use(middleware.AuthMiddleware(jwtSecret))
		{
			notifications.GET("", handler.GetNotifications)
		}
	}

	// WebSocket endpoint
	ws := router.Group("/ws/v1")
	{
		ws.GET("/notifications", handler.HandleWebSocket)
	}

	// Internal endpoints (no authentication - for service-to-service calls)
	internal := router.Group("/api/internal")
	{
		internal.POST("/likes/batch-status", handler.GetBatchLikeStatus)
	}
}
