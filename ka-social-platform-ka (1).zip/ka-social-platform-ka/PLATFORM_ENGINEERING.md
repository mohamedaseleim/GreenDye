# Ka Platform - Platform Engineering Documentation

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Infrastructure as Code](#infrastructure-as-code)
4. [Helm Chart Structure](#helm-chart-structure)
5. [GitOps Workflow](#gitops-workflow)
6. [Observability Stack](#observability-stack)
7. [Deployment Guide](#deployment-guide)
8. [Operations](#operations)
9. [Security](#security)
10. [Disaster Recovery](#disaster-recovery)
11. [Troubleshooting](#troubleshooting)

---

## Overview

The Ka Platform is a cloud-native social media platform built on modern DevOps principles. This document describes the complete operational infrastructure, from cluster provisioning to continuous deployment and monitoring.

### Key Technologies

- **Container Orchestration**: Kubernetes
- **Package Management**: Helm 3
- **GitOps**: Argo CD
- **CI/CD**: GitHub Actions
- **Infrastructure as Code**: Terraform
- **Monitoring**: Prometheus, Grafana
- **Logging**: Loki, Promtail
- **Cloud Providers**: DigitalOcean DOKS, Google GKE

### Design Principles

1. **Cloud-Native**: Built for Kubernetes from the ground up
2. **GitOps**: Declarative infrastructure and application management
3. **Observability**: Comprehensive metrics, logs, and traces
4. **Scalability**: Horizontal pod autoscaling and cluster autoscaling
5. **Security**: Least privilege, secret management, network policies
6. **Resilience**: High availability, automated failover, disaster recovery

---

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Cloud Provider                           │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │              Kubernetes Cluster (GKE/DOKS)                 │  │
│  │                                                             │  │
│  │  ┌──────────────────────────────────────────────────────┐ │  │
│  │  │                 ka-platform Namespace                 │ │  │
│  │  │                                                        │ │  │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │ │  │
│  │  │  │ Auth Service│  │ User Service│  │Content Svc  │  │ │  │
│  │  │  └─────────────┘  └─────────────┘  └─────────────┘  │ │  │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │ │  │
│  │  │  │ Feed Service│  │Discovery Svc│  │ Media Svc   │  │ │  │
│  │  │  └─────────────┘  └─────────────┘  └─────────────┘  │ │  │
│  │  │                                                        │ │  │
│  │  │  ┌──────────┐  ┌─────────┐  ┌──────────┐           │ │  │
│  │  │  │PostgreSQL│  │  Redis  │  │ ScyllaDB │           │ │  │
│  │  │  └──────────┘  └─────────┘  └──────────┘           │ │  │
│  │  │  ┌──────────┐  ┌─────────┐  ┌──────────┐           │ │  │
│  │  │  │   NATS   │  │  MinIO  │  │Meilisearch│          │ │  │
│  │  │  └──────────┘  └─────────┘  └──────────┘           │ │  │
│  │  └────────────────────────────────────────────────────┘ │  │
│  │                                                             │  │
│  │  ┌──────────────────────────────────────────────────────┐ │  │
│  │  │              Observability Stack                      │ │  │
│  │  │  ┌────────────┐  ┌─────────┐  ┌──────────┐          │ │  │
│  │  │  │ Prometheus │  │ Grafana │  │   Loki   │          │ │  │
│  │  │  └────────────┘  └─────────┘  └──────────┘          │ │  │
│  │  └──────────────────────────────────────────────────────┘ │  │
│  │                                                             │  │
│  │  ┌──────────────────────────────────────────────────────┐ │  │
│  │  │                   argocd Namespace                    │ │  │
│  │  │  ┌────────────┐  ┌─────────────┐  ┌──────────────┐  │ │  │
│  │  │  │ Argo Server│  │Repo Server  │  │App Controller│  │ │  │
│  │  │  └────────────┘  └─────────────┘  └──────────────┘  │ │  │
│  │  └──────────────────────────────────────────────────────┘ │  │
│  └─────────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐         │
│  │Load Balancer│  │Managed DBs   │  │Object Storage  │         │
│  └─────────────┘  └──────────────┘  └────────────────┘         │
└─────────────────────────────────────────────────────────────────┘

                            ↕ GitOps Sync
                            
┌─────────────────────────────────────────────────────────────────┐
│                        GitHub Repository                          │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────┐        │
│  │ Source Code │  │  Helm Charts │  │ GitHub Actions  │        │
│  └─────────────┘  └──────────────┘  └─────────────────┘        │
└─────────────────────────────────────────────────────────────────┘
```

### Components

#### Application Services (9 microservices)

1. **Auth Service** (Port 8001): Authentication and authorization
2. **User Service** (Port 8002): User profile management
3. **Content Service** (Port 8003): Post and content management
4. **Feed Service** (Port 8004): Personalized feed generation
5. **Interaction Service** (Port 8005): Likes, follows, comments
6. **Engagement Service** (Port 8007): User engagement tracking
7. **Discovery Service** (Port 8008): Content discovery and search
8. **Media Service** (Port 8009): Media upload and processing
9. **Billing Service** (Port 8010): Payment and subscription management

#### Data Layer

- **PostgreSQL**: Relational data (users, relationships, transactions)
- **Redis**: Caching and session management
- **ScyllaDB**: High-throughput NoSQL (posts, timelines, notifications)
- **NATS**: Message bus for event-driven architecture
- **MinIO**: S3-compatible object storage for media
- **Meilisearch**: Full-text search engine

---

## Infrastructure as Code

### Terraform Structure

```
terraform/
├── digitalocean/
│   ├── main.tf           # DOKS cluster, VPC, databases
│   ├── variables.tf      # Input variables
│   ├── outputs.tf        # Output values
│   └── terraform.tfvars.example
└── gcp/
    ├── main.tf           # GKE cluster, VPC, databases
    ├── variables.tf      # Input variables
    ├── outputs.tf        # Output values
    └── terraform.tfvars.example
```

### Cloud Provider Comparison

| Feature | DigitalOcean | Google Cloud |
|---------|--------------|--------------|
| Kubernetes | DOKS | GKE |
| Cost | Lower ($160+/mo) | Higher ($300+/mo) |
| Managed PostgreSQL | ✅ | ✅ Cloud SQL |
| Managed Redis | ✅ | ✅ Memorystore |
| Object Storage | Spaces | Cloud Storage |
| CDN | Integrated | Cloud CDN |
| Global Reach | Limited | Extensive |
| Best For | Startups, MVPs | Enterprise, Scale |

### Provisioning Steps

1. **Choose Provider**: Select DigitalOcean or GCP based on requirements
2. **Configure Variables**: Copy `terraform.tfvars.example` to `terraform.tfvars`
3. **Initialize**: `terraform init`
4. **Plan**: `terraform plan`
5. **Apply**: `terraform apply`
6. **Configure kubectl**: Use output commands to configure access

---

## Helm Chart Structure

### Chart Hierarchy

```
charts/ka-platform/
├── Chart.yaml                    # Parent chart metadata
├── values.yaml                   # Global configuration
├── templates/
│   └── secrets.yaml             # Platform-wide secrets
└── charts/
    ├── api-services/            # API services sub-chart
    │   ├── Chart.yaml
    │   ├── values.yaml
    │   └── templates/
    │       ├── deployment.yaml  # Service deployments
    │       ├── service.yaml     # Kubernetes services
    │       ├── ingress.yaml     # Ingress configuration
    │       └── hpa.yaml         # Horizontal Pod Autoscaler
    └── databases/               # Database sub-chart
        ├── Chart.yaml
        ├── values.yaml
        └── templates/
            ├── postgres.yaml    # PostgreSQL StatefulSet
            ├── redis.yaml       # Redis StatefulSet
            ├── scylla.yaml      # ScyllaDB StatefulSet
            ├── nats.yaml        # NATS StatefulSet
            ├── minio.yaml       # MinIO StatefulSet
            └── meilisearch.yaml # Meilisearch StatefulSet
```

### Configuration Management

#### Global Values (`values.yaml`)

```yaml
global:
  domain: ka-platform.io           # Platform domain
  environment: production          # Environment
  imageRegistry: ghcr.io/...      # Container registry
  imagePullPolicy: IfNotPresent   # Pull policy
  
  secrets:                         # Centralized secrets
    jwtSecret: "..."
    redisPassword: "..."
    postgresPassword: "..."
  
  resources:                       # Resource templates
    small: { cpu: 100m, mem: 128Mi }
    medium: { cpu: 200m, mem: 256Mi }
    large: { cpu: 500m, mem: 512Mi }
```

#### Service Configuration

Each service can be individually configured:

```yaml
api-services:
  services:
    auth:
      enabled: true
      port: 8001
      image: auth-service
      tag: latest
      resources: medium
      env:
        JWT_EXPIRY: "900"
```

### Deployment Commands

```bash
# Install the chart
helm install ka-platform ./charts/ka-platform \
  --namespace ka-platform \
  --create-namespace \
  --values ./charts/ka-platform/values.yaml

# Upgrade the release
helm upgrade ka-platform ./charts/ka-platform \
  --namespace ka-platform

# Rollback to previous version
helm rollback ka-platform 1 --namespace ka-platform

# Uninstall
helm uninstall ka-platform --namespace ka-platform
```

---

## GitOps Workflow

### Architecture

```
┌──────────────┐
│  Developer   │
└──────┬───────┘
       │ git push
       ↓
┌──────────────────┐
│ GitHub Repository│
└──────┬───────────┘
       │
       ├─→ GitHub Actions (CI)
       │   ├─ Build Docker images
       │   ├─ Run tests
       │   ├─ Security scan
       │   └─ Update values.yaml
       │
       ↓
┌──────────────────┐
│  Updated Repo    │
└──────┬───────────┘
       │
       ↓ Watches
┌──────────────────┐
│    Argo CD       │
└──────┬───────────┘
       │
       ↓ Syncs
┌──────────────────┐
│ Kubernetes Cluster│
└────────────────────┘
```

### Continuous Integration (GitHub Actions)

The CI pipeline performs:

1. **Build Phase**:
   - Build Docker images for all services
   - Tag with git SHA and semantic version
   - Push to GitHub Container Registry

2. **Test Phase**:
   - Run unit tests
   - Run integration tests
   - Security vulnerability scanning

3. **Deploy Phase**:
   - Update image tags in `values.yaml`
   - Commit changes back to repository
   - Argo CD detects changes automatically

### Continuous Deployment (Argo CD)

Argo CD configuration:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: ka-platform
spec:
  source:
    repoURL: https://github.com/mohamedaseleim/ka-social-platform.git
    targetRevision: main
    path: charts/ka-platform
  destination:
    server: https://kubernetes.default.svc
    namespace: ka-platform
  syncPolicy:
    automated:
      prune: true      # Remove old resources
      selfHeal: true   # Automatically fix drift
```

### Deployment Process

1. **Code Change**: Developer pushes code
2. **CI Trigger**: GitHub Actions builds and tests
3. **Image Update**: New images tagged and pushed
4. **Values Update**: `values.yaml` updated with new tags
5. **Auto-Sync**: Argo CD detects and syncs changes
6. **Rolling Update**: Kubernetes performs rolling deployment
7. **Health Check**: Argo CD monitors deployment health

### Rollback Process

```bash
# View deployment history
argocd app history ka-platform

# Rollback to specific revision
argocd app rollback ka-platform 123

# Or use Helm
helm rollback ka-platform 1 --namespace ka-platform
```

---

## Observability Stack

### Architecture

```
┌─────────────────────────────────────────────────────┐
│                 Application Pods                     │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐       │
│  │  Service  │  │  Service  │  │  Service  │       │
│  │  /metrics │  │  /metrics │  │  /metrics │       │
│  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘       │
│        │              │              │              │
│        │ Logs         │ Logs         │ Logs         │
│        ↓              ↓              ↓              │
│  ┌──────────────────────────────────────────┐      │
│  │          Container Logs                   │      │
│  └──────────────────┬───────────────────────┘      │
└─────────────────────┼──────────────────────────────┘
                      │
         ┌────────────┼────────────┐
         │            │            │
         ↓            ↓            ↓
    Prometheus    Promtail       Logs
    (Metrics)     (Shipper)
         │            │
         ↓            ↓
    ┌─────────┐  ┌────────┐
    │ Grafana │  │  Loki  │
    │ (Visual)│  │ (Store)│
    └─────────┘  └────────┘
```

### Prometheus

**Purpose**: Metrics collection and alerting

**Metrics Exposed**:
- HTTP request count and latency
- Database query performance
- Cache hit/miss rates
- Business metrics (posts created, users registered)
- Pod resource usage (CPU, memory)

**Configuration**:
```yaml
scrape_configs:
  - job_name: 'ka-services'
    kubernetes_sd_configs:
      - role: pod
        namespaces:
          names: [ka-platform]
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
        action: keep
        regex: true
```

**Access**:
```bash
kubectl port-forward -n ka-platform svc/prometheus 9090:9090
# Open http://localhost:9090
```

### Grafana

**Purpose**: Metrics visualization

**Pre-configured Dashboards**:
1. **API Gateway Traffic**: Request rates, latency, errors
2. **Database Performance**: Query latency, connection pools
3. **Cache Performance**: Hit rates, memory usage
4. **Pod Resources**: CPU, memory, network
5. **Business Metrics**: User activity, content creation

**Access**:
```bash
kubectl port-forward -n ka-platform svc/grafana 3000:3000
# Open http://localhost:3000
# Username: admin
# Password: (from secret)
```

### Loki & Promtail

**Purpose**: Log aggregation and querying

**Log Collection**:
- Promtail runs as DaemonSet on every node
- Collects logs from all pods
- Ships to Loki for storage and indexing

**Query Examples**:
```logql
# All logs from auth-service
{app="auth-service"}

# Error logs across all services
{namespace="ka-platform"} |= "error"

# Slow queries
{app="content-service"} |~ "query took [0-9]+ms" | regexp "query took (?P<duration>[0-9]+)ms" | duration > 1000
```

**Access**:
```bash
kubectl port-forward -n ka-platform svc/loki 3100:3100
# Query via Grafana UI
```

### Service Instrumentation

Go services use Prometheus client library:

```go
import (
    "github.com/mohamedaseleim/ka-social-platform/backend/shared/metrics"
)

func main() {
    router := gin.Default()
    
    // Add Prometheus middleware
    router.Use(metrics.PrometheusMiddleware("auth-service"))
    
    // Expose /metrics endpoint
    router.GET("/metrics", metrics.PrometheusHandler())
    
    // Your routes...
}
```

Custom metrics:
```go
// Increment counter
metrics.PostsCreatedTotal.WithLabelValues("content-service").Inc()

// Record duration
start := time.Now()
// ... operation ...
metrics.DbQueryDuration.WithLabelValues("content-service", "postgres", "insert").
    Observe(time.Since(start).Seconds())
```

---

## Deployment Guide

### Prerequisites

1. **Tools**:
   - kubectl >= 1.28
   - helm >= 3.13
   - terraform >= 1.5
   - argocd CLI (optional)

2. **Cloud Provider**:
   - DigitalOcean account with API token, OR
   - Google Cloud project with billing enabled

3. **GitHub**:
   - Repository access
   - GitHub Container Registry enabled

### Step-by-Step Deployment

#### 1. Provision Infrastructure

```bash
# Choose your provider
cd terraform/digitalocean  # or terraform/gcp

# Configure
cp terraform.tfvars.example terraform.tfvars
vim terraform.tfvars

# Deploy
terraform init
terraform plan
terraform apply

# Configure kubectl
export KUBECONFIG=$(terraform output -raw kubeconfig_path)
kubectl get nodes
```

#### 2. Install Argo CD

```bash
# Create namespace
kubectl create namespace argocd

# Install Argo CD
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for ready
kubectl wait --for=condition=available --timeout=300s \
  deployment/argocd-server -n argocd

# Get admin password
kubectl -n argocd get secret argocd-initial-admin-secret \
  -o jsonpath="{.data.password}" | base64 -d
```

#### 3. Deploy Ka Platform

```bash
# Apply Application manifest
kubectl apply -f infrastructure/argocd/ka-platform-application.yaml

# Monitor sync
kubectl get application -n argocd
argocd app get ka-platform
argocd app sync ka-platform

# Wait for deployment
kubectl get pods -n ka-platform -w
```

#### 4. Deploy Observability

```bash
# Deploy Prometheus
kubectl apply -f infrastructure/observability/prometheus/

# Deploy Grafana
kubectl apply -f infrastructure/observability/grafana/

# Deploy Loki
kubectl apply -f infrastructure/observability/loki/

# Verify
kubectl get pods -n ka-platform -l app=prometheus
kubectl get pods -n ka-platform -l app=grafana
kubectl get pods -n ka-platform -l app=loki
```

#### 5. Configure DNS and SSL

```bash
# Get load balancer IP
kubectl get svc -n ka-platform

# Install cert-manager
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml

# Create ClusterIssuer
kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@yourdomain.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
EOF

# Update DNS records to point to load balancer
# Wait for SSL certificates to be issued
```

#### 6. Verify Deployment

```bash
# Check all pods
kubectl get pods -n ka-platform

# Check services
kubectl get svc -n ka-platform

# Test API endpoints
curl https://api.yourdomain.com/auth/health
curl https://api.yourdomain.com/user/health

# Check Argo CD sync status
argocd app get ka-platform

# View metrics
kubectl port-forward -n ka-platform svc/grafana 3000:3000
```

---

## Operations

### Daily Operations

#### View Logs

```bash
# Specific service
kubectl logs -n ka-platform deployment/auth-service -f

# All services
stern -n ka-platform .

# Error logs only
kubectl logs -n ka-platform -l component=api --all-containers | grep -i error
```

#### Scale Services

```bash
# Manual scaling
kubectl scale deployment/content-service \
  -n ka-platform --replicas=5

# Enable autoscaling (already configured via HPA)
kubectl get hpa -n ka-platform
```

#### Update Configuration

```bash
# Edit values.yaml
vim charts/ka-platform/values.yaml

# Commit and push (GitOps way)
git add charts/ka-platform/values.yaml
git commit -m "Update configuration"
git push

# Argo CD auto-syncs within minutes

# Or manual sync
argocd app sync ka-platform
```

### Monitoring

#### Key Metrics to Watch

1. **Request Rate**: `rate(http_requests_total[5m])`
2. **Error Rate**: `rate(http_requests_total{status=~"5.."}[5m])`
3. **Latency (p95)**: `histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))`
4. **Pod CPU**: `rate(container_cpu_usage_seconds_total[5m])`
5. **Pod Memory**: `container_memory_working_set_bytes`

#### Alerts

Configure Alertmanager rules:

```yaml
groups:
  - name: ka-platform
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        annotations:
          summary: "High error rate on {{ $labels.service }}"
      
      - alert: HighLatency
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 1
        annotations:
          summary: "High latency on {{ $labels.service }}"
```

### Maintenance

#### Update Kubernetes Version

```bash
# Update in terraform.tfvars
kubernetes_version = "1.29.0"

# Apply
terraform apply

# Nodes will roll with zero downtime
```

#### Update Application

```bash
# Build new images (GitHub Actions does this)
# Update image tags in values.yaml
# Argo CD syncs automatically

# Or manually
kubectl set image deployment/auth-service \
  auth-service=ghcr.io/.../auth-service:v2.0.0 \
  -n ka-platform
```

#### Database Maintenance

```bash
# Backup PostgreSQL
kubectl exec -n ka-platform postgres-0 -- \
  pg_dump -U ka_user ka_db > backup.sql

# Restore PostgreSQL
kubectl exec -i -n ka-platform postgres-0 -- \
  psql -U ka_user ka_db < backup.sql
```

---

## Security

### Best Practices

1. **Secrets Management**:
   - Never commit secrets to Git
   - Use Kubernetes Secrets or external secret managers
   - Rotate secrets regularly

2. **Network Policies**:
   - Restrict pod-to-pod communication
   - Only allow necessary connections
   - Deny all by default

3. **RBAC**:
   - Follow least privilege principle
   - Use service accounts for pods
   - Limit admin access

4. **Image Security**:
   - Scan images for vulnerabilities (Trivy)
   - Use minimal base images (alpine)
   - Pin versions, don't use `latest`

5. **Pod Security**:
   - Run as non-root user
   - Drop unnecessary capabilities
   - Read-only root filesystem where possible

### Security Scanning

```bash
# Scan Docker images
trivy image ghcr.io/.../auth-service:latest

# Scan Helm charts
helm lint charts/ka-platform

# Scan Kubernetes manifests
kubesec scan deployment.yaml
```

### Compliance

- **PCI DSS**: For payment processing (Billing Service)
- **GDPR**: For user data protection
- **SOC 2**: For enterprise customers

---

## Disaster Recovery

### Backup Strategy

#### Application State

- **Git**: All configuration in version control
- **Helm**: Declarative application state
- **Argo CD**: Can recreate entire platform from Git

#### Data Layer

1. **PostgreSQL**:
   - Daily automated backups (managed database)
   - Point-in-time recovery (PITR)
   - Manual backups before major changes

2. **Redis**:
   - AOF (Append-Only File) persistence
   - Snapshots every 6 hours
   - Can be rebuilt from source systems

3. **ScyllaDB**:
   - Daily snapshots
   - Cross-datacenter replication
   - Can be rebuilt from events

4. **Object Storage** (MinIO/Spaces):
   - Versioning enabled
   - Cross-region replication
   - Lifecycle policies for old data

### Recovery Procedures

#### Complete Cluster Failure

```bash
# 1. Provision new cluster
cd terraform/digitalocean
terraform apply

# 2. Install Argo CD
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# 3. Deploy Ka Platform
kubectl apply -f infrastructure/argocd/ka-platform-application.yaml

# 4. Restore databases
kubectl exec -i -n ka-platform postgres-0 -- psql -U ka_user ka_db < backup.sql

# 5. Verify
kubectl get pods -n ka-platform
```

#### Service Failure

```bash
# 1. Check pod status
kubectl get pods -n ka-platform

# 2. View logs
kubectl logs -n ka-platform <pod-name>

# 3. Restart pod
kubectl delete pod -n ka-platform <pod-name>

# 4. Or rollback deployment
kubectl rollout undo deployment/<service> -n ka-platform
```

#### Data Corruption

```bash
# 1. Stop writes
kubectl scale deployment/<service> -n ka-platform --replicas=0

# 2. Restore from backup
# (see database restore procedures above)

# 3. Resume service
kubectl scale deployment/<service> -n ka-platform --replicas=3
```

### RTO and RPO

- **Recovery Time Objective (RTO)**: < 1 hour
- **Recovery Point Objective (RPO)**: < 24 hours (daily backups)
- **High Availability**: 99.9% uptime SLA

---

## Troubleshooting

### Common Issues

#### Pods Not Starting

```bash
# Check pod events
kubectl describe pod <pod-name> -n ka-platform

# Common causes:
# - Image pull errors: Check image name and credentials
# - Resource limits: Check node capacity
# - Failed health checks: Check application logs
```

#### Application Errors

```bash
# Check logs
kubectl logs -n ka-platform deployment/<service> --tail=100

# Check metrics
kubectl top pods -n ka-platform

# Common causes:
# - Database connection issues
# - Configuration errors
# - Dependency failures
```

#### Database Connection Failures

```bash
# Test connectivity
kubectl run -it --rm debug --image=postgres:15 -n ka-platform -- \
  psql -h postgres-service -U ka_user -d ka_db

# Check service endpoints
kubectl get endpoints -n ka-platform postgres-service

# Check secrets
kubectl get secret ka-secrets -n ka-platform -o yaml
```

#### Argo CD Sync Issues

```bash
# Check application status
argocd app get ka-platform

# Force sync
argocd app sync ka-platform --force

# Check for drift
argocd app diff ka-platform

# Refresh application
argocd app get ka-platform --refresh
```

#### Performance Issues

```bash
# Check resource usage
kubectl top nodes
kubectl top pods -n ka-platform

# Check HPA status
kubectl get hpa -n ka-platform

# View Prometheus metrics
kubectl port-forward -n ka-platform svc/prometheus 9090:9090
```

### Debug Tools

```bash
# Interactive shell in pod
kubectl exec -it -n ka-platform <pod-name> -- /bin/sh

# Network debugging
kubectl run -it --rm debug --image=nicolaka/netshoot -n ka-platform

# Database debugging
kubectl run -it --rm psql --image=postgres:15 -n ka-platform -- \
  psql -h postgres-service -U ka_user

# DNS debugging
kubectl run -it --rm busybox --image=busybox -n ka-platform -- nslookup postgres-service
```

### Support Resources

- **Kubernetes Docs**: https://kubernetes.io/docs/
- **Helm Docs**: https://helm.sh/docs/
- **Argo CD Docs**: https://argo-cd.readthedocs.io/
- **Prometheus Docs**: https://prometheus.io/docs/
- **Grafana Docs**: https://grafana.com/docs/

---

## Conclusion

This platform engineering setup provides a production-ready, cloud-native foundation for the Ka Platform. It embraces modern DevOps practices including:

- ✅ Infrastructure as Code with Terraform
- ✅ Declarative application management with Helm
- ✅ GitOps continuous deployment with Argo CD
- ✅ Comprehensive observability with Prometheus, Grafana, and Loki
- ✅ Automated scaling and self-healing
- ✅ Security best practices
- ✅ Disaster recovery procedures

The platform is designed to scale from startup to enterprise, with clear paths for growth and optimization. All components are open-source and cloud-agnostic, allowing flexibility in choosing infrastructure providers.

For questions or contributions, please refer to the project documentation or open an issue on GitHub.

---

**Document Version**: 1.0.0  
**Last Updated**: 2024  
**Maintained By**: Ka Platform Team
