package models

import (
	"time"

	"github.com/google/uuid"
)

// User represents a user in the Ka platform
type User struct {
	ID                uuid.UUID  `json:"id" db:"id"`
	Username          string     `json:"username" db:"username"`
	Email             string     `json:"email" db:"email"`
	Phone             *string    `json:"phone,omitempty" db:"phone"`
	PasswordHash      string     `json:"-" db:"password_hash"`
	DisplayName       *string    `json:"display_name,omitempty" db:"display_name"`
	Bio               *string    `json:"bio,omitempty" db:"bio"`
	ProfilePictureURL *string    `json:"profile_picture_url,omitempty" db:"profile_picture_url"`
	AvatarURLMedium   *string    `json:"avatar_url_medium,omitempty" db:"avatar_url_medium"`
	AvatarURLThumb    *string    `json:"avatar_url_thumb,omitempty" db:"avatar_url_thumb"`
	CoverStoryURL     *string    `json:"cover_story_url,omitempty" db:"cover_story_url"`
	CoverStoryType    string     `json:"cover_story_type" db:"cover_story_type"`
	Location          *string    `json:"location,omitempty" db:"location"`
	Website           *string    `json:"website,omitempty" db:"website"`
	IsVerified        bool       `json:"is_verified" db:"is_verified"`
	IsPremium         bool       `json:"is_premium" db:"is_premium"`
	Language          string     `json:"language" db:"language"`
	FollowerCount     int        `json:"follower_count" db:"follower_count"`
	FollowingCount    int        `json:"following_count" db:"following_count"`
	CreatedAt         time.Time  `json:"created_at" db:"created_at"`
	UpdatedAt         time.Time  `json:"updated_at" db:"updated_at"`
}

// UserProfile represents a public user profile with additional computed fields
type UserProfile struct {
	User
	FollowerCount  int        `json:"follower_count"`
	FollowingCount int        `json:"following_count"`
	EchoCount      int        `json:"echo_count"`
	StoryCount     int        `json:"story_count"`
	TopEcho        *PostShort `json:"top_echo,omitempty"`
	IsFollowing    bool       `json:"is_following"`
	IsFollowedBy   bool       `json:"is_followed_by"`
	HasKaPlus      bool       `json:"has_ka_plus"`
}

// UserShort represents a minimal user object for nested responses
type UserShort struct {
	ID                uuid.UUID `json:"id" db:"id"`
	Username          string    `json:"username" db:"username"`
	DisplayName       *string   `json:"display_name,omitempty" db:"display_name"`
	ProfilePictureURL *string   `json:"profile_picture_url,omitempty" db:"profile_picture_url"`
	IsVerified        bool      `json:"is_verified" db:"is_verified"`
	HasKaPlus         bool      `json:"has_ka_plus"`
}

// RegisterRequest represents a user registration request
type RegisterRequest struct {
	Username    string  `json:"username" binding:"required,min=3,max=50"`
	Email       string  `json:"email" binding:"required,email"`
	Password    string  `json:"password" binding:"required,min=8"`
	Phone       *string `json:"phone,omitempty"`
	DisplayName *string `json:"display_name,omitempty"`
}

// LoginRequest represents a user login request
type LoginRequest struct {
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required"`
}

// UpdateProfileRequest represents a profile update request
type UpdateProfileRequest struct {
	DisplayName *string `json:"display_name,omitempty"`
	Bio         *string `json:"bio,omitempty"`
	Location    *string `json:"location,omitempty"`
	Website     *string `json:"website,omitempty"`
}
