-- Ka Social Platform - Trust & Safety Tables
-- This script creates mutes table for the Trust & Safety system
-- The blocks table already exists in 01-init.sql

-- Mutes table (one-way action)
CREATE TABLE IF NOT EXISTS mutes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    muter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    muted_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(muter_id, muted_id)
);

-- Create indexes for mutes
CREATE INDEX idx_mutes_muter ON mutes(muter_id);
CREATE INDEX idx_mutes_muted ON mutes(muted_id);
CREATE INDEX idx_mutes_created_at ON mutes(created_at);
