#!/bin/bash

# Ka Platform - Google Cloud Platform Deployment Script
# This script automates the deployment of Ka Platform on GCP

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
check_command() {
    if ! command -v $1 &> /dev/null; then
        print_error "$1 is not installed. Please install it first."
        exit 1
    fi
}

# Function to wait for user confirmation
confirm() {
    read -p "$(echo -e ${YELLOW}[CONFIRM]${NC} $1 [y/N]: )" -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "Operation cancelled by user."
        exit 0
    fi
}

print_info "=========================================="
print_info "Ka Platform - GCP Deployment Script"
print_info "=========================================="
echo

# Check prerequisites
print_info "Checking prerequisites..."
check_command gcloud
check_command terraform
check_command kubectl
check_command helm
print_success "All required tools are installed."
echo

# Get or set GCP project ID
print_info "Configuring GCP Project..."
CURRENT_PROJECT=$(gcloud config get-value project 2>/dev/null)
if [ -z "$CURRENT_PROJECT" ]; then
    print_warning "No GCP project is currently set."
    read -p "Enter your GCP Project ID: " PROJECT_ID
    gcloud config set project $PROJECT_ID
else
    print_info "Current project: $CURRENT_PROJECT"
    read -p "Use this project? [Y/n]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Nn]$ ]]; then
        read -p "Enter your GCP Project ID: " PROJECT_ID
        gcloud config set project $PROJECT_ID
    else
        PROJECT_ID=$CURRENT_PROJECT
    fi
fi
print_success "Using project: $PROJECT_ID"
echo

# Verify billing is enabled
print_info "Checking if billing is enabled..."
BILLING_ENABLED=$(gcloud billing projects describe $PROJECT_ID --format="value(billingEnabled)" 2>/dev/null || echo "false")
if [ "$BILLING_ENABLED" != "True" ]; then
    print_error "Billing is not enabled for project $PROJECT_ID"
    print_info "Please enable billing at: https://console.cloud.google.com/billing/linkedaccount?project=$PROJECT_ID"
    exit 1
fi
print_success "Billing is enabled."
echo

# Enable required APIs
print_info "Enabling required GCP APIs..."
gcloud services enable \
  compute.googleapis.com \
  container.googleapis.com \
  sqladmin.googleapis.com \
  redis.googleapis.com \
  storage-api.googleapis.com \
  cloudresourcemanager.googleapis.com \
  servicenetworking.googleapis.com 2>&1 | grep -v "already enabled" || true
print_success "Required APIs are enabled."
echo

# Check if terraform.tfvars exists
print_info "Checking Terraform configuration..."
cd terraform/gcp
if [ ! -f terraform.tfvars ]; then
    print_warning "terraform.tfvars not found. Creating from example..."
    cp terraform.tfvars.example terraform.tfvars
    
    # Update project_id in terraform.tfvars
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/your-gcp-project-id/$PROJECT_ID/" terraform.tfvars
    else
        # Linux
        sed -i "s/your-gcp-project-id/$PROJECT_ID/" terraform.tfvars
    fi
    
    print_warning "Please review and update terraform.tfvars with your desired configuration."
    print_warning "Especially important: db_password and other secrets"
    confirm "Have you reviewed and updated terraform.tfvars?"
else
    print_success "terraform.tfvars found."
fi
echo

# Confirm deployment
print_info "Deployment Configuration:"
print_info "  Project ID: $PROJECT_ID"
print_info "  Region: $(grep '^region' terraform.tfvars | awk -F'"' '{print $2}' || echo 'us-central1')"
print_info "  Cluster: $(grep '^cluster_name' terraform.tfvars | awk -F'"' '{print $2}' || echo 'ka-platform-prod')"
echo
print_warning "This will create resources in GCP and incur costs."
print_warning "Estimated cost: ~$500/month for production setup"
confirm "Do you want to proceed with deployment?"
echo

# Initialize Terraform
print_info "Initializing Terraform..."
terraform init
print_success "Terraform initialized."
echo

# Validate Terraform configuration
print_info "Validating Terraform configuration..."
terraform validate
print_success "Terraform configuration is valid."
echo

# Plan Terraform deployment
print_info "Planning Terraform deployment..."
terraform plan -out=tfplan
print_success "Terraform plan created."
echo

# Apply Terraform
print_info "Applying Terraform configuration..."
print_warning "This will take approximately 10-15 minutes..."
terraform apply tfplan
print_success "Infrastructure provisioned successfully!"
echo

# Save outputs
print_info "Saving Terraform outputs..."
terraform output > ../../outputs.txt
INGRESS_IP=$(terraform output -raw ingress_ip 2>/dev/null || echo "Not available")
KUBECONFIG_CMD=$(terraform output -raw kubeconfig_command 2>/dev/null)
print_success "Outputs saved to outputs.txt"
echo

# Configure kubectl
print_info "Configuring kubectl..."
eval "$KUBECONFIG_CMD"
kubectl get nodes
print_success "kubectl configured successfully."
echo

# Go back to repo root
cd ../..

# Install Argo CD
print_info "Installing Argo CD..."
kubectl create namespace argocd 2>/dev/null || print_warning "argocd namespace already exists"
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

print_info "Waiting for Argo CD to be ready (this may take 2-3 minutes)..."
kubectl wait --for=condition=available --timeout=300s deployment/argocd-server -n argocd
print_success "Argo CD installed successfully!"
echo

# Get Argo CD password
ARGOCD_PASSWORD=$(kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" 2>/dev/null | base64 -d)
print_success "Argo CD admin password: $ARGOCD_PASSWORD"
echo

# Check if secrets are configured
print_warning "IMPORTANT: Before deploying the application, you must configure secrets in charts/ka-platform/values.yaml"
print_info "Generate secrets with: openssl rand -base64 32"
confirm "Have you configured all secrets in charts/ka-platform/values.yaml?"
echo

# Deploy Ka Platform
print_info "Deploying Ka Platform application..."
kubectl apply -f infrastructure/argocd/ka-platform-application.yaml
print_success "Ka Platform application deployed to Argo CD."
echo

print_info "Waiting for application to sync (this may take 5-10 minutes)..."
print_info "You can watch progress with: watch kubectl get pods -n ka-platform"
echo

# Wait for namespace to be created
print_info "Waiting for ka-platform namespace..."
for i in {1..60}; do
    if kubectl get namespace ka-platform &>/dev/null; then
        break
    fi
    sleep 2
done

# Wait for some pods to be created
print_info "Waiting for pods to be created..."
for i in {1..30}; do
    POD_COUNT=$(kubectl get pods -n ka-platform 2>/dev/null | wc -l)
    if [ "$POD_COUNT" -gt 1 ]; then
        break
    fi
    sleep 5
done

# Show pod status
print_info "Current pod status:"
kubectl get pods -n ka-platform 2>/dev/null || print_warning "ka-platform namespace not ready yet"
echo

# Deploy observability stack
print_info "Deploying observability stack..."
kubectl apply -f infrastructure/observability/prometheus/ 2>/dev/null || print_warning "Prometheus deployment failed or already exists"
kubectl apply -f infrastructure/observability/grafana/ 2>/dev/null || print_warning "Grafana deployment failed or already exists"
kubectl apply -f infrastructure/observability/loki/ 2>/dev/null || print_warning "Loki deployment failed or already exists"
print_success "Observability stack deployed."
echo

# Summary
print_success "=========================================="
print_success "Deployment Complete!"
print_success "=========================================="
echo
print_info "Cluster Information:"
print_info "  Project ID: $PROJECT_ID"
print_info "  Ingress IP: $INGRESS_IP"
print_info "  Region: $(grep '^region' terraform/gcp/terraform.tfvars | awk -F'"' '{print $2}' || echo 'us-central1')"
echo
print_info "Access Credentials:"
print_info "  Argo CD Username: admin"
print_info "  Argo CD Password: $ARGOCD_PASSWORD"
echo
print_info "Next Steps:"
print_info "  1. Watch deployment progress:"
print_info "     kubectl get pods -n ka-platform -w"
echo
print_info "  2. Access services via port-forward:"
print_info "     kubectl port-forward -n ka-platform svc/auth-service 8001:8001"
print_info "     kubectl port-forward -n ka-platform svc/grafana 3000:3000"
print_info "     kubectl port-forward -n argocd svc/argocd-server 8080:443"
echo
print_info "  3. Configure DNS (for production):"
print_info "     Point api.yourdomain.com to $INGRESS_IP"
echo
print_info "  4. Set up SSL certificates:"
print_info "     Follow the guide in GOOGLE_CLOUD_DEPLOYMENT.md"
echo
print_info "  5. Monitor the deployment:"
print_info "     kubectl get application -n argocd"
echo
print_info "For detailed information, see GOOGLE_CLOUD_DEPLOYMENT.md"
echo
print_success "Happy deploying! 🚀"
