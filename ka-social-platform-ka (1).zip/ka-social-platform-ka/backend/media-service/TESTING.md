# Media Service Testing Guide

This guide provides comprehensive testing instructions for the Media Service.

## Prerequisites

1. **Docker and Docker Compose** installed
2. **Go 1.21+** installed (for local development)
3. **libvips** installed (for local development)
4. **Test image file** (JPEG, PNG, or WebP)
5. **Valid JWT token** from Auth Service

## Quick Start

### 1. Start Infrastructure Services

```bash
cd infrastructure/docker
docker-compose up -d postgres redis nats minio
```

Wait for all services to be healthy:
```bash
docker-compose ps
```

### 2. Verify MinIO is Running

Access MinIO Console:
- URL: http://localhost:9001
- Username: `minioadmin`
- Password: `minioadmin`

### 3. Start Media Service

**Option A: With Docker Compose**
```bash
docker-compose up -d media-service
```

**Option B: Locally (requires libvips)**
```bash
cd backend/media-service
go run .
```

### 4. Verify Service is Running

```bash
curl http://localhost:8009/health
```

Expected response:
```json
{
  "status": "ok",
  "service": "media-service"
}
```

## Testing the Upload Flow

### Step 1: Get a JWT Token

First, register and login via Auth Service to get a JWT token:

```bash
# Register
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "display_name": "Test User"
  }'

# Login
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }')

# Extract token
JWT_TOKEN=$(echo $LOGIN_RESPONSE | jq -r '.data.access_token')
echo "JWT Token: $JWT_TOKEN"
```

### Step 2: Request Presigned URL

```bash
PRESIGNED_RESPONSE=$(curl -s -X POST http://localhost:8009/api/v1/upload/request \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "filename": "avatar.jpg",
    "content_type": "image/jpeg"
  }')

echo $PRESIGNED_RESPONSE | jq .
```

Expected response:
```json
{
  "success": true,
  "data": {
    "upload_url": "http://minio:9000/ka-media/uploads/user-id/uuid.jpg?X-Amz-...",
    "object_key": "uploads/user-id/uuid.jpg",
    "expires_in": 900
  }
}
```

Extract values:
```bash
UPLOAD_URL=$(echo $PRESIGNED_RESPONSE | jq -r '.data.upload_url')
OBJECT_KEY=$(echo $PRESIGNED_RESPONSE | jq -r '.data.object_key')
```

### Step 3: Upload File to Presigned URL

```bash
curl -X PUT "$UPLOAD_URL" \
  --upload-file test_image.jpg \
  -H "Content-Type: image/jpeg"
```

Expected: HTTP 200 OK

### Step 4: Notify Upload Complete

```bash
curl -X POST http://localhost:8009/api/v1/upload/complete \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"object_key\": \"$OBJECT_KEY\"
  }"
```

Expected response:
```json
{
  "success": true,
  "data": {
    "message": "Media processing queued successfully",
    "object_key": "uploads/user-id/uuid.jpg"
  }
}
```

### Step 5: Verify Processing

**Check Media Service Logs:**
```bash
docker logs -f ka-media-service
```

You should see:
```
Processing media: uploads/user-id/uuid.jpg for user: user-id
Successfully processed image: uploads/user-id/uuid.jpg
Published media.processed event for: uploads/user-id/uuid.jpg
```

**Check NATS Events:**
```bash
# Install NATS CLI (if not installed)
# go install github.com/nats-io/natscli/nats@latest

# Subscribe to events
nats sub "media.>"
```

You should see:
- `media.processing.required` event
- `media.processed` event

**Check MinIO for Processed Images:**
1. Go to http://localhost:9001
2. Login with minioadmin/minioadmin
3. Navigate to `ka-media` bucket
4. Check `processed/` folder for:
   - `thumb_*.webp`
   - `medium_*.webp`

### Step 6: Verify User Profile Updated

```bash
curl -X GET http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer $JWT_TOKEN"
```

Check that the response includes:
```json
{
  "profile_picture_url": "http://minio:9000/ka-media/uploads/...",
  "avatar_url_medium": "http://minio:9000/ka-media/processed/medium_*.webp",
  "avatar_url_thumb": "http://minio:9000/ka-media/processed/thumb_*.webp"
}
```

## Automated Testing Script

Use the provided test script:

```bash
cd backend/media-service
JWT_TOKEN="your-jwt-token" TEST_IMAGE="test.jpg" ./test_media_flow.sh
```

## Testing CDN Integration

### Local Testing with CDN_HOST

1. Set CDN_HOST in docker-compose.yml:
```yaml
environment:
  - CDN_HOST=https://test-cdn.example.com
```

2. Restart service:
```bash
docker-compose restart media-service
```

3. Follow upload flow - URLs should now use CDN_HOST

Expected URLs:
```
https://test-cdn.example.com/ka-media/uploads/...
https://test-cdn.example.com/ka-media/processed/medium_*.webp
https://test-cdn.example.com/ka-media/processed/thumb_*.webp
```

## Performance Testing

### Test Image Processing Speed

```bash
# Time the processing
time (
  # 1. Request URL
  PRESIGNED_RESPONSE=$(curl -s -X POST http://localhost:8009/api/v1/upload/request \
    -H "Authorization: Bearer $JWT_TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"filename": "test.jpg", "content_type": "image/jpeg"}')
  
  UPLOAD_URL=$(echo $PRESIGNED_RESPONSE | jq -r '.data.upload_url')
  OBJECT_KEY=$(echo $PRESIGNED_RESPONSE | jq -r '.data.object_key')
  
  # 2. Upload
  curl -s -X PUT "$UPLOAD_URL" --upload-file test.jpg
  
  # 3. Notify
  curl -s -X POST http://localhost:8009/api/v1/upload/complete \
    -H "Authorization: Bearer $JWT_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"object_key\": \"$OBJECT_KEY\"}"
  
  # 4. Wait for processing (poll user profile)
  while true; do
    PROFILE=$(curl -s http://localhost:8002/api/profile/me \
      -H "Authorization: Bearer $JWT_TOKEN")
    THUMB_URL=$(echo $PROFILE | jq -r '.avatar_url_thumb')
    if [ "$THUMB_URL" != "null" ]; then
      break
    fi
    sleep 0.1
  done
)
```

Expected times:
- Request presigned URL: <50ms
- Upload: Depends on image size and network
- Notify: <10ms
- Processing: <500ms for typical images
- Total end-to-end: <2 seconds

### Load Testing with k6

Create `load_test.js`:
```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '30s', target: 10 },
    { duration: '1m', target: 50 },
    { duration: '30s', target: 0 },
  ],
};

const JWT_TOKEN = 'your-jwt-token';

export default function () {
  // Request presigned URL
  let response = http.post(
    'http://localhost:8009/api/v1/upload/request',
    JSON.stringify({
      filename: 'test.jpg',
      content_type: 'image/jpeg',
    }),
    {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${JWT_TOKEN}`,
      },
    }
  );
  
  check(response, {
    'status is 200': (r) => r.status === 200,
    'has upload_url': (r) => JSON.parse(r.body).data.upload_url !== undefined,
  });
  
  sleep(1);
}
```

Run test:
```bash
k6 run load_test.js
```

## Troubleshooting

### Issue: "Package vips was not found"

**Solution**: Install libvips
```bash
# Ubuntu/Debian
sudo apt-get install libvips-dev

# macOS
brew install vips

# Alpine (Docker)
apk add --no-cache vips-dev
```

### Issue: "Failed to connect to MinIO"

**Solution**: Check MinIO is running
```bash
docker-compose ps minio
curl http://localhost:9000/minio/health/live
```

### Issue: "Failed to connect to NATS"

**Solution**: Check NATS is running
```bash
docker-compose ps nats
curl http://localhost:8222/healthz
```

### Issue: "Presigned URL expired"

**Solution**: Presigned URLs expire after 15 minutes. Request a new one.

### Issue: "Processing never completes"

**Check**:
1. Media Service worker logs: `docker logs ka-media-service`
2. NATS subscriptions: `nats sub "media.>"`
3. MinIO connectivity from worker

### Issue: "User profile not updated"

**Check**:
1. User Service logs: `docker logs ka-user-service`
2. Verify user-service is subscribed to `media.processed`
3. Check database for updated columns

## Integration Testing

### Test Complete Flow End-to-End

```bash
#!/bin/bash
set -e

echo "=== Integration Test ==="

# 1. Register user
REGISTER_RESPONSE=$(curl -s -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "integrationtest",
    "email": "integration@test.com",
    "password": "password123"
  }')

# 2. Login
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "integration@test.com",
    "password": "password123"
  }')

JWT_TOKEN=$(echo $LOGIN_RESPONSE | jq -r '.data.access_token')

# 3. Request presigned URL
PRESIGNED_RESPONSE=$(curl -s -X POST http://localhost:8009/api/v1/upload/request \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"filename": "avatar.jpg", "content_type": "image/jpeg"}')

UPLOAD_URL=$(echo $PRESIGNED_RESPONSE | jq -r '.data.upload_url')
OBJECT_KEY=$(echo $PRESIGNED_RESPONSE | jq -r '.data.object_key')

# 4. Upload file
curl -s -X PUT "$UPLOAD_URL" --upload-file test.jpg

# 5. Notify complete
curl -s -X POST http://localhost:8009/api/v1/upload/complete \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"object_key\": \"$OBJECT_KEY\"}"

# 6. Wait and verify
sleep 3

PROFILE=$(curl -s http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer $JWT_TOKEN")

THUMB_URL=$(echo $PROFILE | jq -r '.avatar_url_thumb')

if [ "$THUMB_URL" != "null" ]; then
  echo "✓ Integration test PASSED"
  echo "  Thumb URL: $THUMB_URL"
else
  echo "✗ Integration test FAILED"
  echo "  Profile: $PROFILE"
  exit 1
fi
```

## Monitoring

### Health Check Endpoint

```bash
curl http://localhost:8009/health
```

### NATS Monitoring

```bash
curl http://localhost:8222/varz | jq .
```

Key metrics:
- `connections`: Number of active connections
- `in_msgs`: Messages received
- `out_msgs`: Messages sent
- `subscriptions`: Active subscriptions

### MinIO Metrics

Access MinIO Console: http://localhost:9001
- Storage usage
- API requests
- Bandwidth usage

### Service Logs

```bash
# Media Service
docker logs -f ka-media-service

# NATS
docker logs -f ka-nats

# MinIO
docker logs -f ka-minio

# User Service
docker logs -f ka-user-service
```

## Best Practices

1. **Always test with real images** of various sizes (small, medium, large)
2. **Test different image formats** (JPEG, PNG, WebP, GIF)
3. **Verify WebP output** in browser or image viewer
4. **Monitor processing time** for different image sizes
5. **Test error scenarios** (invalid token, expired URL, wrong content type)
6. **Check CDN URLs** in production environment
7. **Verify event flow** using NATS monitoring
8. **Test concurrent uploads** for performance

## Next Steps

After successful testing:
1. Configure production CDN (CloudFlare/CloudFront)
2. Set up monitoring and alerting
3. Configure backup for MinIO
4. Set up SSL/TLS for MinIO
5. Implement rate limiting
6. Add support for additional image formats
7. Implement video processing
