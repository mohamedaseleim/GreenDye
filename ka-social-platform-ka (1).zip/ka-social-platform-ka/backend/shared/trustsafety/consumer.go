package trustsafety

import (
	"context"
	"encoding/json"
	"fmt"
	"log"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
	"github.com/redis/go-redis/v9"
)

// BlockEvent represents a user.blocked or user.unblocked event
type BlockEvent struct {
	BlockerID string `json:"blocker_id"`
	BlockedID string `json:"blocked_id"`
	Timestamp string `json:"timestamp"`
}

// MuteEvent represents a user.muted or user.unmuted event
type MuteEvent struct {
	MuterID   string `json:"muter_id"`
	MutedID   string `json:"muted_id"`
	Timestamp string `json:"timestamp"`
}

// EventConsumer handles Trust & Safety NATS events
type EventConsumer struct {
	natsConn     *nats.Conn
	cacheManager *CacheManager
	serviceName  string
}

// NewEventConsumer creates a new Trust & Safety event consumer
func NewEventConsumer(natsConn *nats.Conn, redis *redis.Client, serviceName string) *EventConsumer {
	return &EventConsumer{
		natsConn:     natsConn,
		cacheManager: NewCacheManager(redis, 0), // Use default TTL
		serviceName:  serviceName,
	}
}

// Start subscribes to Trust & Safety events
func (c *EventConsumer) Start() error {
	ctx := context.Background()

	// Subscribe to user.blocked events
	_, err := c.natsConn.Subscribe("user.blocked", func(msg *nats.Msg) {
		var event BlockEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("[%s] Error unmarshaling user.blocked event: %v", c.serviceName, err)
			return
		}

		if err := c.handleBlockEvent(ctx, event); err != nil {
			log.Printf("[%s] Error handling user.blocked event: %v", c.serviceName, err)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.blocked: %w", err)
	}

	// Subscribe to user.unblocked events
	_, err = c.natsConn.Subscribe("user.unblocked", func(msg *nats.Msg) {
		var event BlockEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("[%s] Error unmarshaling user.unblocked event: %v", c.serviceName, err)
			return
		}

		if err := c.handleUnblockEvent(ctx, event); err != nil {
			log.Printf("[%s] Error handling user.unblocked event: %v", c.serviceName, err)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.unblocked: %w", err)
	}

	// Subscribe to user.muted events
	_, err = c.natsConn.Subscribe("user.muted", func(msg *nats.Msg) {
		var event MuteEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("[%s] Error unmarshaling user.muted event: %v", c.serviceName, err)
			return
		}

		if err := c.handleMuteEvent(ctx, event); err != nil {
			log.Printf("[%s] Error handling user.muted event: %v", c.serviceName, err)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.muted: %w", err)
	}

	// Subscribe to user.unmuted events
	_, err = c.natsConn.Subscribe("user.unmuted", func(msg *nats.Msg) {
		var event MuteEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("[%s] Error unmarshaling user.unmuted event: %v", c.serviceName, err)
			return
		}

		if err := c.handleUnmuteEvent(ctx, event); err != nil {
			log.Printf("[%s] Error handling user.unmuted event: %v", c.serviceName, err)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.unmuted: %w", err)
	}

	log.Printf("[%s] Started consuming Trust & Safety events: user.blocked, user.unblocked, user.muted, user.unmuted", c.serviceName)
	return nil
}

// handleBlockEvent handles a user.blocked event by invalidating cache
func (c *EventConsumer) handleBlockEvent(ctx context.Context, event BlockEvent) error {
	blockerID, err := uuid.Parse(event.BlockerID)
	if err != nil {
		return fmt.Errorf("invalid blocker_id: %w", err)
	}

	blockedID, err := uuid.Parse(event.BlockedID)
	if err != nil {
		return fmt.Errorf("invalid blocked_id: %w", err)
	}

	// Invalidate cache for both directions
	if err := c.cacheManager.InvalidateBlockCache(ctx, blockerID, blockedID); err != nil {
		return fmt.Errorf("failed to invalidate block cache: %w", err)
	}

	log.Printf("[%s] Invalidated block cache: blocker=%s, blocked=%s", c.serviceName, blockerID, blockedID)
	return nil
}

// handleUnblockEvent handles a user.unblocked event by invalidating cache
func (c *EventConsumer) handleUnblockEvent(ctx context.Context, event BlockEvent) error {
	blockerID, err := uuid.Parse(event.BlockerID)
	if err != nil {
		return fmt.Errorf("invalid blocker_id: %w", err)
	}

	blockedID, err := uuid.Parse(event.BlockedID)
	if err != nil {
		return fmt.Errorf("invalid blocked_id: %w", err)
	}

	// Invalidate cache for both directions
	if err := c.cacheManager.InvalidateBlockCache(ctx, blockerID, blockedID); err != nil {
		return fmt.Errorf("failed to invalidate block cache: %w", err)
	}

	log.Printf("[%s] Invalidated block cache: blocker=%s, blocked=%s", c.serviceName, blockerID, blockedID)
	return nil
}

// handleMuteEvent handles a user.muted event by invalidating cache
func (c *EventConsumer) handleMuteEvent(ctx context.Context, event MuteEvent) error {
	muterID, err := uuid.Parse(event.MuterID)
	if err != nil {
		return fmt.Errorf("invalid muter_id: %w", err)
	}

	mutedID, err := uuid.Parse(event.MutedID)
	if err != nil {
		return fmt.Errorf("invalid muted_id: %w", err)
	}

	// Invalidate cache
	if err := c.cacheManager.InvalidateMuteCache(ctx, muterID, mutedID); err != nil {
		return fmt.Errorf("failed to invalidate mute cache: %w", err)
	}

	log.Printf("[%s] Invalidated mute cache: muter=%s, muted=%s", c.serviceName, muterID, mutedID)
	return nil
}

// handleUnmuteEvent handles a user.unmuted event by invalidating cache
func (c *EventConsumer) handleUnmuteEvent(ctx context.Context, event MuteEvent) error {
	muterID, err := uuid.Parse(event.MuterID)
	if err != nil {
		return fmt.Errorf("invalid muter_id: %w", err)
	}

	mutedID, err := uuid.Parse(event.MutedID)
	if err != nil {
		return fmt.Errorf("invalid muted_id: %w", err)
	}

	// Invalidate cache
	if err := c.cacheManager.InvalidateMuteCache(ctx, muterID, mutedID); err != nil {
		return fmt.Errorf("failed to invalidate mute cache: %w", err)
	}

	log.Printf("[%s] Invalidated mute cache: muter=%s, muted=%s", c.serviceName, muterID, mutedID)
	return nil
}

// GetCacheManager returns the cache manager instance
func (c *EventConsumer) GetCacheManager() *CacheManager {
	return c.cacheManager
}
