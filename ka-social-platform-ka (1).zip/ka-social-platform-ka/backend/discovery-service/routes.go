package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes configures all routes for the discovery service
func SetupRoutes(router *gin.Engine, handler *Handler, config *Config) {
	// Health check
	router.GET("/health", handler.HealthCheck)

	// API v1
	v1 := router.Group("/api/v1")
	{
		// Search endpoints (public, but rate-limited)
		v1.GET("/search", handler.Search)
		v1.GET("/search/suggest", handler.Suggest)

		// Discovery endpoints
		discover := v1.Group("/discover")
		{
			discover.GET("/trending", handler.GetTrending)
		}
	}

	// Optional: Add authentication for future features
	authMiddleware := middleware.AuthMiddleware(config.JWTSecret)
	_ = authMiddleware // Unused for now, but available for protected endpoints
}
