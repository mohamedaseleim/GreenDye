package main

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
)

// NATSConsumer handles consuming events from NATS
type NATSConsumer struct {
	conn *nats.Conn
	repo *Repository
	hub  *Hub
}

// NATSPublisher handles publishing events to NATS
type NATSPublisher struct {
	conn *nats.Conn
}

// EchoLikedEvent represents an echo.liked event
type EchoLikedEvent struct {
	EchoID    string `json:"echo_id"`
	UserID    string `json:"user_id"`
	EchoOwner string `json:"echo_owner"`
	Timestamp string `json:"timestamp"`
}

// UserFollowedEvent represents a user.followed event
type UserFollowedEvent struct {
	FollowerID  string `json:"follower_id"`
	FollowingID string `json:"following_id"`
	Timestamp   string `json:"timestamp"`
}

// NewNATSConsumer creates a new NATS consumer
func NewNATSConsumer(natsURL string, repo *Repository, hub *Hub) (*NATSConsumer, error) {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to NATS: %w", err)
	}

	return &NATSConsumer{
		conn: nc,
		repo: repo,
		hub:  hub,
	}, nil
}

// NewNATSPublisher creates a new NATS publisher
func NewNATSPublisher(natsURL string) (*NATSPublisher, error) {
	nc, err := nats.Connect(natsURL)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to NATS: %w", err)
	}

	return &NATSPublisher{conn: nc}, nil
}

// Start begins consuming events from NATS
func (nc *NATSConsumer) Start() error {
	// Subscribe to echo.liked events
	_, err := nc.conn.Subscribe("echo.liked", func(msg *nats.Msg) {
		nc.handleEchoLiked(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to echo.liked: %w", err)
	}

	// Subscribe to user.followed events
	_, err = nc.conn.Subscribe("user.followed", func(msg *nats.Msg) {
		nc.handleUserFollowed(msg.Data)
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to user.followed: %w", err)
	}

	log.Println("NATS consumer started, subscribed to echo.liked and user.followed")
	return nil
}

// handleEchoLiked processes echo.liked events and creates notifications
func (nc *NATSConsumer) handleEchoLiked(data []byte) {
	var event EchoLikedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling echo.liked event: %v", err)
		return
	}

	echoID, err := uuid.Parse(event.EchoID)
	if err != nil {
		log.Printf("Error parsing echo ID: %v", err)
		return
	}

	actorID, err := uuid.Parse(event.UserID)
	if err != nil {
		log.Printf("Error parsing user ID: %v", err)
		return
	}

	echoOwnerID, err := uuid.Parse(event.EchoOwner)
	if err != nil {
		log.Printf("Error parsing echo owner ID: %v", err)
		return
	}

	// Don't notify users when they like their own posts
	if actorID == echoOwnerID {
		return
	}

	// Check if there's an existing unread like notification for this echo
	existingNotif, err := nc.repo.FindUnreadLikeNotification(echoOwnerID, echoID)
	if err != nil {
		log.Printf("Error finding existing notification: %v", err)
		// Continue anyway - we'll create a new notification
	}

	now := time.Now().UTC()

	if existingNotif != nil {
		// Update existing notification with new actor
		actorIDs := existingNotif.ActorIDs
		
		// Check if this actor already in the list
		alreadyExists := false
		for _, id := range actorIDs {
			if id == actorID {
				alreadyExists = true
				break
			}
		}

		if !alreadyExists {
			// Add new actor to the beginning of the list
			actorIDs = append([]uuid.UUID{actorID}, actorIDs...)
			
			// Keep only the latest 3 actors
			if len(actorIDs) > 3 {
				actorIDs = actorIDs[:3]
			}

			actorCount := existingNotif.ActorCount + 1

			// Update the notification
			if err := nc.repo.UpdateNotificationActors(existingNotif.ID, actorIDs, actorCount); err != nil {
				log.Printf("Error updating notification actors: %v", err)
				return
			}

			// Update the notification object for broadcasting
			existingNotif.ActorIDs = actorIDs
			existingNotif.ActorCount = actorCount
			existingNotif.UpdatedAt = now
		}

		// Send updated notification via WebSocket if user is connected
		if nc.hub.IsUserConnected(echoOwnerID) {
			if err := nc.hub.SendToUser(echoOwnerID, existingNotif); err != nil {
				log.Printf("Error sending notification to user %s: %v", echoOwnerID, err)
			}
		}
	} else {
		// Create new notification
		notification := &Notification{
			ID:         uuid.New(),
			UserID:     echoOwnerID,
			Type:       "like",
			ActorID:    &actorID,
			EchoID:     &echoID,
			Content:    "liked your echo",
			IsRead:     false,
			CreatedAt:  now,
			UpdatedAt:  now,
			ActorIDs:   []uuid.UUID{actorID},
			ActorCount: 1,
		}

		if err := nc.repo.CreateNotification(notification); err != nil {
			log.Printf("Error creating notification: %v", err)
			return
		}

		log.Printf("Created like notification for user %s (echo %s)", echoOwnerID, echoID)

		// Send notification via WebSocket if user is connected
		if nc.hub.IsUserConnected(echoOwnerID) {
			if err := nc.hub.SendToUser(echoOwnerID, notification); err != nil {
				log.Printf("Error sending notification to user %s: %v", echoOwnerID, err)
			} else {
				log.Printf("Sent real-time notification to user %s", echoOwnerID)
			}
		}
	}
}

// handleUserFollowed processes user.followed events and creates notifications
func (nc *NATSConsumer) handleUserFollowed(data []byte) {
	var event UserFollowedEvent
	if err := json.Unmarshal(data, &event); err != nil {
		log.Printf("Error unmarshaling user.followed event: %v", err)
		return
	}

	followerID, err := uuid.Parse(event.FollowerID)
	if err != nil {
		log.Printf("Error parsing follower ID: %v", err)
		return
	}

	followingID, err := uuid.Parse(event.FollowingID)
	if err != nil {
		log.Printf("Error parsing following ID: %v", err)
		return
	}

	now := time.Now().UTC()

	// Create notification for the user being followed
	notification := &Notification{
		ID:         uuid.New(),
		UserID:     followingID,
		Type:       "follow",
		ActorID:    &followerID,
		Content:    "started following you",
		IsRead:     false,
		CreatedAt:  now,
		UpdatedAt:  now,
		ActorIDs:   []uuid.UUID{followerID},
		ActorCount: 1,
	}

	if err := nc.repo.CreateNotification(notification); err != nil {
		log.Printf("Error creating follow notification: %v", err)
		return
	}

	log.Printf("Created follow notification for user %s (follower %s)", followingID, followerID)

	// Send notification via WebSocket if user is connected
	if nc.hub.IsUserConnected(followingID) {
		if err := nc.hub.SendToUser(followingID, notification); err != nil {
			log.Printf("Error sending notification to user %s: %v", followingID, err)
		} else {
			log.Printf("Sent real-time follow notification to user %s", followingID)
		}
	}
}

// Close closes the NATS connection
func (nc *NATSConsumer) Close() {
	nc.conn.Close()
}

// PublishEchoLiked publishes an echo.liked event to NATS
func (np *NATSPublisher) PublishEchoLiked(echoID, userID, echoOwner uuid.UUID) error {
	event := EchoLikedEvent{
		EchoID:    echoID.String(),
		UserID:    userID.String(),
		EchoOwner: echoOwner.String(),
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal echo.liked event: %w", err)
	}

	if err := np.conn.Publish("echo.liked", data); err != nil {
		return fmt.Errorf("failed to publish echo.liked event: %w", err)
	}

	log.Printf("Published echo.liked event: echo=%s, user=%s, owner=%s", echoID, userID, echoOwner)
	return nil
}

// Close closes the NATS connection
func (np *NATSPublisher) Close() {
	np.conn.Close()
}
