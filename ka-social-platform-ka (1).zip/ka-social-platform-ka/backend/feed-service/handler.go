package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
)

// Handler handles HTTP requests for the feed service
type Handler struct {
	repo   *Repository
	config *Config
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	return &Handler{
		repo:   repo,
		config: config,
	}
}

// GetHomeFeed handles GET /api/v1/feed/home
func (h *Handler) GetHomeFeed(c *gin.Context) {
	ctx := context.Background()

	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Get echo IDs from timeline
	echoIDs, err := h.repo.GetHomeTimeline(ctx, userID, perPage, offset)
	if err != nil {
		log.Printf("Error getting home timeline: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to get home timeline",
			nil,
		))
		return
	}

	// If no echoes in timeline, return empty result
	if len(echoIDs) == 0 {
		total := h.repo.GetTimelineCountWithDefault(ctx, userID)
		totalPages := int(total) / perPage
		if int(total)%perPage > 0 {
			totalPages++
		}

		pagination := models.PaginationInfo{
			Page:       page,
			PerPage:    perPage,
			Total:      total,
			TotalPages: totalPages,
		}

		c.JSON(http.StatusOK, models.PaginatedSuccessResponse([]models.Echo{}, pagination))
		return
	}

	// Hydrate echoes (with caching)
	echoes, err := h.hydrateEchoes(ctx, echoIDs)
	if err != nil {
		log.Printf("Error hydrating echoes: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to hydrate echoes",
			nil,
		))
		return
	}

	// Filter out echoes from muted or blocked users
	echoes = h.filterMutedAndBlockedEchoes(ctx, userID, echoes)

	// Get total count for pagination
	total := h.repo.GetTimelineCountWithDefault(ctx, userID)
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(echoes, pagination))
}

// hydrateEchoes fetches echo details from cache or Content Service
func (h *Handler) hydrateEchoes(ctx context.Context, echoIDs []uuid.UUID) ([]models.Echo, error) {
	if len(echoIDs) == 0 {
		return []models.Echo{}, nil
	}

	// Step 1: Check cache for all echo IDs
	cachedEchoes, err := h.repo.GetBatchCachedEchoes(ctx, echoIDs)
	if err != nil {
		log.Printf("Warning: Failed to get cached echoes: %v", err)
		cachedEchoes = map[string]string{}
	}

	// Step 2: Determine which echoes need to be fetched from Content Service
	uncachedIDs := []uuid.UUID{}
	echoMap := make(map[string]models.Echo)

	for _, echoID := range echoIDs {
		if cachedJSON, found := cachedEchoes[echoID.String()]; found {
			var echo models.Echo
			if err := json.Unmarshal([]byte(cachedJSON), &echo); err == nil {
				echoMap[echoID.String()] = echo
			} else {
				log.Printf("Warning: Failed to unmarshal cached echo %s: %v", echoID, err)
				uncachedIDs = append(uncachedIDs, echoID)
			}
		} else {
			uncachedIDs = append(uncachedIDs, echoID)
		}
	}

	// Step 3: Fetch uncached echoes from Content Service using batch endpoint
	if len(uncachedIDs) > 0 {
		fetchedEchoes, err := h.fetchEchoesBatch(uncachedIDs)
		if err != nil {
			return nil, fmt.Errorf("failed to fetch echoes from content service: %w", err)
		}

		// Step 4: Cache the fetched echoes and add to map
		cacheTTL := 5 * time.Minute
		toCache := make(map[string]string)

		for _, echo := range fetchedEchoes {
			echoJSON, err := json.Marshal(echo)
			if err != nil {
				log.Printf("Warning: Failed to marshal echo %s: %v", echo.ID, err)
				continue
			}
			echoMap[echo.ID.String()] = echo
			toCache[echo.ID.String()] = string(echoJSON)
		}

		if len(toCache) > 0 {
			if err := h.repo.BatchCacheEchoes(ctx, toCache, cacheTTL); err != nil {
				log.Printf("Warning: Failed to cache echoes: %v", err)
			}
		}
	}

	// Step 5: Build result array in the original order
	result := make([]models.Echo, 0, len(echoIDs))
	for _, echoID := range echoIDs {
		if echo, found := echoMap[echoID.String()]; found {
			result = append(result, echo)
		}
	}

	return result, nil
}

// filterMutedAndBlockedEchoes filters out echoes from muted or blocked users
func (h *Handler) filterMutedAndBlockedEchoes(ctx context.Context, userID uuid.UUID, echoes []models.Echo) []models.Echo {
	if len(echoes) == 0 || h.config.TrustSafetyClient == nil {
		return echoes
	}

	filtered := make([]models.Echo, 0, len(echoes))
	for _, echo := range echoes {
		// Skip echoes from blocked users (two-way block)
		isBlocked, err := h.config.TrustSafetyClient.IsBlocked(ctx, userID, echo.UserID)
		if err != nil {
			log.Printf("Warning: Failed to check block status for echo %s: %v", echo.ID, err)
			// On error, include the echo (fail open)
		} else if isBlocked {
			log.Printf("Filtered out echo %s from blocked user %s", echo.ID, echo.UserID)
			continue
		}

		// Skip echoes from muted users (one-way mute)
		isMuted, err := h.config.TrustSafetyClient.IsMuted(ctx, userID, echo.UserID)
		if err != nil {
			log.Printf("Warning: Failed to check mute status for echo %s: %v", echo.ID, err)
			// On error, include the echo (fail open)
		} else if isMuted {
			log.Printf("Filtered out echo %s from muted user %s", echo.ID, echo.UserID)
			continue
		}

		filtered = append(filtered, echo)
	}

	return filtered
}

// fetchEchoesBatch fetches multiple echoes from Content Service using the batch endpoint
func (h *Handler) fetchEchoesBatch(echoIDs []uuid.UUID) ([]models.Echo, error) {
	if len(echoIDs) == 0 {
		return []models.Echo{}, nil
	}

	// Convert UUIDs to strings
	idStrings := make([]string, len(echoIDs))
	for i, id := range echoIDs {
		idStrings[i] = id.String()
	}

	// Prepare request body
	requestBody := map[string][]string{
		"echo_ids": idStrings,
	}

	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	// Call Content Service batch endpoint
	url := fmt.Sprintf("%s/api/internal/echoes/batch", h.config.ContentServiceURL)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call content service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("content service returned status %d: %s", resp.StatusCode, string(body))
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	// Parse response
	var apiResp struct {
		Success bool          `json:"success"`
		Data    []models.Echo `json:"data"`
	}

	if err := json.Unmarshal(body, &apiResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %w", err)
	}

	if !apiResp.Success {
		return nil, fmt.Errorf("content service returned success=false")
	}

	return apiResp.Data, nil
}
