package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes sets up the routes for the interaction service
func SetupRoutes(router *gin.Engine, handler *Handler) {
	// API group
	api := router.Group("/api")
	{
		// All endpoints require authentication
		users := api.Group("/users")
		users.Use(middleware.AuthMiddleware(handler.config.JWTSecret))
		{
			// Follow/unfollow endpoints
			users.POST("/:id/follow", handler.FollowUser)
			users.DELETE("/:id/follow", handler.UnfollowUser)

			// Get followers/following lists (authenticated to check mutual follows)
			users.GET("/:id/followers", handler.GetFollowers)
			users.GET("/:id/following", handler.GetFollowing)

			// Block/unblock endpoints
			users.POST("/:id/block", handler.BlockUser)
			users.DELETE("/:id/block", handler.UnblockUser)
			users.GET("/blocked", handler.GetBlockedUsers)

			// Mute/unmute endpoints
			users.POST("/:id/mute", handler.MuteUser)
			users.DELETE("/:id/mute", handler.UnmuteUser)
			users.GET("/muted", handler.GetMutedUsers)
		}

		// Internal endpoints (no authentication required - internal service-to-service calls)
		internal := api.Group("/internal")
		{
			internal.GET("/users/:id/followers", handler.GetFollowers)
			internal.GET("/users/:id/following", handler.GetFollowing)
			
			// Trust & Safety checks
			internal.GET("/block-status", handler.CheckBlockStatus)
			internal.GET("/mute-status", handler.CheckMuteStatus)
			
			// Batch endpoints
			internal.POST("/follows/batch-status", handler.GetBatchFollowStatus)
		}
	}
}
