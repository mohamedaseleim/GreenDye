# Ka Backend Services

This directory contains all the microservices for the Ka social platform.

## Services

- **auth-service** (Port 8001): User authentication and authorization
- **user-service** (Port 8002): User profiles and social graph
- **content-service** (Port 8003): Echoes and Stories creation
- **feed-service** (Port 8004): Timeline and feed generation
- **interaction-service** (Port 8005): Likes, comments, shares
- **messaging-service** (Port 8006): Direct messaging with E2EE
- **notification-service** (Port 8007): Push and in-app notifications
- **discovery-service** (Port 8008): Trending topics and recommendations

## Shared Module

The `shared/` directory contains common utilities, models, and middleware used across all services:
- Database connection utilities (PostgreSQL, Redis, ScyllaDB)
- JWT authentication utilities
- Password hashing
- Validation utilities
- Common models (User, Post, Response)
- Middleware (Auth, CORS, Logger)

## Development

### Prerequisites

- Go 1.21+
- Docker & Docker Compose
- PostgreSQL 15+
- Redis 7+
- ScyllaDB 5.2+

### Running with Docker Compose

```bash
# Start infrastructure services (PostgreSQL, Redis, ScyllaDB)
cd ../infrastructure/docker
docker-compose up -d postgres redis scylla

# Wait for services to be healthy (about 1-2 minutes for ScyllaDB)
docker-compose ps

# Start all application services
docker-compose up -d

# View logs
docker-compose logs -f auth-service
```

### Running Locally

```bash
# Start infrastructure services only
cd ../infrastructure/docker
docker-compose up -d postgres redis scylla

# Run a specific service
cd auth-service
go run main.go config.go repository.go handler.go routes.go
```

### Environment Variables

Each service uses the following environment variables:

#### Common Variables
- `PORT`: Service port (default: 8001-8008)
- `DB_HOST`: PostgreSQL host (default: localhost)
- `DB_PORT`: PostgreSQL port (default: 5432)
- `DB_USER`: PostgreSQL user (default: ka_user)
- `DB_PASSWORD`: PostgreSQL password
- `DB_NAME`: PostgreSQL database (default: ka_db)
- `REDIS_HOST`: Redis host (default: localhost)
- `REDIS_PORT`: Redis port (default: 6379)
- `REDIS_PASSWORD`: Redis password

#### Service-Specific Variables

**Auth Service:**
- `JWT_SECRET`: Secret key for JWT signing
- `JWT_EXPIRY`: Access token expiry in seconds (default: 900 = 15 minutes)
- `REFRESH_TOKEN_EXPIRY`: Refresh token expiry in seconds (default: 604800 = 7 days)

**Content/Feed/Interaction Services:**
- `SCYLLA_HOSTS`: ScyllaDB hosts (default: localhost)
- `SCYLLA_KEYSPACE`: Keyspace name (e.g., ka_content)

## API Documentation

See [../docs/API_SPEC.md](../docs/API_SPEC.md) for complete API documentation.

### Quick API Examples

#### Register
```bash
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john@example.com",
    "password": "SecurePass123!",
    "display_name": "John Doe"
  }'
```

#### Login
```bash
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "SecurePass123!"
  }'
```

#### Health Check
```bash
curl http://localhost:8001/health
```

## Testing

```bash
# Run tests for a specific service
cd auth-service
go test -v ./...

# Run tests for all services
for dir in */; do
  if [ -f "$dir/go.mod" ]; then
    echo "Testing $dir"
    cd "$dir" && go test -v ./... && cd ..
  fi
done
```

## Building

```bash
# Build a specific service
cd auth-service
go build -o bin/auth-service .

# Build with Docker
docker build -t ka-auth-service .
```

## Troubleshooting

### Database Connection Issues

```bash
# Check if PostgreSQL is running
docker-compose ps postgres

# View PostgreSQL logs
docker-compose logs postgres

# Connect to PostgreSQL
docker-compose exec postgres psql -U ka_user -d ka_db
```

### ScyllaDB Issues

```bash
# Check ScyllaDB status
docker-compose exec scylla nodetool status

# View ScyllaDB logs
docker-compose logs scylla

# Connect to ScyllaDB CQL shell
docker-compose exec scylla cqlsh
```

### Redis Issues

```bash
# Check Redis
docker-compose exec redis redis-cli -a ka_redis_password ping

# View Redis logs
docker-compose logs redis
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Client (Flutter App)                    │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTPS/WSS
                         │
┌────────────────────────▼────────────────────────────────────┐
│                  API Gateway (Optional)                      │
└───┬──────┬──────┬──────┬──────┬──────┬──────┬──────────────┘
    │      │      │      │      │      │      │
┌───▼──┐ ┌─▼────┐ ┌▼────┐ ┌▼────┐ ┌▼───┐ ┌▼──┐ ┌▼──────────┐
│Auth  │ │User  │ │Feed │ │Cont │ │Int │ │Msg│ │Discovery  │
│Svc   │ │Svc   │ │Svc  │ │Svc  │ │Svc │ │Svc│ │Svc        │
└──┬───┘ └──┬───┘ └─┬───┘ └─┬───┘ └─┬──┘ └─┬─┘ └─────┬─────┘
   │        │       │       │       │      │         │
   └────────┴───────┴───────┴───────┴──────┴─────────┘
                    │
   ┌────────────────┴─────────────────────────────────┐
   │                                                   │
┌──▼──────────┐  ┌──────────┐  ┌────────────────────▼┐
│ PostgreSQL  │  │  Redis   │  │  ScyllaDB/Cassandra │
│             │  │ (Cache)  │  │                      │
│- Users      │  │          │  │- Posts (Echoes)      │
│- Relations  │  │- Sessions│  │- Stories             │
│- Settings   │  │- Profiles│  │- Timelines           │
└─────────────┘  └──────────┘  └──────────────────────┘
```

## Next Steps

1. Implement remaining services (user, content, feed, etc.)
2. Add comprehensive tests
3. Set up CI/CD pipeline
4. Add API Gateway for routing and rate limiting
5. Implement monitoring and logging (Prometheus, Grafana, ELK)
6. Set up Kubernetes deployment configs

## License

Copyright © 2024 Ka Social Platform. All rights reserved.
