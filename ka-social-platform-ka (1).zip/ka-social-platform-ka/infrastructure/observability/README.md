# Observability Stack for Ka Platform

This directory contains the complete observability stack for monitoring, logging, and alerting.

## Components

- **Prometheus**: Metrics collection and storage
- **Grafana**: Visualization and dashboards
- **Loki**: Log aggregation and querying
- **Promtail**: Log shipping agent

## Quick Start

### Deploy All Components

```bash
# Create namespace if not exists
kubectl create namespace ka-platform --dry-run=client -o yaml | kubectl apply -f -

# Deploy Prometheus
kubectl apply -f prometheus/

# Deploy Grafana
kubectl apply -f grafana/

# Deploy Loki
kubectl apply -f loki/

# Verify deployments
kubectl get pods -n ka-platform -l app=prometheus
kubectl get pods -n ka-platform -l app=grafana
kubectl get pods -n ka-platform -l app=loki
```

### Access Dashboards

**Prometheus**:
```bash
kubectl port-forward -n ka-platform svc/prometheus 9090:9090
# Open http://localhost:9090
```

**Grafana**:
```bash
kubectl port-forward -n ka-platform svc/grafana 3000:3000
# Open http://localhost:3000
# Default credentials: admin / (see secret)
```

**Loki** (via Grafana):
```bash
# Already configured as datasource in Grafana
# Query logs using LogQL in Grafana Explore
```

## Prometheus

### Metrics Available

- **HTTP Metrics**:
  - `http_requests_total`: Total HTTP requests
  - `http_request_duration_seconds`: Request latency
  - `http_requests_in_flight`: Active requests

- **Database Metrics**:
  - `db_connections_total`: Database connections
  - `db_query_duration_seconds`: Query latency

- **Cache Metrics**:
  - `cache_hits_total`: Cache hits
  - `cache_misses_total`: Cache misses

- **Business Metrics**:
  - `posts_created_total`: Posts created
  - `users_registered_total`: Users registered

### Query Examples

```promql
# Request rate per service
sum(rate(http_requests_total[5m])) by (service)

# Error rate
sum(rate(http_requests_total{status=~"5.."}[5m])) by (service)

# P95 latency
histogram_quantile(0.95, 
  sum(rate(http_request_duration_seconds_bucket[5m])) by (service, le)
)

# Cache hit rate
sum(rate(cache_hits_total[5m])) / 
  (sum(rate(cache_hits_total[5m])) + sum(rate(cache_misses_total[5m])))
```

### Configuration

Edit `prometheus/prometheus-config.yaml` to:
- Add new scrape targets
- Configure retention period
- Add alerting rules
- Adjust scrape intervals

## Grafana

### Pre-configured Dashboards

1. **Ka Platform - API Gateway Traffic**:
   - Request rate by service
   - Latency percentiles
   - Error rates
   - Active requests
   - Cache performance
   - Database performance
   - Pod resources

### Add Custom Dashboards

1. Access Grafana UI
2. Go to Dashboards → New Dashboard
3. Add panels with PromQL queries
4. Save and export JSON
5. Add to `grafana/ka-platform-dashboard.yaml`

### Datasources

Two datasources are pre-configured:
- **Prometheus**: For metrics
- **Loki**: For logs

## Loki

### Log Collection

Promtail runs as a DaemonSet on every node and:
- Collects logs from all pods
- Adds Kubernetes labels
- Ships to Loki for storage

### Query Examples

```logql
# All logs from a service
{app="auth-service"}

# Error logs across all services
{namespace="ka-platform"} |= "error"

# Logs from specific pod
{pod="auth-service-12345"}

# Filter by log level
{app="content-service"} | json | level="error"

# Count errors per minute
sum(rate({namespace="ka-platform"} |= "error" [1m])) by (app)
```

### Access Logs

Use Grafana Explore:
1. Select Loki datasource
2. Enter LogQL query
3. View logs and metrics

## Alerting

### Configure Alerts in Prometheus

Create alert rules in `prometheus/prometheus-config.yaml`:

```yaml
groups:
  - name: ka-platform-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High error rate on {{ $labels.service }}"
          description: "Error rate is {{ $value }} per second"
      
      - alert: HighLatency
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High latency on {{ $labels.service }}"
          description: "P95 latency is {{ $value }} seconds"
      
      - alert: PodCrashLooping
        expr: rate(kube_pod_container_status_restarts_total[15m]) > 0
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Pod {{ $labels.pod }} is crash looping"
```

### Alert Destinations

Configure Alertmanager to send alerts to:
- Slack
- PagerDuty
- Email
- Webhook

Example Alertmanager config:

```yaml
route:
  group_by: ['alertname', 'cluster']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 12h
  receiver: 'slack'

receivers:
  - name: 'slack'
    slack_configs:
      - api_url: 'YOUR_SLACK_WEBHOOK_URL'
        channel: '#alerts'
        text: '{{ range .Alerts }}{{ .Annotations.summary }}\n{{ end }}'
```

## Performance Tuning

### Prometheus

**Retention**:
```yaml
args:
  - '--storage.tsdb.retention.time=15d'  # Adjust as needed
```

**Scrape Interval**:
```yaml
global:
  scrape_interval: 15s  # More frequent = more data
```

**Resource Limits**:
```yaml
resources:
  requests:
    cpu: 500m
    memory: 1Gi
  limits:
    cpu: 1000m
    memory: 2Gi  # Increase for longer retention
```

### Loki

**Retention**:
```yaml
limits_config:
  retention_period: 720h  # 30 days
```

**Compaction**:
```yaml
compactor:
  working_directory: /loki/compactor
  shared_store: filesystem
  compaction_interval: 10m
```

### Grafana

**Performance**:
- Limit time range for large queries
- Use query caching
- Aggregate data at source (Prometheus)

## Troubleshooting

### Prometheus Not Scraping Targets

```bash
# Check service discovery
kubectl get pods -n ka-platform -l app=prometheus -o wide

# Check targets in Prometheus UI
# Go to Status → Targets

# Verify pod annotations
kubectl get pods -n ka-platform -o yaml | grep prometheus.io
```

### Grafana Cannot Connect to Datasources

```bash
# Check service endpoints
kubectl get endpoints -n ka-platform prometheus
kubectl get endpoints -n ka-platform loki

# Test connectivity
kubectl run -it --rm debug --image=curlimages/curl -n ka-platform -- \
  curl http://prometheus:9090/-/healthy
```

### Loki Not Receiving Logs

```bash
# Check Promtail pods
kubectl get pods -n ka-platform -l app=promtail

# Check Promtail logs
kubectl logs -n ka-platform -l app=promtail

# Verify log paths
kubectl exec -it -n ka-platform <promtail-pod> -- ls -la /var/log/pods/
```

### High Memory Usage

```bash
# Check current usage
kubectl top pods -n ka-platform -l app=prometheus

# Solutions:
# 1. Reduce retention period
# 2. Reduce scrape frequency
# 3. Increase memory limits
# 4. Use remote storage (Thanos, Cortex)
```

## Best Practices

1. **Metrics**:
   - Keep cardinality low (avoid high-cardinality labels)
   - Use histograms for latency, counters for rates
   - Aggregate data at collection time

2. **Logs**:
   - Log at appropriate levels (DEBUG, INFO, WARN, ERROR)
   - Include context (request ID, user ID)
   - Use structured logging (JSON)

3. **Dashboards**:
   - Start with USE method (Utilization, Saturation, Errors)
   - Group related metrics
   - Use templating for multi-service views

4. **Alerts**:
   - Alert on symptoms, not causes
   - Set appropriate thresholds
   - Include runbooks in annotations

## Upgrading

### Prometheus

```bash
# Update image version
kubectl set image deployment/prometheus \
  prometheus=prom/prometheus:v2.48.0 \
  -n ka-platform
```

### Grafana

```bash
# Update image version
kubectl set image deployment/grafana \
  grafana=grafana/grafana:10.2.0 \
  -n ka-platform
```

### Loki

```bash
# Update image version
kubectl set image statefulset/loki \
  loki=grafana/loki:2.10.0 \
  -n ka-platform
```

## Resources

- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [Loki Documentation](https://grafana.com/docs/loki/)
- [PromQL Tutorial](https://prometheus.io/docs/prometheus/latest/querying/basics/)
- [LogQL Tutorial](https://grafana.com/docs/loki/latest/logql/)

## Support

For issues or questions:
1. Check logs: `kubectl logs -n ka-platform -l app=<component>`
2. Check events: `kubectl get events -n ka-platform`
3. Review this documentation
4. Open an issue on GitHub
