# Ka Platform - GCP Deployment Flow

Visual guide showing how the deployment process works on Google Cloud Platform.

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         GOOGLE CLOUD PLATFORM                        │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────┐   │
│  │                    GKE Cluster (Regional)                   │   │
│  │                                                              │   │
│  │  ┌─────────────────────────────────────────────────────┐  │   │
│  │  │              Kubernetes Namespace: ka-platform       │  │   │
│  │  │                                                       │  │   │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌───────────┐ │  │   │
│  │  │  │ Auth Service │  │ User Service │  │Feed Service│ │  │   │
│  │  │  │  (3 pods)    │  │  (3 pods)    │  │  (3 pods)  │ │  │   │
│  │  │  └──────────────┘  └──────────────┘  └───────────┘ │  │   │
│  │  │                                                       │  │   │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌───────────┐ │  │   │
│  │  │  │Content Service│ │Interaction   │  │Engagement │ │  │   │
│  │  │  │  (3 pods)    │  │  Service     │  │ Service   │ │  │   │
│  │  │  └──────────────┘  │  (3 pods)    │  │ (3 pods)  │ │  │   │
│  │  │                    └──────────────┘  └───────────┘ │  │   │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌───────────┐ │  │   │
│  │  │  │Discovery     │  │Media Service │  │ Billing   │ │  │   │
│  │  │  │Service       │  │  (3 pods)    │  │ Service   │ │  │   │
│  │  │  │  (3 pods)    │  └──────────────┘  │ (3 pods)  │ │  │   │
│  │  │  └──────────────┘                    └───────────┘ │  │   │
│  │  │                                                       │  │   │
│  │  │  ┌──────────────────────────────────────────────┐  │  │   │
│  │  │  │           Data Layer (StatefulSets)          │  │  │   │
│  │  │  │                                                │  │  │   │
│  │  │  │  PostgreSQL  │  Redis  │  ScyllaDB  │  MinIO │  │  │   │
│  │  │  │  Meilisearch │  NATS                          │  │  │   │
│  │  │  └──────────────────────────────────────────────┘  │  │   │
│  │  │                                                       │  │   │
│  │  │  ┌──────────────────────────────────────────────┐  │  │   │
│  │  │  │        Monitoring Stack                       │  │  │   │
│  │  │  │                                                │  │  │   │
│  │  │  │  Prometheus  │  Grafana  │  Loki  │  Promtail│  │  │   │
│  │  │  └──────────────────────────────────────────────┘  │  │   │
│  │  └─────────────────────────────────────────────────────┘  │   │
│  │                                                              │   │
│  │  ┌─────────────────────────────────────────────────────┐  │   │
│  │  │            Kubernetes Namespace: argocd              │  │   │
│  │  │                                                       │  │   │
│  │  │  Argo CD Server  │  Application Controller          │  │   │
│  │  │  Repo Server     │  Redis                            │  │   │
│  │  └─────────────────────────────────────────────────────┘  │   │
│  └────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────┐   │
│  │              Optional Managed Services                     │   │
│  │                                                              │   │
│  │  Cloud SQL (PostgreSQL) │ Cloud Memorystore (Redis)       │   │
│  │  Cloud Storage (Media)  │ Cloud CDN                        │   │
│  └────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────┐   │
│  │                    Networking                              │   │
│  │                                                              │   │
│  │  VPC Network  │  Subnets  │  Cloud Load Balancer          │   │
│  │  Static IP    │  Firewall Rules                            │   │
│  └────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

## Deployment Flow

### Phase 1: Infrastructure Provisioning (Terraform)

```
┌──────────────┐
│   Developer  │
└──────┬───────┘
       │ 1. terraform apply
       ▼
┌──────────────────┐
│    Terraform     │
│    (Local)       │
└──────┬───────────┘
       │ 2. Create resources via GCP API
       ▼
┌────────────────────────────────────────────┐
│         Google Cloud Platform              │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  1. Create VPC & Subnets             │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  2. Provision GKE Cluster            │ │
│  │     - Master nodes                   │ │
│  │     - Worker node pool               │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  3. Create Node Pool                 │ │
│  │     - 3 zones (HA)                   │ │
│  │     - Autoscaling enabled            │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  4. Setup Managed Services (opt)     │ │
│  │     - Cloud SQL PostgreSQL           │ │
│  │     - Cloud Memorystore Redis        │ │
│  │     - Cloud Storage bucket           │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  5. Create Static IP                 │ │
│  │     - For Ingress/Load Balancer      │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  6. Configure kubectl access         │ │
│  └──────────────────────────────────────┘ │
└────────────────────────────────────────────┘
       │
       ▼
  ✅ Infrastructure Ready
     (~10-15 minutes)
```

### Phase 2: GitOps Setup (Argo CD)

```
┌──────────────┐
│   kubectl    │
└──────┬───────┘
       │ 1. Install Argo CD
       ▼
┌────────────────────────────────────────────┐
│         GKE Cluster                        │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  Namespace: argocd                   │ │
│  │                                       │ │
│  │  - argocd-server                     │ │
│  │  - argocd-application-controller     │ │
│  │  - argocd-repo-server                │ │
│  │  - argocd-redis                      │ │
│  │  - argocd-dex-server                 │ │
│  └──────────────────────────────────────┘ │
└────────────────────────────────────────────┘
       │
       ▼
  ✅ Argo CD Installed
     (~3-5 minutes)
```

### Phase 3: Application Deployment (GitOps)

```
┌──────────────┐
│   kubectl    │
│   apply      │
└──────┬───────┘
       │ 1. Apply Application manifest
       ▼
┌────────────────────────────────────────────┐
│         Argo CD                            │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  Application Controller              │ │
│  │  - Watches Git repository            │ │
│  │  - Detects changes                   │ │
│  │  - Syncs to cluster                  │ │
│  └──────────────────────────────────────┘ │
└──────┬─────────────────────────────────────┘
       │ 2. Read Helm charts from Git
       ▼
┌────────────────────────────────────────────┐
│         GitHub Repository                  │
│                                            │
│  charts/ka-platform/                      │
│  ├── values.yaml                          │
│  ├── Chart.yaml                           │
│  └── templates/                           │
│      ├── deployment.yaml                  │
│      ├── service.yaml                     │
│      └── ...                              │
└──────┬─────────────────────────────────────┘
       │ 3. Template and apply to cluster
       ▼
┌────────────────────────────────────────────┐
│         GKE Cluster                        │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  Namespace: ka-platform              │ │
│  │                                       │ │
│  │  1. Deploy Databases                 │ │
│  │     - PostgreSQL StatefulSet         │ │
│  │     - Redis StatefulSet              │ │
│  │     - ScyllaDB StatefulSet           │ │
│  │     - MinIO Deployment               │ │
│  │     - Meilisearch StatefulSet        │ │
│  │     - NATS Deployment                │ │
│  │                                       │ │
│  │  2. Wait for databases ready         │ │
│  │                                       │ │
│  │  3. Deploy API Services              │ │
│  │     - auth-service                   │ │
│  │     - user-service                   │ │
│  │     - content-service                │ │
│  │     - feed-service                   │ │
│  │     - interaction-service            │ │
│  │     - engagement-service             │ │
│  │     - discovery-service              │ │
│  │     - media-service                  │ │
│  │     - billing-service                │ │
│  │                                       │ │
│  │  4. Create Services & Ingress        │ │
│  │     - ClusterIP services             │ │
│  │     - Load Balancer                  │ │
│  │     - Ingress rules                  │ │
│  │                                       │ │
│  │  5. Configure HPA                    │ │
│  │     - Auto-scaling rules             │ │
│  └──────────────────────────────────────┘ │
└────────────────────────────────────────────┘
       │
       ▼
  ✅ Application Deployed
     (~5-10 minutes)
```

### Phase 4: Observability Setup

```
┌──────────────┐
│   kubectl    │
│   apply      │
└──────┬───────┘
       │ Deploy monitoring manifests
       ▼
┌────────────────────────────────────────────┐
│         GKE Cluster                        │
│         Namespace: ka-platform             │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  1. Deploy Prometheus                │ │
│  │     - Metrics collection             │ │
│  │     - Service discovery              │ │
│  │     - Alert rules                    │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  2. Deploy Grafana                   │ │
│  │     - Dashboards                     │ │
│  │     - Data sources                   │ │
│  │     - Alerts                         │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  3. Deploy Loki                      │ │
│  │     - Log aggregation                │ │
│  │     - Promtail DaemonSet             │ │
│  └──────────────────────────────────────┘ │
└────────────────────────────────────────────┘
       │
       ▼
  ✅ Monitoring Active
     (~3-5 minutes)
```

## CI/CD Flow (Continuous Deployment)

```
┌──────────────┐
│  Developer   │
│  git push    │
└──────┬───────┘
       │ 1. Push code to GitHub
       ▼
┌────────────────────────────────────────────┐
│         GitHub Repository                  │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  GitHub Actions Workflow             │ │
│  │  (.github/workflows/gitops-pipeline) │ │
│  └──────────────────────────────────────┘ │
└──────┬─────────────────────────────────────┘
       │ 2. Trigger workflow
       ▼
┌────────────────────────────────────────────┐
│         GitHub Actions Runner              │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  1. Build Docker Images              │ │
│  │     - For each microservice          │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  2. Push to Container Registry       │ │
│  │     - ghcr.io/*/ka-social-platform/* │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  3. Update Helm values.yaml          │ │
│  │     - Set new image tags             │ │
│  └──────────────────────────────────────┘ │
│           ▼                                 │
│  ┌──────────────────────────────────────┐ │
│  │  4. Commit & Push changes            │ │
│  │     - Git commit to main             │ │
│  └──────────────────────────────────────┘ │
└──────┬─────────────────────────────────────┘
       │ 5. Argo CD detects changes
       ▼
┌────────────────────────────────────────────┐
│         Argo CD (in GKE)                   │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  Application Controller              │ │
│  │  - Polls Git every 3 minutes         │ │
│  │  - Detects new image tags            │ │
│  │  - Syncs changes to cluster          │ │
│  └──────────────────────────────────────┘ │
└──────┬─────────────────────────────────────┘
       │ 6. Rolling update
       ▼
┌────────────────────────────────────────────┐
│         Kubernetes Deployments             │
│                                            │
│  ┌──────────────────────────────────────┐ │
│  │  Rolling Update Strategy             │ │
│  │  - Terminate old pod                 │ │
│  │  - Start new pod with new image      │ │
│  │  - Wait for health check             │ │
│  │  - Repeat for all replicas           │ │
│  │  - Zero downtime                     │ │
│  └──────────────────────────────────────┘ │
└────────────────────────────────────────────┘
       │
       ▼
  ✅ New Version Deployed
     (~5-10 minutes total)
```

## Traffic Flow (Production)

```
┌──────────────┐
│   Internet   │
│   Users      │
└──────┬───────┘
       │ HTTPS Request
       ▼
┌────────────────────────────────────────────┐
│     Google Cloud Load Balancer             │
│     (Static IP: xxx.xxx.xxx.xxx)           │
└──────┬─────────────────────────────────────┘
       │ Route based on domain/path
       ▼
┌────────────────────────────────────────────┐
│         Kubernetes Ingress                 │
│         (NGINX Ingress Controller)         │
└──────┬─────────────────────────────────────┘
       │
       ├─ /auth/*    ──> auth-service:8001
       ├─ /user/*    ──> user-service:8002
       ├─ /content/* ──> content-service:8003
       ├─ /feed/*    ──> feed-service:8004
       ├─ /interact/*──> interaction-service:8005
       └─ /media/*   ──> media-service:8006
       │
       ▼
┌────────────────────────────────────────────┐
│     Kubernetes Services (ClusterIP)        │
│     (Load balancing across pods)           │
└──────┬─────────────────────────────────────┘
       │
       ▼
┌────────────────────────────────────────────┐
│     Application Pods                       │
│     (Auto-scaled 1-10 replicas)            │
│                                            │
│     ┌──────┐  ┌──────┐  ┌──────┐         │
│     │ Pod  │  │ Pod  │  │ Pod  │         │
│     │  1   │  │  2   │  │  3   │         │
│     └──────┘  └──────┘  └──────┘         │
└──────┬─────────────────────────────────────┘
       │ Query databases
       ▼
┌────────────────────────────────────────────┐
│     Data Layer                             │
│                                            │
│  PostgreSQL │ Redis │ ScyllaDB │ MinIO    │
└────────────────────────────────────────────┘
```

## Monitoring & Alerting Flow

```
┌────────────────────────────────────────────┐
│     Application Pods                       │
│     (Expose /metrics endpoint)             │
└──────┬─────────────────────────────────────┘
       │ Scrape metrics
       ▼
┌────────────────────────────────────────────┐
│         Prometheus                         │
│         (Service Discovery + Scraping)     │
└──────┬─────────────────────────────────────┘
       │ Store & Query
       ▼
┌────────────────────────────────────────────┐
│         Grafana                            │
│         (Visualization + Dashboards)       │
└────────────────────────────────────────────┘

┌────────────────────────────────────────────┐
│     Application Pods                       │
│     (stdout/stderr logs)                   │
└──────┬─────────────────────────────────────┘
       │ Collect logs
       ▼
┌────────────────────────────────────────────┐
│         Promtail DaemonSet                 │
│         (Log collection agent on each node)│
└──────┬─────────────────────────────────────┘
       │ Ship logs
       ▼
┌────────────────────────────────────────────┐
│         Loki                               │
│         (Log aggregation & indexing)       │
└──────┬─────────────────────────────────────┘
       │ Query via Grafana
       ▼
┌────────────────────────────────────────────┐
│         Grafana                            │
│         (Log exploration & analysis)       │
└────────────────────────────────────────────┘
```

## Auto-Scaling Flow

```
┌────────────────────────────────────────────┐
│     Metrics Server                         │
│     (Collects CPU/Memory metrics)          │
└──────┬─────────────────────────────────────┘
       │ Reports to
       ▼
┌────────────────────────────────────────────┐
│     Horizontal Pod Autoscaler (HPA)        │
│     - Target: 70% CPU utilization          │
│     - Min replicas: 1                      │
│     - Max replicas: 10                     │
└──────┬─────────────────────────────────────┘
       │
       │ CPU > 70% ─────> Scale UP ──┐
       │                              ▼
       │                    ┌──────────────────┐
       │                    │ Add more pods    │
       │                    └──────────────────┘
       │
       │ CPU < 40% ─────> Scale DOWN ┐
       │                              ▼
       │                    ┌──────────────────┐
       │                    │ Remove pods      │
       │                    └──────────────────┘
       │
       ▼
┌────────────────────────────────────────────┐
│     Deployment                             │
│     (Adjusts replica count)                │
└──────┬─────────────────────────────────────┘
       │
       │ Needs more nodes? ──────────┐
       ▼                              ▼
┌────────────────────────────────────────────┐
│     Cluster Autoscaler                     │
│     - Monitors pending pods                │
│     - Scales node pool                     │
│     - Min nodes: 1 per zone               │
│     - Max nodes: 3 per zone               │
└──────┬─────────────────────────────────────┘
       │
       ▼
┌────────────────────────────────────────────┐
│     GKE Node Pool                          │
│     (Adds or removes nodes)                │
└────────────────────────────────────────────┘
```

## Disaster Recovery Flow

```
┌────────────────────────────────────────────┐
│     Regular Operations                     │
│                                            │
│  Databases ────> Automated Backups        │
│  - PostgreSQL:   Daily snapshots          │
│  - Redis:        AOF persistence          │
│  - ScyllaDB:     Daily snapshots          │
└────────────────────────────────────────────┘

       │ Disaster occurs
       ▼
┌────────────────────────────────────────────┐
│     Disaster Recovery                      │
│                                            │
│  1. Assess damage                         │
│  2. Review latest backups                 │
│  3. Deploy new infrastructure (Terraform) │
│  4. Restore databases from backups        │
│  5. Deploy applications (Argo CD)         │
│  6. Verify functionality                  │
│  7. Update DNS (if needed)                │
└────────────────────────────────────────────┘
       │
       ▼
  ✅ System Recovered
     (RTO: ~30 minutes)
```

## Summary: Complete Deployment Timeline

| Phase | Activity | Duration | Status |
|-------|----------|----------|--------|
| 1 | GCP Project Setup | 5 min | Manual |
| 2 | Terraform Infrastructure | 10-15 min | Automated |
| 3 | Argo CD Installation | 3-5 min | Automated |
| 4 | Application Deployment | 5-10 min | GitOps |
| 5 | Monitoring Setup | 3-5 min | Automated |
| **Total** | **End-to-End Deployment** | **~30 min** | **Mostly Automated** |

## Key Benefits of This Architecture

✅ **High Availability**: Multi-zone GKE cluster  
✅ **Auto-Scaling**: HPA + Cluster Autoscaler  
✅ **Zero Downtime**: Rolling updates  
✅ **GitOps**: Declarative, version-controlled  
✅ **Observable**: Metrics, logs, traces  
✅ **Secure**: Network policies, RBAC, secrets  
✅ **Cost-Optimized**: Autoscaling, right-sizing  

---

**Deployment Flow Version**: 1.0.0  
**Last Updated**: 2024
