package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/database"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"
)

func main() {
	// Get environment variables
	port := getEnv("PORT", "8003")
	scyllaHosts := getEnv("SCYLLA_HOSTS", "localhost")
	scyllaKeyspace := getEnv("SCYLLA_KEYSPACE", "ka_content")
	redisHost := getEnv("REDIS_HOST", "localhost")
	redisPort := getEnv("REDIS_PORT", "6379")
	redisPassword := getEnv("REDIS_PASSWORD", "")
	jwtSecret := getEnv("JWT_SECRET", "your-super-secret-jwt-key-change-in-production")
	natsURL := getEnv("NATS_URL", "nats://localhost:4222")
	mediaServiceURL := getEnv("MEDIA_SERVICE_URL", "http://localhost:8004")
	engagementServiceURL := getEnv("ENGAGEMENT_SERVICE_URL", "http://localhost:8007")
	interactionServiceURL := getEnv("INTERACTION_SERVICE_URL", "http://localhost:8005")

	// Initialize database connections
	scyllaSession, err := database.NewScyllaConnection(database.ScyllaConfig{
		Hosts:    scyllaHosts,
		Keyspace: scyllaKeyspace,
	})
	if err != nil {
		log.Fatalf("Failed to connect to ScyllaDB: %v", err)
	}
	defer scyllaSession.Close()

	redisClient, err := database.NewRedisConnection(database.RedisConfig{
		Host:     redisHost,
		Port:     redisPort,
		Password: redisPassword,
		DB:       0,
	})
	if err != nil {
		log.Fatalf("Failed to connect to Redis: %v", err)
	}
	defer redisClient.Close()

	// Initialize NATS connection
	natsPublisher, err := NewNATSPublisher(natsURL)
	if err != nil {
		log.Fatalf("Failed to connect to NATS: %v", err)
	}
	defer natsPublisher.Close()

	// Initialize Trust & Safety consumer
	tsConsumer := trustsafety.NewEventConsumer(natsPublisher.GetConn(), redisClient, "content-service")
	if err := tsConsumer.Start(); err != nil {
		log.Printf("Warning: Failed to start Trust & Safety consumer: %v", err)
	}

	// Initialize service clients
	mediaClient := NewMediaClient(mediaServiceURL)
	engagementClient := NewEngagementClient(engagementServiceURL)
	interactionClient := NewInteractionClient(interactionServiceURL)

	// Initialize Gin router
	router := gin.Default()

	// Add middleware
	router.Use(middleware.CORSMiddleware())
	router.Use(middleware.LoggerMiddleware())

	// Create config
	config := &Config{
		ScyllaSession:     scyllaSession,
		Redis:             redisClient,
		JWTSecret:         jwtSecret,
		NATSPublisher:     natsPublisher,
		MediaServiceURL:   mediaServiceURL,
		MediaClient:       mediaClient,
		EngagementClient:  engagementClient,
		InteractionClient: interactionClient,
	}

	// Initialize repositories and handlers
	repo := NewRepository(scyllaSession, redisClient)
	handler := NewHandler(repo, config)

	// Setup routes
	SetupRoutes(router, handler, jwtSecret)

	// Health check endpoint
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"status":  "ok",
			"service": "content-service",
		})
	})

	// Start server
	log.Printf("Content service starting on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}

func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}
