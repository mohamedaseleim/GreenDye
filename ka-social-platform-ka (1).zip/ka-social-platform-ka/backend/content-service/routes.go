package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes configures the routes for the content service
func SetupRoutes(router *gin.Engine, handler *Handler, jwtSecret string) {
	// API v1 routes
	v1 := router.Group("/api/v1")
	{
		// Echo endpoints (require authentication)
		echoes := v1.Group("/echoes")
		echoes.Use(middleware.AuthMiddleware(jwtSecret))
		{
			echoes.POST("", handler.CreateEcho)
			echoes.DELETE("/:echoId", handler.DeleteEcho)
			echoes.GET("/:echoId/thread", handler.GetThread)
			echoes.GET("/:echoId/replies", handler.GetReplies)
		}
	}

	// Internal endpoints (no authentication - for service-to-service calls)
	internal := router.Group("/api/internal")
	{
		internal.POST("/echoes/batch", handler.BatchGetEchoes)
		internal.PATCH("/echoes/:echoId/likes", handler.UpdateLikeCount)
	}
}
