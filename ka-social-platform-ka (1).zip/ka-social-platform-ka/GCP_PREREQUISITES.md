# Google Cloud Platform - Prerequisites & Setup

This guide helps you prepare everything needed before deploying Ka Platform to GCP.

## ✅ Checklist

Use this checklist to ensure you're ready to deploy:

### GCP Account
- [ ] Google Cloud account created ([Sign up](https://cloud.google.com/))
- [ ] Billing account created and active
- [ ] Credit card or payment method added
- [ ] Free trial activated (if applicable - $300 credit for 90 days)

### Local Tools
- [ ] Google Cloud SDK (`gcloud`) installed
- [ ] Terraform (v1.5+) installed
- [ ] kubectl (v1.28+) installed
- [ ] Helm (v3.13+) installed
- [ ] Git installed
- [ ] `openssl` available (for secret generation)

### GCP Permissions
- [ ] Project Owner or Editor role on GCP project
- [ ] Or these specific IAM roles:
  - Compute Admin
  - Kubernetes Engine Admin
  - Service Account User
  - Cloud SQL Admin (if using managed databases)
  - Redis Admin (if using managed Redis)

### Resource Quotas
- [ ] Compute Engine CPUs: At least 12 vCPUs in selected region
- [ ] In-use IP addresses: At least 3
- [ ] Persistent Disk SSD: At least 300 GB
- [ ] Cloud SQL instances: At least 1 (if using managed databases)

### Domain & DNS (Production Only)
- [ ] Domain name purchased (if deploying to production)
- [ ] Access to DNS management console
- [ ] SSL certificate or plan to use Let's Encrypt

---

## Step-by-Step Setup

### 1. Install Google Cloud SDK

**macOS:**
```bash
# Using Homebrew
brew install google-cloud-sdk

# Or download installer
curl https://sdk.cloud.google.com | bash
```

**Linux:**
```bash
# Download and install
curl https://sdk.cloud.google.com | bash

# Restart shell
exec -l $SHELL
```

**Windows:**
Download and run the [Windows installer](https://cloud.google.com/sdk/docs/install#windows)

**Verify installation:**
```bash
gcloud version
# Should show: Google Cloud SDK 450.0.0 or later
```

### 2. Install Terraform

**macOS:**
```bash
brew tap hashicorp/tap
brew install hashicorp/tap/terraform
```

**Linux:**
```bash
wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install terraform
```

**Windows:**
Download from [Terraform downloads](https://developer.hashicorp.com/terraform/downloads)

**Verify:**
```bash
terraform version
# Should show: Terraform v1.5.0 or later
```

### 3. Install kubectl

**macOS:**
```bash
brew install kubectl
```

**Linux:**
```bash
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
```

**Windows:**
```bash
choco install kubernetes-cli
```

**Verify:**
```bash
kubectl version --client
# Should show: Client Version: v1.28.0 or later
```

### 4. Install Helm

**macOS:**
```bash
brew install helm
```

**Linux:**
```bash
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

**Windows:**
```bash
choco install kubernetes-helm
```

**Verify:**
```bash
helm version
# Should show: version.BuildInfo{Version:"v3.13.0" or later}
```

### 5. Initialize Google Cloud SDK

```bash
# Login to Google Cloud
gcloud auth login
# This will open a browser window for authentication

# Set up application default credentials (for Terraform)
gcloud auth application-default login

# Verify authentication
gcloud auth list
```

### 6. Create or Select GCP Project

**Create a new project:**
```bash
# Set project ID (must be globally unique)
export PROJECT_ID="ka-platform-prod"

# Create project
gcloud projects create $PROJECT_ID \
  --name="Ka Social Platform Production"

# Set as default
gcloud config set project $PROJECT_ID

# Verify
gcloud config get-value project
```

**Or use existing project:**
```bash
# List projects
gcloud projects list

# Set project
gcloud config set project YOUR_PROJECT_ID
```

### 7. Enable Billing

```bash
# List billing accounts
gcloud billing accounts list

# Link billing to project
gcloud billing projects link $PROJECT_ID \
  --billing-account=XXXXXX-XXXXXX-XXXXXX

# Verify billing is enabled
gcloud billing projects describe $PROJECT_ID
```

If you don't have a billing account, create one at:
https://console.cloud.google.com/billing

### 8. Check Resource Quotas

```bash
# Check current quotas in your region
gcloud compute project-info describe \
  --project=$PROJECT_ID

# Check specific quota
gcloud compute regions describe us-central1 \
  --format="table(quotas.metric,quotas.limit,quotas.usage)"
```

**Minimum Required Quotas:**
- `CPUS`: 12+ (for 3 nodes with e2-standard-4)
- `IN_USE_ADDRESSES`: 3+
- `PERSISTENT_DISK_SSD_GB`: 300+

**Request quota increase if needed:**
1. Go to: https://console.cloud.google.com/iam-admin/quotas
2. Select region and quotas to increase
3. Click "Edit Quotas" and submit request
4. Usually approved within minutes to hours

### 9. Enable Required APIs

```bash
# Enable all APIs needed for Ka Platform
gcloud services enable \
  compute.googleapis.com \
  container.googleapis.com \
  sqladmin.googleapis.com \
  redis.googleapis.com \
  storage-api.googleapis.com \
  cloudresourcemanager.googleapis.com \
  servicenetworking.googleapis.com \
  logging.googleapis.com \
  monitoring.googleapis.com

# Verify APIs are enabled
gcloud services list --enabled
```

### 10. Set Up IAM Permissions (If Not Project Owner)

If you're not the project owner, request these roles:

```bash
# Replace USER_EMAIL with the deploying user's email
USER_EMAIL="user@example.com"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="user:$USER_EMAIL" \
  --role="roles/compute.admin"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="user:$USER_EMAIL" \
  --role="roles/container.admin"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="user:$USER_EMAIL" \
  --role="roles/iam.serviceAccountUser"

# If using managed databases
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="user:$USER_EMAIL" \
  --role="roles/cloudsql.admin"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="user:$USER_EMAIL" \
  --role="roles/redis.admin"
```

---

## Cost Estimation & Budgets

### Set Up Budget Alerts

```bash
# Create budget alert (via Console)
# 1. Go to: https://console.cloud.google.com/billing/budgets
# 2. Click "Create Budget"
# 3. Set budget amount (e.g., $600/month)
# 4. Set alerts at 50%, 90%, 100%
# 5. Add email notifications
```

### Estimated Monthly Costs

**Production Setup:**
- GKE Cluster: $75
- Compute (3x e2-standard-4): $175
- Cloud SQL (2 vCPU, 7.5GB): $125
- Cloud Memorystore (1GB): $50
- Load Balancer: $20
- Network: $50
- **Total: ~$495/month**

**Development Setup:**
- GKE Cluster: $75
- Compute (1x e2-standard-2): $50
- In-cluster databases: $0
- Load Balancer: $20
- Network: $10
- **Total: ~$155/month**

**Free Tier Benefits:**
- New accounts get $300 credit for 90 days
- Always free tier includes some compute and networking
- Can significantly reduce costs during initial testing

### Cost Optimization

Enable these to reduce costs:

```bash
# 1. Use committed use discounts (up to 57% off)
#    Apply in console: https://console.cloud.google.com/compute/commitments

# 2. Use preemptible nodes for dev/staging
#    Edit terraform/gcp/terraform.tfvars:
#    Add: preemptible = true to node_config

# 3. Schedule cluster shutdown for non-prod environments
#    Use Cloud Scheduler to stop/start cluster

# 4. Enable autoscaling to scale down during low traffic
#    Already configured in terraform
```

---

## Verification

Run these commands to verify everything is set up:

```bash
# 1. Check gcloud
gcloud version
gcloud auth list
gcloud config get-value project

# 2. Check Terraform
terraform version

# 3. Check kubectl
kubectl version --client

# 4. Check Helm
helm version

# 5. Verify GCP project and billing
gcloud projects describe $(gcloud config get-value project)
gcloud billing projects describe $(gcloud config get-value project)

# 6. Check enabled APIs
gcloud services list --enabled | grep -E "compute|container|sql"

# 7. Check quotas
gcloud compute project-info describe --format="get(quotas)"
```

**Expected output:**
- ✅ All commands work without errors
- ✅ Project is set
- ✅ Billing is enabled
- ✅ Required APIs are enabled
- ✅ Quotas are sufficient

---

## Security Best Practices

### 1. Use Service Accounts (Production)

```bash
# Create service account for Terraform
gcloud iam service-accounts create terraform-sa \
  --display-name="Terraform Service Account"

# Grant required roles
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:terraform-sa@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/editor"

# Create and download key
gcloud iam service-accounts keys create terraform-key.json \
  --iam-account=terraform-sa@$PROJECT_ID.iam.gserviceaccount.com

# Use with Terraform
export GOOGLE_APPLICATION_CREDENTIALS="./terraform-key.json"
```

### 2. Enable Audit Logging

```bash
# Enable admin activity audit logs (already enabled by default)
# Enable data access audit logs for sensitive operations
gcloud projects get-iam-policy $PROJECT_ID --format=json > policy.json

# Edit policy.json to add audit configs
# Then apply:
gcloud projects set-iam-policy $PROJECT_ID policy.json
```

### 3. Set Up Organization Policies (Enterprise)

```bash
# Restrict public IP assignment
gcloud resource-manager org-policies enable-enforce \
  compute.vmExternalIpAccess \
  --project=$PROJECT_ID

# Require OS Login
gcloud compute project-info add-metadata \
  --metadata enable-oslogin=TRUE
```

---

## Common Issues

### Issue: "Billing not enabled"
**Solution:**
1. Go to https://console.cloud.google.com/billing
2. Create billing account or link existing one
3. Add payment method
4. Link to project

### Issue: "Quota exceeded"
**Solution:**
1. Check current usage: `gcloud compute project-info describe`
2. Request increase: https://console.cloud.google.com/iam-admin/quotas
3. Or reduce node size/count in terraform.tfvars

### Issue: "API not enabled"
**Solution:**
```bash
gcloud services enable <api-name>.googleapis.com
```

### Issue: "Permission denied"
**Solution:**
Ensure you have required IAM roles:
```bash
gcloud projects get-iam-policy $PROJECT_ID \
  --flatten="bindings[].members" \
  --filter="bindings.members:user:YOUR_EMAIL"
```

---

## Next Steps

Once you've completed this checklist:

1. ✅ **All prerequisites met** - You're ready to deploy!
2. 🚀 **Quick Deployment** - Run `./infrastructure/scripts/deploy-gcp.sh`
3. 📖 **Manual Deployment** - Follow [GCP_QUICK_START.md](./GCP_QUICK_START.md)
4. 📚 **Detailed Guide** - See [GOOGLE_CLOUD_DEPLOYMENT.md](./GOOGLE_CLOUD_DEPLOYMENT.md)

---

## Resources

- [Google Cloud Free Tier](https://cloud.google.com/free)
- [GCP Pricing Calculator](https://cloud.google.com/products/calculator)
- [GKE Documentation](https://cloud.google.com/kubernetes-engine/docs)
- [Terraform GCP Provider](https://registry.terraform.io/providers/hashicorp/google/latest/docs)
- [gcloud CLI Reference](https://cloud.google.com/sdk/gcloud/reference)

---

**Prerequisites Guide Version**: 1.0.0  
**Last Updated**: 2024
