# Engagement Service

The Engagement Service handles user interactions (likes) and delivers real-time notifications through WebSocket connections.

## Features

- **Like/Unlike Echoes**: REST API for liking and unliking echoes
- **Real-Time Notifications**: WebSocket endpoint for instant notification delivery
- **Event-Driven**: Consumes `echo.liked` and `user.followed` events from NATS
- **Notification Aggregation**: Groups multiple likes on the same echo to prevent spam
- **Denormalized Counts**: Updates like counts in Content Service for fast reads
- **Connection Pool**: Manages active WebSocket connections per user

## Architecture

### Event Flow

```
User likes echo → Engagement Service REST API
                → Store like in PostgreSQL
                → Publish echo.liked to NATS
                → Update Content Service like count
                ↓
NATS echo.liked event → Engagement Service Consumer
                      → Create/update notification
                      → Push to WebSocket if user connected
                      ↓
                      User receives real-time notification
```

### WebSocket Connection Management

The service maintains a Hub that manages multiple WebSocket connections per user:
- Users can have multiple connections (e.g., web and mobile)
- Notifications are sent to all active connections
- Automatic cleanup on disconnect
- Heartbeat/ping-pong for connection health

## API Endpoints

### REST Endpoints

#### Like an Echo
```
POST /api/v1/echoes/:echoId/like
Authorization: Bearer <jwt_token>

Response:
{
  "success": true,
  "data": {
    "liked": true,
    "already_liked": false
  }
}
```

#### Unlike an Echo
```
DELETE /api/v1/echoes/:echoId/like
Authorization: Bearer <jwt_token>

Response:
{
  "success": true,
  "data": {
    "liked": false,
    "was_liked": true
  }
}
```

#### Get Notifications
```
GET /api/v1/notifications?page=1&per_page=20
Authorization: Bearer <jwt_token>

Response:
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "user_id": "uuid",
      "type": "like",
      "actor_id": "uuid",
      "echo_id": "uuid",
      "content": "liked your echo",
      "is_read": false,
      "created_at": "2024-01-01T00:00:00Z",
      "actor_count": 3,
      "actor_ids": ["uuid1", "uuid2", "uuid3"]
    }
  ],
  "pagination": {
    "page": 1,
    "per_page": 20,
    "total": 100,
    "total_pages": 5
  }
}
```

### WebSocket Endpoint

#### Connect to Notifications Stream
```
ws://localhost:8007/ws/v1/notifications?token=<jwt_token>
```

The WebSocket connection sends real-time notifications as JSON:
```json
{
  "id": "uuid",
  "user_id": "uuid",
  "type": "like",
  "actor_id": "uuid",
  "echo_id": "uuid",
  "content": "liked your echo",
  "is_read": false,
  "created_at": "2024-01-01T00:00:00Z",
  "actor_count": 1,
  "actor_ids": ["uuid"]
}
```

## Notification Aggregation

To prevent notification spam, the service implements aggregation for like notifications:

1. When a like event arrives, check if an unread like notification exists for that echo
2. If yes, update the existing notification:
   - Add the new actor to the `actor_ids` array
   - Increment `actor_count`
   - Keep only the latest 3 actors
3. If no, create a new notification

Example aggregated notification:
```json
{
  "type": "like",
  "content": "liked your echo",
  "actor_count": 15,
  "actor_ids": ["uuid1", "uuid2", "uuid3"]
}
```

The UI can display: "User1, User2, and 13 others liked your post"

## Event Subscriptions

### echo.liked
Published when a user likes an echo. Used to generate like notifications.

Event payload:
```json
{
  "echo_id": "uuid",
  "user_id": "uuid",
  "echo_owner": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### user.followed
Published when a user follows another user. Used to generate follow notifications.

Event payload:
```json
{
  "follower_id": "uuid",
  "following_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

## Database Schema

### likes table (PostgreSQL)
```sql
CREATE TABLE likes (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    echo_id UUID NOT NULL,
    created_at TIMESTAMP,
    UNIQUE(user_id, echo_id)
);
```

### notifications table (PostgreSQL)
```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    type VARCHAR(50),
    actor_id UUID REFERENCES users(id),
    echo_id UUID,
    content TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    actor_ids UUID[],
    actor_count INT DEFAULT 1
);
```

## Configuration

Environment variables:
- `PORT`: Service port (default: 8007)
- `DB_HOST`: PostgreSQL host
- `DB_PORT`: PostgreSQL port
- `DB_USER`: PostgreSQL user
- `DB_PASSWORD`: PostgreSQL password
- `DB_NAME`: PostgreSQL database name
- `REDIS_HOST`: Redis host
- `REDIS_PORT`: Redis port
- `REDIS_PASSWORD`: Redis password
- `JWT_SECRET`: JWT secret for authentication
- `NATS_URL`: NATS server URL
- `CONTENT_SERVICE_URL`: Content Service URL for internal API calls

## Running Locally

```bash
# Start dependencies
cd infrastructure/docker
docker-compose up -d postgres redis nats content-service

# Run the service
cd backend/engagement-service
go run *.go
```

## Testing WebSocket Connection

Using `websocat` (WebSocket client):
```bash
# Install websocat
cargo install websocat

# Connect to notifications stream
websocat "ws://localhost:8007/ws/v1/notifications?token=YOUR_JWT_TOKEN"
```

Using JavaScript:
```javascript
const ws = new WebSocket('ws://localhost:8007/ws/v1/notifications?token=YOUR_JWT_TOKEN');

ws.onmessage = (event) => {
  const notification = JSON.parse(event.data);
  console.log('New notification:', notification);
};

ws.onopen = () => {
  console.log('Connected to notifications stream');
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
};
```

## Integration with Other Services

### Content Service
- **Batch Echo Retrieval**: `POST /api/internal/echoes/batch` - Get echo details including owner
- **Update Like Count**: `PATCH /api/internal/echoes/:id/likes` - Increment/decrement like count

### Interaction Service
- **User Followed Events**: Consumes `user.followed` events to generate follow notifications

## Performance Considerations

- **WebSocket Scaling**: Multiple instances can run behind a load balancer with sticky sessions
- **Database Indexes**: Indexes on `user_id`, `echo_id`, `type`, and `is_read` for fast queries
- **Event Processing**: NATS consumer groups for load balancing across multiple instances
- **Connection Limits**: Monitor and limit concurrent WebSocket connections per instance

## Monitoring

Health check endpoint includes:
```json
{
  "status": "ok",
  "service": "engagement-service",
  "connected_users": 150,
  "total_connections": 250
}
```

Metrics to monitor:
- Number of connected users
- Total WebSocket connections
- Notification creation rate
- Event processing lag
- Database query performance
