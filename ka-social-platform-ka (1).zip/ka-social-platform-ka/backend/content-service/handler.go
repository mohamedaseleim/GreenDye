package main

import (
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/utils"
)

// Handler handles HTTP requests for the content service
type Handler struct {
	repo   *Repository
	config *Config
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	return &Handler{
		repo:   repo,
		config: config,
	}
}

// CreateEcho handles POST /api/v1/echoes
func (h *Handler) CreateEcho(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse request body
	var req models.CreateEchoRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Validate media attachments if present
	if len(req.MediaAttachments) > 0 {
		// Check entitlements for upload limits
		maxAttachments := h.getMaxMediaAttachments(c)
		if len(req.MediaAttachments) > maxAttachments {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"MEDIA_LIMIT_EXCEEDED",
				"Too many media attachments. Free users can attach 1 image, Ka+ users can attach 4 images.",
				gin.H{
					"max_allowed": maxAttachments,
					"provided":    len(req.MediaAttachments),
				},
			))
			return
		}

		// Extract media keys
		mediaKeys := make([]string, len(req.MediaAttachments))
		for i, attachment := range req.MediaAttachments {
			mediaKeys[i] = attachment.MediaKey
		}

		// Validate media ownership with Media Service
		validationResp, err := h.config.MediaClient.ValidateMedia(mediaKeys, userIDStr.(string))
		if err != nil {
			log.Printf("Error validating media: %v", err)
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"MEDIA_VALIDATION_ERROR",
				"Failed to validate media attachments",
				nil,
			))
			return
		}

		if !validationResp.Valid {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"INVALID_MEDIA",
				validationResp.Message,
				validationResp.Invalid,
			))
			return
		}
	}

	// Validate parent echo if specified
	if req.ParentEchoID != nil {
		parentEcho, err := h.repo.GetEchoByID(*req.ParentEchoID)
		if err != nil {
			log.Printf("Error checking parent echo: %v", err)
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"INTERNAL_ERROR",
				"Failed to validate parent echo",
				nil,
			))
			return
		}
		if parentEcho == nil {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"PARENT_ECHO_NOT_FOUND",
				"Parent echo does not exist",
				nil,
			))
			return
		}
	}

	// Extract hashtags from content
	hashtags := ExtractHashtags(req.Content)

	// Create echo
	now := time.Now().UTC()
	echo := &models.Echo{
		ID:               uuid.New(),
		UserID:           userID,
		Content:          req.Content,
		MediaURLs:        req.MediaURLs,
		MediaAttachments: req.MediaAttachments,
		Hashtags:         hashtags,
		Mentions:         req.Mentions,
		ParentEchoID:     req.ParentEchoID,
		Visibility:       req.Visibility,
		LikeCount:        0,
		CommentCount:     0,
		ShareCount:       0,
		CreatedAt:        now,
		UpdatedAt:        now,
	}

	// Save to database
	if err := h.repo.CreateEcho(echo); err != nil {
		log.Printf("Error creating echo: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to create echo",
			nil,
		))
		return
	}

	// Publish event to NATS
	echoEvent := &EchoCreatedEvent{
		EchoID:     echo.ID.String(),
		UserID:     echo.UserID.String(),
		Content:    echo.Content,
		Hashtags:   echo.Hashtags,
		LikesCount: echo.LikeCount,
		Visibility: echo.Visibility,
		Timestamp:  echo.CreatedAt.Format(time.RFC3339),
	}
	if echo.ParentEchoID != nil {
		parentID := echo.ParentEchoID.String()
		echoEvent.ParentEchoID = &parentID
	}
	
	if err := h.config.NATSPublisher.PublishEchoCreated(echoEvent); err != nil {
		// Log error but don't fail the request - echo is already saved
		log.Printf("Warning: Failed to publish echo.created event: %v", err)
	}

	// Return created echo
	c.JSON(http.StatusCreated, models.SuccessResponse(
		echo,
		"Echo created successfully",
	))
}

// DeleteEcho handles DELETE /api/v1/echoes/:echoId
func (h *Handler) DeleteEcho(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse echo ID from URL
	echoIDStr := c.Param("echoId")
	echoID, err := uuid.Parse(echoIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID",
			nil,
		))
		return
	}

	// Get echo to verify ownership
	echo, err := h.repo.GetEchoByID(echoID)
	if err != nil {
		log.Printf("Error retrieving echo: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to retrieve echo",
			nil,
		))
		return
	}

	if echo == nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"ECHO_NOT_FOUND",
			"Echo not found",
			nil,
		))
		return
	}

	// Verify user owns the echo
	if echo.UserID != userID {
		c.JSON(http.StatusForbidden, models.ErrorResponse(
			"FORBIDDEN",
			"You do not have permission to delete this echo",
			nil,
		))
		return
	}

	// Delete echo
	if err := h.repo.DeleteEcho(echoID); err != nil {
		log.Printf("Error deleting echo: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to delete echo",
			nil,
		))
		return
	}

	// Publish event to NATS
	if err := h.config.NATSPublisher.PublishEchoDeleted(echoID, userID); err != nil {
		// Log error but don't fail the request - echo is already deleted
		log.Printf("Warning: Failed to publish echo.deleted event: %v", err)
	}

	// Return success
	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{"echo_id": echoID.String()},
		"Echo deleted successfully",
	))
}

// BatchGetEchoes handles POST /api/internal/echoes/batch
func (h *Handler) BatchGetEchoes(c *gin.Context) {
	// Parse request body
	var req struct {
		EchoIDs []string `json:"echo_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Validate and parse echo IDs
	echoIDs := make([]uuid.UUID, 0, len(req.EchoIDs))
	for _, idStr := range req.EchoIDs {
		echoID, err := uuid.Parse(idStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"INVALID_ECHO_ID",
				"Invalid echo ID format",
				idStr,
			))
			return
		}
		echoIDs = append(echoIDs, echoID)
	}

	// Fetch echoes
	echoes := make([]models.Echo, 0, len(echoIDs))
	for _, echoID := range echoIDs {
		echo, err := h.repo.GetEchoByID(echoID)
		if err != nil {
			log.Printf("Error retrieving echo %s: %v", echoID, err)
			continue
		}
		if echo != nil {
			echoes = append(echoes, *echo)
		}
	}

	// Hydrate media attachments with URLs
	for i := range echoes {
		if len(echoes[i].MediaAttachments) > 0 {
			hydratedAttachments, err := h.config.MediaClient.HydrateMediaAttachments(echoes[i].MediaAttachments)
			if err != nil {
				log.Printf("Warning: Failed to hydrate media for echo %s: %v", echoes[i].ID, err)
				// Continue without hydration rather than failing
			} else {
				echoes[i].MediaAttachments = hydratedAttachments
			}
		}
	}

	// Return echoes (even if some are missing - client will handle)
	c.JSON(http.StatusOK, models.SuccessResponse(
		echoes,
		"Echoes retrieved successfully",
	))
}

// UpdateLikeCount handles PATCH /api/internal/echoes/:echoId/likes
func (h *Handler) UpdateLikeCount(c *gin.Context) {
	// Parse echo ID from URL
	echoIDStr := c.Param("echoId")
	echoID, err := uuid.Parse(echoIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID",
			nil,
		))
		return
	}

	// Parse request body
	var req struct {
		Delta int `json:"delta" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Validate delta is either +1 or -1
	if req.Delta != 1 && req.Delta != -1 {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_DELTA",
			"Delta must be +1 or -1",
			nil,
		))
		return
	}

	// Update like count
	if err := h.repo.UpdateLikeCount(echoID, req.Delta); err != nil {
		log.Printf("Error updating like count: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to update like count",
			nil,
		))
		return
	}

	// Get the updated echo to get the new likes count
	echo, err := h.repo.GetEchoByID(echoID)
	if err != nil {
		log.Printf("Error retrieving updated echo: %v", err)
	} else if echo != nil {
		// Publish echo.updated event to NATS
		if err := h.config.NATSPublisher.PublishEchoUpdated(echoID, echo.LikeCount); err != nil {
			log.Printf("Warning: Failed to publish echo.updated event: %v", err)
		}
	}

	// Return success
	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{"echo_id": echoID.String(), "delta": req.Delta},
		"Like count updated successfully",
	))
}

// getMaxMediaAttachments returns the maximum number of media attachments based on user entitlements
func (h *Handler) getMaxMediaAttachments(c *gin.Context) int {
	// Get entitlements from context (set by auth middleware)
	entitlements := utils.GetEntitlementsFromContext(c)

	// Check if user has EXTENDED_UPLOADS entitlement
	if utils.HasEntitlement(entitlements, utils.EntitlementExtendedUploads) {
		return 4 // Ka+ users can attach 4 images
	}

	return 1 // Free users can attach 1 image
}
