package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
)

// NATSConsumer handles consuming events from NATS
type NATSConsumer struct {
	conn                  *nats.Conn
	repo                  *Repository
	interactionServiceURL string
}

// NewNATSConsumer creates a new NATS consumer
func NewNATSConsumer(url string, repo *Repository, interactionServiceURL string) (*NATSConsumer, error) {
	conn, err := nats.Connect(url)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to NATS: %w", err)
	}

	log.Printf("Successfully connected to NATS at %s", url)
	return &NATSConsumer{
		conn:                  conn,
		repo:                  repo,
		interactionServiceURL: interactionServiceURL,
	}, nil
}

// Close closes the NATS connection
func (c *NATSConsumer) Close() {
	if c.conn != nil {
		c.conn.Close()
	}
}

// GetConn returns the NATS connection
func (c *NATSConsumer) GetConn() *nats.Conn {
	return c.conn
}

// EchoCreatedEvent represents an echo.created event
type EchoCreatedEvent struct {
	EchoID       string  `json:"echo_id"`
	UserID       string  `json:"user_id"`
	Timestamp    string  `json:"timestamp"`
	ParentEchoID *string `json:"parent_echo_id,omitempty"`
}

// EchoDeletedEvent represents an echo.deleted event
type EchoDeletedEvent struct {
	EchoID    string `json:"echo_id"`
	UserID    string `json:"user_id"`
	Timestamp string `json:"timestamp"`
}

// FollowerResponse represents a follower from the interaction service
type FollowerResponse struct {
	Success bool `json:"success"`
	Data    struct {
		Items []struct {
			ID string `json:"id"`
		} `json:"items"`
		Pagination struct {
			Total      int64 `json:"total"`
			TotalPages int   `json:"total_pages"`
		} `json:"pagination"`
	} `json:"data"`
}

// Start starts consuming events from NATS
func (c *NATSConsumer) Start() error {
	// Subscribe to echo.created events
	_, err := c.conn.Subscribe("echo.created", func(msg *nats.Msg) {
		var event EchoCreatedEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("Error unmarshaling echo.created event: %v", err)
			return
		}

		if err := c.handleEchoCreated(event); err != nil {
			log.Printf("Error handling echo.created event: %v", err)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to echo.created: %w", err)
	}

	// Subscribe to echo.deleted events
	_, err = c.conn.Subscribe("echo.deleted", func(msg *nats.Msg) {
		var event EchoDeletedEvent
		if err := json.Unmarshal(msg.Data, &event); err != nil {
			log.Printf("Error unmarshaling echo.deleted event: %v", err)
			return
		}

		if err := c.handleEchoDeleted(event); err != nil {
			log.Printf("Error handling echo.deleted event: %v", err)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to subscribe to echo.deleted: %w", err)
	}

	log.Printf("Started consuming NATS events: echo.created, echo.deleted")
	return nil
}

// handleEchoCreated handles an echo.created event
func (c *NATSConsumer) handleEchoCreated(event EchoCreatedEvent) error {
	ctx := context.Background()

	// Parse UUIDs
	echoID, err := uuid.Parse(event.EchoID)
	if err != nil {
		return fmt.Errorf("invalid echo_id: %w", err)
	}

	userID, err := uuid.Parse(event.UserID)
	if err != nil {
		return fmt.Errorf("invalid user_id: %w", err)
	}

	// Parse timestamp
	timestamp, err := time.Parse(time.RFC3339, event.Timestamp)
	if err != nil {
		timestamp = time.Now().UTC()
	}

	// Fetch the author's followers from the Interaction Service
	followers, err := c.fetchFollowers(userID)
	if err != nil {
		log.Printf("Warning: Failed to fetch followers for user %s: %v", userID, err)
		// Continue with empty followers list rather than failing
		followers = []uuid.UUID{}
	}

	// Fan-out: Add the echo to each follower's timeline
	successCount := 0
	for _, followerID := range followers {
		if err := c.repo.AddToTimeline(ctx, followerID, echoID, timestamp); err != nil {
			log.Printf("Warning: Failed to add echo %s to follower %s timeline: %v", echoID, followerID, err)
		} else {
			successCount++
		}
	}

	log.Printf("Fan-out complete for echo %s: added to %d/%d follower timelines", echoID, successCount, len(followers))
	return nil
}

// handleEchoDeleted handles an echo.deleted event
func (c *NATSConsumer) handleEchoDeleted(event EchoDeletedEvent) error {
	ctx := context.Background()

	// Parse UUIDs
	echoID, err := uuid.Parse(event.EchoID)
	if err != nil {
		return fmt.Errorf("invalid echo_id: %w", err)
	}

	userID, err := uuid.Parse(event.UserID)
	if err != nil {
		return fmt.Errorf("invalid user_id: %w", err)
	}

	// Fetch the author's followers from the Interaction Service
	followers, err := c.fetchFollowers(userID)
	if err != nil {
		log.Printf("Warning: Failed to fetch followers for user %s: %v", userID, err)
		followers = []uuid.UUID{}
	}

	// Fan-out: Remove the echo from each follower's timeline
	successCount := 0
	for _, followerID := range followers {
		if err := c.repo.RemoveFromTimeline(ctx, followerID, echoID); err != nil {
			log.Printf("Warning: Failed to remove echo %s from follower %s timeline: %v", echoID, followerID, err)
		} else {
			successCount++
		}
	}

	log.Printf("Fan-out delete complete for echo %s: removed from %d/%d follower timelines", echoID, successCount, len(followers))
	return nil
}

// fetchFollowers fetches all followers for a user from the Interaction Service
func (c *NATSConsumer) fetchFollowers(userID uuid.UUID) ([]uuid.UUID, error) {
	// We need to paginate through all followers
	allFollowers := []uuid.UUID{}
	page := 1
	perPage := 100

	for {
		url := fmt.Sprintf("%s/api/internal/users/%s/followers?page=%d&per_page=%d",
			c.interactionServiceURL, userID.String(), page, perPage)

		resp, err := http.Get(url)
		if err != nil {
			return nil, fmt.Errorf("failed to fetch followers: %w", err)
		}

		if resp.StatusCode != http.StatusOK {
			resp.Body.Close()
			return nil, fmt.Errorf("interaction service returned status: %d", resp.StatusCode)
		}

		body, err := io.ReadAll(resp.Body)
		resp.Body.Close()
		if err != nil {
			return nil, fmt.Errorf("failed to read response body: %w", err)
		}

		var followerResp FollowerResponse
		if err := json.Unmarshal(body, &followerResp); err != nil {
			return nil, fmt.Errorf("failed to unmarshal response: %w", err)
		}

		// Parse follower IDs
		for _, follower := range followerResp.Data.Items {
			followerID, err := uuid.Parse(follower.ID)
			if err != nil {
				log.Printf("Warning: Invalid follower ID: %s", follower.ID)
				continue
			}
			allFollowers = append(allFollowers, followerID)
		}

		// Check if we've fetched all pages
		if page >= followerResp.Data.Pagination.TotalPages {
			break
		}

		page++
	}

	return allFollowers, nil
}
