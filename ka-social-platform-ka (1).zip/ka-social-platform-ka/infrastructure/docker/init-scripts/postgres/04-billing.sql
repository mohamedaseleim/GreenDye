-- Ka+ Billing and Entitlements Tables

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stripe_customer_id VARCHAR(255) NOT NULL,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    status VARCHAR(50) NOT NULL, -- active, canceled, past_due, trialing, incomplete
    current_period_start TIMESTAMP NOT NULL,
    current_period_end TIMESTAMP NOT NULL,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    canceled_at TIMESTAMP
);

CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_stripe_customer_id ON subscriptions(stripe_customer_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);

-- Entitlements table
CREATE TABLE IF NOT EXISTS entitlements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    feature VARCHAR(100) NOT NULL, -- PROFILE_BADGE, EXTENDED_UPLOADS, ADVANCED_ANALYTICS
    granted_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP, -- NULL means no expiration
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, feature)
);

CREATE INDEX idx_entitlements_user_id ON entitlements(user_id);
CREATE INDEX idx_entitlements_feature ON entitlements(feature);
CREATE INDEX idx_entitlements_expires_at ON entitlements(expires_at);

-- Comments for documentation
COMMENT ON TABLE subscriptions IS 'Stores user subscription information synced from Stripe';
COMMENT ON TABLE entitlements IS 'Stores feature entitlements for users (granted when subscription is active)';
COMMENT ON COLUMN entitlements.feature IS 'Feature identifier: PROFILE_BADGE, EXTENDED_UPLOADS, ADVANCED_ANALYTICS';
COMMENT ON COLUMN entitlements.expires_at IS 'When the entitlement expires (usually matches subscription period end)';
