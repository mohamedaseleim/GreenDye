# Media Service Quick Start

Get started with the Ka Platform Media Service in 5 minutes.

## What is the Media Service?

The Media Service handles all media uploads for the Ka platform using:
- **Presigned URLs**: Direct client-to-storage uploads (no bandwidth consumed by service)
- **Background Processing**: Automatic image optimization and resizing
- **CDN-Ready**: URLs optimized for global CDN deployment
- **WebP Format**: Modern, efficient image format for fast loading

## Prerequisites

- Docker and Docker Compose
- A test image file (e.g., `avatar.jpg`)

## Step 1: Start Services

```bash
cd infrastructure/docker
docker-compose up -d postgres redis nats minio media-service user-service auth-service
```

Wait for all services to start (about 30 seconds):
```bash
docker-compose ps
```

## Step 2: Get a JWT Token

```bash
# Register a test user
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
  }'

# Login to get JWT token
LOGIN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }')

# Extract token
TOKEN=$(echo $LOGIN | jq -r '.data.access_token')
echo "Your JWT Token: $TOKEN"
```

## Step 3: Upload an Image

### 3.1: Request Presigned URL

```bash
PRESIGNED=$(curl -s -X POST http://localhost:8009/api/v1/upload/request \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "filename": "avatar.jpg",
    "content_type": "image/jpeg"
  }')

echo $PRESIGNED | jq .
```

You'll get a response like:
```json
{
  "success": true,
  "data": {
    "upload_url": "http://minio:9000/ka-media/uploads/.../uuid.jpg?X-Amz-...",
    "object_key": "uploads/.../uuid.jpg",
    "expires_in": 900
  }
}
```

### 3.2: Upload Your Image

```bash
UPLOAD_URL=$(echo $PRESIGNED | jq -r '.data.upload_url')
OBJECT_KEY=$(echo $PRESIGNED | jq -r '.data.object_key')

curl -X PUT "$UPLOAD_URL" \
  --upload-file avatar.jpg \
  -H "Content-Type: image/jpeg"
```

### 3.3: Notify Upload Complete

```bash
curl -X POST http://localhost:8009/api/v1/upload/complete \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"object_key\": \"$OBJECT_KEY\"}"
```

## Step 4: Check Processing Status

The Media Service worker will automatically:
1. Download your image
2. Generate thumbnail (150x150)
3. Generate medium version (600x600)
4. Convert both to WebP format
5. Upload processed images
6. Update your user profile

**Check the logs:**
```bash
docker logs ka-media-service -f
```

You should see:
```
Processing media: uploads/.../uuid.jpg for user: ...
Successfully processed image: uploads/.../uuid.jpg
Published media.processed event for: uploads/.../uuid.jpg
```

## Step 5: View Your Profile

```bash
curl -s http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer $TOKEN" | jq .
```

You'll see your profile with new avatar URLs:
```json
{
  "id": "...",
  "username": "testuser",
  "profile_picture_url": "http://minio:9000/ka-media/uploads/.../uuid.jpg",
  "avatar_url_medium": "http://minio:9000/ka-media/processed/medium_xyz.webp",
  "avatar_url_thumb": "http://minio:9000/ka-media/processed/thumb_xyz.webp"
}
```

## Step 6: View Images in MinIO

1. Open http://localhost:9001 in your browser
2. Login with `minioadmin` / `minioadmin`
3. Click on the `ka-media` bucket
4. Browse the folders:
   - `uploads/` - Original images
   - `processed/` - Optimized WebP images

## What Just Happened?

```
1. You requested a presigned URL from Media Service
2. You uploaded directly to MinIO (S3-compatible storage)
3. You notified Media Service that upload is complete
4. Media Service published "media.processing.required" event to NATS
5. Background worker consumed the event
6. Worker downloaded, resized, and converted your image to WebP
7. Worker uploaded processed images to MinIO
8. Worker published "media.processed" event
9. User Service consumed the event and updated your profile
10. Your profile now has 3 URLs: original, medium, and thumbnail
```

## Architecture Benefits

- **Scalable**: Direct uploads don't consume service bandwidth
- **Fast**: Processing happens in the background
- **Efficient**: WebP images are ~30% smaller than JPEG
- **CDN-Ready**: Switch to CDN by setting `CDN_HOST` env variable
- **Reliable**: Event-driven architecture with NATS

## Production Configuration

For production, set the `CDN_HOST` environment variable:

```yaml
# docker-compose.yml
media-service:
  environment:
    - CDN_HOST=https://cdn.kaplatform.com
```

Your URLs will then use the CDN:
```
https://cdn.kaplatform.com/ka-media/uploads/.../uuid.jpg
https://cdn.kaplatform.com/ka-media/processed/medium_xyz.webp
https://cdn.kaplatform.com/ka-media/processed/thumb_xyz.webp
```

## Automated Testing

Use the provided test script:

```bash
cd backend/media-service
JWT_TOKEN="$TOKEN" TEST_IMAGE="avatar.jpg" ./test_media_flow.sh
```

## Troubleshooting

**Service not starting?**
```bash
docker logs ka-media-service
```

**Upload failing?**
- Check JWT token is valid
- Verify MinIO is running: `docker ps | grep minio`
- Check presigned URL hasn't expired (15 min limit)

**Processing not working?**
- Check NATS is running: `curl http://localhost:8222/healthz`
- View NATS events: `docker logs ka-nats`
- Check worker logs: `docker logs ka-media-service`

**Images not in profile?**
- Check User Service logs: `docker logs ka-user-service`
- Verify database has new columns: `docker exec -it ka-postgres psql -U ka_user -d ka_db -c "\d users"`

## Next Steps

- Read [README.md](README.md) for detailed documentation
- Read [TESTING.md](TESTING.md) for comprehensive testing guide
- Check [ARCHITECTURE.md](../../docs/ARCHITECTURE.md) for system design
- Explore MinIO Console at http://localhost:9001
- Monitor NATS at http://localhost:8222

## Key Features

✅ **Presigned URLs** - Secure, direct-to-storage uploads  
✅ **Background Processing** - Non-blocking image optimization  
✅ **Multi-Size Generation** - Thumbnail and medium versions  
✅ **WebP Conversion** - Modern, efficient format  
✅ **CDN Integration** - Production-ready URLs  
✅ **Event-Driven** - NATS message broker  
✅ **Horizontal Scaling** - Multiple workers and API instances  
✅ **S3-Compatible** - Works with any S3-compatible storage  

## Support

For issues or questions:
- Check logs: `docker-compose logs media-service`
- Read docs: [README.md](README.md), [TESTING.md](TESTING.md)
- Open issue on GitHub

---

**Built with ❤️ for the Ka Platform**
