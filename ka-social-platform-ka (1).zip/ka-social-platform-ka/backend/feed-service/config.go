package main

import (
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"
	"github.com/redis/go-redis/v9"
)

// Config holds the configuration for the service
type Config struct {
	Redis                 *redis.Client
	JWTSecret             string
	InteractionServiceURL string
	ContentServiceURL     string
	TrustSafetyClient     *trustsafety.Client
}
