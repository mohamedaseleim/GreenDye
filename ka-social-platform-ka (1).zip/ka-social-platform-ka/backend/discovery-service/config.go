package main

import (
	"log"
	"os"
)

// Config holds application configuration
type Config struct {
	Port                string
	RedisHost           string
	RedisPort           string
	RedisPassword       string
	JWTSecret           string
	NATSUrl             string
	MeilisearchHost     string
	MeilisearchAPIKey   string
	ContentServiceURL   string
}

// LoadConfig loads configuration from environment variables
func LoadConfig() *Config {
	config := &Config{
		Port:                getEnv("PORT", "8008"),
		RedisHost:           getEnv("REDIS_HOST", "localhost"),
		RedisPort:           getEnv("REDIS_PORT", "6379"),
		RedisPassword:       getEnv("REDIS_PASSWORD", ""),
		JWTSecret:           getEnv("JWT_SECRET", "your-super-secret-jwt-key"),
		NATSUrl:             getEnv("NATS_URL", "nats://localhost:4222"),
		MeilisearchHost:     getEnv("MEILISEARCH_HOST", "http://localhost:7700"),
		MeilisearchAPIKey:   getEnv("MEILISEARCH_API_KEY", "masterKey123"),
		ContentServiceURL:   getEnv("CONTENT_SERVICE_URL", "http://localhost:8003"),
	}

	log.Println("Configuration loaded successfully")
	return config
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}
