package main

import (
	"context"
	"fmt"
	"strconv"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
)

// Repository handles data operations for the feed service
type Repository struct {
	redis *redis.Client
}

// NewRepository creates a new repository
func NewRepository(redis *redis.Client) *Repository {
	return &Repository{
		redis: redis,
	}
}

// AddToTimeline adds an echo ID to a user's home timeline
func (r *Repository) AddToTimeline(ctx context.Context, userID uuid.UUID, echoID uuid.UUID, timestamp time.Time) error {
	key := fmt.Sprintf("timeline:home:%s", userID.String())
	score := float64(timestamp.Unix())

	// Use ZADD to add echo with timestamp as score (for chronological ordering)
	if err := r.redis.ZAdd(ctx, key, redis.Z{
		Score:  score,
		Member: echoID.String(),
	}).Err(); err != nil {
		return fmt.Errorf("failed to add to timeline: %w", err)
	}

	// Keep only the latest 1000 items in the timeline (to prevent unbounded growth)
	if err := r.redis.ZRemRangeByRank(ctx, key, 0, -1001).Err(); err != nil {
		// Log but don't fail - this is a maintenance operation
		fmt.Printf("Warning: Failed to trim timeline for user %s: %v\n", userID, err)
	}

	return nil
}

// RemoveFromTimeline removes an echo ID from a user's home timeline
func (r *Repository) RemoveFromTimeline(ctx context.Context, userID uuid.UUID, echoID uuid.UUID) error {
	key := fmt.Sprintf("timeline:home:%s", userID.String())

	if err := r.redis.ZRem(ctx, key, echoID.String()).Err(); err != nil {
		return fmt.Errorf("failed to remove from timeline: %w", err)
	}

	return nil
}

// GetHomeTimeline retrieves echo IDs from a user's home timeline with pagination
func (r *Repository) GetHomeTimeline(ctx context.Context, userID uuid.UUID, limit, offset int) ([]uuid.UUID, error) {
	key := fmt.Sprintf("timeline:home:%s", userID.String())

	// Get echo IDs from sorted set in reverse chronological order (highest score first)
	// offset is the start index, offset+limit-1 is the end index
	echoIDStrs, err := r.redis.ZRevRange(ctx, key, int64(offset), int64(offset+limit-1)).Result()
	if err != nil {
		return nil, fmt.Errorf("failed to get home timeline: %w", err)
	}

	// Convert string IDs to UUIDs
	echoIDs := make([]uuid.UUID, 0, len(echoIDStrs))
	for _, idStr := range echoIDStrs {
		id, err := uuid.Parse(idStr)
		if err != nil {
			// Skip invalid UUIDs
			fmt.Printf("Warning: Invalid UUID in timeline: %s\n", idStr)
			continue
		}
		echoIDs = append(echoIDs, id)
	}

	return echoIDs, nil
}

// GetTimelineCount returns the total number of items in a user's home timeline
func (r *Repository) GetTimelineCount(ctx context.Context, userID uuid.UUID) (int64, error) {
	key := fmt.Sprintf("timeline:home:%s", userID.String())

	count, err := r.redis.ZCard(ctx, key).Result()
	if err != nil {
		return 0, fmt.Errorf("failed to get timeline count: %w", err)
	}

	return count, nil
}

// CacheEcho caches a hydrated echo object in Redis with a TTL
func (r *Repository) CacheEcho(ctx context.Context, echoID uuid.UUID, echoJSON string, ttl time.Duration) error {
	key := fmt.Sprintf("echo:details:%s", echoID.String())

	if err := r.redis.Set(ctx, key, echoJSON, ttl).Err(); err != nil {
		return fmt.Errorf("failed to cache echo: %w", err)
	}

	return nil
}

// GetCachedEcho retrieves a cached echo from Redis
func (r *Repository) GetCachedEcho(ctx context.Context, echoID uuid.UUID) (string, error) {
	key := fmt.Sprintf("echo:details:%s", echoID.String())

	echoJSON, err := r.redis.Get(ctx, key).Result()
	if err == redis.Nil {
		return "", nil // Cache miss
	}
	if err != nil {
		return "", fmt.Errorf("failed to get cached echo: %w", err)
	}

	return echoJSON, nil
}

// BatchCacheEchoes caches multiple echoes at once
func (r *Repository) BatchCacheEchoes(ctx context.Context, echoes map[string]string, ttl time.Duration) error {
	if len(echoes) == 0 {
		return nil
	}

	pipe := r.redis.Pipeline()
	for echoID, echoJSON := range echoes {
		key := fmt.Sprintf("echo:details:%s", echoID)
		pipe.Set(ctx, key, echoJSON, ttl)
	}

	_, err := pipe.Exec(ctx)
	if err != nil {
		return fmt.Errorf("failed to batch cache echoes: %w", err)
	}

	return nil
}

// GetBatchCachedEchoes retrieves multiple cached echoes at once
func (r *Repository) GetBatchCachedEchoes(ctx context.Context, echoIDs []uuid.UUID) (map[string]string, error) {
	if len(echoIDs) == 0 {
		return map[string]string{}, nil
	}

	pipe := r.redis.Pipeline()
	cmds := make(map[string]*redis.StringCmd)

	for _, echoID := range echoIDs {
		key := fmt.Sprintf("echo:details:%s", echoID.String())
		cmds[echoID.String()] = pipe.Get(ctx, key)
	}

	_, err := pipe.Exec(ctx)
	if err != nil && err != redis.Nil {
		// Continue even if some commands fail
	}

	result := make(map[string]string)
	for echoID, cmd := range cmds {
		val, err := cmd.Result()
		if err == redis.Nil {
			continue // Cache miss for this echo
		}
		if err == nil {
			result[echoID] = val
		}
	}

	return result, nil
}

// GetTimelineCountWithDefault returns the count or 0 if error
func (r *Repository) GetTimelineCountWithDefault(ctx context.Context, userID uuid.UUID) int64 {
	count, err := r.GetTimelineCount(ctx, userID)
	if err != nil {
		return 0
	}
	return count
}

// AddToForYouTimeline adds an echo ID to a user's "for you" timeline (future use)
func (r *Repository) AddToForYouTimeline(ctx context.Context, userID uuid.UUID, echoID uuid.UUID, timestamp time.Time) error {
	key := fmt.Sprintf("timeline:foryou:%s", userID.String())
	score := float64(timestamp.Unix())

	if err := r.redis.ZAdd(ctx, key, redis.Z{
		Score:  score,
		Member: echoID.String(),
	}).Err(); err != nil {
		return fmt.Errorf("failed to add to for you timeline: %w", err)
	}

	// Keep only the latest 1000 items
	if err := r.redis.ZRemRangeByRank(ctx, key, 0, -1001).Err(); err != nil {
		fmt.Printf("Warning: Failed to trim for you timeline for user %s: %v\n", userID, err)
	}

	return nil
}

// Helper function to convert int64 to string
func int64ToString(n int64) string {
	return strconv.FormatInt(n, 10)
}
