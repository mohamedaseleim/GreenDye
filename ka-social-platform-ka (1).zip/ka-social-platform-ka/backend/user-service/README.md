# User Service

The User Service manages user profiles and public user data for the Ka social platform. It handles profile CRUD operations, user search, and provides both public and private user endpoints.

## Architecture

The User Service follows the same architectural pattern as the Auth Service:
- **Handler Layer**: HTTP request handlers
- **Repository Layer**: Database operations
- **Routes**: API endpoint definitions
- **Config**: Service configuration

## Responsibilities

- User profile management (display name, bio, location, website)
- Public profile retrieval (by username or ID)
- Private profile access (authenticated user's own profile)
- User search functionality
- Profile picture and cover story URL management
- Social graph queries (follower/following counts)

## Data Model

The service interacts with the `users` table in PostgreSQL, which is shared with the Auth Service. However, User Service focuses on profile data while Auth Service focuses on authentication credentials.

### User Profile Fields

**Public Fields** (visible to everyone):
- `id`, `username`, `display_name`, `bio`
- `profile_picture_url`, `cover_story_url`, `cover_story_type`
- `location`, `website`
- `is_verified`, `is_premium`
- `created_at`

**Private Fields** (only visible to the user):
- `email`, `phone`
- `language`

**Auth-only Fields** (never exposed by User Service):
- `password_hash`

## Endpoints

### Public Endpoints (No Authentication Required)

#### Get User Profile by Username
```http
GET /api/users/:username
```

Returns public profile information for a user, including follower/following counts and relationship status (if authenticated).

**Example:**
```bash
curl http://localhost:8002/api/users/john_doe
```

#### Get User Profile by ID
```http
GET /api/users/id/:id
```

Returns public profile information for a user by their UUID.

**Example:**
```bash
curl http://localhost:8002/api/users/id/123e4567-e89b-12d3-a456-426614174000
```

#### Search Users
```http
GET /api/users/search?q=query&page=1&per_page=20
```

Search for users by username or display name.

**Query Parameters:**
- `q` (required): Search query
- `page` (optional): Page number (default: 1)
- `per_page` (optional): Results per page (default: 20, max: 100)

**Example:**
```bash
curl "http://localhost:8002/api/users/search?q=john&page=1&per_page=20"
```

### Private Endpoints (Authentication Required)

#### Get Current User Profile
```http
GET /api/profile/me
Authorization: Bearer <access_token>
```

Returns the authenticated user's complete profile, including private fields like email.

**Example:**
```bash
curl http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer eyJhbGc..."
```

#### Update Current User Profile
```http
PUT /api/profile/me
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "display_name": "John Doe",
  "bio": "Software engineer and coffee enthusiast",
  "location": "Cairo, Egypt",
  "website": "https://johndoe.com"
}
```

Updates the authenticated user's profile. All fields are optional.

**Example:**
```bash
curl -X PUT http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer eyJhbGc..." \
  -H "Content-Type: application/json" \
  -d '{
    "display_name": "John Doe",
    "bio": "Updated bio"
  }'
```

## Environment Variables

- `PORT`: Service port (default: 8002)
- `DB_HOST`: PostgreSQL host (default: localhost)
- `DB_PORT`: PostgreSQL port (default: 5432)
- `DB_USER`: PostgreSQL user (default: ka_user)
- `DB_PASSWORD`: PostgreSQL password
- `DB_NAME`: PostgreSQL database (default: ka_db)
- `REDIS_HOST`: Redis host (default: localhost)
- `REDIS_PORT`: Redis port (default: 6379)
- `REDIS_PASSWORD`: Redis password
- `JWT_SECRET`: JWT secret for token validation (must match auth-service)

## Running Locally

### Prerequisites

- Go 1.21+
- PostgreSQL (running via Docker Compose)
- Redis (running via Docker Compose)

### Start Infrastructure

```bash
cd ../../infrastructure/docker
docker-compose up -d postgres redis
```

### Run the Service

```bash
cd backend/user-service
go run .
```

The service will start on port 8002.

## Running with Docker

### Build the Docker Image

```bash
docker build -t ka-user-service .
```

### Run with Docker Compose

```bash
cd ../../infrastructure/docker
docker-compose up -d user-service
```

## Testing

### Health Check

```bash
curl http://localhost:8002/health
```

### Test Flow

1. Register a user via Auth Service:
```bash
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john@example.com",
    "password": "SecurePass123!",
    "display_name": "John Doe"
  }'
```

2. Login to get access token:
```bash
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "SecurePass123!"
  }'
```

3. Get your own profile:
```bash
curl http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer <access_token>"
```

4. Update your profile:
```bash
curl -X PUT http://localhost:8002/api/profile/me \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "bio": "Hello from User Service!",
    "location": "Cairo, Egypt"
  }'
```

5. View public profile:
```bash
curl http://localhost:8002/api/users/john_doe
```

## Caching Strategy

The User Service uses Redis for caching frequently accessed user profiles:
- Cache TTL: 5 minutes
- Cache key format: `user:profile:{user_id}`
- Cache invalidation: On profile update

## Security

- Public endpoints use `OptionalAuthMiddleware` to enhance responses when authenticated
- Private endpoints use `AuthMiddleware` to require authentication
- Sensitive fields (email, phone, password_hash) are filtered from public responses
- JWT validation uses the same secret as Auth Service

## Dependencies

- **gin-gonic/gin**: HTTP framework
- **jmoiron/sqlx**: SQL toolkit
- **redis/go-redis**: Redis client
- **google/uuid**: UUID generation
- **shared module**: Common utilities and models

## Future Enhancements

- Profile picture upload and processing
- Cover story upload and slideshow management
- User blocking functionality
- Muting users
- Privacy settings
- Profile verification badges
- Premium features

## Related Services

- **Auth Service** (8001): User authentication and credentials
- **Content Service** (8003): User posts and stories
- **Feed Service** (8004): User timelines
- **Discovery Service** (8008): User recommendations

## License

Copyright © 2024 Ka Social Platform. All rights reserved.
