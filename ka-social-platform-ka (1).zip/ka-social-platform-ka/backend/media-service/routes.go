package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes sets up the routes for the media service
func SetupRoutes(router *gin.Engine, handler *Handler, jwtSecret string) {
	// API v1 routes
	v1 := router.Group("/api/v1")
	{
		// Protected routes (require authentication)
		protected := v1.Group("/")
		protected.Use(middleware.JWTAuthMiddleware(jwtSecret))
		{
			// Upload request endpoint
			protected.POST("/upload/request", handler.RequestUpload)

			// Upload complete notification endpoint
			protected.POST("/upload/complete", handler.NotifyUploadComplete)
		}
	}

	// Internal endpoints (no authentication - for service-to-service calls)
	internal := router.Group("/api/internal")
	{
		// Media validation endpoint
		internal.POST("/media/validate", handler.ValidateMedia)

		// Media details retrieval endpoint
		internal.POST("/media/details", handler.GetMediaDetails)
	}
}
