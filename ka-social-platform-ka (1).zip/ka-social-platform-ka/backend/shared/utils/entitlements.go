package utils

// Entitlement constants
const (
	EntitlementProfileBadge      = "PROFILE_BADGE"
	EntitlementExtendedUploads   = "EXTENDED_UPLOADS"
	EntitlementAdvancedAnalytics = "ADVANCED_ANALYTICS"
)

// HasEntitlement checks if a user has a specific entitlement
func HasEntitlement(entitlements []string, entitlement string) bool {
	for _, e := range entitlements {
		if e == entitlement {
			return true
		}
	}
	return false
}

// GetEntitlementsFromContext extracts entitlements from JWT claims
func GetEntitlementsFromClaims(claims *JWTClaims) []string {
	if claims == nil {
		return []string{}
	}
	return claims.Entitlements
}
