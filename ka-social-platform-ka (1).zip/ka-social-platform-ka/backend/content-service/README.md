# Content Service

The Content Service is responsible for managing content creation and deletion in the Ka platform using an **event-driven architecture**. This service owns the `echoes` table in ScyllaDB and publishes events to NATS for downstream processing.

## Architecture

The Content Service follows an event-driven design pattern:

1. **Write Path**: Validates and persists content to ScyllaDB
2. **Event Publishing**: Publishes events to NATS message broker
3. **Decoupled Processing**: Other services subscribe to events for their own processing

This design ensures:
- **Fast response times**: Users get immediate feedback after content is saved
- **Scalability**: Event consumers can scale independently
- **Resilience**: Services can be temporarily unavailable without data loss
- **Extensibility**: New features can subscribe to events without modifying the content service

## Features

### Echo Management
- **Create Echo**: Create a new short-form post (echo)
- **Delete Echo**: Delete an existing echo
- **Reply Support**: Echoes can be replies to other echoes via `parent_echo_id`
- **Hashtag Extraction**: Automatically extracts hashtags from content
- **Media Support**: Supports multiple media URLs per echo

### Event Publishing
- **echo.created**: Published when a new echo is created
- **echo.deleted**: Published when an echo is deleted

## API Endpoints

All endpoints require authentication via Bearer token.

### Create Echo
```
POST /api/v1/echoes
```

**Request Body**:
```json
{
  "content": "Hello Ka! #introduction",
  "media_urls": ["https://example.com/image.jpg"],
  "parent_echo_id": "optional-parent-uuid",
  "visibility": "public",
  "mentions": ["user-uuid-1", "user-uuid-2"]
}
```

**Response** (201 Created):
```json
{
  "status": "success",
  "message": "Echo created successfully",
  "data": {
    "id": "echo-uuid",
    "user_id": "user-uuid",
    "content": "Hello Ka! #introduction",
    "media_urls": ["https://example.com/image.jpg"],
    "hashtags": ["introduction"],
    "mentions": ["user-uuid-1", "user-uuid-2"],
    "parent_echo_id": "optional-parent-uuid",
    "visibility": "public",
    "like_count": 0,
    "comment_count": 0,
    "share_count": 0,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
}
```

### Delete Echo
```
DELETE /api/v1/echoes/:echoId
```

**Response** (200 OK):
```json
{
  "status": "success",
  "message": "Echo deleted successfully",
  "data": {
    "echo_id": "echo-uuid"
  }
}
```

## Event Schema

### echo.created Event
Published to NATS subject: `echo.created`

```json
{
  "echo_id": "uuid",
  "user_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z",
  "parent_echo_id": "optional-uuid"
}
```

### echo.deleted Event
Published to NATS subject: `echo.deleted`

```json
{
  "echo_id": "uuid",
  "user_id": "uuid",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

## Database Schema

The Content Service owns the `echoes` table in ScyllaDB:

```cql
CREATE TABLE echoes (
    id UUID PRIMARY KEY,
    user_id UUID,
    content TEXT,
    media_urls LIST<TEXT>,
    hashtags SET<TEXT>,
    mentions SET<UUID>,
    parent_echo_id UUID,
    visibility TEXT,
    like_count INT,
    comment_count INT,
    share_count INT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

## Event Consumers

Future services that will subscribe to content events:

1. **Feed Service**: Updates user feeds when echoes are created/deleted
2. **Notification Service**: Notifies mentioned users
3. **Analytics Service**: Tracks content metrics
4. **Search Service**: Indexes content for search

## Running the Service

### Local Development
```bash
PORT=8003 \
SCYLLA_HOSTS=localhost \
SCYLLA_KEYSPACE=ka_content \
REDIS_HOST=localhost \
REDIS_PORT=6379 \
REDIS_PASSWORD=ka_redis_password \
JWT_SECRET=your-super-secret-jwt-key \
NATS_URL=nats://localhost:4222 \
go run *.go
```

### Docker
```bash
docker-compose up content-service
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Service port | `8003` |
| `SCYLLA_HOSTS` | ScyllaDB hosts (comma-separated) | `localhost` |
| `SCYLLA_KEYSPACE` | ScyllaDB keyspace | `ka_content` |
| `REDIS_HOST` | Redis host | `localhost` |
| `REDIS_PORT` | Redis port | `6379` |
| `REDIS_PASSWORD` | Redis password | `` |
| `JWT_SECRET` | JWT signing secret | Required |
| `NATS_URL` | NATS server URL | `nats://localhost:4222` |

## Dependencies

- **Gin**: Web framework
- **ScyllaDB/Cassandra**: Primary data store for echoes
- **Redis**: Caching layer (future use)
- **NATS**: Message broker for event publishing
- **gocql**: ScyllaDB driver
- **nats.go**: NATS client library
- **shared**: Internal shared library

## Design Decisions

### Why Event-Driven?

1. **Performance**: Users don't wait for downstream processing (notifications, feed updates, etc.)
2. **Scalability**: Event consumers can be scaled independently based on load
3. **Resilience**: If a consumer is down, events are queued and processed when it's back up
4. **Flexibility**: New features can be added by creating new consumers without modifying the content service

### Why NATS?

1. **Performance**: Extremely fast and lightweight
2. **Simplicity**: Easy to set up and use
3. **Go Native**: Excellent Go client library
4. **JetStream**: Built-in persistence and replay capabilities

### Trade-offs

- **Eventual Consistency**: Feed updates may lag by milliseconds/seconds
- **Complexity**: More moving parts to monitor and debug
- **Message Ordering**: Events must be processed in the correct order (NATS JetStream handles this)

## Related Documentation

- [Architecture Documentation](../../docs/ARCHITECTURE.md) - Event-driven architecture details
- [API Specification](../../docs/API_SPEC.md) - Complete API documentation
- [NATS Documentation](https://docs.nats.io/) - NATS message broker documentation
