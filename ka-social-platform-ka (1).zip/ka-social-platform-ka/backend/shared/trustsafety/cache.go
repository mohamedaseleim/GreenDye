package trustsafety

import (
	"context"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
)

// CacheManager manages Trust & Safety cache operations in Redis
type CacheManager struct {
	redis *redis.Client
	ttl   time.Duration // Cache TTL (default: 5 minutes for hot data)
}

// NewCacheManager creates a new Trust & Safety cache manager
func NewCacheManager(redis *redis.Client, ttl time.Duration) *CacheManager {
	if ttl == 0 {
		ttl = 5 * time.Minute // Default TTL
	}
	return &CacheManager{
		redis: redis,
		ttl:   ttl,
	}
}

// IsBlockedCached checks if there's a block relationship (cached)
// Returns: blocked (bool), found in cache (bool), error
func (c *CacheManager) IsBlockedCached(ctx context.Context, user1ID, user2ID uuid.UUID) (bool, bool, error) {
	// Check both directions in parallel
	key1 := c.blockCacheKey(user1ID, user2ID)
	key2 := c.blockCacheKey(user2ID, user1ID)

	pipe := c.redis.Pipeline()
	res1 := pipe.Get(ctx, key1)
	res2 := pipe.Get(ctx, key2)
	_, err := pipe.Exec(ctx)

	// Check first direction
	val1, err1 := res1.Result()
	if err1 == nil && val1 == "1" {
		return true, true, nil
	}

	// Check second direction
	val2, err2 := res2.Result()
	if err2 == nil && val2 == "1" {
		return true, true, nil
	}

	// If both keys not found, return cache miss
	if err1 == redis.Nil && err2 == redis.Nil {
		return false, false, nil
	}

	// If we got actual values (0 or 1), it's a cache hit
	if (err1 == nil || err1 == redis.Nil) && (err2 == nil || err2 == redis.Nil) {
		return false, true, nil
	}

	// Unexpected error
	if err != nil {
		return false, false, fmt.Errorf("failed to check block cache: %w", err)
	}

	return false, false, nil
}

// IsMutedCached checks if user1 is muting user2 (cached)
// Returns: muted (bool), found in cache (bool), error
func (c *CacheManager) IsMutedCached(ctx context.Context, muterID, mutedID uuid.UUID) (bool, bool, error) {
	key := c.muteCacheKey(muterID, mutedID)
	
	val, err := c.redis.Get(ctx, key).Result()
	if err == redis.Nil {
		return false, false, nil // Cache miss
	}
	if err != nil {
		return false, false, fmt.Errorf("failed to check mute cache: %w", err)
	}

	return val == "1", true, nil
}

// CacheBlockStatus stores block status in cache
func (c *CacheManager) CacheBlockStatus(ctx context.Context, blockerID, blockedID uuid.UUID, isBlocked bool) error {
	key := c.blockCacheKey(blockerID, blockedID)
	value := "0"
	if isBlocked {
		value = "1"
	}

	err := c.redis.Set(ctx, key, value, c.ttl).Err()
	if err != nil {
		return fmt.Errorf("failed to cache block status: %w", err)
	}

	return nil
}

// CacheMuteStatus stores mute status in cache
func (c *CacheManager) CacheMuteStatus(ctx context.Context, muterID, mutedID uuid.UUID, isMuted bool) error {
	key := c.muteCacheKey(muterID, mutedID)
	value := "0"
	if isMuted {
		value = "1"
	}

	err := c.redis.Set(ctx, key, value, c.ttl).Err()
	if err != nil {
		return fmt.Errorf("failed to cache mute status: %w", err)
	}

	return nil
}

// InvalidateBlockCache invalidates block cache for a relationship
func (c *CacheManager) InvalidateBlockCache(ctx context.Context, user1ID, user2ID uuid.UUID) error {
	// Invalidate both directions
	key1 := c.blockCacheKey(user1ID, user2ID)
	key2 := c.blockCacheKey(user2ID, user1ID)

	pipe := c.redis.Pipeline()
	pipe.Del(ctx, key1)
	pipe.Del(ctx, key2)
	_, err := pipe.Exec(ctx)

	if err != nil {
		return fmt.Errorf("failed to invalidate block cache: %w", err)
	}

	return nil
}

// InvalidateMuteCache invalidates mute cache for a relationship
func (c *CacheManager) InvalidateMuteCache(ctx context.Context, muterID, mutedID uuid.UUID) error {
	key := c.muteCacheKey(muterID, mutedID)
	
	err := c.redis.Del(ctx, key).Err()
	if err != nil {
		return fmt.Errorf("failed to invalidate mute cache: %w", err)
	}

	return nil
}

// Helper functions to generate cache keys
func (c *CacheManager) blockCacheKey(user1ID, user2ID uuid.UUID) string {
	return fmt.Sprintf("block:%s:%s", user1ID.String(), user2ID.String())
}

func (c *CacheManager) muteCacheKey(muterID, mutedID uuid.UUID) string {
	return fmt.Sprintf("mute:%s:%s", muterID.String(), mutedID.String())
}
