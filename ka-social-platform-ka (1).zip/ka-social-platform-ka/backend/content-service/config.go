package main

import (
	"github.com/gocql/gocql"
	"github.com/redis/go-redis/v9"
)

// Config holds the configuration for the content service
type Config struct {
	ScyllaSession      *gocql.Session
	Redis              *redis.Client
	JWTSecret          string
	NATSPublisher      *NATSPublisher
	MediaServiceURL    string
	MediaClient        *MediaClient
	EngagementClient   *EngagementClient
	InteractionClient  *InteractionClient
}
