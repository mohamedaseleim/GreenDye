# Ka Platform - Deployment Checklist

Complete checklist for deploying and operating the Ka Platform.

## Pre-Deployment Checklist

### Prerequisites

- [ ] kubectl installed (v1.28+)
- [ ] Terraform installed (v1.5+)
- [ ] Git repository cloned
- [ ] Cloud provider account created
- [ ] Domain name purchased (optional for production)
- [ ] SSL certificate ready (or use Let's Encrypt)

### Cloud Provider Setup

#### DigitalOcean
- [ ] DigitalOcean account created
- [ ] API token generated
- [ ] Billing method added
- [ ] Resource quotas checked

#### Google Cloud Platform
- [ ] GCP project created
- [ ] Billing enabled
- [ ] Required APIs enabled
- [ ] Service account created (optional)

### Configuration Files

- [ ] `terraform/digitalocean/terraform.tfvars` created (or GCP equivalent)
- [ ] Cluster name decided
- [ ] Region selected
- [ ] Node size and count configured
- [ ] Secrets generated (JWT, passwords)

---

## Infrastructure Deployment

### Step 1: Terraform Initialization
- [ ] Navigate to terraform directory
  ```bash
  cd terraform/digitalocean  # or terraform/gcp
  ```
- [ ] Copy example variables
  ```bash
  cp terraform.tfvars.example terraform.tfvars
  ```
- [ ] Edit terraform.tfvars with your values
- [ ] Initialize Terraform
  ```bash
  terraform init
  ```
- [ ] Validate configuration
  ```bash
  terraform validate
  ```
- [ ] Plan deployment
  ```bash
  terraform plan
  ```

### Step 2: Provision Infrastructure
- [ ] Apply Terraform configuration
  ```bash
  terraform apply
  ```
- [ ] Save outputs
  ```bash
  terraform output > outputs.txt
  ```
- [ ] Configure kubectl
  ```bash
  export KUBECONFIG=$(terraform output -raw kubeconfig_path)
  # or for GCP:
  eval $(terraform output -raw kubeconfig_command)
  ```
- [ ] Verify cluster access
  ```bash
  kubectl get nodes
  ```
- [ ] Check node status (all Ready)
  ```bash
  kubectl get nodes -o wide
  ```

**⏱️ Time: ~10-15 minutes**

---

## Argo CD Installation

### Step 3: Install Argo CD
- [ ] Create argocd namespace
  ```bash
  kubectl create namespace argocd
  ```
- [ ] Install Argo CD
  ```bash
  kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
  ```
- [ ] Wait for Argo CD to be ready
  ```bash
  kubectl wait --for=condition=available --timeout=300s \
    deployment/argocd-server -n argocd
  ```
- [ ] Get admin password
  ```bash
  kubectl -n argocd get secret argocd-initial-admin-secret \
    -o jsonpath="{.data.password}" | base64 -d && echo
  ```
- [ ] Save password securely
- [ ] Test Argo CD UI (optional)
  ```bash
  kubectl port-forward svc/argocd-server -n argocd 8080:443
  # Open https://localhost:8080
  ```

**⏱️ Time: ~5 minutes**

---

## Application Deployment

### Step 4: Configure Secrets
- [ ] Update secrets in `charts/ka-platform/values.yaml`
  - [ ] JWT secret
  - [ ] PostgreSQL password
  - [ ] Redis password
  - [ ] MinIO credentials
  - [ ] Meilisearch API key
- [ ] Commit secrets (or use external secret manager)
  ```bash
  git add charts/ka-platform/values.yaml
  git commit -m "Update secrets for production"
  git push
  ```

### Step 5: Deploy Ka Platform
- [ ] Apply Ka Platform Application
  ```bash
  kubectl apply -f infrastructure/argocd/ka-platform-application.yaml
  ```
- [ ] Check application status
  ```bash
  kubectl get application -n argocd
  ```
- [ ] Watch sync progress
  ```bash
  watch kubectl get pods -n ka-platform
  ```
- [ ] Wait for all pods to be Running
  ```bash
  kubectl wait --for=condition=ready pod \
    -l component=api -n ka-platform --timeout=600s
  ```

**⏱️ Time: ~10-15 minutes**

### Step 6: Verify Application
- [ ] Check all pods are running
  ```bash
  kubectl get pods -n ka-platform
  ```
- [ ] Check services
  ```bash
  kubectl get svc -n ka-platform
  ```
- [ ] Check persistent volumes
  ```bash
  kubectl get pvc -n ka-platform
  ```
- [ ] Check ingress
  ```bash
  kubectl get ingress -n ka-platform
  ```

---

## Observability Stack Deployment

### Step 7: Deploy Prometheus
- [ ] Apply Prometheus manifests
  ```bash
  kubectl apply -f infrastructure/observability/prometheus/
  ```
- [ ] Wait for Prometheus to be ready
  ```bash
  kubectl wait --for=condition=ready pod \
    -l app=prometheus -n ka-platform --timeout=300s
  ```
- [ ] Verify Prometheus is scraping
  ```bash
  kubectl port-forward -n ka-platform svc/prometheus 9090:9090
  # Check http://localhost:9090/targets
  ```

### Step 8: Deploy Grafana
- [ ] Update Grafana admin password (if needed)
  ```bash
  kubectl edit secret grafana-secrets -n ka-platform
  ```
- [ ] Apply Grafana manifests
  ```bash
  kubectl apply -f infrastructure/observability/grafana/
  ```
- [ ] Wait for Grafana to be ready
  ```bash
  kubectl wait --for=condition=ready pod \
    -l app=grafana -n ka-platform --timeout=300s
  ```
- [ ] Access Grafana UI
  ```bash
  kubectl port-forward -n ka-platform svc/grafana 3000:3000
  # Open http://localhost:3000
  ```
- [ ] Verify datasources configured
- [ ] Check dashboards loaded

### Step 9: Deploy Loki
- [ ] Apply Loki manifests
  ```bash
  kubectl apply -f infrastructure/observability/loki/
  ```
- [ ] Wait for Loki to be ready
  ```bash
  kubectl wait --for=condition=ready pod \
    -l app=loki -n ka-platform --timeout=300s
  ```
- [ ] Verify Promtail DaemonSet
  ```bash
  kubectl get daemonset -n ka-platform promtail
  ```
- [ ] Test log query in Grafana

**⏱️ Time: ~5-10 minutes**

---

## Post-Deployment Configuration

### Step 10: Configure DNS
- [ ] Get load balancer IP
  ```bash
  # DigitalOcean
  terraform output load_balancer_ip
  # GCP
  terraform output ingress_ip
  ```
- [ ] Create DNS A records
  - [ ] api.yourdomain.com → Load Balancer IP
  - [ ] grafana.yourdomain.com → Load Balancer IP (optional)
- [ ] Wait for DNS propagation (5-30 minutes)
- [ ] Verify DNS resolution
  ```bash
  nslookup api.yourdomain.com
  ```

### Step 11: Configure SSL/TLS
- [ ] Install cert-manager
  ```bash
  kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml
  ```
- [ ] Create ClusterIssuer
  ```bash
  cat <<EOF | kubectl apply -f -
  apiVersion: cert-manager.io/v1
  kind: ClusterIssuer
  metadata:
    name: letsencrypt-prod
  spec:
    acme:
      server: https://acme-v02.api.letsencrypt.org/directory
      email: admin@yourdomain.com
      privateKeySecretRef:
        name: letsencrypt-prod
      solvers:
      - http01:
          ingress:
            class: nginx
  EOF
  ```
- [ ] Update ingress annotations in values.yaml
- [ ] Wait for certificates to be issued
  ```bash
  kubectl get certificate -n ka-platform
  ```

### Step 12: Configure GitHub Container Registry
- [ ] Create GitHub Personal Access Token
- [ ] Create image pull secret
  ```bash
  kubectl create secret docker-registry ghcr-secret \
    --docker-server=ghcr.io \
    --docker-username=YOUR_USERNAME \
    --docker-password=YOUR_TOKEN \
    --docker-email=YOUR_EMAIL \
    -n ka-platform
  ```
- [ ] Update deployment to use secret
  ```yaml
  imagePullSecrets:
    - name: ghcr-secret
  ```

### Step 13: Configure GitHub Actions
- [ ] Add repository secrets in GitHub
  - [ ] `GHCR_TOKEN` - GitHub token for container registry
- [ ] Test CI/CD pipeline
  ```bash
  git commit --allow-empty -m "Test CI/CD"
  git push
  ```
- [ ] Watch GitHub Actions workflow
- [ ] Verify images are built and pushed
- [ ] Verify Argo CD syncs new images

**⏱️ Time: ~15-30 minutes**

---

## Testing & Verification

### Step 14: API Testing
- [ ] Test health endpoints
  ```bash
  curl https://api.yourdomain.com/auth/health
  curl https://api.yourdomain.com/user/health
  curl https://api.yourdomain.com/content/health
  curl https://api.yourdomain.com/feed/health
  curl https://api.yourdomain.com/media/health
  ```
- [ ] Expected: `{"status":"ok"}` or similar
- [ ] Test authentication
  ```bash
  curl -X POST https://api.yourdomain.com/auth/register \
    -H "Content-Type: application/json" \
    -d '{"email":"test@example.com","password":"test123"}'
  ```

### Step 15: Database Testing
- [ ] Connect to PostgreSQL
  ```bash
  kubectl exec -it -n ka-platform postgres-0 -- psql -U ka_user -d ka_db
  ```
- [ ] Check tables created
  ```sql
  \dt
  ```
- [ ] Test Redis
  ```bash
  kubectl exec -it -n ka-platform redis-0 -- redis-cli ping
  ```
- [ ] Expected: `PONG`

### Step 16: Monitoring Testing
- [ ] Check Prometheus targets
  - [ ] All services showing as UP
  - [ ] No scrape errors
- [ ] Check Grafana dashboards
  - [ ] Data is flowing
  - [ ] No empty panels
- [ ] Check Loki logs
  - [ ] Logs from all services
  - [ ] No gaps in timeline

### Step 17: Scaling Testing
- [ ] Generate load (optional)
  ```bash
  kubectl run -it --rm load-generator --image=busybox -- /bin/sh
  # Inside the pod:
  while true; do wget -q -O- http://auth-service:8001/health; done
  ```
- [ ] Watch HPA
  ```bash
  kubectl get hpa -n ka-platform -w
  ```
- [ ] Verify pods scale up
- [ ] Stop load and verify scale down

**⏱️ Time: ~15-20 minutes**

---

## Production Readiness

### Step 18: Security Hardening
- [ ] Change all default passwords
- [ ] Enable pod security policies
- [ ] Configure network policies
- [ ] Enable audit logging
- [ ] Set up secret rotation schedule
- [ ] Configure RBAC for team members
- [ ] Enable image signing (optional)

### Step 19: Backup Configuration
- [ ] Configure PostgreSQL backups
  - [ ] Automated daily backups
  - [ ] 30-day retention
  - [ ] Test restore procedure
- [ ] Configure ScyllaDB backups
- [ ] Set up Velero for cluster backups (optional)
  ```bash
  velero install --provider aws \
    --plugins velero/velero-plugin-for-aws:v1.7.0 \
    --bucket ka-platform-backups
  ```
- [ ] Document backup procedures
- [ ] Schedule regular backup tests

### Step 20: Monitoring & Alerting
- [ ] Configure alert rules
  - [ ] High error rate
  - [ ] High latency
  - [ ] Pod crashes
  - [ ] Disk space
  - [ ] Memory usage
- [ ] Set up notification channels
  - [ ] Slack
  - [ ] PagerDuty
  - [ ] Email
- [ ] Test alerts
- [ ] Create runbooks for common alerts
- [ ] Set up on-call rotation

### Step 21: Documentation
- [ ] Document deployment process
- [ ] Create runbooks for common operations
- [ ] Document disaster recovery procedures
- [ ] Create architecture diagrams
- [ ] Set up team wiki/knowledge base
- [ ] Document escalation procedures

**⏱️ Time: ~2-4 hours**

---

## Maintenance Schedule

### Daily
- [ ] Check cluster health
  ```bash
  kubectl get nodes
  kubectl get pods -A
  ```
- [ ] Review error logs
- [ ] Check Grafana dashboards
- [ ] Review alerts (if any)

### Weekly
- [ ] Review resource usage trends
- [ ] Check for available updates
- [ ] Review security scans
- [ ] Backup verification
- [ ] Performance optimization review

### Monthly
- [ ] Update Kubernetes version (if available)
- [ ] Update application versions
- [ ] Security audit
- [ ] Cost optimization review
- [ ] Disaster recovery drill
- [ ] Documentation review

---

## Troubleshooting Checklist

### Pods Not Starting
- [ ] Check pod events
  ```bash
  kubectl describe pod <pod-name> -n ka-platform
  ```
- [ ] Check logs
  ```bash
  kubectl logs <pod-name> -n ka-platform
  ```
- [ ] Check node resources
  ```bash
  kubectl describe nodes
  ```
- [ ] Check image pull secrets
  ```bash
  kubectl get secrets -n ka-platform
  ```

### Database Connection Issues
- [ ] Check database pod status
  ```bash
  kubectl get pods -n ka-platform | grep postgres
  ```
- [ ] Check database service
  ```bash
  kubectl get svc -n ka-platform postgres-service
  ```
- [ ] Test connection
  ```bash
  kubectl run -it --rm psql-test --image=postgres:15 -n ka-platform -- \
    psql -h postgres-service -U ka_user -d ka_db
  ```
- [ ] Check secrets
  ```bash
  kubectl get secret ka-secrets -n ka-platform -o yaml
  ```

### Argo CD Not Syncing
- [ ] Check application status
  ```bash
  kubectl get application -n argocd
  ```
- [ ] Check Argo CD logs
  ```bash
  kubectl logs -n argocd deployment/argocd-application-controller
  ```
- [ ] Force refresh
  ```bash
  argocd app get ka-platform --refresh
  ```
- [ ] Force sync
  ```bash
  argocd app sync ka-platform --force
  ```

### Monitoring Not Working
- [ ] Check Prometheus targets
  - Open http://localhost:9090/targets
- [ ] Check service discovery
  ```bash
  kubectl get pods -n ka-platform -o yaml | grep prometheus.io
  ```
- [ ] Check Grafana datasources
  - Open Grafana → Configuration → Data Sources
- [ ] Check Promtail pods
  ```bash
  kubectl get pods -n ka-platform -l app=promtail
  ```

---

## Rollback Procedures

### Application Rollback
- [ ] List revisions
  ```bash
  argocd app history ka-platform
  ```
- [ ] Rollback to previous version
  ```bash
  argocd app rollback ka-platform <revision>
  ```
- [ ] Or use Helm
  ```bash
  helm rollback ka-platform -n ka-platform
  ```

### Infrastructure Rollback
- [ ] Revert Terraform changes
  ```bash
  git revert <commit-hash>
  terraform apply
  ```
- [ ] Or use Terraform state
  ```bash
  terraform state list
  terraform state pull
  ```

---

## Success Criteria

### Deployment Complete When:
- [ ] All infrastructure provisioned
- [ ] All pods running and healthy
- [ ] All services accessible
- [ ] Metrics being collected
- [ ] Logs being aggregated
- [ ] DNS configured (for production)
- [ ] SSL certificates issued (for production)
- [ ] Backups configured
- [ ] Monitoring and alerting operational
- [ ] Documentation updated
- [ ] Team trained on operations

### Production Ready When:
- [ ] All success criteria met
- [ ] Load testing completed
- [ ] Disaster recovery tested
- [ ] Security audit passed
- [ ] Performance benchmarks met
- [ ] On-call rotation established
- [ ] Runbooks documented
- [ ] SLA defined

---

## Emergency Contacts

### Critical Issues
- **Cloud Provider Support**: [Provider support link]
- **On-Call Engineer**: [Phone/Slack]
- **Team Lead**: [Contact info]
- **Security Team**: [Contact info]

### Useful Links
- **Argo CD**: https://localhost:8080 (port-forward)
- **Grafana**: https://grafana.yourdomain.com
- **Prometheus**: https://localhost:9090 (port-forward)
- **Documentation**: [Your wiki/docs link]
- **Status Page**: [If you have one]

---

## Final Checklist

Before going live:
- [ ] All items in this checklist completed
- [ ] Load testing completed successfully
- [ ] Disaster recovery plan tested
- [ ] Team trained on operations
- [ ] Documentation complete and accessible
- [ ] Monitoring dashboards configured
- [ ] Alerts tested and routed correctly
- [ ] Backup and restore tested
- [ ] Security scan passed
- [ ] Performance benchmarks met
- [ ] Stakeholders notified
- [ ] Go-live date confirmed

---

**Document Version**: 1.0.0  
**Last Updated**: 2024  
**Next Review**: [Schedule monthly review]
