#!/bin/bash
# Simple test script for Discovery Service API endpoints

set -e

DISCOVERY_URL="${DISCOVERY_URL:-http://localhost:8008}"

echo "Testing Discovery Service at $DISCOVERY_URL"
echo "============================================"

# Test health endpoint
echo ""
echo "1. Testing health endpoint..."
curl -s "$DISCOVERY_URL/health" | jq '.'

# Test trending hashtags endpoint
echo ""
echo "2. Testing trending hashtags endpoint..."
curl -s "$DISCOVERY_URL/api/v1/discover/trending?limit=5" | jq '.'

# Test search endpoint (with a sample query)
echo ""
echo "3. Testing search endpoint..."
curl -s "$DISCOVERY_URL/api/v1/search?q=test&limit=5" | jq '.'

# Test autocomplete endpoint
echo ""
echo "4. Testing autocomplete endpoint..."
curl -s "$DISCOVERY_URL/api/v1/search/suggest?q=john&limit=3" | jq '.'

echo ""
echo "All tests completed successfully!"
