# Terraform Infrastructure for Ka Platform

This directory contains Terraform configurations for provisioning the infrastructure for the Ka Platform on different cloud providers.

## Supported Providers

- **DigitalOcean**: Managed Kubernetes (DOKS) with optional managed databases
- **Google Cloud Platform**: Google Kubernetes Engine (GKE) with optional Cloud SQL and Memorystore

## Prerequisites

1. **Terraform**: Install Terraform >= 1.5.0
   ```bash
   # macOS
   brew install terraform

   # Linux
   wget https://releases.hashicorp.com/terraform/1.5.7/terraform_1.5.7_linux_amd64.zip
   unzip terraform_1.5.7_linux_amd64.zip
   sudo mv terraform /usr/local/bin/
   ```

2. **Cloud Provider CLI**:
   - DigitalOcean: Install `doctl`
   - GCP: Install `gcloud`

3. **kubectl**: Install Kubernetes CLI
   ```bash
   # macOS
   brew install kubectl

   # Linux
   curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
   sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
   ```

## DigitalOcean Setup

### 1. Get API Token

1. Log in to DigitalOcean
2. Go to API → Tokens/Keys
3. Generate New Token with read/write scope

### 2. Configure Terraform

```bash
cd digitalocean
cp terraform.tfvars.example terraform.tfvars
```

Edit `terraform.tfvars` with your values:
```hcl
do_token = "your-digitalocean-token"
cluster_name = "ka-platform-prod"
region = "nyc3"
```

### 3. Deploy Infrastructure

```bash
# Initialize Terraform
terraform init

# Preview changes
terraform plan

# Apply changes
terraform apply

# Get kubeconfig
export KUBECONFIG=$(terraform output -raw kubeconfig_path)

# Verify cluster access
kubectl get nodes
```

### 4. Configuration Options

| Variable | Description | Default |
|----------|-------------|---------|
| `cluster_name` | Cluster name | `ka-platform` |
| `region` | DO region | `nyc3` |
| `node_size` | Node size | `s-4vcpu-8gb` |
| `node_count` | Initial nodes | `3` |
| `enable_autoscaling` | Enable autoscaling | `true` |
| `use_managed_databases` | Use managed databases | `true` |

### 5. Cost Estimation

**Basic Setup (3 nodes):**
- Kubernetes: $120/month (3 x $40)
- Managed PostgreSQL: $15/month
- Managed Redis: $15/month
- Load Balancer: $10/month
- **Total: ~$160/month**

**Production Setup (with autoscaling):**
- Kubernetes: $200-400/month
- Managed Databases: $60/month
- Load Balancer: $10/month
- **Total: ~$270-470/month**

## Google Cloud Platform Setup

### 1. Set Up GCP Project

```bash
# Authenticate with GCP
gcloud auth login
gcloud auth application-default login

# Create or select project
gcloud projects create ka-platform-prod
gcloud config set project ka-platform-prod

# Enable billing (required)
# https://console.cloud.google.com/billing
```

### 2. Configure Terraform

```bash
cd gcp
cp terraform.tfvars.example terraform.tfvars
```

Edit `terraform.tfvars` with your values:
```hcl
project_id = "ka-platform-prod"
cluster_name = "ka-platform-prod"
region = "us-central1"
```

### 3. Deploy Infrastructure

```bash
# Initialize Terraform
terraform init

# Preview changes
terraform plan

# Apply changes
terraform apply

# Get kubeconfig
eval $(terraform output -raw kubeconfig_command)

# Verify cluster access
kubectl get nodes
```

### 4. Configuration Options

| Variable | Description | Default |
|----------|-------------|---------|
| `project_id` | GCP project ID | Required |
| `cluster_name` | Cluster name | `ka-platform` |
| `region` | GCP region | `us-central1` |
| `node_machine_type` | Machine type | `e2-standard-4` |
| `use_managed_databases` | Use Cloud SQL & Memorystore | `true` |

### 5. Cost Estimation

**Basic Setup (3 nodes across 3 zones):**
- GKE: $220/month
- Cloud SQL: $50/month
- Memorystore: $30/month
- **Total: ~$300/month**

**Production Setup:**
- GKE: $400-800/month
- Cloud SQL: $150/month
- Memorystore: $100/month
- Load Balancer: $20/month
- **Total: ~$670-1,070/month**

## Post-Deployment Steps

### 1. Install Argo CD

```bash
# Create namespace
kubectl create namespace argocd

# Install Argo CD
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for deployment
kubectl wait --for=condition=available --timeout=300s deployment/argocd-server -n argocd

# Get admin password
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d
```

### 2. Deploy Ka Platform

```bash
# Apply Ka Platform Application
kubectl apply -f ../../infrastructure/argocd/ka-platform-application.yaml

# Watch deployment
kubectl get application -n argocd
kubectl get pods -n ka-platform -w
```

### 3. Deploy Observability Stack

```bash
# Create namespace if not exists
kubectl create namespace ka-platform --dry-run=client -o yaml | kubectl apply -f -

# Deploy Prometheus
kubectl apply -f ../../infrastructure/observability/prometheus/

# Deploy Grafana
kubectl apply -f ../../infrastructure/observability/grafana/

# Deploy Loki
kubectl apply -f ../../infrastructure/observability/loki/
```

### 4. Configure DNS

Point your domain to the load balancer IP:

**DigitalOcean:**
```bash
terraform output load_balancer_ip
```

**GCP:**
```bash
terraform output ingress_ip
```

Create DNS A records:
- `api.yourdomain.com` → Load Balancer IP
- `grafana.yourdomain.com` → Load Balancer IP

### 5. Configure SSL

Install cert-manager for automatic SSL certificates:

```bash
# Install cert-manager
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml

# Create ClusterIssuer for Let's Encrypt
kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@yourdomain.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
EOF
```

## State Management

For production, use remote state backend:

**DigitalOcean (Spaces):**
```hcl
terraform {
  backend "s3" {
    endpoint                    = "nyc3.digitaloceanspaces.com"
    key                         = "terraform/ka-platform.tfstate"
    bucket                      = "ka-platform-terraform-state"
    region                      = "us-east-1"
    skip_credentials_validation = true
    skip_metadata_api_check     = true
  }
}
```

**GCP (Cloud Storage):**
```hcl
terraform {
  backend "gcs" {
    bucket = "ka-platform-terraform-state"
    prefix = "terraform/state"
  }
}
```

## Maintenance

### Update Kubernetes Version

1. Check available versions:
   ```bash
   # DigitalOcean
   doctl kubernetes options versions

   # GCP
   gcloud container get-server-config --region us-central1
   ```

2. Update `kubernetes_version` in `terraform.tfvars`

3. Apply changes:
   ```bash
   terraform apply
   ```

### Scale Cluster

Update node count in `terraform.tfvars`:
```hcl
node_count = 5  # or min_nodes/max_nodes for autoscaling
```

Apply changes:
```bash
terraform apply
```

### Backup and Disaster Recovery

**Kubernetes Backups:**
```bash
# Install Velero for backups
velero install --provider aws --plugins velero/velero-plugin-for-aws:v1.7.0 \
  --bucket ka-platform-backups \
  --backup-location-config region=us-east-1

# Create backup
velero backup create ka-platform-backup

# Restore from backup
velero restore create --from-backup ka-platform-backup
```

**Database Backups:**
- Both DigitalOcean and GCP managed databases include automatic daily backups
- Configure retention period in cloud provider console

## Destroy Infrastructure

⚠️ **Warning**: This will destroy all resources and data!

```bash
# Preview what will be destroyed
terraform plan -destroy

# Destroy infrastructure
terraform destroy

# Confirm with 'yes' when prompted
```

## Troubleshooting

### Cluster Access Issues

```bash
# DigitalOcean
doctl kubernetes cluster kubeconfig save <cluster-name>

# GCP
gcloud container clusters get-credentials <cluster-name> --region <region>
```

### Terraform State Lock

If state is locked:
```bash
# Force unlock (use with caution)
terraform force-unlock <lock-id>
```

### Provider Authentication

**DigitalOcean:**
```bash
export DIGITALOCEAN_TOKEN="your-token"
```

**GCP:**
```bash
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account-key.json"
```

## Additional Resources

- [Terraform Documentation](https://www.terraform.io/docs)
- [DigitalOcean Kubernetes](https://www.digitalocean.com/products/kubernetes)
- [Google Kubernetes Engine](https://cloud.google.com/kubernetes-engine)
- [Kubernetes Best Practices](https://kubernetes.io/docs/concepts/configuration/overview/)

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review Terraform logs: `terraform apply -debug`
3. Check cloud provider status pages
4. Open an issue in the repository
