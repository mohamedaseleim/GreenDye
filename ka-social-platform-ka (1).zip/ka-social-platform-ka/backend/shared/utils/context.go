package utils

import (
	"github.com/gin-gonic/gin"
)

// GetEntitlementsFromContext extracts entitlements from gin context
func GetEntitlementsFromContext(c *gin.Context) []string {
	entitlements, exists := c.Get("entitlements")
	if !exists {
		return []string{}
	}

	if entList, ok := entitlements.([]string); ok {
		return entList
	}

	return []string{}
}
