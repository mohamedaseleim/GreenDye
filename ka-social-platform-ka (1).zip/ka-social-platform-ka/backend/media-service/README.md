# Media Service

The Media Service is a professional-grade, highly scalable media pipeline for the Ka platform. It provides secure, direct-to-storage uploads using presigned URLs and background image processing with CDN-ready URLs.

## Features

### 1. Presigned URL Uploads
- **Direct to MinIO**: Clients upload files directly to MinIO storage, bypassing the service
- **Secure**: One-time presigned URLs with expiration (default: 15 minutes)
- **Scalable**: No bandwidth consumed by the service during uploads
- **S3-Compatible**: Uses MinIO for S3-compatible object storage

### 2. Background Image Processing
- **Event-Driven**: Uses NATS for asynchronous processing
- **Multiple Sizes**: Generates thumbnail (150x150) and medium (600x600) versions
- **WebP Conversion**: Converts images to modern, efficient WebP format
- **High Performance**: Uses libvips via bimg for fast image processing

### 3. CDN-Ready URLs
- **Configurable CDN**: Switch from MinIO direct URLs to CDN via `CDN_HOST` env variable
- **Production Ready**: Designed for global CDN integration (CloudFlare, CloudFront, etc.)

## Architecture

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ 1. POST /api/v1/upload/request
       ▼
┌─────────────────────┐
│  Media Service      │
│  (Presigned URL)    │
└──────┬──────────────┘
       │ 2. Returns presigned URL
       ▼
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ 3. PUT to presigned URL
       ▼
┌─────────────────────┐
│      MinIO          │
│  (Object Storage)   │
└──────┬──────────────┘
       │
       │ 4. POST /api/v1/upload/complete
       ▼
┌─────────────────────┐
│  Media Service      │
│  (Event Publisher)  │
└──────┬──────────────┘
       │ 5. Publish media.processing.required
       ▼
┌─────────────────────┐
│       NATS          │
│  (Message Broker)   │
└──────┬──────────────┘
       │ 6. Consume event
       ▼
┌─────────────────────┐
│  Media Service      │
│  (Worker)           │
└──────┬──────────────┘
       │ 7. Download, process, upload
       ▼
┌─────────────────────┐
│      MinIO          │
│  (Processed Images) │
└──────┬──────────────┘
       │ 8. Publish media.processed
       ▼
┌─────────────────────┐
│   User Service      │
│  (Update Profile)   │
└─────────────────────┘
```

## API Endpoints

### POST /api/v1/upload/request
Request a presigned URL for direct upload to storage.

**Authentication**: Required (JWT)

**Request Body**:
```json
{
  "filename": "avatar.jpg",
  "content_type": "image/jpeg"
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "upload_url": "https://minio:9000/ka-media/uploads/user-id/uuid.jpg?X-Amz-...",
    "object_key": "uploads/user-id/uuid.jpg",
    "expires_in": 900
  }
}
```

**Usage**:
1. Client calls this endpoint to get a presigned URL
2. Client uploads the file directly to the `upload_url` using HTTP PUT
3. Client calls `/api/v1/upload/complete` with the `object_key`

### POST /api/v1/upload/complete
Notify the service that an upload is complete and trigger processing.

**Authentication**: Required (JWT)

**Request Body**:
```json
{
  "object_key": "uploads/user-id/uuid.jpg"
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "message": "Media processing queued successfully",
    "object_key": "uploads/user-id/uuid.jpg"
  }
}
```

## Events

### Published Events

#### media.processing.required
Published when a client notifies that an upload is complete.

**Subject**: `media.processing.required`

**Payload**:
```json
{
  "object_key": "uploads/user-id/uuid.jpg",
  "user_id": "uuid",
  "content_type": "image/jpeg",
  "uploaded_at": 1234567890
}
```

#### media.processed
Published when image processing is complete.

**Subject**: `media.processed`

**Payload**:
```json
{
  "object_key": "uploads/user-id/uuid.jpg",
  "user_id": "uuid",
  "original_url": "https://cdn.example.com/ka-media/uploads/user-id/uuid.jpg",
  "medium_url": "https://cdn.example.com/ka-media/processed/medium_xyz.webp",
  "thumb_url": "https://cdn.example.com/ka-media/processed/thumb_xyz.webp",
  "processed_at": 1234567890
}
```

### Consumed Events

The Media Service worker consumes `media.processing.required` events to process images in the background.

## Configuration

### Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `PORT` | HTTP server port | `8009` | No |
| `MINIO_ENDPOINT` | MinIO server endpoint | `localhost:9000` | Yes |
| `MINIO_ACCESS_KEY` | MinIO access key | `minioadmin` | Yes |
| `MINIO_SECRET_KEY` | MinIO secret key | `minioadmin` | Yes |
| `MINIO_BUCKET` | MinIO bucket name | `ka-media` | Yes |
| `MINIO_USE_SSL` | Use SSL for MinIO | `false` | No |
| `CDN_HOST` | CDN base URL (e.g., `https://cdn.example.com`) | `` | No |
| `NATS_URL` | NATS server URL | `nats://localhost:4222` | Yes |
| `REDIS_HOST` | Redis host | `localhost` | Yes |
| `REDIS_PORT` | Redis port | `6379` | Yes |
| `REDIS_PASSWORD` | Redis password | `` | No |
| `JWT_SECRET` | JWT secret for authentication | Required | Yes |
| `PRESIGNED_URL_EXPIRY` | Presigned URL expiration (seconds) | `900` | No |

### CDN Configuration

In development, the service returns direct MinIO URLs:
```
http://minio:9000/ka-media/uploads/user-id/uuid.jpg
```

In production, set `CDN_HOST` to switch to CDN URLs:
```bash
export CDN_HOST="https://cdn.kaplatform.com"
```

The service will then return:
```
https://cdn.kaplatform.com/ka-media/uploads/user-id/uuid.jpg
```

## Image Processing

### Sizes
- **Original**: Stored as uploaded
- **Medium**: 600x600 pixels, cropped, WebP format
- **Thumbnail**: 150x150 pixels, cropped, WebP format

### Format
All processed images are converted to **WebP** format for optimal file size and quality:
- 85% quality setting
- Lossless compression
- Modern browsers support (Chrome, Firefox, Edge, Safari 14+)

### Performance
- Uses **libvips** via **bimg** for high-performance image processing
- 3-10x faster than ImageMagick
- Low memory usage
- Multi-threaded

## Dependencies

### Required Services
- **MinIO**: S3-compatible object storage
- **NATS**: Message broker for event-driven processing
- **Redis**: Caching (optional, for future features)

### Required Libraries
- **bimg**: Go bindings for libvips
- **libvips**: High-performance image processing library
- **minio-go**: MinIO Go client
- **nats.go**: NATS Go client

### Installing libvips

**Alpine Linux** (Docker):
```bash
apk add --no-cache vips-dev
```

**Ubuntu/Debian**:
```bash
apt-get install libvips-dev
```

**macOS**:
```bash
brew install vips
```

## Development

### Running Locally

1. Start infrastructure services:
```bash
cd infrastructure/docker
docker-compose up -d postgres redis nats minio
```

2. Run the service:
```bash
cd backend/media-service
go run .
```

3. Test the upload flow:
```bash
# Get presigned URL
curl -X POST http://localhost:8009/api/v1/upload/request \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "filename": "test.jpg",
    "content_type": "image/jpeg"
  }'

# Upload file to presigned URL
curl -X PUT "PRESIGNED_URL" \
  --upload-file test.jpg

# Notify upload complete
curl -X POST http://localhost:8009/api/v1/upload/complete \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "object_key": "uploads/user-id/uuid.jpg"
  }'
```

### Running with Docker Compose

```bash
cd infrastructure/docker
docker-compose up -d media-service
```

## Testing

### Manual Testing

1. **Get presigned URL**: Call `/api/v1/upload/request`
2. **Upload file**: PUT file to the presigned URL
3. **Notify completion**: Call `/api/v1/upload/complete`
4. **Check NATS**: Verify `media.processing.required` event is published
5. **Wait for processing**: Worker consumes event and processes image
6. **Verify results**: Check MinIO for processed images
7. **Check user profile**: Verify `media.processed` event updates User Service

### Health Check

```bash
curl http://localhost:8009/health
```

Expected response:
```json
{
  "status": "ok",
  "service": "media-service"
}
```

## Production Considerations

### Scaling
- **Horizontal Scaling**: Run multiple instances of the service
- **Worker Scaling**: Multiple workers can consume `media.processing.required` events
- **NATS Consumer Groups**: Use consumer groups for load balancing

### CDN Integration
1. Configure CloudFlare or CloudFront in front of MinIO
2. Set `CDN_HOST` environment variable
3. Update MinIO bucket policy for public read access
4. Configure CDN caching headers

### Security
- **Presigned URLs**: Expire after 15 minutes
- **User Validation**: Object keys are validated to match authenticated user
- **Content Type Validation**: Only image types are accepted
- **JWT Authentication**: All endpoints require valid JWT tokens

### Monitoring
- **Health Endpoint**: `/health` for liveness/readiness probes
- **NATS Metrics**: Monitor event queue depth
- **Processing Time**: Track image processing duration
- **Storage Usage**: Monitor MinIO bucket size

## Troubleshooting

### libvips errors
If you see "failed to process image" errors, ensure libvips is installed:
```bash
# Check if vips is available
vips --version
```

### MinIO connection errors
Verify MinIO is running and accessible:
```bash
curl http://localhost:9000/minio/health/live
```

### NATS connection errors
Check NATS is running:
```bash
curl http://localhost:8222/healthz
```

### Processing not triggered
Check NATS logs to see if events are being published and consumed:
```bash
curl http://localhost:8222/varz
```

## Future Enhancements

- [ ] Video processing support
- [ ] Additional image sizes (large, xlarge)
- [ ] Face detection and smart cropping
- [ ] Animated GIF/WebP support
- [ ] Metadata extraction (EXIF, GPS)
- [ ] Image moderation (NSFW detection)
- [ ] Progress tracking for large uploads
- [ ] Webhook notifications on completion
- [ ] Admin API for bulk operations
