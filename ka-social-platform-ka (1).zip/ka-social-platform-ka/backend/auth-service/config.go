package main

import (
	"github.com/jmoiron/sqlx"
	"github.com/nats-io/nats.go"
	"github.com/redis/go-redis/v9"
)

// Config holds the configuration for the auth service
type Config struct {
	DB                 *sqlx.DB
	Redis              *redis.Client
	JWTSecret          string
	JWTExpiry          string
	RefreshTokenExpiry string
	NATSConn           *nats.Conn
	BillingServiceURL  string
}
