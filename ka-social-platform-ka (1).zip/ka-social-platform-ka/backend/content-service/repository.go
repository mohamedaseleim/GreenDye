package main

import (
	"fmt"

	"github.com/gocql/gocql"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/redis/go-redis/v9"
)

// Repository handles data operations for the content service
type Repository struct {
	scylla *gocql.Session
	redis  *redis.Client
}

// NewRepository creates a new repository
func NewRepository(scylla *gocql.Session, redis *redis.Client) *Repository {
	return &Repository{
		scylla: scylla,
		redis:  redis,
	}
}

// CreateEcho creates a new echo in ScyllaDB
func (r *Repository) CreateEcho(echo *models.Echo) error {
	query := `INSERT INTO echoes (
		id, user_id, content, media_urls, media_attachments, hashtags, mentions, 
		parent_echo_id, visibility, like_count, comment_count, 
		share_count, created_at, updated_at
	) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`

	// Convert slices to CQL types
	var mediaURLs []string
	if echo.MediaURLs != nil {
		mediaURLs = echo.MediaURLs
	}

	// Convert MediaAttachments to list of maps for ScyllaDB
	var mediaAttachments []map[string]string
	if echo.MediaAttachments != nil {
		for _, attachment := range echo.MediaAttachments {
			mediaMap := map[string]string{
				"media_key": attachment.MediaKey,
				"type":      attachment.Type,
				"alt_text":  attachment.AltText,
			}
			mediaAttachments = append(mediaAttachments, mediaMap)
		}
	}

	var hashtags []string
	if echo.Hashtags != nil {
		hashtags = echo.Hashtags
	}

	var mentions []gocql.UUID
	if echo.Mentions != nil {
		for _, m := range echo.Mentions {
			mentions = append(mentions, gocql.UUID(m))
		}
	}

	var parentEchoID *gocql.UUID
	if echo.ParentEchoID != nil {
		parentUUID := gocql.UUID(*echo.ParentEchoID)
		parentEchoID = &parentUUID
	}

	err := r.scylla.Query(query,
		gocql.UUID(echo.ID),
		gocql.UUID(echo.UserID),
		echo.Content,
		mediaURLs,
		mediaAttachments,
		hashtags,
		mentions,
		parentEchoID,
		echo.Visibility,
		echo.LikeCount,
		echo.CommentCount,
		echo.ShareCount,
		echo.CreatedAt,
		echo.UpdatedAt,
	).Exec()

	if err != nil {
		return fmt.Errorf("failed to create echo: %w", err)
	}

	return nil
}

// GetEchoByID retrieves an echo by ID
func (r *Repository) GetEchoByID(echoID uuid.UUID) (*models.Echo, error) {
	query := `SELECT id, user_id, content, media_urls, media_attachments, hashtags, mentions, 
		parent_echo_id, visibility, like_count, comment_count, 
		share_count, created_at, updated_at 
		FROM echoes WHERE id = ?`

	var echo models.Echo
	var id, userID gocql.UUID
	var parentEchoID *gocql.UUID
	var mediaURLs []string
	var mediaAttachments []map[string]string
	var hashtags []string
	var mentions []gocql.UUID

	err := r.scylla.Query(query, gocql.UUID(echoID)).Scan(
		&id,
		&userID,
		&echo.Content,
		&mediaURLs,
		&mediaAttachments,
		&hashtags,
		&mentions,
		&parentEchoID,
		&echo.Visibility,
		&echo.LikeCount,
		&echo.CommentCount,
		&echo.ShareCount,
		&echo.CreatedAt,
		&echo.UpdatedAt,
	)

	if err == gocql.ErrNotFound {
		return nil, nil
	}

	if err != nil {
		return nil, fmt.Errorf("failed to get echo: %w", err)
	}

	echo.ID = uuid.UUID(id)
	echo.UserID = uuid.UUID(userID)
	echo.MediaURLs = mediaURLs
	echo.Hashtags = hashtags

	// Convert media attachments from maps to structs
	if mediaAttachments != nil {
		for _, mediaMap := range mediaAttachments {
			attachment := models.MediaAttachment{
				MediaKey: mediaMap["media_key"],
				Type:     mediaMap["type"],
				AltText:  mediaMap["alt_text"],
			}
			echo.MediaAttachments = append(echo.MediaAttachments, attachment)
		}
	}

	if mentions != nil {
		for _, m := range mentions {
			echo.Mentions = append(echo.Mentions, uuid.UUID(m))
		}
	}

	if parentEchoID != nil {
		parentID := uuid.UUID(*parentEchoID)
		echo.ParentEchoID = &parentID
	}

	return &echo, nil
}

// DeleteEcho deletes an echo by ID
func (r *Repository) DeleteEcho(echoID uuid.UUID) error {
	query := `DELETE FROM echoes WHERE id = ?`

	err := r.scylla.Query(query, gocql.UUID(echoID)).Exec()
	if err != nil {
		return fmt.Errorf("failed to delete echo: %w", err)
	}

	return nil
}

// ExtractHashtags extracts hashtags from content
func ExtractHashtags(content string) []string {
	// Simple hashtag extraction (can be improved with regex)
	hashtags := []string{}
	words := splitWords(content)
	for _, word := range words {
		if len(word) > 1 && word[0] == '#' {
			hashtags = append(hashtags, word[1:])
		}
	}
	return hashtags
}

// splitWords is a simple word splitter
func splitWords(s string) []string {
	var words []string
	var current string
	for _, r := range s {
		if r == ' ' || r == '\n' || r == '\t' {
			if current != "" {
				words = append(words, current)
				current = ""
			}
		} else {
			current += string(r)
		}
	}
	if current != "" {
		words = append(words, current)
	}
	return words
}

// UpdateLikeCount updates the like count for an echo
func (r *Repository) UpdateLikeCount(echoID uuid.UUID, delta int) error {
	// First, get the current like count to avoid negative values
	echo, err := r.GetEchoByID(echoID)
	if err != nil {
		return fmt.Errorf("failed to get echo: %w", err)
	}
	if echo == nil {
		return fmt.Errorf("echo not found")
	}

	newCount := echo.LikeCount + delta
	if newCount < 0 {
		newCount = 0
	}

	query := `UPDATE echoes SET like_count = ? WHERE id = ?`
	err = r.scylla.Query(query, newCount, gocql.UUID(echoID)).Exec()
	if err != nil {
		return fmt.Errorf("failed to update like count: %w", err)
	}

	return nil
}

// GetReplies retrieves direct replies to an echo with cursor-based pagination
func (r *Repository) GetReplies(parentEchoID uuid.UUID, cursor *Cursor, limit int) ([]models.Echo, error) {
	var query string
	var args []interface{}

	if cursor == nil {
		// First page - get most recent replies
		query = `SELECT id, user_id, content, media_urls, media_attachments, hashtags, mentions, 
			parent_echo_id, visibility, like_count, comment_count, 
			share_count, created_at, updated_at 
			FROM echoes WHERE parent_echo_id = ? 
			ORDER BY created_at DESC LIMIT ?`
		args = []interface{}{gocql.UUID(parentEchoID), limit}
	} else {
		// Subsequent pages - get replies older than cursor
		query = `SELECT id, user_id, content, media_urls, media_attachments, hashtags, mentions, 
			parent_echo_id, visibility, like_count, comment_count, 
			share_count, created_at, updated_at 
			FROM echoes WHERE parent_echo_id = ? AND created_at < ? 
			ORDER BY created_at DESC LIMIT ?`
		args = []interface{}{gocql.UUID(parentEchoID), cursor.Timestamp, limit}
	}

	iter := r.scylla.Query(query, args...).Iter()
	defer iter.Close()

	replies := []models.Echo{}
	for {
		var echo models.Echo
		var id, userID gocql.UUID
		var parentEchoID *gocql.UUID
		var mediaURLs []string
		var mediaAttachments []map[string]string
		var hashtags []string
		var mentions []gocql.UUID

		if !iter.Scan(
			&id,
			&userID,
			&echo.Content,
			&mediaURLs,
			&mediaAttachments,
			&hashtags,
			&mentions,
			&parentEchoID,
			&echo.Visibility,
			&echo.LikeCount,
			&echo.CommentCount,
			&echo.ShareCount,
			&echo.CreatedAt,
			&echo.UpdatedAt,
		) {
			break
		}

		echo.ID = uuid.UUID(id)
		echo.UserID = uuid.UUID(userID)
		echo.MediaURLs = mediaURLs
		echo.Hashtags = hashtags

		// Convert media attachments from maps to structs
		if mediaAttachments != nil {
			for _, mediaMap := range mediaAttachments {
				attachment := models.MediaAttachment{
					MediaKey: mediaMap["media_key"],
					Type:     mediaMap["type"],
					AltText:  mediaMap["alt_text"],
				}
				echo.MediaAttachments = append(echo.MediaAttachments, attachment)
			}
		}

		if mentions != nil {
			for _, m := range mentions {
				echo.Mentions = append(echo.Mentions, uuid.UUID(m))
			}
		}

		if parentEchoID != nil {
			parentID := uuid.UUID(*parentEchoID)
			echo.ParentEchoID = &parentID
		}

		replies = append(replies, echo)
	}

	if err := iter.Close(); err != nil {
		return nil, fmt.Errorf("failed to get replies: %w", err)
	}

	return replies, nil
}
