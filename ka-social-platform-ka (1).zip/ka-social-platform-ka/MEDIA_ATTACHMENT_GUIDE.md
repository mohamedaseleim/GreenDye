# Media Attachment Integration Guide

This guide documents the secure media attachment system for the Ka Social Platform.

## Overview

The Ka platform now supports secure, extensible media attachments on Echoes (posts) with the following features:

- **Secure Ownership Validation**: Users can only attach media they have uploaded
- **Extensible Media Model**: Rich media objects supporting images, videos, GIFs with metadata
- **Alt Text Support**: Accessibility features for screen readers
- **Optimized Feed Hydration**: Media URLs automatically resolved when fetching echoes
- **Backward Compatibility**: Existing `media_urls` field maintained during migration

## Architecture Components

### Media Service
- **Upload Flow**: Presigned URLs for direct-to-storage uploads
- **Validation Endpoint**: `POST /api/internal/media/validate` - Validates media ownership
- **Details Endpoint**: `POST /api/internal/media/details` - Returns CDN URLs for media keys
- **Storage**: MinIO (S3-compatible object storage)

### Content Service
- **Echo Creation**: Validates media attachments before saving
- **Batch Endpoint**: Hydrates media URLs when returning echoes to Feed Service
- **Media Client**: Communicates with Media Service for validation and hydration
- **Database**: ScyllaDB with `media_attachments` field

### Feed Service
- **Timeline Generation**: Receives fully hydrated echoes from Content Service
- **No Changes Required**: Content Service handles all media hydration

## API Changes

### 1. Create Echo with Media

**Endpoint**: `POST /api/v1/echoes`

**Request Body**:
```json
{
  "content": "Amazing sunset at the Nile! #travel #egypt",
  "media_attachments": [
    {
      "media_key": "uploads/123e4567-e89b-12d3-a456-426614174000/abc123.jpg",
      "type": "image",
      "alt_text": "A photo of the Nile river at sunset with feluccas sailing."
    }
  ],
  "visibility": "public"
}
```

**Response** (Success):
```json
{
  "success": true,
  "message": "Echo created successfully",
  "data": {
    "id": "echo-uuid",
    "user_id": "user-uuid",
    "content": "Amazing sunset at the Nile! #travel #egypt",
    "media_attachments": [
      {
        "media_key": "uploads/123e4567-e89b-12d3-a456-426614174000/abc123.jpg",
        "type": "image",
        "alt_text": "A photo of the Nile river at sunset with feluccas sailing.",
        "url": ""
      }
    ],
    "hashtags": ["travel", "egypt"],
    "visibility": "public",
    "like_count": 0,
    "created_at": "2024-01-01T12:00:00Z"
  }
}
```

**Response** (Validation Error):
```json
{
  "success": false,
  "error": {
    "code": "INVALID_MEDIA",
    "message": "Some media keys are invalid or not owned by user",
    "details": ["uploads/other-user-id/xyz789.jpg"]
  }
}
```

### 2. Batch Get Echoes (Internal)

**Endpoint**: `POST /api/internal/echoes/batch`

**Request Body**:
```json
{
  "echo_ids": ["echo-uuid-1", "echo-uuid-2"]
}
```

**Response** (with hydrated media):
```json
{
  "success": true,
  "data": [
    {
      "id": "echo-uuid-1",
      "content": "Check out this photo!",
      "media_attachments": [
        {
          "media_key": "uploads/user-id/abc123.jpg",
          "type": "image",
          "alt_text": "A beautiful landscape",
          "url": "https://cdn.kaplatform.com/ka-media/uploads/user-id/abc123.jpg"
        }
      ],
      "created_at": "2024-01-01T12:00:00Z"
    }
  ]
}
```

### 3. Media Validation (Internal)

**Endpoint**: `POST /api/internal/media/validate`

**Request Body**:
```json
{
  "media_keys": ["uploads/user-id/abc123.jpg"],
  "user_id": "user-id"
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "valid": true,
    "message": "All media keys are valid"
  }
}
```

### 4. Media Details (Internal)

**Endpoint**: `POST /api/internal/media/details`

**Request Body**:
```json
{
  "media_keys": ["uploads/user-id/abc123.jpg"]
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "media": [
      {
        "media_key": "uploads/user-id/abc123.jpg",
        "url": "https://cdn.kaplatform.com/ka-media/uploads/user-id/abc123.jpg",
        "exists": true
      }
    ]
  }
}
```

## Data Models

### MediaAttachment

```go
type MediaAttachment struct {
    MediaKey string `json:"media_key" binding:"required"`
    Type     string `json:"type" binding:"required,oneof=image video gif"`
    AltText  string `json:"alt_text,omitempty"`
    URL      string `json:"url,omitempty"` // Populated during hydration
}
```

**Fields**:
- `media_key` (required): Unique identifier from Media Service (e.g., `uploads/{user_id}/{uuid}.jpg`)
- `type` (required): Media type - one of: `image`, `video`, `gif`
- `alt_text` (optional): Accessibility description for screen readers
- `url` (populated): Full CDN URL, added during hydration by Content Service

### Echo Model Changes

```go
type Echo struct {
    // ... existing fields
    MediaURLs        []string          `json:"media_urls,omitempty"`           // Deprecated
    MediaAttachments []MediaAttachment `json:"media_attachments,omitempty"`   // New
    // ... existing fields
}
```

## Database Schema

### ScyllaDB - echoes table

```cql
CREATE TABLE echoes (
    id UUID PRIMARY KEY,
    user_id UUID,
    content TEXT,
    media_urls LIST<TEXT>,                          -- Deprecated: backward compatibility
    media_attachments LIST<FROZEN<MAP<TEXT, TEXT>>>, -- New: extensible media objects
    hashtags SET<TEXT>,
    mentions SET<UUID>,
    parent_echo_id UUID,
    visibility TEXT,
    like_count INT,
    comment_count INT,
    share_count INT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

## Flow Diagrams

### Upload and Attach Flow

```
1. Upload Media
   Client → Media Service: POST /api/v1/upload/request
   Client ← Media Service: {upload_url, object_key}
   Client → MinIO: PUT {upload_url} (direct upload)
   Client → Media Service: POST /api/v1/upload/complete
   
   Result: media_key = object_key

2. Create Echo with Media
   Client → Content Service: POST /api/v1/echoes {media_attachments}
   Content Service → Media Service: POST /api/internal/media/validate
   Media Service → MinIO: Check ownership and existence
   Media Service → Content Service: {valid: true}
   Content Service → ScyllaDB: INSERT echo
   Content Service → NATS: Publish echo.created event
   Content Service → Client: {echo created}

3. Fetch Feed with Media
   Client → Feed Service: GET /api/v1/feed/home
   Feed Service → Redis: Get timeline echo IDs
   Feed Service → Content Service: POST /api/internal/echoes/batch
   Content Service → ScyllaDB: Fetch echoes
   Content Service → Media Service: POST /api/internal/media/details
   Media Service → Content Service: {media URLs}
   Content Service → Feed Service: {hydrated echoes}
   Feed Service → Client: {feed with media URLs}
```

## Security Features

### Media Ownership Validation

1. **Key Structure**: Media keys encode user ID: `uploads/{user_id}/{uuid}.{ext}`
2. **Validation**: Media Service checks key prefix matches requesting user
3. **Storage Check**: Validates object exists in MinIO
4. **Rejection**: Invalid or unauthorized keys reject echo creation

### Internal Endpoints

- Internal endpoints (`/api/internal/*`) have no JWT authentication
- Network-level security via VPC/firewall rules
- Only accessible within the service mesh
- Not exposed to public internet

## Testing

### Run Integration Test

```bash
cd backend/content-service
./test_media_attachment.sh
```

This script tests:
1. Media upload flow
2. Echo creation with media attachment
3. Media ownership validation
4. Feed hydration with media URLs

### Manual Testing

1. **Upload Media**:
```bash
curl -X POST http://localhost:8004/api/v1/upload/request \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"filename": "test.jpg", "content_type": "image/jpeg"}'
```

2. **Create Echo**:
```bash
curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Test echo with media",
    "media_attachments": [
      {
        "media_key": "uploads/user-id/abc123.jpg",
        "type": "image",
        "alt_text": "Test image"
      }
    ],
    "visibility": "public"
  }'
```

3. **Validate Media** (Internal):
```bash
curl -X POST http://localhost:8004/api/internal/media/validate \
  -H "Content-Type: application/json" \
  -d '{
    "media_keys": ["uploads/user-id/abc123.jpg"],
    "user_id": "user-id"
  }'
```

## Environment Variables

### Content Service

```bash
MEDIA_SERVICE_URL=http://media-service:8004  # Media Service endpoint
```

### Media Service

```bash
CDN_HOST=https://cdn.kaplatform.com          # Optional: CDN host for URLs
MINIO_ENDPOINT=minio:9000                     # MinIO endpoint
MINIO_ACCESS_KEY=minioadmin                   # MinIO credentials
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=ka-media                         # Storage bucket
MINIO_USE_SSL=false                           # Use SSL for MinIO
```

## Migration Strategy

### Phase 1: Current - Dual Support
- Both `media_urls` and `media_attachments` supported
- New echoes use `media_attachments`
- Old echoes still have `media_urls`

### Phase 2: Migration
- Backfill `media_attachments` from `media_urls`
- Run migration script on existing data
- Both fields populated for all echoes

### Phase 3: Deprecation
- Mark `media_urls` as deprecated in API docs
- Mobile app updated to use only `media_attachments`
- `media_urls` remains in database for compatibility

### Phase 4: Removal (Future)
- Remove `media_urls` from API responses
- Keep in database for data archaeology
- Major version bump required

## Performance Characteristics

### Media Validation
- **Latency**: <50ms for up to 10 media keys
- **Throughput**: 1000+ validations/sec
- **Caching**: Future - Redis cache for repeated validations

### Media Hydration
- **Latency**: <10ms for up to 100 media keys
- **Overhead**: Minimal - string concatenation for URLs
- **Scaling**: Stateless - no database queries

### Echo Creation
- **Baseline**: ~50ms (without media)
- **With Media**: ~100ms (including validation)
- **Target**: Sub-200ms total response time

### Feed Retrieval
- **Baseline**: ~50ms (without media)
- **With Hydration**: ~60ms (single batch call)
- **Target**: Sub-100ms total response time

## Monitoring

### Metrics to Track

**Media Service**:
- `media_validation_requests_total`
- `media_validation_duration_seconds`
- `media_validation_failures_total`
- `media_details_requests_total`

**Content Service**:
- `echo_creation_with_media_total`
- `echo_media_validation_failures_total`
- `echo_batch_hydration_duration_seconds`

### Alerts

- Media validation failure rate > 5%
- Media Service response time > 100ms
- Content Service response time > 200ms

## Troubleshooting

### Echo Creation Fails with "MEDIA_VALIDATION_ERROR"

**Cause**: Media Service unavailable or network issue

**Solution**: 
1. Check Media Service is running: `curl http://media-service:8004/health`
2. Check network connectivity between services
3. Review Content Service logs for detailed error

### Media Attachment Rejected with "INVALID_MEDIA"

**Cause**: Media key doesn't belong to user or doesn't exist

**Solution**:
1. Verify media was uploaded by the user
2. Check media key format: `uploads/{user_id}/{uuid}.{ext}`
3. Verify object exists in MinIO: Check MinIO console
4. Test validation endpoint directly

### Feed Shows Echoes Without Media URLs

**Cause**: Media hydration failed or Media Service unavailable

**Solution**:
1. Check Media Service is running
2. Review Content Service logs for hydration errors
3. Verify media keys exist in storage
4. System degrades gracefully - echoes still shown

## References

- **ARCHITECTURE.md**: Complete technical architecture documentation
- **Media Service README**: Presigned URL flow and background processing
- **Content Service README**: Echo creation and NATS events
- **Feed Service README**: Timeline generation and caching

## Support

For questions or issues:
1. Check the test script: `backend/content-service/test_media_attachment.sh`
2. Review ARCHITECTURE.md for detailed flow diagrams
3. Check service logs: `docker logs ka-content-service`, `docker logs ka-media-service`
4. Verify infrastructure: `docker-compose ps`
