package main

import (
	"time"

	"github.com/google/uuid"
)

// Subscription represents a user subscription
type Subscription struct {
	ID                 uuid.UUID  `db:"id" json:"id"`
	UserID             uuid.UUID  `db:"user_id" json:"user_id"`
	StripeCustomerID   string     `db:"stripe_customer_id" json:"stripe_customer_id"`
	StripeSubscriptionID string   `db:"stripe_subscription_id" json:"stripe_subscription_id"`
	Status             string     `db:"status" json:"status"` // active, canceled, past_due, trialing
	CurrentPeriodStart time.Time  `db:"current_period_start" json:"current_period_start"`
	CurrentPeriodEnd   time.Time  `db:"current_period_end" json:"current_period_end"`
	CancelAtPeriodEnd  bool       `db:"cancel_at_period_end" json:"cancel_at_period_end"`
	CreatedAt          time.Time  `db:"created_at" json:"created_at"`
	UpdatedAt          time.Time  `db:"updated_at" json:"updated_at"`
	CanceledAt         *time.Time `db:"canceled_at" json:"canceled_at,omitempty"`
}

// Entitlement represents a feature entitlement
type Entitlement struct {
	ID          uuid.UUID `db:"id" json:"id"`
	UserID      uuid.UUID `db:"user_id" json:"user_id"`
	Feature     string    `db:"feature" json:"feature"`
	GrantedAt   time.Time `db:"granted_at" json:"granted_at"`
	ExpiresAt   *time.Time `db:"expires_at" json:"expires_at,omitempty"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
}

// CheckoutSessionRequest represents a request to create a checkout session
type CheckoutSessionRequest struct {
	UserID      uuid.UUID `json:"user_id" binding:"required"`
	SuccessURL  string    `json:"success_url" binding:"required"`
	CancelURL   string    `json:"cancel_url" binding:"required"`
}

// CheckoutSessionResponse represents the response from creating a checkout session
type CheckoutSessionResponse struct {
	SessionID  string `json:"session_id"`
	SessionURL string `json:"session_url"`
}

// EntitlementsResponse represents the entitlements for a user
type EntitlementsResponse struct {
	UserID       uuid.UUID `json:"user_id"`
	Entitlements []string  `json:"entitlements"`
	Subscription *Subscription `json:"subscription,omitempty"`
}

// Available entitlements
const (
	EntitlementProfileBadge       = "PROFILE_BADGE"
	EntitlementExtendedUploads    = "EXTENDED_UPLOADS"
	EntitlementAdvancedAnalytics  = "ADVANCED_ANALYTICS"
)

// Stripe subscription status constants
const (
	SubscriptionStatusActive    = "active"
	SubscriptionStatusCanceled  = "canceled"
	SubscriptionStatusPastDue   = "past_due"
	SubscriptionStatusTrialing  = "trialing"
	SubscriptionStatusIncomplete = "incomplete"
)
