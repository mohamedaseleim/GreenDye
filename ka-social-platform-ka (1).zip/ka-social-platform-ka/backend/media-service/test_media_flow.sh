#!/bin/bash

# Test script for Media Service upload flow
# This script demonstrates the complete presigned URL upload flow

set -e

echo "=== Media Service Upload Flow Test ==="
echo ""

# Configuration
MEDIA_SERVICE_URL="${MEDIA_SERVICE_URL:-http://localhost:8009}"
JWT_TOKEN="${JWT_TOKEN:-your-test-jwt-token}"
TEST_IMAGE="${TEST_IMAGE:-test_image.jpg}"

# Check if test image exists
if [ ! -f "$TEST_IMAGE" ]; then
    echo "Error: Test image '$TEST_IMAGE' not found"
    echo "Please provide a test image file or set TEST_IMAGE environment variable"
    exit 1
fi

echo "Step 1: Request presigned URL"
echo "=============================="
PRESIGNED_RESPONSE=$(curl -s -X POST "$MEDIA_SERVICE_URL/api/v1/upload/request" \
    -H "Authorization: Bearer $JWT_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
        \"filename\": \"$TEST_IMAGE\",
        \"content_type\": \"image/jpeg\"
    }")

echo "Response: $PRESIGNED_RESPONSE"
echo ""

# Extract upload URL and object key from response
UPLOAD_URL=$(echo "$PRESIGNED_RESPONSE" | jq -r '.data.upload_url')
OBJECT_KEY=$(echo "$PRESIGNED_RESPONSE" | jq -r '.data.object_key')

if [ "$UPLOAD_URL" == "null" ] || [ -z "$UPLOAD_URL" ]; then
    echo "Error: Failed to get presigned URL"
    echo "Response: $PRESIGNED_RESPONSE"
    exit 1
fi

echo "Upload URL: $UPLOAD_URL"
echo "Object Key: $OBJECT_KEY"
echo ""

echo "Step 2: Upload file directly to MinIO"
echo "====================================="
UPLOAD_RESPONSE=$(curl -s -w "\n%{http_code}" -X PUT "$UPLOAD_URL" \
    --upload-file "$TEST_IMAGE" \
    -H "Content-Type: image/jpeg")

HTTP_CODE=$(echo "$UPLOAD_RESPONSE" | tail -n1)
echo "HTTP Status: $HTTP_CODE"

if [ "$HTTP_CODE" != "200" ]; then
    echo "Error: Upload failed with status $HTTP_CODE"
    exit 1
fi

echo "Upload successful!"
echo ""

echo "Step 3: Notify upload complete"
echo "=============================="
COMPLETE_RESPONSE=$(curl -s -X POST "$MEDIA_SERVICE_URL/api/v1/upload/complete" \
    -H "Authorization: Bearer $JWT_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
        \"object_key\": \"$OBJECT_KEY\"
    }")

echo "Response: $COMPLETE_RESPONSE"
echo ""

echo "Step 4: Wait for processing"
echo "==========================="
echo "Background worker is now processing the image..."
echo "- Generating thumbnail (150x150)"
echo "- Generating medium (600x600)"
echo "- Converting to WebP format"
echo ""
echo "Processing typically takes 1-2 seconds"
echo ""

echo "=== Test Complete ==="
echo ""
echo "What happens next:"
echo "1. Media Service worker consumes 'media.processing.required' event"
echo "2. Worker downloads original image from MinIO"
echo "3. Worker generates thumbnail and medium versions in WebP format"
echo "4. Worker uploads processed images to MinIO"
echo "5. Worker publishes 'media.processed' event with CDN-ready URLs"
echo "6. User Service updates user profile with new avatar URLs"
echo ""
echo "To verify the processing:"
echo "- Check NATS logs: docker logs ka-nats"
echo "- Check Media Service logs: docker logs ka-media-service"
echo "- Check MinIO console: http://localhost:9001 (minioadmin/minioadmin)"
echo "- Check user profile via User Service API"
