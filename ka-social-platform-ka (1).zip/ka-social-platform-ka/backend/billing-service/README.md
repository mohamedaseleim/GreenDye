# Billing Service - Ka+ Subscription Management

The Billing Service manages Ka+ premium subscriptions through Stripe integration and provides JWT-based entitlements for stateless feature gating across the platform.

## Features

- **Stripe Checkout Integration**: Create hosted checkout sessions for Ka+ subscription
- **Webhook Processing**: Handle subscription lifecycle events from Stripe
- **Entitlement Management**: Grant/revoke feature entitlements based on subscription status
- **Redis Caching**: Cache entitlements for fast access (5-minute TTL)
- **Event Publishing**: Publish subscription events to NATS for cache invalidation
- **Internal API**: Provide entitlements data to Auth Service

## Environment Variables

```bash
# Service Configuration
PORT=8009

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=ka_user
DB_PASSWORD=ka_password
DB_NAME=ka_db

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# NATS
NATS_URL=nats://localhost:4222

# JWT
JWT_SECRET=your-super-secret-jwt-key-change-in-production

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_ID=price_...

# Service URLs
SERVICE_URL=http://localhost:8009
```

## API Endpoints

### Public Endpoints

#### Create Checkout Session
```http
POST /api/v1/billing/checkout
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "user_id": "uuid",
  "success_url": "https://app.ka.com/success",
  "cancel_url": "https://app.ka.com/cancel"
}
```

Response:
```json
{
  "success": true,
  "data": {
    "session_id": "cs_...",
    "session_url": "https://checkout.stripe.com/..."
  },
  "message": "Checkout session created successfully"
}
```

#### Get Subscription
```http
GET /api/v1/billing/subscription
Authorization: Bearer <jwt_token>
```

Response:
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "user_id": "uuid",
    "stripe_customer_id": "cus_...",
    "stripe_subscription_id": "sub_...",
    "status": "active",
    "current_period_start": "2024-01-01T00:00:00Z",
    "current_period_end": "2024-02-01T00:00:00Z",
    "cancel_at_period_end": false,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  },
  "message": "Subscription retrieved successfully"
}
```

#### Stripe Webhook
```http
POST /api/v1/billing/webhook
Stripe-Signature: t=...,v1=...,v2=...
Content-Type: application/json

{
  "type": "customer.subscription.created",
  "data": { ... }
}
```

### Internal Endpoints

#### Get User Entitlements
```http
GET /api/internal/billing/entitlements/:userId
```

Response:
```json
{
  "success": true,
  "data": {
    "user_id": "uuid",
    "entitlements": [
      "PROFILE_BADGE",
      "EXTENDED_UPLOADS",
      "ADVANCED_ANALYTICS"
    ],
    "subscription": {
      "status": "active",
      "current_period_end": "2024-02-01T00:00:00Z"
    }
  },
  "message": "Entitlements retrieved successfully"
}
```

## Available Entitlements

- `PROFILE_BADGE` - Shows Ka+ badge on user profile
- `EXTENDED_UPLOADS` - Upload 4 images per echo (vs 1 for free)
- `ADVANCED_ANALYTICS` - Access detailed engagement analytics

## Stripe Webhook Events

The service handles the following Stripe webhook events:

1. **checkout.session.completed**: User completed checkout
2. **customer.subscription.created**: New subscription created → Grant entitlements
3. **customer.subscription.updated**: Subscription status changed → Update entitlements
4. **customer.subscription.deleted**: Subscription canceled → Revoke entitlements

## NATS Events

### Published Events

- **subscription.activated**: User subscribed to Ka+
  ```json
  {
    "user_id": "uuid",
    "event": "subscription.activated",
    "timestamp": "2024-01-01T00:00:00Z"
  }
  ```

- **subscription.canceled**: User canceled Ka+ subscription
  ```json
  {
    "user_id": "uuid",
    "event": "subscription.canceled",
    "timestamp": "2024-01-01T00:00:00Z"
  }
  ```

## Database Schema

```sql
-- Subscriptions
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    stripe_customer_id VARCHAR(255) NOT NULL,
    stripe_subscription_id VARCHAR(255) NOT NULL UNIQUE,
    status VARCHAR(50) NOT NULL,
    current_period_start TIMESTAMP NOT NULL,
    current_period_end TIMESTAMP NOT NULL,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    canceled_at TIMESTAMP
);

-- Entitlements
CREATE TABLE entitlements (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id),
    feature VARCHAR(100) NOT NULL,
    granted_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, feature)
);
```

## Building and Running

### Development
```bash
# Install dependencies
go mod download

# Run service
go run .
```

### Docker
```bash
# Build image
docker build -t ka-billing-service .

# Run container
docker run -p 8009:8009 \
  -e STRIPE_SECRET_KEY=sk_test_... \
  -e STRIPE_WEBHOOK_SECRET=whsec_... \
  ka-billing-service
```

## Testing

### Create Checkout Session
```bash
curl -X POST http://localhost:8009/api/v1/billing/checkout \
  -H "Authorization: Bearer <jwt_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "user-uuid",
    "success_url": "http://localhost:3000/success",
    "cancel_url": "http://localhost:3000/cancel"
  }'
```

### Test Webhook (Stripe CLI)
```bash
# Install Stripe CLI
stripe listen --forward-to localhost:8009/api/v1/billing/webhook

# Trigger test event
stripe trigger customer.subscription.created
```

## Architecture Integration

The Billing Service is the **source of truth** for Ka+ subscriptions and entitlements:

1. **Stripe** → Billing Service: Subscription lifecycle events
2. **Billing Service** → PostgreSQL: Store subscriptions and entitlements
3. **Billing Service** → Redis: Cache entitlements (5-min TTL)
4. **Auth Service** → Billing Service: Fetch entitlements on login/refresh
5. **Auth Service** → JWT: Embed entitlements in token
6. **Feature Services** → JWT: Inspect entitlements for access control

This architecture ensures:
- Zero-latency feature checks (JWT inspection only)
- Services never call Billing Service for checks
- Entitlements stay fresh (15-min JWT expiry)
- Scalable and decoupled design

## Security

- **Webhook Signature Verification**: Validates all Stripe webhooks
- **JWT Authentication**: All authenticated endpoints require valid JWT
- **Internal Endpoints**: Protected by network/firewall (no public access)
- **PCI Compliance**: Stripe handles all payment data
- **Entitlement Verification**: Server-side only, cannot be bypassed

## Monitoring

Key metrics to monitor:
- Checkout session creation rate
- Webhook processing success rate
- Entitlement fetch latency
- Cache hit/miss ratio
- Subscription churn rate

## Support

For issues or questions:
- GitHub Issues: [ka-social-platform/issues](https://github.com/mohamedaseleim/ka-social-platform/issues)
- Email: support@ka.com
