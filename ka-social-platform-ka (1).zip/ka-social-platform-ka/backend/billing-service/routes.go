package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes sets up the routes for the billing service
func SetupRoutes(router *gin.Engine, handler *Handler, jwtSecret string) {
	// Public routes
	api := router.Group("/api/v1")
	{
		// Webhook endpoint (no auth)
		api.POST("/billing/webhook", handler.HandleWebhook)
	}

	// Protected routes (require JWT)
	protected := api.Group("/billing")
	protected.Use(middleware.AuthMiddleware(jwtSecret))
	{
		protected.POST("/checkout", handler.CreateCheckoutSession)
		protected.GET("/subscription", handler.GetUserSubscription)
	}

	// Internal routes (no auth, should be protected by network/firewall)
	internal := router.Group("/api/internal/billing")
	{
		internal.GET("/entitlements/:userId", handler.GetUserEntitlements)
	}
}
