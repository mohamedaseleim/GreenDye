package main

import (
	"context"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/stripe/stripe-go/v79"
	"github.com/stripe/stripe-go/v79/checkout/session"
	"github.com/stripe/stripe-go/v79/customer"
	"github.com/stripe/stripe-go/v79/webhook"
)

// Handler handles HTTP requests for billing
type Handler struct {
	repo   *Repository
	config *Config
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	// Initialize Stripe
	stripe.Key = config.StripeSecretKey
	
	return &Handler{
		repo:   repo,
		config: config,
	}
}

// CreateCheckoutSession creates a Stripe Checkout session
func (h *Handler) CreateCheckoutSession(c *gin.Context) {
	// Get user ID from JWT
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_REQUIRED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	var req CheckoutSessionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Check if user already has an active subscription
	existingSub, err := h.repo.GetSubscriptionByUserID(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to check existing subscription",
			nil,
		))
		return
	}

	if existingSub != nil && existingSub.Status == SubscriptionStatusActive {
		c.JSON(http.StatusConflict, models.ErrorResponse(
			"SUBSCRIPTION_EXISTS",
			"User already has an active subscription",
			nil,
		))
		return
	}

	// Create or retrieve Stripe customer
	var stripeCustomerID string
	if existingSub != nil && existingSub.StripeCustomerID != "" {
		stripeCustomerID = existingSub.StripeCustomerID
	} else {
		// Create new customer
		customerParams := &stripe.CustomerParams{
			Metadata: map[string]string{
				"user_id": userID.String(),
			},
		}
		cust, err := customer.New(customerParams)
		if err != nil {
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"STRIPE_ERROR",
				"Failed to create customer",
				err.Error(),
			))
			return
		}
		stripeCustomerID = cust.ID
	}

	// Create checkout session
	params := &stripe.CheckoutSessionParams{
		Customer: stripe.String(stripeCustomerID),
		Mode:     stripe.String(string(stripe.CheckoutSessionModeSubscription)),
		LineItems: []*stripe.CheckoutSessionLineItemParams{
			{
				Price:    stripe.String(h.config.StripePriceID),
				Quantity: stripe.Int64(1),
			},
		},
		SuccessURL: stripe.String(req.SuccessURL),
		CancelURL:  stripe.String(req.CancelURL),
		Metadata: map[string]string{
			"user_id": userID.String(),
		},
	}

	sess, err := session.New(params)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"STRIPE_ERROR",
			"Failed to create checkout session",
			err.Error(),
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		CheckoutSessionResponse{
			SessionID:  sess.ID,
			SessionURL: sess.URL,
		},
		"Checkout session created successfully",
	))
}

// GetUserSubscription gets the current user's subscription
func (h *Handler) GetUserSubscription(c *gin.Context) {
	// Get user ID from JWT
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_REQUIRED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	sub, err := h.repo.GetSubscriptionByUserID(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to get subscription",
			nil,
		))
		return
	}

	if sub == nil {
		c.JSON(http.StatusOK, models.SuccessResponse(
			nil,
			"No active subscription",
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		sub,
		"Subscription retrieved successfully",
	))
}

// GetUserEntitlements gets the current user's entitlements (internal endpoint)
func (h *Handler) GetUserEntitlements(c *gin.Context) {
	userIDStr := c.Param("userId")
	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	ctx := context.Background()

	// Try cache first
	cached, err := h.repo.GetCachedEntitlements(ctx, userID)
	if err == nil && len(cached) > 0 {
		c.JSON(http.StatusOK, models.SuccessResponse(
			EntitlementsResponse{
				UserID:       userID,
				Entitlements: cached,
			},
			"Entitlements retrieved from cache",
		))
		return
	}

	// Get from database
	entitlements, err := h.repo.GetUserEntitlements(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to get entitlements",
			nil,
		))
		return
	}

	// Cache the result
	if err := h.repo.CacheEntitlements(ctx, userID, entitlements); err != nil {
		log.Printf("Warning: Failed to cache entitlements: %v", err)
	}

	// Get subscription info
	sub, _ := h.repo.GetSubscriptionByUserID(userID)

	c.JSON(http.StatusOK, models.SuccessResponse(
		EntitlementsResponse{
			UserID:       userID,
			Entitlements: entitlements,
			Subscription: sub,
		},
		"Entitlements retrieved successfully",
	))
}

// HandleWebhook handles Stripe webhook events
func (h *Handler) HandleWebhook(c *gin.Context) {
	payload, err := io.ReadAll(c.Request.Body)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_PAYLOAD",
			"Error reading request body",
			nil,
		))
		return
	}

	event, err := webhook.ConstructEvent(
		payload,
		c.GetHeader("Stripe-Signature"),
		h.config.StripeWebhookKey,
	)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_SIGNATURE",
			"Invalid webhook signature",
			err.Error(),
		))
		return
	}

	// Handle the event
	switch event.Type {
	case "checkout.session.completed":
		h.handleCheckoutCompleted(event)
	case "customer.subscription.created":
		h.handleSubscriptionCreated(event)
	case "customer.subscription.updated":
		h.handleSubscriptionUpdated(event)
	case "customer.subscription.deleted":
		h.handleSubscriptionDeleted(event)
	default:
		log.Printf("Unhandled webhook event type: %s", event.Type)
	}

	c.JSON(http.StatusOK, gin.H{"received": true})
}

// handleCheckoutCompleted handles checkout.session.completed webhook
func (h *Handler) handleCheckoutCompleted(event stripe.Event) {
	var session stripe.CheckoutSession
	if err := json.Unmarshal(event.Data.Raw, &session); err != nil {
		log.Printf("Error unmarshaling session: %v", err)
		return
	}

	userIDStr := session.Metadata["user_id"]
	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		log.Printf("Invalid user ID in metadata: %s", userIDStr)
		return
	}

	log.Printf("Checkout completed for user %s, subscription %s", userID, session.Subscription.ID)
}

// handleSubscriptionCreated handles customer.subscription.created webhook
func (h *Handler) handleSubscriptionCreated(event stripe.Event) {
	var stripeSub stripe.Subscription
	if err := json.Unmarshal(event.Data.Raw, &stripeSub); err != nil {
		log.Printf("Error unmarshaling subscription: %v", err)
		return
	}

	userIDStr := stripeSub.Metadata["user_id"]
	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		log.Printf("Invalid user ID in metadata: %s", userIDStr)
		return
	}

	// Create subscription in database
	sub := &Subscription{
		ID:                   uuid.New(),
		UserID:               userID,
		StripeCustomerID:     stripeSub.Customer.ID,
		StripeSubscriptionID: stripeSub.ID,
		Status:               string(stripeSub.Status),
		CurrentPeriodStart:   time.Unix(stripeSub.CurrentPeriodStart, 0),
		CurrentPeriodEnd:     time.Unix(stripeSub.CurrentPeriodEnd, 0),
		CancelAtPeriodEnd:    stripeSub.CancelAtPeriodEnd,
		CreatedAt:            time.Now(),
		UpdatedAt:            time.Now(),
	}

	if err := h.repo.CreateSubscription(sub); err != nil {
		log.Printf("Error creating subscription: %v", err)
		return
	}

	// Grant entitlements
	if stripeSub.Status == stripe.SubscriptionStatusActive || stripeSub.Status == stripe.SubscriptionStatusTrialing {
		h.grantKaPlusEntitlements(userID, &sub.CurrentPeriodEnd)
		h.publishSubscriptionActivated(userID)
	}

	log.Printf("Subscription created for user %s", userID)
}

// handleSubscriptionUpdated handles customer.subscription.updated webhook
func (h *Handler) handleSubscriptionUpdated(event stripe.Event) {
	var stripeSub stripe.Subscription
	if err := json.Unmarshal(event.Data.Raw, &stripeSub); err != nil {
		log.Printf("Error unmarshaling subscription: %v", err)
		return
	}

	// Get existing subscription
	existingSub, err := h.repo.GetSubscriptionByStripeID(stripeSub.ID)
	if err != nil || existingSub == nil {
		log.Printf("Subscription not found: %s", stripeSub.ID)
		return
	}

	// Update subscription
	existingSub.Status = string(stripeSub.Status)
	existingSub.CurrentPeriodStart = time.Unix(stripeSub.CurrentPeriodStart, 0)
	existingSub.CurrentPeriodEnd = time.Unix(stripeSub.CurrentPeriodEnd, 0)
	existingSub.CancelAtPeriodEnd = stripeSub.CancelAtPeriodEnd
	existingSub.UpdatedAt = time.Now()

	if stripeSub.CanceledAt != 0 {
		canceledAt := time.Unix(stripeSub.CanceledAt, 0)
		existingSub.CanceledAt = &canceledAt
	}

	if err := h.repo.UpdateSubscription(existingSub); err != nil {
		log.Printf("Error updating subscription: %v", err)
		return
	}

	// Update entitlements based on status
	if stripeSub.Status == stripe.SubscriptionStatusActive || stripeSub.Status == stripe.SubscriptionStatusTrialing {
		h.grantKaPlusEntitlements(existingSub.UserID, &existingSub.CurrentPeriodEnd)
		h.publishSubscriptionActivated(existingSub.UserID)
	} else {
		h.revokeKaPlusEntitlements(existingSub.UserID)
		h.publishSubscriptionCanceled(existingSub.UserID)
	}

	log.Printf("Subscription updated for user %s", existingSub.UserID)
}

// handleSubscriptionDeleted handles customer.subscription.deleted webhook
func (h *Handler) handleSubscriptionDeleted(event stripe.Event) {
	var stripeSub stripe.Subscription
	if err := json.Unmarshal(event.Data.Raw, &stripeSub); err != nil {
		log.Printf("Error unmarshaling subscription: %v", err)
		return
	}

	// Get existing subscription
	existingSub, err := h.repo.GetSubscriptionByStripeID(stripeSub.ID)
	if err != nil || existingSub == nil {
		log.Printf("Subscription not found: %s", stripeSub.ID)
		return
	}

	// Update subscription status
	existingSub.Status = SubscriptionStatusCanceled
	existingSub.UpdatedAt = time.Now()
	now := time.Now()
	existingSub.CanceledAt = &now

	if err := h.repo.UpdateSubscription(existingSub); err != nil {
		log.Printf("Error updating subscription: %v", err)
		return
	}

	// Revoke all entitlements
	h.revokeKaPlusEntitlements(existingSub.UserID)
	h.publishSubscriptionCanceled(existingSub.UserID)

	log.Printf("Subscription deleted for user %s", existingSub.UserID)
}

// grantKaPlusEntitlements grants all Ka+ entitlements to a user
func (h *Handler) grantKaPlusEntitlements(userID uuid.UUID, expiresAt *time.Time) {
	ctx := context.Background()
	
	entitlements := []string{
		EntitlementProfileBadge,
		EntitlementExtendedUploads,
		EntitlementAdvancedAnalytics,
	}

	for _, feature := range entitlements {
		if err := h.repo.GrantEntitlement(userID, feature, expiresAt); err != nil {
			log.Printf("Error granting entitlement %s to user %s: %v", feature, userID, err)
		}
	}

	// Invalidate cache
	h.repo.InvalidateEntitlementsCache(ctx, userID)
}

// revokeKaPlusEntitlements revokes all Ka+ entitlements from a user
func (h *Handler) revokeKaPlusEntitlements(userID uuid.UUID) {
	ctx := context.Background()
	
	entitlements := []string{
		EntitlementProfileBadge,
		EntitlementExtendedUploads,
		EntitlementAdvancedAnalytics,
	}

	for _, feature := range entitlements {
		if err := h.repo.RevokeEntitlement(userID, feature); err != nil {
			log.Printf("Error revoking entitlement %s from user %s: %v", feature, userID, err)
		}
	}

	// Invalidate cache
	h.repo.InvalidateEntitlementsCache(ctx, userID)
}

// publishSubscriptionActivated publishes a subscription.activated event
func (h *Handler) publishSubscriptionActivated(userID uuid.UUID) {
	if h.config.NATSConn == nil {
		return
	}

	event := map[string]interface{}{
		"user_id":   userID.String(),
		"event":     "subscription.activated",
		"timestamp": time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		log.Printf("Warning: Failed to marshal subscription.activated event: %v", err)
		return
	}

	if err := h.config.NATSConn.Publish("subscription.activated", data); err != nil {
		log.Printf("Warning: Failed to publish subscription.activated event: %v", err)
	} else {
		log.Printf("Published subscription.activated event for user %s", userID)
	}
}

// publishSubscriptionCanceled publishes a subscription.canceled event
func (h *Handler) publishSubscriptionCanceled(userID uuid.UUID) {
	if h.config.NATSConn == nil {
		return
	}

	event := map[string]interface{}{
		"user_id":   userID.String(),
		"event":     "subscription.canceled",
		"timestamp": time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		log.Printf("Warning: Failed to marshal subscription.canceled event: %v", err)
		return
	}

	if err := h.config.NATSConn.Publish("subscription.canceled", data); err != nil {
		log.Printf("Warning: Failed to publish subscription.canceled event: %v", err)
	} else {
		log.Printf("Published subscription.canceled event for user %s", userID)
	}
}
