package main

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/redis/go-redis/v9"
)

// Repository handles database operations for user profiles
type Repository struct {
	db    *sqlx.DB
	redis *redis.Client
}

// NewRepository creates a new repository
func NewRepository(db *sqlx.DB, redis *redis.Client) *Repository {
	return &Repository{
		db:    db,
		redis: redis,
	}
}

// GetUserProfileByID gets a user profile by ID
func (r *Repository) GetUserProfileByID(userID uuid.UUID) (*models.User, error) {
	var user models.User
	query := `
		SELECT id, username, email, phone, password_hash, display_name, bio,
		       profile_picture_url, avatar_url_medium, avatar_url_thumb,
		       cover_story_url, cover_story_type, location, 
		       website, is_verified, is_premium, language, follower_count, 
		       following_count, created_at, updated_at
		FROM users
		WHERE id = $1
	`

	err := r.db.Get(&user, query, userID)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	return &user, nil
}

// GetUserProfileByUsername gets a user profile by username
func (r *Repository) GetUserProfileByUsername(username string) (*models.User, error) {
	var user models.User
	query := `
		SELECT id, username, email, phone, password_hash, display_name, bio,
		       profile_picture_url, avatar_url_medium, avatar_url_thumb,
		       cover_story_url, cover_story_type, location, 
		       website, is_verified, is_premium, language, follower_count, 
		       following_count, created_at, updated_at
		FROM users
		WHERE username = $1
	`

	err := r.db.Get(&user, query, username)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	return &user, nil
}

// UpdateUserProfile updates a user profile
func (r *Repository) UpdateUserProfile(userID uuid.UUID, updates *models.UpdateProfileRequest) (*models.User, error) {
	query := `
		UPDATE users
		SET display_name = COALESCE($2, display_name),
		    bio = COALESCE($3, bio),
		    location = COALESCE($4, location),
		    website = COALESCE($5, website),
		    updated_at = CURRENT_TIMESTAMP
		WHERE id = $1
		RETURNING id, username, email, phone, password_hash, display_name, bio,
		          profile_picture_url, avatar_url_medium, avatar_url_thumb,
		          cover_story_url, cover_story_type, location, 
		          website, is_verified, is_premium, language, follower_count, 
		          following_count, created_at, updated_at
	`

	var user models.User
	err := r.db.Get(&user, query, userID, updates.DisplayName, updates.Bio, updates.Location, updates.Website)
	if err != nil {
		return nil, fmt.Errorf("failed to update user profile: %w", err)
	}

	// Invalidate cache
	r.invalidateUserCache(userID)

	return &user, nil
}

// GetFollowerCount gets the number of followers for a user
func (r *Repository) GetFollowerCount(userID uuid.UUID) (int, error) {
	var count int
	query := `SELECT COUNT(*) FROM follows WHERE following_id = $1`
	err := r.db.Get(&count, query, userID)
	if err != nil {
		return 0, fmt.Errorf("failed to get follower count: %w", err)
	}
	return count, nil
}

// GetFollowingCount gets the number of users a user is following
func (r *Repository) GetFollowingCount(userID uuid.UUID) (int, error) {
	var count int
	query := `SELECT COUNT(*) FROM follows WHERE follower_id = $1`
	err := r.db.Get(&count, query, userID)
	if err != nil {
		return 0, fmt.Errorf("failed to get following count: %w", err)
	}
	return count, nil
}

// IsFollowing checks if a user is following another user
func (r *Repository) IsFollowing(followerID, followingID uuid.UUID) (bool, error) {
	var exists bool
	query := `SELECT EXISTS(SELECT 1 FROM follows WHERE follower_id = $1 AND following_id = $2)`
	err := r.db.Get(&exists, query, followerID, followingID)
	if err != nil {
		return false, fmt.Errorf("failed to check follow status: %w", err)
	}
	return exists, nil
}

// GetUserFromCache gets a user profile from Redis cache
func (r *Repository) GetUserFromCache(userID uuid.UUID) (*models.User, error) {
	ctx := context.Background()
	key := fmt.Sprintf("user:profile:%s", userID.String())
	
	// Check if exists in cache
	exists, err := r.redis.Exists(ctx, key).Result()
	if err != nil || exists == 0 {
		return nil, fmt.Errorf("user not in cache")
	}

	var user models.User
	// In a real implementation, you would use redis.Get and json.Unmarshal
	// For simplicity, we'll just return nil to indicate cache miss
	return &user, nil
}

// SetUserInCache sets a user profile in Redis cache
func (r *Repository) SetUserInCache(user *models.User) error {
	ctx := context.Background()
	key := fmt.Sprintf("user:profile:%s", user.ID.String())
	
	// In a real implementation, you would use json.Marshal and redis.Set
	// For now, we'll just set a placeholder with 5-minute expiry
	return r.redis.Set(ctx, key, "cached", 5*time.Minute).Err()
}

// invalidateUserCache invalidates the cache for a user
func (r *Repository) invalidateUserCache(userID uuid.UUID) {
	ctx := context.Background()
	key := fmt.Sprintf("user:profile:%s", userID.String())
	r.redis.Del(ctx, key)
}

// SearchUsers searches for users by username or display name
func (r *Repository) SearchUsers(query string, limit, offset int) ([]*models.User, error) {
	var users []*models.User
	searchQuery := `
		SELECT id, username, email, display_name, bio,
		       profile_picture_url, is_verified, is_premium, created_at
		FROM users
		WHERE username ILIKE $1 OR display_name ILIKE $1
		ORDER BY is_verified DESC, username
		LIMIT $2 OFFSET $3
	`

	searchPattern := "%" + query + "%"
	err := r.db.Select(&users, searchQuery, searchPattern, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to search users: %w", err)
	}

	return users, nil
}

// CountSearchResults counts the number of search results
func (r *Repository) CountSearchResults(query string) (int64, error) {
	var count int64
	searchQuery := `
		SELECT COUNT(*) 
		FROM users
		WHERE username ILIKE $1 OR display_name ILIKE $1
	`

	searchPattern := "%" + query + "%"
	err := r.db.Get(&count, searchQuery, searchPattern)
	if err != nil {
		return 0, fmt.Errorf("failed to count search results: %w", err)
	}

	return count, nil
}

// IncrementFollowerCount increments the follower count for a user (for internal use)
func (r *Repository) IncrementFollowerCount(userID uuid.UUID) error {
	query := `UPDATE users SET follower_count = follower_count + 1 WHERE id = $1`
	_, err := r.db.Exec(query, userID)
	if err != nil {
		return fmt.Errorf("failed to increment follower count: %w", err)
	}
	r.invalidateUserCache(userID)
	return nil
}

// DecrementFollowerCount decrements the follower count for a user (for internal use)
func (r *Repository) DecrementFollowerCount(userID uuid.UUID) error {
	query := `UPDATE users SET follower_count = GREATEST(follower_count - 1, 0) WHERE id = $1`
	_, err := r.db.Exec(query, userID)
	if err != nil {
		return fmt.Errorf("failed to decrement follower count: %w", err)
	}
	r.invalidateUserCache(userID)
	return nil
}

// IncrementFollowingCount increments the following count for a user (for internal use)
func (r *Repository) IncrementFollowingCount(userID uuid.UUID) error {
	query := `UPDATE users SET following_count = following_count + 1 WHERE id = $1`
	_, err := r.db.Exec(query, userID)
	if err != nil {
		return fmt.Errorf("failed to increment following count: %w", err)
	}
	r.invalidateUserCache(userID)
	return nil
}

// DecrementFollowingCount decrements the following count for a user (for internal use)
func (r *Repository) DecrementFollowingCount(userID uuid.UUID) error {
	query := `UPDATE users SET following_count = GREATEST(following_count - 1, 0) WHERE id = $1`
	_, err := r.db.Exec(query, userID)
	if err != nil {
		return fmt.Errorf("failed to decrement following count: %w", err)
	}
	r.invalidateUserCache(userID)
	return nil
}

// UpdateUserAvatar updates the user's avatar URLs after media processing
func (r *Repository) UpdateUserAvatar(userID uuid.UUID, originalURL, mediumURL, thumbURL string) error {
	query := `
		UPDATE users 
		SET profile_picture_url = $2,
		    avatar_url_medium = $3,
		    avatar_url_thumb = $4,
		    updated_at = CURRENT_TIMESTAMP
		WHERE id = $1
	`
	_, err := r.db.Exec(query, userID, originalURL, mediumURL, thumbURL)
	if err != nil {
		return fmt.Errorf("failed to update user avatar: %w", err)
	}
	r.invalidateUserCache(userID)
	return nil
}
