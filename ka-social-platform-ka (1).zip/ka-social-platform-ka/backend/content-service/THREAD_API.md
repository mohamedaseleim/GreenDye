# Conversation Thread API

The Content Service provides a high-performance, context-aware Conversation Thread API for retrieving and navigating echo threads.

## Features

- **Complete Thread View**: Ancestors, focus echo, and replies in a single request
- **Context Enrichment**: Each echo includes viewer-specific context (is_liked, is_followed)
- **Cursor-Based Pagination**: Efficient pagination for large reply sets
- **Graceful Degradation**: Handles deleted echoes and blocked users
- **Batch Optimization**: Single batch call to Engagement and Interaction services

## Endpoints

### GET /api/v1/echoes/{echoId}/thread

Retrieve a complete conversation thread including ancestors, focus echo, and replies.

**Authentication**: Required (Bearer token)

**Response**:
```json
{
  "success": true,
  "data": {
    "ancestors": [
      {
        "id": "root-echo-uuid",
        "user_id": "author-uuid",
        "content": "Original echo that started the thread",
        "is_liked_by_viewer": true,
        "author": {
          "user_id": "author-uuid",
          "is_followed_by_viewer": false
        },
        "like_count": 42,
        "created_at": "2024-01-01T12:00:00Z",
        ...
      },
      {
        "id": "parent-echo-uuid",
        "user_id": "author-uuid",
        "content": "Reply to the original echo",
        "is_liked_by_viewer": false,
        "author": {
          "user_id": "author-uuid",
          "is_followed_by_viewer": true
        },
        "like_count": 15,
        "created_at": "2024-01-01T12:30:00Z",
        ...
      }
    ],
    "focus": {
      "id": "focus-echo-uuid",
      "user_id": "author-uuid",
      "content": "The echo you requested (focus of the thread view)",
      "is_liked_by_viewer": false,
      "author": {
        "user_id": "author-uuid",
        "is_followed_by_viewer": true
      },
      "like_count": 8,
      "reply_count": 25,
      "created_at": "2024-01-01T13:00:00Z",
      ...
    },
    "replies": [
      {
        "id": "reply-1-uuid",
        "user_id": "author-uuid",
        "content": "First reply to the focus echo",
        "is_liked_by_viewer": true,
        "author": {
          "user_id": "author-uuid",
          "is_followed_by_viewer": false
        },
        "like_count": 3,
        "created_at": "2024-01-01T13:15:00Z",
        ...
      }
    ],
    "next_cursor": "eyJ0cyI6IjIwMjQtMDEtMDFUMTM6MTU6MDAuMDAwWiIsImlkIjoicmVwbHktMjAtdXVpZCJ9"
  },
  "message": "Thread retrieved successfully"
}
```

**Structure**:
- `ancestors`: Array of echoes from root to focus (oldest first)
- `focus`: The requested echo
- `replies`: First 20 direct replies to focus echo (newest first)
- `next_cursor`: Pagination cursor for fetching more replies (null if no more)

**Edge Cases**:

1. **Deleted Echo in Ancestors**:
```json
{
  "id": "deleted-echo-uuid",
  "status": "deleted",
  "author": {
    "user_id": "00000000-0000-0000-0000-000000000000",
    "is_followed_by_viewer": false
  }
}
```

2. **Blocked User**:
```json
{
  "id": "blocked-echo-uuid",
  "status": "blocked",
  "author": {
    "user_id": "00000000-0000-0000-0000-000000000000",
    "is_followed_by_viewer": false
  }
}
```

### GET /api/v1/echoes/{echoId}/replies

Retrieve paginated replies to an echo.

**Authentication**: Required (Bearer token)

**Query Parameters**:
- `cursor` (optional): Pagination cursor from previous response
- `limit` (optional): Number of replies to return (default: 20, max: 100)

**Response**:
```json
{
  "success": true,
  "data": {
    "replies": [
      {
        "id": "reply-uuid",
        "user_id": "author-uuid",
        "content": "Reply content",
        "is_liked_by_viewer": false,
        "author": {
          "user_id": "author-uuid",
          "is_followed_by_viewer": true
        },
        "like_count": 5,
        "created_at": "2024-01-01T14:00:00Z",
        ...
      }
    ],
    "next_cursor": "eyJ0cyI6IjIwMjQtMDEtMDFUMTQ6MDA6MDAuMDAwWiIsImlkIjoicmVwbHktdXVpZCJ9"
  },
  "message": "Replies retrieved successfully"
}
```

## Context Enrichment

Each echo in the response is enriched with viewer-specific context:

### is_liked_by_viewer
- **Type**: boolean
- **Source**: Engagement Service (POST /api/internal/likes/batch-status)
- **Description**: True if the authenticated user has liked this echo
- **Fallback**: false (if Engagement Service unavailable)

### author.is_followed_by_viewer
- **Type**: boolean
- **Source**: Interaction Service (POST /api/internal/follows/batch-status)
- **Description**: True if the authenticated user follows the echo's author
- **Fallback**: false (if Interaction Service unavailable)

**Optimization**: Both statuses are fetched in a single batch call per service, reducing network overhead.

## Pagination

The API uses **cursor-based pagination** (not offset-based) for consistency and performance.

### Cursor Structure
```json
{
  "ts": "2024-01-01T14:00:00.000Z",
  "id": "last-reply-uuid"
}
```

The cursor is Base64-encoded and includes:
- `ts`: Timestamp of the last reply (for ordering)
- `id`: ID of the last reply (for tie-breaking)

### Usage
1. First page: Call without `cursor` parameter
2. Subsequent pages: Use `next_cursor` from previous response
3. End of list: `next_cursor` is null or empty

### Example
```bash
# First page
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8003/api/v1/echoes/abc123/replies?limit=20"

# Second page
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8003/api/v1/echoes/abc123/replies?cursor=eyJ0c...&limit=20"
```

## Performance Characteristics

### Thread Endpoint
- **Ancestor Chain**: O(D) queries where D = depth (typically 1-3)
- **Replies**: O(1) query (indexed by parent_echo_id)
- **Context Enrichment**: 2 batch calls (Engagement + Interaction)
- **Typical Latency**: 50-150ms

### Replies Endpoint
- **Query**: O(1) with cursor (indexed)
- **Context Enrichment**: 2 batch calls
- **Typical Latency**: 30-80ms

### Optimizations
- **Batch Calls**: Single call per service (not N calls)
- **Redis Caching**: Services cache results with 5-minute TTL
- **Index Usage**: ScyllaDB indexes on parent_echo_id and created_at
- **Graceful Degradation**: Continues even if enrichment fails

## Error Responses

### 401 Unauthorized
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "User not authenticated"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": {
    "code": "ECHO_NOT_FOUND",
    "message": "Echo not found"
  }
}
```

### 400 Bad Request
```json
{
  "success": false,
  "error": {
    "code": "INVALID_CURSOR",
    "message": "Invalid cursor format"
  }
}
```

## Data Model

The thread system uses an **Adjacency List** model:

```cql
CREATE TABLE echoes (
    id UUID PRIMARY KEY,
    user_id UUID,
    content TEXT,
    parent_echo_id UUID,  -- NULL for root, UUID for replies
    created_at TIMESTAMP,
    ...
);

CREATE INDEX ON echoes (parent_echo_id);
```

**Why Adjacency List?**
- Simple writes (single parent reference)
- Flexible for editing/deleting
- Natural fit for our read patterns (direct replies, ancestor chains)
- Most threads are shallow (1-3 levels)

See [ARCHITECTURE.md](../../docs/ARCHITECTURE.md) for detailed discussion of data modeling choices.

## Trust & Safety

The API respects user blocking and content deletion:

1. **Blocked Users**: Echoes from users who blocked you or whom you blocked are replaced with placeholders
2. **Deleted Echoes**: Deleted echoes in the ancestor chain are replaced with placeholders
3. **Privacy**: Placeholders don't leak information about blocked users

**Implementation**: Uses Trust & Safety client with Redis caching for sub-millisecond checks.

## Testing

### Manual Testing
```bash
# Create a thread
TOKEN=$(curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}' | jq -r '.data.access_token')

# Create root echo
ROOT_ID=$(curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content":"Root echo","visibility":"public"}' | jq -r '.data.id')

# Create reply
REPLY_ID=$(curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"content\":\"Reply\",\"parent_echo_id\":\"$ROOT_ID\",\"visibility\":\"public\"}" | jq -r '.data.id')

# Get thread
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8003/api/v1/echoes/$REPLY_ID/thread" | jq

# Get replies
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8003/api/v1/echoes/$ROOT_ID/replies" | jq
```

## Future Enhancements

1. **Nested Replies**: Expand replies to show their sub-replies
2. **Thread Caching**: Cache entire thread structures in Redis
3. **Reply Counts**: Denormalized reply counts for "View N replies" UI
4. **Hot Threads**: Pre-compute popular thread structures
5. **Parallel Ancestor Fetching**: Batch fetch ancestors instead of iterative

## Related Documentation

- [ARCHITECTURE.md](../../docs/ARCHITECTURE.md) - Conversation Thread Architecture section
- [Content Service README](README.md) - Main service documentation
- [API Specification](../../docs/API_SPEC.md) - Complete API documentation
