package main

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/utils"
)

// Handler handles HTTP requests for user profiles
type Handler struct {
	repo   *Repository
	config *Config
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	return &Handler{
		repo:   repo,
		config: config,
	}
}

// GetCurrentUserProfile gets the authenticated user's own profile (private data)
func (h *Handler) GetCurrentUserProfile(c *gin.Context) {
	// Get user ID from context (set by auth middleware)
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get user profile from database
	user, err := h.repo.GetUserProfileByID(userID)
	if err != nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"User not found",
			nil,
		))
		return
	}

	// Remove sensitive data before sending
	user.PasswordHash = ""

	c.JSON(http.StatusOK, models.SuccessResponse(
		user,
		"Profile retrieved successfully",
	))
}

// UpdateCurrentUserProfile updates the authenticated user's profile
func (h *Handler) UpdateCurrentUserProfile(c *gin.Context) {
	// Get user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	var req models.UpdateProfileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Update user profile
	user, err := h.repo.UpdateUserProfile(userID, &req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to update profile",
			err.Error(),
		))
		return
	}

	// Publish user.updated event to NATS
	if h.config.NATSConn != nil {
		h.publishUserUpdatedEvent(user)
	}

	// Remove sensitive data
	user.PasswordHash = ""

	c.JSON(http.StatusOK, models.SuccessResponse(
		user,
		"Profile updated successfully",
	))
}

// GetUserProfileByUsername gets a public user profile by username
func (h *Handler) GetUserProfileByUsername(c *gin.Context) {
	username := c.Param("username")

	// Get user profile from database
	user, err := h.repo.GetUserProfileByUsername(username)
	if err != nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"User not found",
			nil,
		))
		return
	}

	// Build user profile response with additional data
	profile := h.buildUserProfile(user, c)

	c.JSON(http.StatusOK, models.SuccessResponse(
		profile,
		"Profile retrieved successfully",
	))
}

// GetUserProfileByID gets a public user profile by ID
func (h *Handler) GetUserProfileByID(c *gin.Context) {
	userIDParam := c.Param("id")
	userID, err := uuid.Parse(userIDParam)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID format",
			nil,
		))
		return
	}

	// Get user profile from database
	user, err := h.repo.GetUserProfileByID(userID)
	if err != nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"User not found",
			nil,
		))
		return
	}

	// Build user profile response with additional data
	profile := h.buildUserProfile(user, c)

	c.JSON(http.StatusOK, models.SuccessResponse(
		profile,
		"Profile retrieved successfully",
	))
}

// SearchUsers searches for users by username or display name
func (h *Handler) SearchUsers(c *gin.Context) {
	query := c.Query("q")
	if query == "" {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Search query is required",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Search users
	users, err := h.repo.SearchUsers(query, perPage, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to search users",
			err.Error(),
		))
		return
	}

	// Get total count
	total, err := h.repo.CountSearchResults(query)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to count results",
			err.Error(),
		))
		return
	}

	// Build response with pagination
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(users, pagination))
}

// buildUserProfile builds a complete user profile with counts and relationship info
func (h *Handler) buildUserProfile(user *models.User, c *gin.Context) *models.UserProfile {
	// Remove sensitive data
	user.PasswordHash = ""
	user.Email = "" // Email is private
	user.Phone = nil

	profile := &models.UserProfile{
		User: *user,
	}

	// Counts are now part of the user model (denormalized)
	profile.FollowerCount = user.FollowerCount
	profile.FollowingCount = user.FollowingCount

	// Check if current user is following this user
	currentUserIDStr, exists := c.Get("user_id")
	if exists {
		currentUserID, err := uuid.Parse(currentUserIDStr.(string))
		if err == nil && currentUserID != user.ID {
			isFollowing, err := h.repo.IsFollowing(currentUserID, user.ID)
			if err == nil {
				profile.IsFollowing = isFollowing
			}

			isFollowedBy, err := h.repo.IsFollowing(user.ID, currentUserID)
			if err == nil {
				profile.IsFollowedBy = isFollowedBy
			}
		}
	}

	// Post counts would be fetched from content service in a real implementation
	// For now, we'll set them to 0
	profile.EchoCount = 0
	profile.StoryCount = 0

	// Check for Ka+ entitlements - query on the profile owner
	profile.HasKaPlus = h.hasKaPlusBadge(user.ID, c)

	return profile
}

// UpdateFollowCounts updates follower/following counts (internal endpoint for Interaction Service)
func (h *Handler) UpdateFollowCounts(c *gin.Context) {
	var req struct {
		FollowerUserID  string `json:"follower_user_id" binding:"required"`
		FollowingUserID string `json:"following_user_id" binding:"required"`
		Action          string `json:"action" binding:"required,oneof=follow unfollow"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	followerID, err := uuid.Parse(req.FollowerUserID)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid follower user ID",
			nil,
		))
		return
	}

	followingID, err := uuid.Parse(req.FollowingUserID)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid following user ID",
			nil,
		))
		return
	}

	// Update counts based on action
	if req.Action == "follow" {
		// Increment follower count for the user being followed
		if err := h.repo.IncrementFollowerCount(followingID); err != nil {
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"SERVER_ERROR",
				"Failed to update follower count",
				err.Error(),
			))
			return
		}

		// Increment following count for the follower
		if err := h.repo.IncrementFollowingCount(followerID); err != nil {
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"SERVER_ERROR",
				"Failed to update following count",
				err.Error(),
			))
			return
		}
	} else if req.Action == "unfollow" {
		// Decrement follower count for the user being unfollowed
		if err := h.repo.DecrementFollowerCount(followingID); err != nil {
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"SERVER_ERROR",
				"Failed to update follower count",
				err.Error(),
			))
			return
		}

		// Decrement following count for the unfollower
		if err := h.repo.DecrementFollowingCount(followerID); err != nil {
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"SERVER_ERROR",
				"Failed to update following count",
				err.Error(),
			))
			return
		}
	}

	// Publish user.updated event for the followed/unfollowed user (to update their follower count in search)
	if h.config.NATSConn != nil {
		user, err := h.repo.GetUserProfileByID(followingID)
		if err == nil {
			h.publishUserUpdatedEvent(user)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		nil,
		"Follow counts updated successfully",
	))
}

// publishUserUpdatedEvent publishes a user.updated event to NATS
func (h *Handler) publishUserUpdatedEvent(user *models.User) {
	event := map[string]interface{}{
		"user_id":             user.ID.String(),
		"username":            user.Username,
		"display_name":        user.DisplayName,
		"bio":                 user.Bio,
		"profile_picture_url": user.ProfilePictureURL,
		"is_verified":         user.IsVerified,
		"follower_count":      user.FollowerCount,
		"timestamp":           time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		log.Printf("Warning: Failed to marshal user.updated event: %v", err)
		return
	}

	if err := h.config.NATSConn.Publish("user.updated", data); err != nil {
		log.Printf("Warning: Failed to publish user.updated event: %v", err)
	} else {
		log.Printf("Published user.updated event for user %s", user.ID)
	}
}

// hasKaPlusBadge checks if a user has the PROFILE_BADGE entitlement
// This is done by checking if the user is viewing their own profile from the JWT
// or by fetching from billing service for other users
func (h *Handler) hasKaPlusBadge(profileUserID uuid.UUID, c *gin.Context) bool {
	// If the current user is viewing their own profile, use entitlements from JWT
	currentUserIDStr, exists := c.Get("user_id")
	if exists {
		currentUserID, err := uuid.Parse(currentUserIDStr.(string))
		if err == nil && currentUserID == profileUserID {
			// Same user - check JWT entitlements
			entitlements := utils.GetEntitlementsFromContext(c)
			return utils.HasEntitlement(entitlements, utils.EntitlementProfileBadge)
		}
	}

	// Different user - fetch from billing service
	// For performance, we could cache this, but for now we'll call the billing service
	// In production, you might want to cache this in Redis
	billingClient := utils.NewBillingClient(h.config.BillingServiceURL)
	entitlements, err := billingClient.GetUserEntitlements(c.Request.Context(), profileUserID)
	if err != nil {
		log.Printf("Warning: Failed to get entitlements for user %s: %v", profileUserID, err)
		return false
	}

	return utils.HasEntitlement(entitlements, utils.EntitlementProfileBadge)
}
