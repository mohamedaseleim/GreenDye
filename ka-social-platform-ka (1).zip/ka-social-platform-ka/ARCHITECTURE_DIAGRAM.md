# Ka Platform - Architecture Diagrams

Visual representations of the Ka Platform cloud-native architecture.

## Complete System Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                         DEVELOPER WORKFLOW                              │
│                                                                         │
│  ┌──────────┐    git push    ┌──────────────┐                         │
│  │Developer │──────────────▶ │   GitHub     │                         │
│  └──────────┘                 │  Repository  │                         │
│                               └──────┬───────┘                         │
└───────────────────────────────────────┼──────────────────────────────────┘
                                       │
                    ┌──────────────────┴──────────────────┐
                    │                                     │
                    ▼                                     ▼
        ┌─────────────────────┐              ┌─────────────────────┐
        │  GitHub Actions     │              │    Argo CD          │
        │      (CI/CD)        │              │   (GitOps)          │
        │                     │              │                     │
        │ • Build images      │              │ • Watch repo        │
        │ • Run tests         │◀─────────────│ • Auto sync         │
        │ • Security scan     │  Image tags  │ • Self-heal         │
        │ • Update values.yaml│              │ • Health check      │
        └─────────┬───────────┘              └─────────┬───────────┘
                  │                                    │
                  │ Push to GHCR                       │ Deploy
                  ▼                                    ▼
        ┌─────────────────────┐              ┌─────────────────────┐
        │  Container Registry │              │   Helm Charts       │
        │       (GHCR)        │              │                     │
        │                     │              │ • Parent chart      │
        │ auth-service:sha123 │              │ • API services      │
        │ user-service:sha123 │              │ • Databases         │
        │ content-service:... │              │                     │
        └─────────────────────┘              └─────────┬───────────┘
                                                       │
┌──────────────────────────────────────────────────────┼──────────────────┐
│                    CLOUD INFRASTRUCTURE               │                  │
│                                                       ▼                  │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                  Kubernetes Cluster (GKE/DOKS)                   │   │
│  │                                                                   │   │
│  │  ┌──────────────────────────────────────────────────────────┐   │   │
│  │  │                  ka-platform Namespace                    │   │   │
│  │  │                                                            │   │   │
│  │  │  ┌─────────────────  API Services  ─────────────────┐    │   │   │
│  │  │  │                                                   │    │   │   │
│  │  │  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐  │    │   │   │
│  │  │  │  │Auth  │ │User  │ │Content│ │Feed  │ │Media │  │    │   │   │
│  │  │  │  │Svc   │ │Svc   │ │ Svc  │ │ Svc  │ │ Svc  │  │    │   │   │
│  │  │  │  └──┬───┘ └──┬───┘ └──┬───┘ └──┬───┘ └──┬───┘  │    │   │   │
│  │  │  │     │        │        │        │        │       │    │   │   │
│  │  │  │  ┌──▼───┐ ┌─▼────┐ ┌─▼────┐ ┌─▼────┐ ┌──▼───┐ │    │   │   │
│  │  │  │  │Inter-│ │Engage│ │Disco-│ │Billing│ │  ... │ │    │   │   │
│  │  │  │  │action│ │-ment │ │-very │ │       │ │      │ │    │   │   │
│  │  │  │  └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ │    │   │   │
│  │  │  │                                                 │    │   │   │
│  │  │  │  All services expose:                          │    │   │   │
│  │  │  │  • /health endpoint                            │    │   │   │
│  │  │  │  • /metrics endpoint (Prometheus)              │    │   │   │
│  │  │  └─────────────────────────────────────────────────┘    │   │   │
│  │  │                                                          │   │   │
│  │  │  ┌─────────────────  Data Layer  ──────────────────┐   │   │   │
│  │  │  │                                                  │   │   │   │
│  │  │  │  ┌──────────┐  ┌────────┐  ┌──────────┐        │   │   │   │
│  │  │  │  │PostgreSQL│  │ Redis  │  │ ScyllaDB │        │   │   │   │
│  │  │  │  │          │  │        │  │          │        │   │   │   │
│  │  │  │  │ Users    │  │ Cache  │  │ Posts    │        │   │   │   │
│  │  │  │  │ Relations│  │Session │  │Timelines │        │   │   │   │
│  │  │  │  └──────────┘  └────────┘  └──────────┘        │   │   │   │
│  │  │  │                                                  │   │   │   │
│  │  │  │  ┌──────────┐  ┌────────┐  ┌──────────┐        │   │   │   │
│  │  │  │  │   NATS   │  │ MinIO  │  │Meili-    │        │   │   │   │
│  │  │  │  │          │  │        │  │search    │        │   │   │   │
│  │  │  │  │ Events   │  │ Media  │  │ Search   │        │   │   │   │
│  │  │  │  │ Messages │  │Objects │  │ Index    │        │   │   │   │
│  │  │  │  └──────────┘  └────────┘  └──────────┘        │   │   │   │
│  │  │  └──────────────────────────────────────────────────┘   │   │   │
│  │  │                                                          │   │   │
│  │  │  ┌───────────── Observability Stack ───────────────┐   │   │   │
│  │  │  │                                                  │   │   │   │
│  │  │  │  ┌──────────┐  ┌─────────┐  ┌─────────┐        │   │   │   │
│  │  │  │  │Prometheus│  │ Grafana │  │  Loki   │        │   │   │   │
│  │  │  │  │          │  │         │  │         │        │   │   │   │
│  │  │  │  │ Metrics  │◀─│Dashboard│◀─│  Logs   │        │   │   │   │
│  │  │  │  │ Scraping │  │Visualize│  │Aggregate│        │   │   │   │
│  │  │  │  └────▲─────┘  └─────────┘  └────▲────┘        │   │   │   │
│  │  │  │       │                           │             │   │   │   │
│  │  │  │       └─────metrics───────────────┘             │   │   │   │
│  │  │  │                                                  │   │   │   │
│  │  │  │  ┌──────────────────────────────────────┐       │   │   │   │
│  │  │  │  │         Promtail (DaemonSet)         │       │   │   │   │
│  │  │  │  │    Collects logs from all pods       │       │   │   │   │
│  │  │  │  └──────────────────────────────────────┘       │   │   │   │
│  │  │  └──────────────────────────────────────────────────┘   │   │   │
│  │  └──────────────────────────────────────────────────────────┘   │   │
│  │                                                                   │   │
│  │  ┌──────────────────────────────────────────────────────────┐   │   │
│  │  │                    argocd Namespace                       │   │   │
│  │  │  ┌────────┐  ┌──────────┐  ┌────────────────┐           │   │   │
│  │  │  │ Server │  │   Repo   │  │  Application   │           │   │   │
│  │  │  │   UI   │  │  Server  │  │  Controller    │           │   │   │
│  │  │  └────────┘  └──────────┘  └────────────────┘           │   │   │
│  │  └──────────────────────────────────────────────────────────┘   │   │
│  │                                                                   │   │
│  │  ┌──────────────  Ingress Controller (Nginx)  ────────────┐     │   │
│  │  │                                                          │     │   │
│  │  │  Routes:                                                │     │   │
│  │  │  api.ka-platform.io/auth    ──▶ auth-service          │     │   │
│  │  │  api.ka-platform.io/user    ──▶ user-service          │     │   │
│  │  │  api.ka-platform.io/content ──▶ content-service       │     │   │
│  │  │  ...                                                    │     │   │
│  │  └──────────────────────────────────────────────────────────┘     │   │
│  └───────────────────────────────────────────────────────────────────┘   │
│                                                                           │
│  ┌────────────────────  Cloud Provider Services  ─────────────────┐     │
│  │                                                                  │     │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │     │
│  │  │Load Balancer │  │ Managed DBs  │  │Block Storage │         │     │
│  │  │   (L4/L7)    │  │ (Optional)   │  │Persistent Vol│         │     │
│  │  └──────┬───────┘  └──────────────┘  └──────────────┘         │     │
│  │         │                                                       │     │
│  │         │ SSL/TLS                                              │     │
│  └─────────┼───────────────────────────────────────────────────────┘     │
└────────────┼─────────────────────────────────────────────────────────────┘
             │
             ▼
    ┌────────────────┐
    │   Internet     │
    │    Users       │
    └────────────────┘
```

---

## Data Flow Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                       REQUEST FLOW                                │
└──────────────────────────────────────────────────────────────────┘

User Request
    │
    ▼
┌─────────────────┐
│ Load Balancer   │ ◀── SSL/TLS termination, DDoS protection
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Ingress (Nginx) │ ◀── Path-based routing, rate limiting
└────────┬────────┘
         │
         ├──▶ /auth      ──▶ Auth Service
         ├──▶ /user      ──▶ User Service
         ├──▶ /content   ──▶ Content Service
         ├──▶ /feed      ──▶ Feed Service
         └──▶ /media     ──▶ Media Service
                               │
                               ▼
                      ┌─────────────────┐
                      │  Service Logic  │
                      └────────┬────────┘
                               │
                               ├──▶ PostgreSQL (ACID transactions)
                               ├──▶ Redis (Cache lookup)
                               ├──▶ ScyllaDB (High-throughput writes)
                               ├──▶ NATS (Publish events)
                               └──▶ Meilisearch (Search queries)
                                    │
                                    ▼
                               Response
```

---

## Event-Driven Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                    EVENT FLOW (NATS)                              │
└──────────────────────────────────────────────────────────────────┘

Content Service                Feed Service
     │                              │
     │  POST /posts                 │
     ├──▶ Create post               │
     │   in ScyllaDB                │
     │                              │
     ├──▶ Publish event             │
     │   "post.created"             │
     │        │                     │
     │        ▼                     │
     │   ┌──────────┐               │
     │   │   NATS   │               │
     │   │  Message │               │
     │   │   Bus    │               │
     │   └─────┬────┘               │
     │         │                    │
     │         ├────────────────────┼──▶ Subscribe "post.created"
     │         │                    │
     │         │                    ├──▶ Update feed cache
     │         │                    │    in Redis
     │         │                    │
     │         └────────────────────┼──▶ Discovery Service
     │                              │    ├──▶ Index in Meilisearch
     │                              │
     │                              └──▶ Engagement Service
     │                                   └──▶ Track engagement

Multiple services can subscribe to same events
Events are processed asynchronously
Each service maintains its own data model
```

---

## Deployment Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                    DEPLOYMENT PIPELINE                            │
└──────────────────────────────────────────────────────────────────┘

1. CODE COMMIT
   Developer → git push main
                  │
                  ▼
2. CI PIPELINE (GitHub Actions)
   ┌────────────────────────────┐
   │ • Checkout code            │
   │ • Build Docker images      │
   │ • Run unit tests           │
   │ • Security scan (Trivy)    │
   │ • Push to GHCR             │
   │   - Tag: sha-abc123        │
   │   - Tag: latest            │
   └────────────┬───────────────┘
                │
                ▼
3. GITOPS UPDATE
   ┌────────────────────────────┐
   │ • Update values.yaml       │
   │   image: auth-service      │
   │   tag: sha-abc123          │
   │ • Commit back to repo      │
   └────────────┬───────────────┘
                │
                ▼
4. ARGO CD SYNC (Automatic)
   ┌────────────────────────────┐
   │ • Detect repo change       │
   │ • Pull Helm charts         │
   │ • Render templates         │
   │ • Compare with cluster     │
   └────────────┬───────────────┘
                │
                ▼
5. KUBERNETES DEPLOYMENT
   ┌────────────────────────────┐
   │ • Rolling update           │
   │   - Old pods: 3            │
   │   - New pods: 1 ──▶ 2 ──▶ 3│
   │   - Old pods: 2 ──▶ 1 ──▶ 0│
   │ • Health checks            │
   │ • Readiness probes         │
   └────────────┬───────────────┘
                │
                ▼
6. VERIFICATION
   ┌────────────────────────────┐
   │ • All pods healthy         │
   │ • Metrics being collected  │
   │ • Logs flowing to Loki     │
   │ • Services responding      │
   └────────────────────────────┘
                │
                ▼
           DEPLOYED!

Time: ~5-10 minutes from commit to production
Zero downtime deployment
Automatic rollback on failure
```

---

## Monitoring & Observability

```
┌──────────────────────────────────────────────────────────────────┐
│                   OBSERVABILITY STACK                             │
└──────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                      Application Pods                        │
│                                                              │
│  Each pod exposes:                                           │
│  • /metrics endpoint (Prometheus format)                     │
│  • stdout/stderr logs                                        │
└──────────────────┬────────────────────────────┬──────────────┘
                   │                            │
                   │ Metrics                    │ Logs
                   ▼                            ▼
         ┌─────────────────┐          ┌────────────────┐
         │   Prometheus    │          │   Promtail     │
         │                 │          │   (DaemonSet)  │
         │ • Scrapes /     │          │                │
         │   metrics every │          │ • Reads pod    │
         │   15s           │          │   logs from    │
         │ • Stores time   │          │   /var/log/pods│
         │   series data   │          │ • Ships to Loki│
         │ • 15d retention │          └───────┬────────┘
         └────────┬────────┘                  │
                  │                           ▼
                  │                  ┌────────────────┐
                  │                  │     Loki       │
                  │                  │                │
                  │                  │ • Stores logs  │
                  │                  │ • Indexes by   │
                  │                  │   labels       │
                  │                  │ • 30d retention│
                  │                  └───────┬────────┘
                  │                          │
                  │                          │
                  ▼                          ▼
         ┌──────────────────────────────────────────┐
         │              Grafana                      │
         │                                           │
         │  Datasources:                             │
         │  • Prometheus (metrics)                   │
         │  • Loki (logs)                            │
         │                                           │
         │  Dashboards:                              │
         │  • API Gateway Traffic                    │
         │  • Service Health                         │
         │  • Database Performance                   │
         │  • Pod Resources                          │
         │                                           │
         │  Features:                                │
         │  • Real-time metrics                      │
         │  • Log correlation                        │
         │  • Alerting                               │
         └───────────────────────────────────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   Ops Team   │
                    │  Dashboards  │
                    └──────────────┘
```

---

## Scaling Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                    AUTO-SCALING FLOW                              │
└──────────────────────────────────────────────────────────────────┘

Load Increases
    │
    ▼
┌─────────────────────────┐
│ Metrics Server          │ ◀── Collects resource metrics
│ • CPU usage: 85%        │     from all pods
│ • Memory usage: 75%     │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ Horizontal Pod          │ ◀── Defined in HPA manifests
│ Autoscaler (HPA)        │     Target: CPU 70%, Memory 80%
│                         │
│ Decision:               │
│ Current: 3 replicas     │
│ Target: 5 replicas      │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ Deployment Controller   │ ◀── Creates new pod replicas
│ • Scale up: +2 pods     │
│ • Schedule on nodes     │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ Kubernetes Scheduler    │ ◀── Finds nodes with capacity
│ • Check node resources  │
│ • Node 1: ✓ Available   │
│ • Node 2: ✓ Available   │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ New Pods Created        │
│ Pod 4: Pending ──▶      │
│        Running          │
│ Pod 5: Pending ──▶      │
│        Running          │
└─────────────────────────┘

If no node capacity available:
    │
    ▼
┌─────────────────────────┐
│ Cluster Autoscaler      │ ◀── Provisions new nodes
│ • Detects pending pods  │     (DigitalOcean/GCP)
│ • Request new node      │
│ • Wait for ready        │
└─────────────────────────┘

Scale down happens in reverse:
• Low load detected
• HPA scales down replicas
• Cluster autoscaler removes empty nodes
```

---

## Disaster Recovery Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                  BACKUP & RECOVERY STRATEGY                       │
└──────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    WHAT'S BACKED UP                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. Git Repository (Source of Truth)                        │
│     • All Helm charts                                       │
│     • All manifests                                         │
│     • Configuration values                                  │
│     • Terraform code                                        │
│                                                              │
│  2. PostgreSQL Database                                     │
│     • Daily automated backups (managed DB)                  │
│     • Point-in-time recovery (PITR)                         │
│     • Retention: 30 days                                    │
│                                                              │
│  3. Object Storage (MinIO/Spaces)                           │
│     • Versioning enabled                                    │
│     • Cross-region replication                              │
│     • Lifecycle policies                                    │
│                                                              │
│  4. Cluster State                                           │
│     • Terraform state (remote backend)                      │
│     • Can recreate entire cluster                           │
│                                                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    RECOVERY PROCEDURE                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Total Loss Scenario:                                       │
│                                                              │
│  Step 1: Provision new cluster (15 min)                     │
│    terraform apply                                          │
│                                                              │
│  Step 2: Install Argo CD (5 min)                            │
│    kubectl apply -f argocd-install.yaml                     │
│                                                              │
│  Step 3: Deploy platform (10 min)                           │
│    kubectl apply -f ka-platform-application.yaml            │
│    (Argo CD syncs from Git)                                 │
│                                                              │
│  Step 4: Restore data (30 min)                              │
│    • Restore PostgreSQL from backup                         │
│    • Restore object storage                                 │
│                                                              │
│  Total Recovery Time: ~60 minutes                           │
│  Recovery Point: Last database backup (< 24 hours)          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Security Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                      SECURITY LAYERS                              │
└──────────────────────────────────────────────────────────────────┘

Layer 1: Network Security
┌─────────────────────────────────────────────┐
│ • Load Balancer with DDoS protection        │
│ • SSL/TLS encryption                        │
│ • Rate limiting at ingress                  │
│ • Network policies (pod-to-pod)             │
└─────────────────────────────────────────────┘

Layer 2: Authentication & Authorization
┌─────────────────────────────────────────────┐
│ • JWT tokens (signed)                       │
│ • Service-to-service mTLS (optional)        │
│ • RBAC for Kubernetes resources             │
│ • Service accounts with minimal permissions │
└─────────────────────────────────────────────┘

Layer 3: Secrets Management
┌─────────────────────────────────────────────┐
│ • Kubernetes Secrets (base64)               │
│ • External secrets manager (recommended)    │
│ • Encrypted at rest                         │
│ • Rotate regularly                          │
└─────────────────────────────────────────────┘

Layer 4: Container Security
┌─────────────────────────────────────────────┐
│ • Vulnerability scanning (Trivy)            │
│ • Non-root containers                       │
│ • Read-only root filesystem                 │
│ • Drop unnecessary capabilities             │
└─────────────────────────────────────────────┘

Layer 5: Compliance & Audit
┌─────────────────────────────────────────────┐
│ • All changes in Git (audit trail)          │
│ • Access logs                               │
│ • Security scanning in CI/CD                │
│ • Regular security updates                  │
└─────────────────────────────────────────────┘
```

---

## Cost Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                     COST BREAKDOWN                                │
└──────────────────────────────────────────────────────────────────┘

DigitalOcean (Starting Configuration)
┌────────────────────────────────────────┐
│ Kubernetes (3 nodes, 4vCPU/8GB each)   │ $120/mo
│ Managed PostgreSQL (2vCPU/4GB)         │  $15/mo
│ Managed Redis (1GB)                    │  $15/mo
│ Load Balancer                          │  $10/mo
│ Block Storage (300GB)                  │  $30/mo
├────────────────────────────────────────┤
│ Total (Basic)                          │ $190/mo
└────────────────────────────────────────┘

DigitalOcean (Production with Scaling)
┌────────────────────────────────────────┐
│ Kubernetes (5-10 nodes autoscaling)    │ $200-400/mo
│ Managed Databases (upgraded)           │   $60/mo
│ Spaces (object storage)                │   $10/mo
│ Bandwidth                              │   $20/mo
├────────────────────────────────────────┤
│ Total (Production)                     │ $290-490/mo
└────────────────────────────────────────┘

Google Cloud Platform
┌────────────────────────────────────────┐
│ GKE (3x3 nodes, e2-standard-4)         │ $220/mo
│ Cloud SQL PostgreSQL                   │  $50/mo
│ Memorystore Redis                      │  $30/mo
│ Load Balancer                          │  $20/mo
│ Persistent Disks                       │  $40/mo
├────────────────────────────────────────┤
│ Total (Basic)                          │ $360/mo
└────────────────────────────────────────┘
```

---

*All diagrams represent the Ka Platform v1.0.0 architecture*
