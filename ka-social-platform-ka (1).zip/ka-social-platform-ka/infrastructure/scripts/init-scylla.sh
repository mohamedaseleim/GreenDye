#!/bin/bash

# Script to initialize ScyllaDB with the Ka platform schema
# This should be run after ScyllaDB container is healthy

set -e

echo "Waiting for ScyllaDB to be ready..."
sleep 10

# Check if ScyllaDB is healthy
docker-compose -f ../docker/docker-compose.yml exec -T scylla nodetool status || {
    echo "Error: ScyllaDB is not ready. Please wait for it to start."
    exit 1
}

echo "ScyllaDB is ready. Initializing schema..."

# Run the initialization script
docker-compose -f ../docker/docker-compose.yml exec -T scylla cqlsh -f /docker-entrypoint-initdb.d/01-init.cql

echo "ScyllaDB initialization complete!"

# Verify keyspaces were created
echo ""
echo "Verifying keyspaces..."
docker-compose -f ../docker/docker-compose.yml exec -T scylla cqlsh -e "DESCRIBE KEYSPACES;"

echo ""
echo "All done! You can now start the application services."
