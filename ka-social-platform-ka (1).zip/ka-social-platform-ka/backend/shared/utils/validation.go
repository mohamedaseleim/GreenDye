package utils

import (
	"regexp"
	"strings"
	"unicode"

	"github.com/google/uuid"
)

// IsValidEmail validates an email address
func IsValidEmail(email string) bool {
	emailRegex := regexp.MustCompile(`^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`)
	return emailRegex.MatchString(email)
}

// IsValidUsername validates a username
func IsValidUsername(username string) bool {
	if len(username) < 3 || len(username) > 50 {
		return false
	}
	usernameRegex := regexp.MustCompile(`^[a-zA-Z0-9_]+$`)
	return usernameRegex.MatchString(username)
}

// IsValidPassword validates a password
func IsValidPassword(password string) bool {
	if len(password) < 8 {
		return false
	}

	var (
		hasUpper   bool
		hasLower   bool
		hasNumber  bool
		hasSpecial bool
	)

	for _, char := range password {
		switch {
		case unicode.IsUpper(char):
			hasUpper = true
		case unicode.IsLower(char):
			hasLower = true
		case unicode.IsNumber(char):
			hasNumber = true
		case unicode.IsPunct(char) || unicode.IsSymbol(char):
			hasSpecial = true
		}
	}

	return hasUpper && hasLower && hasNumber && hasSpecial
}

// ExtractHashtags extracts hashtags from text
func ExtractHashtags(text string) []string {
	hashtagRegex := regexp.MustCompile(`#\w+`)
	matches := hashtagRegex.FindAllString(text, -1)
	
	hashtags := make([]string, 0, len(matches))
	for _, match := range matches {
		hashtag := strings.TrimPrefix(match, "#")
		hashtags = append(hashtags, strings.ToLower(hashtag))
	}
	
	return hashtags
}

// ExtractMentions extracts user mentions from text
func ExtractMentions(text string) []string {
	mentionRegex := regexp.MustCompile(`@\w+`)
	matches := mentionRegex.FindAllString(text, -1)
	
	mentions := make([]string, 0, len(matches))
	for _, match := range matches {
		mention := strings.TrimPrefix(match, "@")
		mentions = append(mentions, mention)
	}
	
	return mentions
}

// IsValidUUID validates a UUID string
func IsValidUUID(uuidStr string) bool {
	_, err := uuid.Parse(uuidStr)
	return err == nil
}

// SanitizeString removes leading/trailing whitespace and limits length
func SanitizeString(s string, maxLength int) string {
	s = strings.TrimSpace(s)
	if len(s) > maxLength {
		return s[:maxLength]
	}
	return s
}
