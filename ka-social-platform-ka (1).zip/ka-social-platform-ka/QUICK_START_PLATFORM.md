# Ka Platform - Quick Start Guide

Get the Ka Platform running on Kubernetes in under 30 minutes.

## Prerequisites

- kubectl installed and configured
- Terraform installed (for infrastructure)
- Git repository cloned

## Option 1: DigitalOcean (Fastest & Cheapest)

### Step 1: Provision Cluster (5 min)

```bash
cd terraform/digitalocean

# Configure
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your DO token

# Deploy
terraform init
terraform apply -auto-approve

# Get kubeconfig
export KUBECONFIG=$(terraform output -raw kubeconfig_path)
kubectl get nodes
```

### Step 2: Install Argo CD (3 min)

```bash
# Install Argo CD
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for ready
kubectl wait --for=condition=available --timeout=300s deployment/argocd-server -n argocd

# Get admin password
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d && echo
```

### Step 3: Deploy Ka Platform (5 min)

```bash
cd ../..  # Back to repo root

# Deploy via Argo CD
kubectl apply -f infrastructure/argocd/ka-platform-application.yaml

# Watch deployment
kubectl get pods -n ka-platform -w
```

### Step 4: Deploy Observability (5 min)

```bash
# Deploy monitoring stack
kubectl apply -f infrastructure/observability/prometheus/
kubectl apply -f infrastructure/observability/grafana/
kubectl apply -f infrastructure/observability/loki/

# Verify
kubectl get pods -n ka-platform | grep -E "prometheus|grafana|loki"
```

### Step 5: Access Services (2 min)

```bash
# Port forward to test
kubectl port-forward -n ka-platform svc/auth-service 8001:8001 &
kubectl port-forward -n ka-platform svc/grafana 3000:3000 &
kubectl port-forward -n argocd svc/argocd-server 8080:443 &

# Test API
curl http://localhost:8001/health

# Open dashboards
# Grafana: http://localhost:3000
# Argo CD: http://localhost:8080
```

**Total Time: ~20 minutes**  
**Total Cost: ~$160/month**

---

## Option 2: Google Cloud Platform (Production-Grade)

### Step 1: Provision Cluster (10 min)

```bash
cd terraform/gcp

# Configure
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your project ID

# Deploy
terraform init
terraform apply -auto-approve

# Get kubeconfig
eval $(terraform output -raw kubeconfig_command)
kubectl get nodes
```

### Step 2-5: Same as DigitalOcean

Follow steps 2-5 from DigitalOcean guide.

**Total Time: ~30 minutes**  
**Total Cost: ~$300/month**

---

## Post-Deployment Checklist

### 1. Verify All Pods Running

```bash
kubectl get pods -n ka-platform
```

Expected output: All pods in `Running` state.

### 2. Check Argo CD Sync Status

```bash
kubectl get application -n argocd
```

Expected: `HEALTH: Healthy`, `SYNC STATUS: Synced`

### 3. Test API Endpoints

```bash
# Auth service
curl http://localhost:8001/health

# User service
curl http://localhost:8002/health

# Content service
curl http://localhost:8003/health
```

Expected: `{"status":"ok"}` or similar.

### 4. Access Dashboards

**Grafana**:
- URL: http://localhost:3000
- Username: `admin`
- Password: Check secret
  ```bash
  kubectl get secret grafana-secrets -n ka-platform -o jsonpath="{.data.admin-password}" | base64 -d
  ```

**Argo CD**:
- URL: http://localhost:8080
- Username: `admin`
- Password: From step 2

**Prometheus**:
- URL: http://localhost:9090

### 5. Verify Metrics Collection

```bash
# Port forward Prometheus
kubectl port-forward -n ka-platform svc/prometheus 9090:9090

# Open http://localhost:9090 and query:
# http_requests_total
# http_request_duration_seconds
```

---

## Common Issues

### Pods Stuck in Pending

**Cause**: Insufficient cluster resources

**Solution**:
```bash
# Check node resources
kubectl describe nodes | grep -A 5 "Allocated resources"

# Scale up cluster (increase node count in terraform.tfvars)
terraform apply
```

### Image Pull Errors

**Cause**: Container registry not accessible

**Solution**:
```bash
# Check if images exist
docker pull ghcr.io/mohamedaseleim/ka-social-platform/auth-service:latest

# If not, build and push images
cd backend
docker build -t ghcr.io/mohamedaseleim/ka-social-platform/auth-service:latest -f auth-service/Dockerfile .
docker push ghcr.io/mohamedaseleim/ka-social-platform/auth-service:latest
```

### Database Connection Failures

**Cause**: Databases not ready yet

**Solution**:
```bash
# Check database pods
kubectl get pods -n ka-platform | grep -E "postgres|redis|scylla"

# Wait for StatefulSets to be ready
kubectl wait --for=condition=ready pod -l app=postgres -n ka-platform --timeout=300s
```

### Argo CD Not Syncing

**Cause**: Git repository not accessible or sync disabled

**Solution**:
```bash
# Check application status
kubectl get application ka-platform -n argocd -o yaml

# Force sync
argocd app sync ka-platform --force

# Check Argo CD logs
kubectl logs -n argocd deployment/argocd-application-controller
```

---

## Next Steps

1. **Configure DNS**:
   - Point your domain to load balancer IP
   - Update `global.domain` in `charts/ka-platform/values.yaml`

2. **Enable SSL**:
   - Install cert-manager
   - Configure Let's Encrypt issuer
   - Update ingress annotations

3. **Set Up CI/CD**:
   - Configure GitHub Actions secrets
   - Push code to trigger build
   - Watch Argo CD auto-deploy

4. **Configure Monitoring**:
   - Set up alert rules
   - Configure notification channels
   - Create custom dashboards

5. **Enable Backups**:
   - Configure database backups
   - Set up cluster snapshots
   - Test restore procedures

---

## Useful Commands

### View All Resources

```bash
kubectl get all -n ka-platform
```

### View Logs

```bash
# Specific service
kubectl logs -n ka-platform deployment/auth-service -f

# All services
kubectl logs -n ka-platform -l component=api -f --max-log-requests=10
```

### Scale Service

```bash
kubectl scale deployment/content-service -n ka-platform --replicas=5
```

### Update Configuration

```bash
# Edit values
vim charts/ka-platform/values.yaml

# Sync changes
git add . && git commit -m "Update config" && git push
# Argo CD auto-syncs in ~3 minutes
```

### Restart Service

```bash
kubectl rollout restart deployment/auth-service -n ka-platform
```

### Get Service URL

```bash
kubectl get ingress -n ka-platform
```

---

## Support

- **Documentation**: See [PLATFORM_ENGINEERING.md](./PLATFORM_ENGINEERING.md)
- **Troubleshooting**: Check logs and pod events
- **Issues**: Open GitHub issue with logs and description

---

## Architecture Overview

```
GitHub → Actions → Build Images → Update Helm → Argo CD → Kubernetes
                                                      ↓
                                           ┌─────────┴─────────┐
                                           │                   │
                                      API Services        Databases
                                   (9 microservices)   (6 data stores)
                                           │                   │
                                           └─────────┬─────────┘
                                                     ↓
                                              Load Balancer
                                                     ↓
                                                 Internet
```

---

**Platform**: Ka Social Platform  
**Version**: 1.0.0  
**Last Updated**: 2024
