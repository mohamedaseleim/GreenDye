package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
)

// Handler handles HTTP requests for interactions
type Handler struct {
	repo   *Repository
	config *Config
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	return &Handler{
		repo:   repo,
		config: config,
	}
}

// FollowUser handles the follow user request (idempotent)
func (h *Handler) FollowUser(c *gin.Context) {
	// Get current user ID from context (set by auth middleware)
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get target user ID from URL
	targetUserIDStr := c.Param("id")
	targetUserID, err := uuid.Parse(targetUserIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid target user ID",
			nil,
		))
		return
	}

	// Users cannot follow themselves
	if currentUserID == targetUserID {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ACTION",
			"Cannot follow yourself",
			nil,
		))
		return
	}

	// Check if target user exists
	exists, err = h.repo.UserExists(targetUserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to verify user",
			err.Error(),
		))
		return
	}
	if !exists {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"Target user not found",
			nil,
		))
		return
	}

	// Check if already following (for reporting to user)
	alreadyFollowing, _ := h.repo.IsFollowing(currentUserID, targetUserID)

	// Create follow relationship (idempotent)
	if err := h.repo.Follow(currentUserID, targetUserID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to follow user",
			err.Error(),
		))
		return
	}

	// Only update counts in User Service if this is a new follow
	if !alreadyFollowing {
		if err := h.updateUserServiceCounts(currentUserID, targetUserID, "follow"); err != nil {
			// Log error but don't fail the request - counts will be eventually consistent
			log.Printf("Warning: Failed to update user service counts: %v\n", err)
		}

		// Publish user.followed event to NATS
		if h.config.NATSConn != nil {
			event := map[string]string{
				"follower_id":  currentUserID.String(),
				"following_id": targetUserID.String(),
				"timestamp":    time.Now().UTC().Format(time.RFC3339),
			}
			data, _ := json.Marshal(event)
			if err := h.config.NATSConn.Publish("user.followed", data); err != nil {
				log.Printf("Warning: Failed to publish user.followed event: %v", err)
			} else {
				log.Printf("Published user.followed event: follower=%s, following=%s", currentUserID, targetUserID)
			}
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"following":         true,
			"already_following": alreadyFollowing,
		},
		"Successfully followed user",
	))
}

// UnfollowUser handles the unfollow user request (idempotent)
func (h *Handler) UnfollowUser(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get target user ID from URL
	targetUserIDStr := c.Param("id")
	targetUserID, err := uuid.Parse(targetUserIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid target user ID",
			nil,
		))
		return
	}

	// Check if was following (for reporting to user)
	wasFollowing, _ := h.repo.IsFollowing(currentUserID, targetUserID)

	// Remove follow relationship (idempotent)
	if err := h.repo.Unfollow(currentUserID, targetUserID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to unfollow user",
			err.Error(),
		))
		return
	}

	// Only update counts in User Service if there was a follow to remove
	if wasFollowing {
		if err := h.updateUserServiceCounts(currentUserID, targetUserID, "unfollow"); err != nil {
			// Log error but don't fail the request
			fmt.Printf("Warning: Failed to update user service counts: %v\n", err)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"following":     false,
			"was_following": wasFollowing,
		},
		"Successfully unfollowed user",
	))
}

// GetFollowers retrieves the list of followers for a user
func (h *Handler) GetFollowers(c *gin.Context) {
	// Get user ID from URL
	userIDStr := c.Param("id")
	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Get followers
	followers, err := h.repo.GetFollowers(userID, perPage, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to get followers",
			err.Error(),
		))
		return
	}

	// Get total count
	total, err := h.repo.CountFollowers(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to count followers",
			err.Error(),
		))
		return
	}

	// Build response with pagination
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(followers, pagination))
}

// GetFollowing retrieves the list of users a user is following
func (h *Handler) GetFollowing(c *gin.Context) {
	// Get user ID from URL
	userIDStr := c.Param("id")
	userID, err := uuid.Parse(userIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Get following
	following, err := h.repo.GetFollowing(userID, perPage, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to get following",
			err.Error(),
		))
		return
	}

	// Get total count
	total, err := h.repo.CountFollowing(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to count following",
			err.Error(),
		))
		return
	}

	// Build response with pagination
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(following, pagination))
}

// updateUserServiceCounts makes a synchronous call to User Service to update denormalized counts
func (h *Handler) updateUserServiceCounts(followerID, followingID uuid.UUID, action string) error {
	url := fmt.Sprintf("%s/api/internal/follow-counts", h.config.UserServiceURL)

	payload := map[string]string{
		"follower_user_id":  followerID.String(),
		"following_user_id": followingID.String(),
		"action":            action,
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal request: %w", err)
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to call user service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("user service returned status: %d", resp.StatusCode)
	}

	return nil
}

// BlockUser handles the block user request (idempotent)
func (h *Handler) BlockUser(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get target user ID from URL
	targetUserIDStr := c.Param("id")
	targetUserID, err := uuid.Parse(targetUserIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid target user ID",
			nil,
		))
		return
	}

	// Users cannot block themselves
	if currentUserID == targetUserID {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ACTION",
			"Cannot block yourself",
			nil,
		))
		return
	}

	// Check if target user exists
	exists, err = h.repo.UserExists(targetUserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to verify user",
			err.Error(),
		))
		return
	}
	if !exists {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"Target user not found",
			nil,
		))
		return
	}

	// Check if already blocking
	alreadyBlocking, _ := h.repo.IsBlocking(currentUserID, targetUserID)

	// Create block relationship (idempotent)
	if err := h.repo.Block(currentUserID, targetUserID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to block user",
			err.Error(),
		))
		return
	}

	// If this is a new block, sever any existing follow relationships and publish event
	if !alreadyBlocking {
		// Remove follow relationships in both directions
		_ = h.repo.Unfollow(currentUserID, targetUserID)
		_ = h.repo.Unfollow(targetUserID, currentUserID)

		// Update user service counts (best effort)
		wasFollowing, _ := h.repo.IsFollowing(currentUserID, targetUserID)
		wasFollowedBy, _ := h.repo.IsFollowing(targetUserID, currentUserID)
		
		if wasFollowing {
			_ = h.updateUserServiceCounts(currentUserID, targetUserID, "unfollow")
		}
		if wasFollowedBy {
			_ = h.updateUserServiceCounts(targetUserID, currentUserID, "unfollow")
		}

		// Publish user.blocked event to NATS
		if h.config.NATSConn != nil {
			event := map[string]string{
				"blocker_id": currentUserID.String(),
				"blocked_id": targetUserID.String(),
				"timestamp":  time.Now().UTC().Format(time.RFC3339),
			}
			data, _ := json.Marshal(event)
			if err := h.config.NATSConn.Publish("user.blocked", data); err != nil {
				log.Printf("Warning: Failed to publish user.blocked event: %v", err)
			} else {
				log.Printf("Published user.blocked event: blocker=%s, blocked=%s", currentUserID, targetUserID)
			}
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"blocking":         true,
			"already_blocking": alreadyBlocking,
		},
		"Successfully blocked user",
	))
}

// UnblockUser handles the unblock user request (idempotent)
func (h *Handler) UnblockUser(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get target user ID from URL
	targetUserIDStr := c.Param("id")
	targetUserID, err := uuid.Parse(targetUserIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid target user ID",
			nil,
		))
		return
	}

	// Check if was blocking
	wasBlocking, _ := h.repo.IsBlocking(currentUserID, targetUserID)

	// Remove block relationship (idempotent)
	if err := h.repo.Unblock(currentUserID, targetUserID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to unblock user",
			err.Error(),
		))
		return
	}

	// Publish user.unblocked event if there was a block to remove
	if wasBlocking && h.config.NATSConn != nil {
		event := map[string]string{
			"blocker_id": currentUserID.String(),
			"blocked_id": targetUserID.String(),
			"timestamp":  time.Now().UTC().Format(time.RFC3339),
		}
		data, _ := json.Marshal(event)
		if err := h.config.NATSConn.Publish("user.unblocked", data); err != nil {
			log.Printf("Warning: Failed to publish user.unblocked event: %v", err)
		} else {
			log.Printf("Published user.unblocked event: blocker=%s, blocked=%s", currentUserID, targetUserID)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"blocking":     false,
			"was_blocking": wasBlocking,
		},
		"Successfully unblocked user",
	))
}

// MuteUser handles the mute user request (idempotent)
func (h *Handler) MuteUser(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get target user ID from URL
	targetUserIDStr := c.Param("id")
	targetUserID, err := uuid.Parse(targetUserIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid target user ID",
			nil,
		))
		return
	}

	// Users cannot mute themselves
	if currentUserID == targetUserID {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ACTION",
			"Cannot mute yourself",
			nil,
		))
		return
	}

	// Check if target user exists
	exists, err = h.repo.UserExists(targetUserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to verify user",
			err.Error(),
		))
		return
	}
	if !exists {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"Target user not found",
			nil,
		))
		return
	}

	// Check if already muting
	alreadyMuting, _ := h.repo.IsMuting(currentUserID, targetUserID)

	// Create mute relationship (idempotent)
	if err := h.repo.Mute(currentUserID, targetUserID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to mute user",
			err.Error(),
		))
		return
	}

	// Publish user.muted event if this is a new mute
	if !alreadyMuting && h.config.NATSConn != nil {
		event := map[string]string{
			"muter_id": currentUserID.String(),
			"muted_id": targetUserID.String(),
			"timestamp": time.Now().UTC().Format(time.RFC3339),
		}
		data, _ := json.Marshal(event)
		if err := h.config.NATSConn.Publish("user.muted", data); err != nil {
			log.Printf("Warning: Failed to publish user.muted event: %v", err)
		} else {
			log.Printf("Published user.muted event: muter=%s, muted=%s", currentUserID, targetUserID)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"muting":         true,
			"already_muting": alreadyMuting,
		},
		"Successfully muted user",
	))
}

// UnmuteUser handles the unmute user request (idempotent)
func (h *Handler) UnmuteUser(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Get target user ID from URL
	targetUserIDStr := c.Param("id")
	targetUserID, err := uuid.Parse(targetUserIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid target user ID",
			nil,
		))
		return
	}

	// Check if was muting
	wasMuting, _ := h.repo.IsMuting(currentUserID, targetUserID)

	// Remove mute relationship (idempotent)
	if err := h.repo.Unmute(currentUserID, targetUserID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to unmute user",
			err.Error(),
		))
		return
	}

	// Publish user.unmuted event if there was a mute to remove
	if wasMuting && h.config.NATSConn != nil {
		event := map[string]string{
			"muter_id": currentUserID.String(),
			"muted_id": targetUserID.String(),
			"timestamp": time.Now().UTC().Format(time.RFC3339),
		}
		data, _ := json.Marshal(event)
		if err := h.config.NATSConn.Publish("user.unmuted", data); err != nil {
			log.Printf("Warning: Failed to publish user.unmuted event: %v", err)
		} else {
			log.Printf("Published user.unmuted event: muter=%s, muted=%s", currentUserID, targetUserID)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"muting":     false,
			"was_muting": wasMuting,
		},
		"Successfully unmuted user",
	))
}

// GetBlockedUsers retrieves the list of users blocked by the current user
func (h *Handler) GetBlockedUsers(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Get blocked users
	blockedUsers, err := h.repo.GetBlockedUsers(currentUserID, perPage, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to get blocked users",
			err.Error(),
		))
		return
	}

	// Get total count
	total, err := h.repo.CountBlockedUsers(currentUserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to count blocked users",
			err.Error(),
		))
		return
	}

	// Build response with pagination
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(blockedUsers, pagination))
}

// GetMutedUsers retrieves the list of users muted by the current user
func (h *Handler) GetMutedUsers(c *gin.Context) {
	// Get current user ID from context
	currentUserIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	currentUserID, err := uuid.Parse(currentUserIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Get muted users
	mutedUsers, err := h.repo.GetMutedUsers(currentUserID, perPage, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to get muted users",
			err.Error(),
		))
		return
	}

	// Get total count
	total, err := h.repo.CountMutedUsers(currentUserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to count muted users",
			err.Error(),
		))
		return
	}

	// Build response with pagination
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(mutedUsers, pagination))
}

// CheckBlockStatus checks if there's any block relationship between two users (internal)
func (h *Handler) CheckBlockStatus(c *gin.Context) {
	// Get user IDs from query parameters
	user1IDStr := c.Query("user1_id")
	user2IDStr := c.Query("user2_id")

	if user1IDStr == "" || user2IDStr == "" {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_PARAMETERS",
			"Both user1_id and user2_id are required",
			nil,
		))
		return
	}

	user1ID, err := uuid.Parse(user1IDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user1_id",
			nil,
		))
		return
	}

	user2ID, err := uuid.Parse(user2IDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user2_id",
			nil,
		))
		return
	}

	// Check both directions
	user1BlocksUser2, _ := h.repo.IsBlocking(user1ID, user2ID)
	user2BlocksUser1, _ := h.repo.IsBlocking(user2ID, user1ID)

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"blocked":           user1BlocksUser2 || user2BlocksUser1,
			"user1_blocks_user2": user1BlocksUser2,
			"user2_blocks_user1": user2BlocksUser1,
		},
		"Block status checked successfully",
	))
}

// CheckMuteStatus checks if a user is muting another user (internal)
func (h *Handler) CheckMuteStatus(c *gin.Context) {
	// Get user IDs from query parameters
	muterIDStr := c.Query("muter_id")
	mutedIDStr := c.Query("muted_id")

	if muterIDStr == "" || mutedIDStr == "" {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_PARAMETERS",
			"Both muter_id and muted_id are required",
			nil,
		))
		return
	}

	muterID, err := uuid.Parse(muterIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid muter_id",
			nil,
		))
		return
	}

	mutedID, err := uuid.Parse(mutedIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid muted_id",
			nil,
		))
		return
	}

	// Check mute status
	isMuting, _ := h.repo.IsMuting(muterID, mutedID)

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"muted": isMuting,
		},
		"Mute status checked successfully",
	))
}

// GetBatchFollowStatus handles POST /api/internal/follows/batch-status (internal endpoint)
func (h *Handler) GetBatchFollowStatus(c *gin.Context) {
	var req struct {
		FollowerID string   `json:"follower_id" binding:"required"`
		UserIDs    []string `json:"user_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	followerID, err := uuid.Parse(req.FollowerID)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid follower ID",
			nil,
		))
		return
	}

	// Parse user IDs
	userIDs := make([]uuid.UUID, 0, len(req.UserIDs))
	for _, idStr := range req.UserIDs {
		userID, err := uuid.Parse(idStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"INVALID_USER_ID",
				"Invalid user ID format",
				idStr,
			))
			return
		}
		userIDs = append(userIDs, userID)
	}

	// Get follow status from repository
	followStatus, err := h.repo.GetBatchFollowStatus(followerID, userIDs)
	if err != nil {
		log.Printf("Error fetching batch follow status: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to fetch follow status",
			nil,
		))
		return
	}

	// Convert to string map for response
	followStatusStr := make(map[string]bool)
	for userID, isFollowed := range followStatus {
		followStatusStr[userID.String()] = isFollowed
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{"follow_status": followStatusStr},
		"Follow status retrieved successfully",
	))
}
