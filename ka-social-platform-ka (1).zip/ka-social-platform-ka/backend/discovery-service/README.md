# Discovery Service

The Discovery Service provides advanced search capabilities and trending content discovery for the Ka social platform.

## Features

### 1. Advanced Search with Meilisearch
- **Full-text search** across users and echoes
- **Typo-tolerant** search for better user experience
- **Intelligent ranking** based on engagement metrics
- **Multi-index search** returning both users and content

### 2. Autocomplete
- Type-ahead suggestions for users
- Optimized for fast response (<50ms)
- Limited results for quick UI feedback

### 3. Trending Hashtags
- Real-time hashtag tracking
- 24-hour sliding window algorithm
- Redis ZSET-based implementation
- Automatic cleanup of old entries

## Architecture

### Event-Driven Indexing

The Discovery Service consumes events from NATS and indexes them in Meilisearch:

```
NATS Events → Discovery Service → Meilisearch
                                → Redis (Trending)
```

**Consumed Events:**
- `user.created` - Index new users
- `user.updated` - Update user data (including follower_count)
- `echo.created` - Index new echoes and update trending hashtags
- `echo.updated` - Update echo likes count
- `echo.deleted` - Remove echoes from index

### Meilisearch Indexes

#### Users Index
**Ranking Rules:**
1. Search relevance (words, typo, proximity, attribute)
2. **follower_count:desc** - Users with more followers rank higher
3. Exact matches

**Searchable Attributes:**
- username
- display_name
- bio

#### Echoes Index
**Ranking Rules:**
1. Search relevance (words, typo, proximity, attribute)
2. **likes_count:desc** - More liked echoes rank higher
3. **created_at:desc** - More recent echoes rank higher
4. Exact matches

**Searchable Attributes:**
- content
- hashtags

**Filters:**
- Only public echoes are searchable

### Trending Algorithm

Uses Redis Sorted Sets (ZSET) for efficient hashtag tracking:

1. **Increment**: Each hashtag mention increments its score
2. **Timestamp Tracking**: Store timestamps for each mention
3. **Sliding Window**: Remove entries older than 24 hours
4. **Ranking**: Sort by total count within the window

**Redis Keys:**
- `trending:hashtags` - Global sorted set of hashtag counts
- `trending:hashtag:{tag}:timestamps` - Timestamps for each hashtag (24h TTL)

## API Endpoints

### Search
```
GET /api/v1/search?q={query}&limit={limit}&offset={offset}
```

**Query Parameters:**
- `q` (required): Search query
- `limit` (optional): Results per page (default: 20, max: 100)
- `offset` (optional): Pagination offset (default: 0)

**Response:**
```json
{
  "success": true,
  "data": {
    "users": [
      {
        "id": "uuid",
        "username": "johndoe",
        "display_name": "John Doe",
        "follower_count": 1234,
        "is_verified": true
      }
    ],
    "echoes": [
      {
        "id": "uuid",
        "content": "Hello world #tech",
        "likes_count": 42,
        "created_at": 1234567890
      }
    ],
    "hits": 12
  }
}
```

### Autocomplete
```
GET /api/v1/search/suggest?q={prefix}&limit={limit}
```

**Query Parameters:**
- `q` (required): Search prefix
- `limit` (optional): Number of suggestions (default: 5, max: 20)

**Response:**
```json
{
  "success": true,
  "data": {
    "users": [
      {
        "id": "uuid",
        "username": "johndoe",
        "display_name": "John Doe"
      }
    ],
    "echoes": []
  }
}
```

### Trending Hashtags
```
GET /api/v1/discover/trending?limit={limit}
```

**Query Parameters:**
- `limit` (optional): Number of trending hashtags (default: 10, max: 50)

**Response:**
```json
{
  "success": true,
  "data": {
    "trending_hashtags": [
      {
        "tag": "tech",
        "count": 1523
      },
      {
        "tag": "news",
        "count": 987
      }
    ]
  }
}
```

## Configuration

Environment variables:

- `PORT` - Service port (default: 8008)
- `REDIS_HOST` - Redis host
- `REDIS_PORT` - Redis port
- `REDIS_PASSWORD` - Redis password
- `JWT_SECRET` - JWT secret for authentication
- `NATS_URL` - NATS server URL
- `MEILISEARCH_HOST` - Meilisearch server URL
- `MEILISEARCH_API_KEY` - Meilisearch API key
- `CONTENT_SERVICE_URL` - Content Service URL (for future features)

## Dependencies

- **Meilisearch**: Fast, typo-tolerant search engine
- **Redis**: In-memory data store for trending hashtags
- **NATS**: Message broker for event consumption
- **Gin**: Web framework

## Performance

- **Search Response Time**: <100ms for most queries
- **Autocomplete Response Time**: <50ms
- **Trending Calculation**: O(log N) operations on Redis ZSET
- **Index Update**: Asynchronous via NATS events

## Future Enhancements

- User recommendations based on interests
- Geographic trending (regional hashtags)
- Trending echoes (not just hashtags)
- Search filters (date range, verified users only, etc.)
- Search analytics and popular queries
