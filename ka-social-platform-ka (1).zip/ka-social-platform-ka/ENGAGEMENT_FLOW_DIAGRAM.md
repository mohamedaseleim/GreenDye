# Engagement Service Flow Diagrams

## 1. Like Operation Flow

```
┌─────────────┐
│   User A    │ (clicks like button on User B's echo)
└──────┬──────┘
       │ POST /api/v1/echoes/:id/like
       │ Authorization: Bearer JWT
       ▼
┌─────────────────────────────────────────┐
│      Engagement Service (Port 8007)     │
│  ┌─────────────────────────────────┐   │
│  │  1. Validate JWT Token          │   │
│  │  2. Parse Echo ID from URL      │   │
│  │  3. Get Echo from Content Svc   │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  4. Insert into likes table     │   │
│  │     (user_id, echo_id)          │   │
│  │     UNIQUE constraint           │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  5. Publish to NATS             │   │
│  │     Subject: echo.liked         │   │
│  │     Payload: {echo_id, user_id, │   │
│  │              echo_owner, time}  │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  6. Call Content Service        │   │
│  │     PATCH /internal/echoes/     │   │
│  │           :id/likes             │   │
│  │     Body: {delta: 1}            │   │
│  └──────────┬──────────────────────┘   │
└─────────────┼──────────────────────────┘
              │
              ▼
       ┌─────────────┐
       │   Success   │
       │  Response   │
       └─────────────┘
```

## 2. Real-Time Notification Flow

```
NATS Server
─────────────────────────────────────────────────────────────
Subject: echo.liked
Payload: {echo_id, user_id, echo_owner, timestamp}
─────────────────────────────────────────────────────────────
       │
       │ (consumed by)
       ▼
┌─────────────────────────────────────────┐
│      Engagement Service Consumer        │
│  ┌─────────────────────────────────┐   │
│  │  1. Parse Event Payload         │   │
│  │  2. Extract echo_owner          │   │
│  │  3. Check if owner = liker      │   │
│  │     (don't notify self)         │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  4. Query for existing          │   │
│  │     unread like notification    │   │
│  │     WHERE user_id = echo_owner  │   │
│  │       AND echo_id = :echo_id    │   │
│  │       AND type = 'like'         │   │
│  │       AND is_read = false       │   │
│  └──────────┬──────────────────────┘   │
│             │                            │
│      ┌──────┴──────┐                    │
│      ▼             ▼                    │
│  Exists?       Not Exists               │
│      │             │                    │
│      │             │                    │
│  ┌───▼──────┐  ┌──▼──────────────┐    │
│  │ UPDATE   │  │ CREATE NEW      │    │
│  │ - Add to │  │ NOTIFICATION    │    │
│  │   actors │  │ - type: 'like'  │    │
│  │ - Incr   │  │ - actor_id      │    │
│  │   count  │  │ - echo_id       │    │
│  │ - Update │  │ - actor_count:1 │    │
│  │   time   │  │ - actor_ids:[id]│    │
│  └───┬──────┘  └──┬──────────────┘    │
│      └─────┬──────┘                    │
│            ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  5. Check if user connected     │   │
│  │     via WebSocket               │   │
│  └──────────┬──────────────────────┘   │
└─────────────┼──────────────────────────┘
              │
       ┌──────┴──────┐
       ▼             ▼
   Connected    Not Connected
       │             │
       │             └─────> (Notification stored
       │                      for later retrieval)
       ▼
┌─────────────────────────────────────────┐
│         WebSocket Hub                   │
│  ┌─────────────────────────────────┐   │
│  │  Lookup connections for user    │   │
│  │  user_id -> [conn1, conn2, ...]│   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  Send JSON notification to      │   │
│  │  all active connections         │   │
│  │  {id, type, actor_id, ...}     │   │
│  └──────────┬──────────────────────┘   │
└─────────────┼──────────────────────────┘
              │
              ▼
       ┌─────────────┐
       │   User B    │ (receives notification in <10ms)
       │  (Browser)  │
       └─────────────┘
```

## 3. WebSocket Connection Flow

```
┌─────────────┐
│   User B    │ (opens notification page)
└──────┬──────┘
       │ ws://localhost:8007/ws/v1/notifications?token=JWT
       │
       ▼
┌─────────────────────────────────────────┐
│      Engagement Service Handler         │
│  ┌─────────────────────────────────┐   │
│  │  1. Extract token from query    │   │
│  │  2. Validate JWT token          │   │
│  │  3. Extract user_id from token  │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  4. Upgrade HTTP to WebSocket   │   │
│  │     using gorilla/websocket     │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  5. Create Client struct        │   │
│  │     {hub, conn, send, user_id}  │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  6. Register with Hub           │   │
│  │     hub.register <- client      │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  7. Start goroutines            │   │
│  │     - readPump (ping/pong)      │   │
│  │     - writePump (send msgs)     │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘

         ┌──────────────────┐
         │   WebSocket Hub  │
         │                  │
         │  User B -> [Conn1, Conn2]
         │  User C -> [Conn3]
         └──────────────────┘
```

## 4. Notification Aggregation Example

```
Timeline:
─────────────────────────────────────────────────────────────

T0: User A creates echo
    Echo ID: 123

T1: User B likes echo 123
    ┌────────────────────────────────────────┐
    │ Notification Created                   │
    │ ───────────────────────────────────   │
    │ user_id: User A                        │
    │ type: "like"                           │
    │ echo_id: 123                           │
    │ actor_id: User B                       │
    │ actor_ids: [User B]                    │
    │ actor_count: 1                         │
    │ content: "liked your echo"             │
    │ is_read: false                         │
    └────────────────────────────────────────┘
    
    User A sees: "User B liked your echo"

T2: User C likes echo 123
    ┌────────────────────────────────────────┐
    │ Notification Updated (same record)     │
    │ ───────────────────────────────────   │
    │ user_id: User A                        │
    │ type: "like"                           │
    │ echo_id: 123                           │
    │ actor_id: User B (unchanged)           │
    │ actor_ids: [User C, User B]            │
    │ actor_count: 2                         │
    │ content: "liked your echo"             │
    │ is_read: false                         │
    └────────────────────────────────────────┘
    
    User A sees: "User C, User B liked your echo"

T3: User D likes echo 123
    ┌────────────────────────────────────────┐
    │ Notification Updated (same record)     │
    │ ───────────────────────────────────   │
    │ user_id: User A                        │
    │ type: "like"                           │
    │ echo_id: 123                           │
    │ actor_id: User B (unchanged)           │
    │ actor_ids: [User D, User C, User B]    │
    │ actor_count: 3                         │
    │ content: "liked your echo"             │
    │ is_read: false                         │
    └────────────────────────────────────────┘
    
    User A sees: "User D, User C, and 1 other liked your echo"

T4: User E likes echo 123
    ┌────────────────────────────────────────┐
    │ Notification Updated (same record)     │
    │ ───────────────────────────────────   │
    │ user_id: User A                        │
    │ type: "like"                           │
    │ echo_id: 123                           │
    │ actor_id: User B (unchanged)           │
    │ actor_ids: [User E, User D, User C]    │
    │ actor_count: 4                         │
    │ content: "liked your echo"             │
    │ is_read: false                         │
    └────────────────────────────────────────┘
    
    User A sees: "User E, User D, and 2 others liked your echo"

Note: Only last 3 actors kept in array for UI display
      Total count tracks all likes
```

## 5. Content Service Integration

```
┌─────────────────────────────────────────┐
│      Engagement Service                 │
│                                          │
│  Like Operation                          │
│  ───────────────                         │
│  1. Store like in PostgreSQL            │
│  2. Publish to NATS ✓                   │
│  3. Update Content Service ────────────┐│
│     (denormalized count)               ││
└────────────────────────────────────────┼┘
                                          │
                                          ▼
┌─────────────────────────────────────────┐
│      Content Service (Port 8003)        │
│                                          │
│  PATCH /api/internal/echoes/:id/likes   │
│  Body: {delta: 1}                       │
│                                          │
│  ┌─────────────────────────────────┐   │
│  │  1. Get echo from ScyllaDB      │   │
│  │     SELECT * FROM echoes        │   │
│  │     WHERE id = :id              │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  2. Calculate new count         │   │
│  │     new_count = old_count + 1   │   │
│  │     if new_count < 0: set to 0  │   │
│  └──────────┬──────────────────────┘   │
│             ▼                            │
│  ┌─────────────────────────────────┐   │
│  │  3. Update ScyllaDB             │   │
│  │     UPDATE echoes               │   │
│  │     SET like_count = new_count  │   │
│  │     WHERE id = :id              │   │
│  └──────────┬──────────────────────┘   │
└─────────────┼──────────────────────────┘
              │
              ▼
       ┌─────────────┐
       │   Success   │
       └─────────────┘

Benefits:
─────────
• Fast reads (no JOIN with likes table)
• Feed Service can show counts directly
• Eventually consistent (acceptable)
• Atomic operations prevent race conditions
```

## 6. System Architecture Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                     Ka Social Platform                            │
└──────────────────────────────────────────────────────────────────┘

┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│    Auth     │  │    User     │  │  Content    │  │    Feed     │
│  Service    │  │  Service    │  │  Service    │  │  Service    │
│  (Port      │  │  (Port      │  │  (Port      │  │  (Port      │
│   8001)     │  │   8002)     │  │   8003)     │  │   8004)     │
└─────┬───────┘  └─────┬───────┘  └─────┬───────┘  └─────┬───────┘
      │                │                │                │
      │                │                │                │
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│Interaction  │  │ Engagement  │  │ Discovery   │
│  Service    │  │  Service    │  │  Service    │
│  (Port      │  │  (Port      │  │  (Port      │
│   8005)     │  │   8007) ★   │  │   8008)     │
└─────┬───────┘  └─────┬───────┘  └─────────────┘
      │                │
      └────────┬───────┘
               │
─────────────────────────────────────────────────────
            Infrastructure Layer
─────────────────────────────────────────────────────

┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  PostgreSQL  │  │   ScyllaDB   │  │    Redis     │
│              │  │              │  │              │
│  • Users     │  │  • Echoes    │  │  • Timelines │
│  • Follows   │  │  • Stories   │  │  • Cache     │
│  • Likes ★   │  │  • Comments  │  │              │
│  • Notifs ★  │  │              │  │              │
└──────────────┘  └──────────────┘  └──────────────┘

       ┌──────────────────────────────┐
       │         NATS Server          │
       │                              │
       │  Subjects:                   │
       │  • echo.created              │
       │  • echo.deleted              │
       │  • echo.liked ★              │
       │  • user.followed ★           │
       └──────────────────────────────┘

★ = New in Engagement Service implementation
```

## 7. Event-Driven vs Synchronous Patterns

```
Pattern 1: Event-Driven (Engagement Service)
═══════════════════════════════════════════════

Advantages:
• Fast response to user (don't wait for processing)
• Loose coupling between services
• Easy to add new consumers
• Natural retry/replay capabilities
• Scales independently

┌────────┐      ┌──────────┐      ┌──────────┐
│ Client │─────▶│ Service  │─────▶│  Database│
└────────┘      └────┬─────┘      └──────────┘
                     │
                     ▼ (publish)
                ┌──────────┐
                │   NATS   │
                └────┬─────┘
                     │
        ┌────────────┼────────────┐
        ▼            ▼            ▼
   Consumer1    Consumer2    Consumer3
   (Notify)     (Analytics)  (Search)


Pattern 2: Synchronous (Interaction Service - Old)
═══════════════════════════════════════════════════

Advantages:
• Strong consistency
• Immediate confirmation
• Simple to understand

┌────────┐      ┌──────────┐      ┌──────────┐
│ Client │─────▶│ServiceA  │─────▶│ ServiceB │
└────────┘      └────┬─────┘      └──────────┘
                     │
                     ▼ (HTTP call)
                ┌──────────┐
                │ ServiceC │
                └──────────┘
                     │
                     ▼ (wait for all)
                Response


Migration Strategy:
═══════════════════

1. Keep synchronous for critical path (e.g., auth)
2. Use events for fan-out operations (e.g., notifications)
3. Use events for analytics and non-critical features
4. Monitor and optimize based on load
```

## Summary

The Engagement Service implements a sophisticated real-time notification system with:

1. **Fast Like Operations**: Single DB write + async processing
2. **Real-Time Delivery**: WebSocket push in <10ms
3. **Smart Aggregation**: Prevents notification spam
4. **Scalable Architecture**: Event-driven with NATS
5. **Denormalized Counts**: Fast reads for feeds
6. **Multiple Connections**: Support for multiple devices

All flows are designed for high performance and scalability while maintaining excellent user experience.
