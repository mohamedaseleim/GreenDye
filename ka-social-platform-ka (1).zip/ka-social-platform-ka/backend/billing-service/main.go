package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/database"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
	"github.com/nats-io/nats.go"
)

func main() {
	// Get environment variables
	port := getEnv("PORT", "8009")
	dbHost := getEnv("DB_HOST", "localhost")
	dbPort := getEnv("DB_PORT", "5432")
	dbUser := getEnv("DB_USER", "ka_user")
	dbPassword := getEnv("DB_PASSWORD", "ka_password")
	dbName := getEnv("DB_NAME", "ka_db")
	redisHost := getEnv("REDIS_HOST", "localhost")
	redisPort := getEnv("REDIS_PORT", "6379")
	redisPassword := getEnv("REDIS_PASSWORD", "")
	natsURL := getEnv("NATS_URL", "nats://localhost:4222")
	jwtSecret := getEnv("JWT_SECRET", "your-super-secret-jwt-key-change-in-production")
	
	// Stripe configuration
	stripeSecretKey := getEnv("STRIPE_SECRET_KEY", "")
	stripeWebhookKey := getEnv("STRIPE_WEBHOOK_SECRET", "")
	stripePriceID := getEnv("STRIPE_PRICE_ID", "")
	serviceURL := getEnv("SERVICE_URL", "http://localhost:8009")

	if stripeSecretKey == "" {
		log.Println("Warning: STRIPE_SECRET_KEY not set, Stripe integration will not work")
	}

	// Initialize database connections
	db, err := database.NewPostgresConnection(database.PostgresConfig{
		Host:     dbHost,
		Port:     dbPort,
		User:     dbUser,
		Password: dbPassword,
		DBName:   dbName,
	})
	if err != nil {
		log.Fatalf("Failed to connect to PostgreSQL: %v", err)
	}
	defer db.Close()

	redisClient, err := database.NewRedisConnection(database.RedisConfig{
		Host:     redisHost,
		Port:     redisPort,
		Password: redisPassword,
		DB:       0,
	})
	if err != nil {
		log.Fatalf("Failed to connect to Redis: %v", err)
	}
	defer redisClient.Close()

	// Initialize NATS connection
	natsConn, err := nats.Connect(natsURL)
	if err != nil {
		log.Printf("Warning: Failed to connect to NATS: %v (continuing without event publishing)", err)
	} else {
		defer natsConn.Close()
		log.Println("Successfully connected to NATS")
	}

	// Initialize Gin router
	router := gin.Default()

	// Add middleware
	router.Use(middleware.CORSMiddleware())
	router.Use(middleware.LoggerMiddleware())

	// Create config
	config := &Config{
		DB:               db,
		Redis:            redisClient,
		NATSConn:         natsConn,
		StripeSecretKey:  stripeSecretKey,
		StripeWebhookKey: stripeWebhookKey,
		StripePriceID:    stripePriceID,
		ServiceURL:       serviceURL,
	}

	// Initialize repositories and handlers
	repo := NewRepository(db, redisClient)
	handler := NewHandler(repo, config)

	// Setup routes
	SetupRoutes(router, handler, jwtSecret)

	// Health check endpoint
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"status":  "ok",
			"service": "billing-service",
		})
	})

	// Start server
	log.Printf("Billing service starting on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}

func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}
