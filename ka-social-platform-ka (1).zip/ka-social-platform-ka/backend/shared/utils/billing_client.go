package utils

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/google/uuid"
)

// BillingClient handles communication with the billing service
type BillingClient struct {
	baseURL    string
	httpClient *http.Client
}

// EntitlementsResponse represents the response from the billing service
type EntitlementsResponse struct {
	Success bool `json:"success"`
	Data    struct {
		UserID       uuid.UUID `json:"user_id"`
		Entitlements []string  `json:"entitlements"`
	} `json:"data"`
}

// NewBillingClient creates a new billing client
func NewBillingClient(baseURL string) *BillingClient {
	return &BillingClient{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 5 * time.Second,
		},
	}
}

// GetUserEntitlements fetches entitlements for a user from the billing service
func (c *BillingClient) GetUserEntitlements(ctx context.Context, userID uuid.UUID) ([]string, error) {
	url := fmt.Sprintf("%s/api/internal/billing/entitlements/%s", c.baseURL, userID.String())

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call billing service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("billing service returned status %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	var entitlementsResp EntitlementsResponse
	if err := json.Unmarshal(body, &entitlementsResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %w", err)
	}

	if !entitlementsResp.Success {
		return nil, fmt.Errorf("billing service returned error")
	}

	return entitlementsResp.Data.Entitlements, nil
}
