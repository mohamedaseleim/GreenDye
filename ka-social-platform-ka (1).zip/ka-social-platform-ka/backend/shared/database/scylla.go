package database

import (
	"fmt"
	"log"
	"strings"

	"github.com/gocql/gocql"
)

// ScyllaConfig holds the configuration for ScyllaDB connection
type ScyllaConfig struct {
	Hosts    string
	Keyspace string
	Username string
	Password string
}

// NewScyllaConnection creates a new ScyllaDB session
func NewScyllaConnection(config ScyllaConfig) (*gocql.Session, error) {
	hosts := strings.Split(config.Hosts, ",")
	
	cluster := gocql.NewCluster(hosts...)
	cluster.Keyspace = config.Keyspace
	cluster.Consistency = gocql.Quorum
	
	if config.Username != "" && config.Password != "" {
		cluster.Authenticator = gocql.PasswordAuthenticator{
			Username: config.Username,
			Password: config.Password,
		}
	}

	session, err := cluster.CreateSession()
	if err != nil {
		return nil, fmt.Errorf("failed to connect to ScyllaDB: %w", err)
	}

	log.Printf("Successfully connected to ScyllaDB at %s (keyspace: %s)", config.Hosts, config.Keyspace)
	return session, nil
}
