package main

import (
	"context"
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"github.com/redis/go-redis/v9"
)

// Repository handles database operations for billing
type Repository struct {
	db    *sqlx.DB
	redis *redis.Client
}

// NewRepository creates a new repository
func NewRepository(db *sqlx.DB, redis *redis.Client) *Repository {
	return &Repository{
		db:    db,
		redis: redis,
	}
}

// CreateSubscription creates a new subscription
func (r *Repository) CreateSubscription(sub *Subscription) error {
	query := `
		INSERT INTO subscriptions (
			id, user_id, stripe_customer_id, stripe_subscription_id, 
			status, current_period_start, current_period_end, 
			cancel_at_period_end, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
	`
	
	_, err := r.db.Exec(query,
		sub.ID, sub.UserID, sub.StripeCustomerID, sub.StripeSubscriptionID,
		sub.Status, sub.CurrentPeriodStart, sub.CurrentPeriodEnd,
		sub.CancelAtPeriodEnd, sub.CreatedAt, sub.UpdatedAt,
	)
	
	return err
}

// UpdateSubscription updates an existing subscription
func (r *Repository) UpdateSubscription(sub *Subscription) error {
	query := `
		UPDATE subscriptions 
		SET status = $1, current_period_start = $2, current_period_end = $3,
		    cancel_at_period_end = $4, updated_at = $5, canceled_at = $6
		WHERE stripe_subscription_id = $7
	`
	
	_, err := r.db.Exec(query,
		sub.Status, sub.CurrentPeriodStart, sub.CurrentPeriodEnd,
		sub.CancelAtPeriodEnd, sub.UpdatedAt, sub.CanceledAt,
		sub.StripeSubscriptionID,
	)
	
	return err
}

// GetSubscriptionByUserID gets a user's active subscription
func (r *Repository) GetSubscriptionByUserID(userID uuid.UUID) (*Subscription, error) {
	var sub Subscription
	query := `
		SELECT * FROM subscriptions 
		WHERE user_id = $1 
		ORDER BY created_at DESC 
		LIMIT 1
	`
	
	err := r.db.Get(&sub, query, userID)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	
	return &sub, err
}

// GetSubscriptionByStripeID gets a subscription by Stripe subscription ID
func (r *Repository) GetSubscriptionByStripeID(stripeSubID string) (*Subscription, error) {
	var sub Subscription
	query := `SELECT * FROM subscriptions WHERE stripe_subscription_id = $1`
	
	err := r.db.Get(&sub, query, stripeSubID)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	
	return &sub, err
}

// GrantEntitlement grants an entitlement to a user
func (r *Repository) GrantEntitlement(userID uuid.UUID, feature string, expiresAt *time.Time) error {
	query := `
		INSERT INTO entitlements (id, user_id, feature, granted_at, expires_at, created_at)
		VALUES ($1, $2, $3, $4, $5, $6)
		ON CONFLICT (user_id, feature) 
		DO UPDATE SET expires_at = $5, granted_at = $4
	`
	
	id := uuid.New()
	now := time.Now()
	
	_, err := r.db.Exec(query, id, userID, feature, now, expiresAt, now)
	return err
}

// RevokeEntitlement revokes an entitlement from a user
func (r *Repository) RevokeEntitlement(userID uuid.UUID, feature string) error {
	query := `DELETE FROM entitlements WHERE user_id = $1 AND feature = $2`
	_, err := r.db.Exec(query, userID, feature)
	return err
}

// GetUserEntitlements gets all entitlements for a user
func (r *Repository) GetUserEntitlements(userID uuid.UUID) ([]string, error) {
	query := `
		SELECT feature FROM entitlements 
		WHERE user_id = $1 
		AND (expires_at IS NULL OR expires_at > NOW())
	`
	
	var features []string
	err := r.db.Select(&features, query, userID)
	if err == sql.ErrNoRows {
		return []string{}, nil
	}
	
	return features, err
}

// CacheEntitlements caches entitlements in Redis
func (r *Repository) CacheEntitlements(ctx context.Context, userID uuid.UUID, entitlements []string) error {
	key := "entitlements:" + userID.String()
	
	// Convert to interface slice for Redis
	values := make([]interface{}, len(entitlements))
	for i, e := range entitlements {
		values[i] = e
	}
	
	// Clear existing cache
	r.redis.Del(ctx, key)
	
	// Cache for 5 minutes
	if len(values) > 0 {
		if err := r.redis.SAdd(ctx, key, values...).Err(); err != nil {
			return err
		}
		return r.redis.Expire(ctx, key, 5*time.Minute).Err()
	}
	
	return nil
}

// GetCachedEntitlements gets cached entitlements from Redis
func (r *Repository) GetCachedEntitlements(ctx context.Context, userID uuid.UUID) ([]string, error) {
	key := "entitlements:" + userID.String()
	return r.redis.SMembers(ctx, key).Result()
}

// InvalidateEntitlementsCache invalidates the entitlements cache for a user
func (r *Repository) InvalidateEntitlementsCache(ctx context.Context, userID uuid.UUID) error {
	key := "entitlements:" + userID.String()
	return r.redis.Del(ctx, key).Err()
}
