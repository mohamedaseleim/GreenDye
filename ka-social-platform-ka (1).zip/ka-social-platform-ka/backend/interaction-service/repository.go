package main

import (
	"database/sql"
	"fmt"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/redis/go-redis/v9"
)

// Repository handles database operations for interactions
type Repository struct {
	db    *sqlx.DB
	redis *redis.Client
}

// NewRepository creates a new repository
func NewRepository(db *sqlx.DB, redis *redis.Client) *Repository {
	return &Repository{
		db:    db,
		redis: redis,
	}
}

// Follow creates a follow relationship (idempotent)
func (r *Repository) Follow(followerID, followingID uuid.UUID) error {
	// Use INSERT ... ON CONFLICT DO NOTHING for idempotency
	query := `
		INSERT INTO follows (follower_id, following_id)
		VALUES ($1, $2)
		ON CONFLICT (follower_id, following_id) DO NOTHING
	`

	_, err := r.db.Exec(query, followerID, followingID)
	if err != nil {
		return fmt.Errorf("failed to create follow relationship: %w", err)
	}

	return nil
}

// Unfollow removes a follow relationship (idempotent)
func (r *Repository) Unfollow(followerID, followingID uuid.UUID) error {
	query := `
		DELETE FROM follows 
		WHERE follower_id = $1 AND following_id = $2
	`

	_, err := r.db.Exec(query, followerID, followingID)
	if err != nil {
		return fmt.Errorf("failed to remove follow relationship: %w", err)
	}

	return nil
}

// IsFollowing checks if a user is following another user
func (r *Repository) IsFollowing(followerID, followingID uuid.UUID) (bool, error) {
	var exists bool
	query := `SELECT EXISTS(SELECT 1 FROM follows WHERE follower_id = $1 AND following_id = $2)`
	err := r.db.Get(&exists, query, followerID, followingID)
	if err != nil {
		return false, fmt.Errorf("failed to check follow status: %w", err)
	}
	return exists, nil
}

// GetFollowers retrieves a list of followers for a user
func (r *Repository) GetFollowers(userID uuid.UUID, limit, offset int) ([]*models.UserShort, error) {
	var users []*models.UserShort
	query := `
		SELECT u.id, u.username, u.display_name, u.profile_picture_url, u.is_verified
		FROM users u
		INNER JOIN follows f ON u.id = f.follower_id
		WHERE f.following_id = $1
		ORDER BY f.created_at DESC
		LIMIT $2 OFFSET $3
	`

	err := r.db.Select(&users, query, userID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to get followers: %w", err)
	}

	return users, nil
}

// GetFollowing retrieves a list of users a user is following
func (r *Repository) GetFollowing(userID uuid.UUID, limit, offset int) ([]*models.UserShort, error) {
	var users []*models.UserShort
	query := `
		SELECT u.id, u.username, u.display_name, u.profile_picture_url, u.is_verified
		FROM users u
		INNER JOIN follows f ON u.id = f.following_id
		WHERE f.follower_id = $1
		ORDER BY f.created_at DESC
		LIMIT $2 OFFSET $3
	`

	err := r.db.Select(&users, query, userID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to get following: %w", err)
	}

	return users, nil
}

// CountFollowers counts the number of followers for a user
func (r *Repository) CountFollowers(userID uuid.UUID) (int64, error) {
	var count int64
	query := `SELECT COUNT(*) FROM follows WHERE following_id = $1`
	err := r.db.Get(&count, query, userID)
	if err != nil {
		return 0, fmt.Errorf("failed to count followers: %w", err)
	}
	return count, nil
}

// CountFollowing counts the number of users a user is following
func (r *Repository) CountFollowing(userID uuid.UUID) (int64, error) {
	var count int64
	query := `SELECT COUNT(*) FROM follows WHERE follower_id = $1`
	err := r.db.Get(&count, query, userID)
	if err != nil {
		return 0, fmt.Errorf("failed to count following: %w", err)
	}
	return count, nil
}

// UserExists checks if a user exists
func (r *Repository) UserExists(userID uuid.UUID) (bool, error) {
	var exists bool
	query := `SELECT EXISTS(SELECT 1 FROM users WHERE id = $1)`
	err := r.db.Get(&exists, query, userID)
	if err != nil && err != sql.ErrNoRows {
		return false, fmt.Errorf("failed to check user existence: %w", err)
	}
	return exists, nil
}

// Block creates a block relationship (idempotent)
func (r *Repository) Block(blockerID, blockedID uuid.UUID) error {
	// Use INSERT ... ON CONFLICT DO NOTHING for idempotency
	query := `
		INSERT INTO blocks (blocker_id, blocked_id)
		VALUES ($1, $2)
		ON CONFLICT (blocker_id, blocked_id) DO NOTHING
	`

	_, err := r.db.Exec(query, blockerID, blockedID)
	if err != nil {
		return fmt.Errorf("failed to create block relationship: %w", err)
	}

	return nil
}

// Unblock removes a block relationship (idempotent)
func (r *Repository) Unblock(blockerID, blockedID uuid.UUID) error {
	query := `
		DELETE FROM blocks 
		WHERE blocker_id = $1 AND blocked_id = $2
	`

	_, err := r.db.Exec(query, blockerID, blockedID)
	if err != nil {
		return fmt.Errorf("failed to remove block relationship: %w", err)
	}

	return nil
}

// IsBlocking checks if a user is blocking another user
func (r *Repository) IsBlocking(blockerID, blockedID uuid.UUID) (bool, error) {
	var exists bool
	query := `SELECT EXISTS(SELECT 1 FROM blocks WHERE blocker_id = $1 AND blocked_id = $2)`
	err := r.db.Get(&exists, query, blockerID, blockedID)
	if err != nil {
		return false, fmt.Errorf("failed to check block status: %w", err)
	}
	return exists, nil
}

// IsBlockedBy checks if a user is blocked by another user (reverse check)
func (r *Repository) IsBlockedBy(userID, blockerID uuid.UUID) (bool, error) {
	return r.IsBlocking(blockerID, userID)
}

// Mute creates a mute relationship (idempotent)
func (r *Repository) Mute(muterID, mutedID uuid.UUID) error {
	// Use INSERT ... ON CONFLICT DO NOTHING for idempotency
	query := `
		INSERT INTO mutes (muter_id, muted_id)
		VALUES ($1, $2)
		ON CONFLICT (muter_id, muted_id) DO NOTHING
	`

	_, err := r.db.Exec(query, muterID, mutedID)
	if err != nil {
		return fmt.Errorf("failed to create mute relationship: %w", err)
	}

	return nil
}

// Unmute removes a mute relationship (idempotent)
func (r *Repository) Unmute(muterID, mutedID uuid.UUID) error {
	query := `
		DELETE FROM mutes 
		WHERE muter_id = $1 AND muted_id = $2
	`

	_, err := r.db.Exec(query, muterID, mutedID)
	if err != nil {
		return fmt.Errorf("failed to remove mute relationship: %w", err)
	}

	return nil
}

// IsMuting checks if a user is muting another user
func (r *Repository) IsMuting(muterID, mutedID uuid.UUID) (bool, error) {
	var exists bool
	query := `SELECT EXISTS(SELECT 1 FROM mutes WHERE muter_id = $1 AND muted_id = $2)`
	err := r.db.Get(&exists, query, muterID, mutedID)
	if err != nil {
		return false, fmt.Errorf("failed to check mute status: %w", err)
	}
	return exists, nil
}

// GetBlockedUsers retrieves a list of users blocked by a user
func (r *Repository) GetBlockedUsers(userID uuid.UUID, limit, offset int) ([]*models.UserShort, error) {
	var users []*models.UserShort
	query := `
		SELECT u.id, u.username, u.display_name, u.profile_picture_url, u.is_verified
		FROM users u
		INNER JOIN blocks b ON u.id = b.blocked_id
		WHERE b.blocker_id = $1
		ORDER BY b.created_at DESC
		LIMIT $2 OFFSET $3
	`

	err := r.db.Select(&users, query, userID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to get blocked users: %w", err)
	}

	return users, nil
}

// GetMutedUsers retrieves a list of users muted by a user
func (r *Repository) GetMutedUsers(userID uuid.UUID, limit, offset int) ([]*models.UserShort, error) {
	var users []*models.UserShort
	query := `
		SELECT u.id, u.username, u.display_name, u.profile_picture_url, u.is_verified
		FROM users u
		INNER JOIN mutes m ON u.id = m.muted_id
		WHERE m.muter_id = $1
		ORDER BY m.created_at DESC
		LIMIT $2 OFFSET $3
	`

	err := r.db.Select(&users, query, userID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("failed to get muted users: %w", err)
	}

	return users, nil
}

// CountBlockedUsers counts the number of users blocked by a user
func (r *Repository) CountBlockedUsers(userID uuid.UUID) (int64, error) {
	var count int64
	query := `SELECT COUNT(*) FROM blocks WHERE blocker_id = $1`
	err := r.db.Get(&count, query, userID)
	if err != nil {
		return 0, fmt.Errorf("failed to count blocked users: %w", err)
	}
	return count, nil
}

// CountMutedUsers counts the number of users muted by a user
func (r *Repository) CountMutedUsers(userID uuid.UUID) (int64, error) {
	var count int64
	query := `SELECT COUNT(*) FROM mutes WHERE muter_id = $1`
	err := r.db.Get(&count, query, userID)
	if err != nil {
		return 0, fmt.Errorf("failed to count muted users: %w", err)
	}
	return count, nil
}

// GetBatchFollowStatus checks follow status for multiple users by a follower
func (r *Repository) GetBatchFollowStatus(followerID uuid.UUID, userIDs []uuid.UUID) (map[uuid.UUID]bool, error) {
	if len(userIDs) == 0 {
		return map[uuid.UUID]bool{}, nil
	}

	query := `
		SELECT following_id, true as is_following
		FROM follows
		WHERE follower_id = $1 AND following_id = ANY($2)
	`
	
	rows, err := r.db.Query(query, followerID, userIDs)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch batch follow status: %w", err)
	}
	defer rows.Close()

	result := make(map[uuid.UUID]bool)
	// Initialize all to false
	for _, userID := range userIDs {
		result[userID] = false
	}

	// Set followed ones to true
	for rows.Next() {
		var followingID uuid.UUID
		var isFollowing bool
		if err := rows.Scan(&followingID, &isFollowing); err != nil {
			return nil, fmt.Errorf("failed to scan follow status: %w", err)
		}
		result[followingID] = isFollowing
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating follow status rows: %w", err)
	}

	return result, nil
}
