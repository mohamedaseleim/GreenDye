package main

import (
	"context"
	"fmt"
	"log"
	"regexp"
	"strings"
	"time"

	"github.com/go-redis/redis/v8"
)

const (
	TrendingHashtagsKey = "trending:hashtags"
	HashtagTTL          = 24 * time.Hour
)

// TrendingService manages trending hashtags
type TrendingService struct {
	redis *redis.Client
}

// NewTrendingService creates a new trending service
func NewTrendingService(redisClient *redis.Client) *TrendingService {
	return &TrendingService{
		redis: redisClient,
	}
}

// HashtagInfo represents a trending hashtag with its count
type HashtagInfo struct {
	Tag   string  `json:"tag"`
	Count float64 `json:"count"`
}

// ExtractHashtags extracts hashtags from text content
func ExtractHashtags(content string) []string {
	// Match hashtags: # followed by alphanumeric characters (including Arabic, Unicode)
	re := regexp.MustCompile(`#[\p{L}\p{N}_]+`)
	matches := re.FindAllString(content, -1)
	
	hashtags := make([]string, 0, len(matches))
	seen := make(map[string]bool)
	
	for _, match := range matches {
		// Remove the # prefix and convert to lowercase
		tag := strings.ToLower(strings.TrimPrefix(match, "#"))
		if tag != "" && !seen[tag] {
			hashtags = append(hashtags, tag)
			seen[tag] = true
		}
	}
	
	return hashtags
}

// IncrementHashtags increments the count for hashtags
func (ts *TrendingService) IncrementHashtags(hashtags []string) error {
	if len(hashtags) == 0 {
		return nil
	}

	ctx := context.Background()
	now := float64(time.Now().Unix())

	// Use a pipeline for better performance
	pipe := ts.redis.Pipeline()

	for _, tag := range hashtags {
		// Increment the score for this hashtag
		pipe.ZIncrBy(ctx, TrendingHashtagsKey, 1, tag)
		
		// Also store the timestamp of this occurrence for potential time-decay
		timestampKey := fmt.Sprintf("trending:hashtag:%s:timestamps", tag)
		pipe.ZAdd(ctx, timestampKey, &redis.Z{
			Score:  now,
			Member: now, // Use timestamp as both score and member
		})
		pipe.Expire(ctx, timestampKey, HashtagTTL)
	}

	_, err := pipe.Exec(ctx)
	if err != nil {
		return fmt.Errorf("failed to increment hashtags: %w", err)
	}

	log.Printf("Incremented %d hashtags", len(hashtags))
	return nil
}

// GetTrendingHashtags returns the top trending hashtags
func (ts *TrendingService) GetTrendingHashtags(limit int) ([]HashtagInfo, error) {
	if limit <= 0 {
		limit = 10
	}

	ctx := context.Background()

	// Get top hashtags from the sorted set
	results, err := ts.redis.ZRevRangeWithScores(ctx, TrendingHashtagsKey, 0, int64(limit-1)).Result()
	if err != nil {
		return nil, fmt.Errorf("failed to get trending hashtags: %w", err)
	}

	hashtags := make([]HashtagInfo, 0, len(results))
	cutoffTime := float64(time.Now().Add(-HashtagTTL).Unix())

	for _, z := range results {
		tag := z.Member.(string)
		
		// Clean up old entries (sliding window)
		timestampKey := fmt.Sprintf("trending:hashtag:%s:timestamps", tag)
		ts.redis.ZRemRangeByScore(ctx, timestampKey, "0", fmt.Sprintf("%f", cutoffTime))
		
		// Get the count within the time window
		count, err := ts.redis.ZCard(ctx, timestampKey).Result()
		if err != nil || count == 0 {
			// If no recent activity, remove from trending
			ts.redis.ZRem(ctx, TrendingHashtagsKey, tag)
			continue
		}

		hashtags = append(hashtags, HashtagInfo{
			Tag:   tag,
			Count: float64(count),
		})
	}

	log.Printf("Retrieved %d trending hashtags", len(hashtags))
	return hashtags, nil
}

// CleanupOldHashtags removes hashtags that haven't been used recently
func (ts *TrendingService) CleanupOldHashtags() error {
	ctx := context.Background()
	cutoffTime := float64(time.Now().Add(-HashtagTTL).Unix())

	// Get all hashtags
	allTags, err := ts.redis.ZRange(ctx, TrendingHashtagsKey, 0, -1).Result()
	if err != nil {
		return fmt.Errorf("failed to get all hashtags: %w", err)
	}

	for _, tag := range allTags {
		timestampKey := fmt.Sprintf("trending:hashtag:%s:timestamps", tag)
		
		// Remove old timestamps
		ts.redis.ZRemRangeByScore(ctx, timestampKey, "0", fmt.Sprintf("%f", cutoffTime))
		
		// Check if any timestamps remain
		count, err := ts.redis.ZCard(ctx, timestampKey).Result()
		if err != nil || count == 0 {
			// Remove from trending if no recent activity
			ts.redis.ZRem(ctx, TrendingHashtagsKey, tag)
			ts.redis.Del(ctx, timestampKey)
		}
	}

	log.Println("Completed trending hashtags cleanup")
	return nil
}
