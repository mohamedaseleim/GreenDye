package main

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
)

// NATSPublisher handles publishing events to NATS
type NATSPublisher struct {
	conn *nats.Conn
}

// NewNATSPublisher creates a new NATS publisher
func NewNATSPublisher(url string) (*NATSPublisher, error) {
	conn, err := nats.Connect(url)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to NATS: %w", err)
	}

	log.Printf("Successfully connected to NATS at %s", url)
	return &NATSPublisher{conn: conn}, nil
}

// Close closes the NATS connection
func (p *NATSPublisher) Close() {
	if p.conn != nil {
		p.conn.Close()
	}
}

// GetConn returns the NATS connection
func (p *NATSPublisher) GetConn() *nats.Conn {
	return p.conn
}

// EchoCreatedEvent represents an echo.created event
type EchoCreatedEvent struct {
	EchoID       string   `json:"echo_id"`
	UserID       string   `json:"user_id"`
	Content      string   `json:"content"`
	Hashtags     []string `json:"hashtags"`
	LikesCount   int      `json:"likes_count"`
	Visibility   string   `json:"visibility"`
	Timestamp    string   `json:"timestamp"`
	ParentEchoID *string  `json:"parent_echo_id,omitempty"`
}

// EchoDeletedEvent represents an echo.deleted event
type EchoDeletedEvent struct {
	EchoID    string `json:"echo_id"`
	UserID    string `json:"user_id"`
	Timestamp string `json:"timestamp"`
}

// EchoUpdatedEvent represents an echo.updated event
type EchoUpdatedEvent struct {
	EchoID     string `json:"echo_id"`
	LikesCount int    `json:"likes_count"`
	Timestamp  string `json:"timestamp"`
}

// PublishEchoCreated publishes an echo.created event
func (p *NATSPublisher) PublishEchoCreated(echo *EchoCreatedEvent) error {
	data, err := json.Marshal(echo)
	if err != nil {
		return fmt.Errorf("failed to marshal echo.created event: %w", err)
	}

	if err := p.conn.Publish("echo.created", data); err != nil {
		return fmt.Errorf("failed to publish echo.created event: %w", err)
	}

	log.Printf("Published echo.created event: echo_id=%s, user_id=%s", echo.EchoID, echo.UserID)
	return nil
}

// PublishEchoDeleted publishes an echo.deleted event
func (p *NATSPublisher) PublishEchoDeleted(echoID, userID uuid.UUID) error {
	event := EchoDeletedEvent{
		EchoID:    echoID.String(),
		UserID:    userID.String(),
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal echo.deleted event: %w", err)
	}

	if err := p.conn.Publish("echo.deleted", data); err != nil {
		return fmt.Errorf("failed to publish echo.deleted event: %w", err)
	}

	log.Printf("Published echo.deleted event: echo_id=%s, user_id=%s", echoID, userID)
	return nil
}

// PublishEchoUpdated publishes an echo.updated event
func (p *NATSPublisher) PublishEchoUpdated(echoID uuid.UUID, likesCount int) error {
	event := EchoUpdatedEvent{
		EchoID:     echoID.String(),
		LikesCount: likesCount,
		Timestamp:  time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal echo.updated event: %w", err)
	}

	if err := p.conn.Publish("echo.updated", data); err != nil {
		return fmt.Errorf("failed to publish echo.updated event: %w", err)
	}

	log.Printf("Published echo.updated event: echo_id=%s, likes_count=%d", echoID, likesCount)
	return nil
}
