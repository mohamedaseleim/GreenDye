# Discovery Service - Quick Start Guide

Get the Discovery Service up and running in minutes.

## Prerequisites

- Docker and Docker Compose installed
- Go 1.24+ (for local development)

## Starting the Service

### Option 1: Docker Compose (Recommended)

Start all services including Discovery Service:

```bash
cd infrastructure/docker
docker compose up -d
```

Wait for services to be healthy:

```bash
docker compose ps
```

The Discovery Service will be available at `http://localhost:8008`

### Option 2: Local Development

1. Start infrastructure services:
```bash
cd infrastructure/docker
docker compose up -d postgres redis scylla nats meilisearch
```

2. Run the Discovery Service locally:
```bash
cd backend/discovery-service
go run .
```

## Quick Test

### 1. Health Check

```bash
curl http://localhost:8008/health
```

Expected:
```json
{
  "status": "healthy",
  "service": "discovery-service"
}
```

### 2. Search (initially empty)

```bash
curl "http://localhost:8008/api/v1/search?q=test"
```

### 3. Trending Hashtags (initially empty)

```bash
curl "http://localhost:8008/api/v1/discover/trending"
```

## Populating Data

The Discovery Service indexes data from events. To populate:

### 1. Create a User

```bash
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "johndoe",
    "email": "john@example.com",
    "password": "password123",
    "display_name": "John Doe"
  }'
```

Wait 2-3 seconds for indexing.

### 2. Search for the User

```bash
curl "http://localhost:8008/api/v1/search?q=johndoe" | jq '.data.users'
```

You should see the user in search results!

### 3. Create an Echo with Hashtags

First, login to get a token:

```bash
TOKEN=$(curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }' | jq -r '.data.access_token')
```

Create an echo:

```bash
curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "content": "Hello world! This is my first echo #tech #programming",
    "visibility": "public"
  }'
```

Wait 2-3 seconds for indexing.

### 4. Search for the Echo

```bash
curl "http://localhost:8008/api/v1/search?q=tech" | jq '.data.echoes'
```

### 5. Check Trending Hashtags

```bash
curl "http://localhost:8008/api/v1/discover/trending" | jq '.data.trending_hashtags'
```

You should see "tech" and "programming" in the trending list!

## Common Operations

### Search with Limit

```bash
curl "http://localhost:8008/api/v1/search?q=john&limit=10"
```

### Autocomplete

```bash
curl "http://localhost:8008/api/v1/search/suggest?q=jo&limit=5"
```

### Get Top 20 Trending Hashtags

```bash
curl "http://localhost:8008/api/v1/discover/trending?limit=20"
```

## Monitoring

### Check Logs

```bash
docker compose logs -f discovery-service
```

Look for:
- `Successfully connected to NATS`
- `NATS consumer started`
- `Published echo.created event` (from content service)
- `User indexed: ...`
- `Echo indexed: ...`

### Check Meilisearch

```bash
# List indexes
curl "http://localhost:7700/indexes" \
  -H "Authorization: Bearer masterKey123" | jq '.'

# Check users index
curl "http://localhost:7700/indexes/users/stats" \
  -H "Authorization: Bearer masterKey123" | jq '.numberOfDocuments'

# Check echoes index
curl "http://localhost:7700/indexes/echoes/stats" \
  -H "Authorization: Bearer masterKey123" | jq '.numberOfDocuments'
```

### Check Redis Trending Data

```bash
docker compose exec redis redis-cli -a ka_redis_password

# Inside Redis CLI:
ZREVRANGE trending:hashtags 0 10 WITHSCORES
```

## Troubleshooting

### No search results after creating content?

1. Check if Discovery Service is running:
   ```bash
   docker compose ps discovery-service
   ```

2. Check if events are being published:
   ```bash
   docker compose logs content-service | grep "Published"
   ```

3. Check if Discovery Service is consuming events:
   ```bash
   docker compose logs discovery-service | grep "indexed"
   ```

4. Restart Discovery Service:
   ```bash
   docker compose restart discovery-service
   ```

### Meilisearch not responding?

```bash
# Check Meilisearch health
curl http://localhost:7700/health

# Restart Meilisearch
docker compose restart meilisearch
```

### NATS connection issues?

```bash
# Check NATS status
curl http://localhost:8222/healthz

# Check NATS connections
curl http://localhost:8222/connz | jq '.connections'
```

## Performance Testing

### Search Performance

```bash
# Install Apache Bench (ab) if not available
# sudo apt-get install apache2-utils

# Run 100 requests with 10 concurrent
ab -n 100 -c 10 "http://localhost:8008/api/v1/search?q=test"
```

### Autocomplete Performance

```bash
ab -n 100 -c 10 "http://localhost:8008/api/v1/search/suggest?q=jo"
```

## Next Steps

- Read the full documentation: `backend/discovery-service/README.md`
- Follow the testing guide: `backend/discovery-service/TESTING.md`
- Review the architecture: `docs/ARCHITECTURE.md`
- Explore the API with Postman or similar tools

## Clean Up

To stop all services:

```bash
docker compose down
```

To remove all data (including indexes):

```bash
docker compose down -v
```

## Support

For issues or questions:
1. Check the logs: `docker compose logs [service-name]`
2. Review the TESTING.md troubleshooting section
3. Verify all services are healthy: `docker compose ps`
