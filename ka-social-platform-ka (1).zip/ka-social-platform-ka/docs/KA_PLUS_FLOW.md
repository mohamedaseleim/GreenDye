# Ka+ Subscription Flow Diagrams

Visual representations of the Ka+ subscription and entitlements system.

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Ka+ System Architecture                   │
└─────────────────────────────────────────────────────────────────┘

┌──────────┐         ┌──────────┐         ┌───────────────┐
│  Client  │         │  Stripe  │         │  PostgreSQL   │
│  (App)   │         │ Checkout │         │   Database    │
└────┬─────┘         └────┬─────┘         └───────┬───────┘
     │                    │                        │
     │                    │                        │
     ▼                    ▼                        ▼
┌────────────┐      ┌──────────┐           ┌──────────┐
│    Auth    │◄────►│ Billing  │◄─────────►│  Redis   │
│  Service   │      │ Service  │           │  Cache   │
└────┬───────┘      └────┬─────┘           └──────────┘
     │                   │
     │                   │
     │                   ├──────────────────────────┐
     │                   │                          │
     ▼                   ▼                          ▼
┌──────────┐       ┌──────────┐              ┌──────────┐
│   User   │       │ Content  │              │Engagement│
│ Service  │       │ Service  │              │ Service  │
└──────────┘       └──────────┘              └──────────┘
     │                   │                          │
     ▼                   ▼                          ▼
[Profile Badge]   [Extended Uploads]      [Advanced Analytics]
```

## User Subscription Journey

### 1. User Upgrade Flow

```
User clicks "Upgrade to Ka+"
         │
         ▼
┌────────────────────────────────────────┐
│ POST /api/v1/billing/checkout         │
│ Authorization: Bearer <jwt>           │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Billing Service                        │
│ • Check if user has subscription       │
│ • Create/retrieve Stripe customer      │
│ • Create Checkout Session              │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Return Checkout URL                    │
│ {                                      │
│   "session_url": "https://..."        │
│ }                                      │
└──────────────┬─────────────────────────┘
               │
               ▼
User redirected to Stripe Checkout
         │
         ▼
User enters payment details
         │
         ▼
Payment processed successfully
         │
         ▼
┌────────────────────────────────────────┐
│ Stripe Webhook → Billing Service      │
│ Event: customer.subscription.created   │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Billing Service Processing             │
│ 1. Create subscription record          │
│ 2. Grant entitlements:                 │
│    • PROFILE_BADGE                     │
│    • EXTENDED_UPLOADS                  │
│    • ADVANCED_ANALYTICS                │
│ 3. Publish subscription.activated      │
│ 4. Invalidate cache                    │
└──────────────┬─────────────────────────┘
               │
               ▼
User Ka+ subscription is active!
```

### 2. Login with Entitlements Flow

```
User enters credentials
         │
         ▼
┌────────────────────────────────────────┐
│ POST /api/auth/login                   │
│ {                                      │
│   "email": "user@example.com",         │
│   "password": "********"               │
│ }                                      │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Auth Service                           │
│ 1. Validate credentials                │
│ 2. Fetch user from database            │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ GET /api/internal/billing/             │
│     entitlements/{user_id}             │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Billing Service                        │
│ 1. Check Redis cache                   │
│ 2. If miss, query PostgreSQL           │
│ 3. Return entitlements array           │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Entitlements: [                        │
│   "PROFILE_BADGE",                     │
│   "EXTENDED_UPLOADS",                  │
│   "ADVANCED_ANALYTICS"                 │
│ ]                                      │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Auth Service                           │
│ • Generate JWT with entitlements       │
│ • Sign with secret key                 │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Return JWT to Client                   │
│ {                                      │
│   "access_token": "eyJhbGci...",       │
│   "expires_in": 900                    │
│ }                                      │
└────────────────────────────────────────┘
         │
         ▼
JWT Payload:
{
  "sub": "user_id",
  "username": "johndoe",
  "entitlements": [
    "PROFILE_BADGE",
    "EXTENDED_UPLOADS",
    "ADVANCED_ANALYTICS"
  ],
  "exp": 1234567890
}
```

### 3. Feature Access Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    User Makes API Request                        │
└─────────────────────────────────────────────────────────────────┘

Example: Create echo with 4 images
         │
         ▼
┌────────────────────────────────────────┐
│ POST /api/v1/echoes                    │
│ Authorization: Bearer eyJhbGci...      │
│ {                                      │
│   "content": "Great photos!",          │
│   "media_attachments": [1,2,3,4]       │
│ }                                      │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Auth Middleware                        │
│ 1. Extract JWT from header             │
│ 2. Validate signature                  │
│ 3. Decode claims                       │
│ 4. Add to context:                     │
│    • user_id                           │
│    • entitlements array                │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Content Service Handler                │
│ 1. Get entitlements from context       │
│ 2. Check for EXTENDED_UPLOADS          │
└──────────────┬─────────────────────────┘
               │
         ┌─────┴─────┐
         │           │
         ▼           ▼
    [Has]         [No]
         │           │
         │           ▼
         │    ┌──────────────────┐
         │    │ Max: 1 image     │
         │    │ Provided: 4      │
         │    │ → Error 400      │
         │    └──────────────────┘
         │
         ▼
┌────────────────────────────────────────┐
│ Max: 4 images                          │
│ Provided: 4                            │
│ → Continue processing                  │
└────────────────────────────────────────┘
         │
         ▼
Validate media ownership
         │
         ▼
Create echo in database
         │
         ▼
Publish echo.created event
         │
         ▼
Return success response
```

## Entitlement Check Performance

```
┌──────────────────────────────────────────────────────────────┐
│            Performance Comparison: Traditional vs JWT         │
└──────────────────────────────────────────────────────────────┘

Traditional Approach (every request):
─────────────────────────────────────
Request → Service → Database Query → Response
                    ↑
                    └─ 10-50ms per check

Total: ~50ms per feature check
Scalability: Limited by database

JWT Approach (Ka+ system):
──────────────────────────
Request → Service → Local JWT Inspection → Response
                    ↑
                    └─ <1ms per check

Total: <1ms per feature check
Scalability: Unlimited (stateless)

Performance Gain: 50x faster! ⚡
```

## Caching Strategy

```
┌──────────────────────────────────────────────────────────────┐
│                   Entitlement Caching Flow                    │
└──────────────────────────────────────────────────────────────┘

Auth Service requests entitlements
         │
         ▼
┌────────────────────────────────────────┐
│ GET /api/internal/billing/             │
│     entitlements/{user_id}             │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Billing Service                        │
│ Check Redis:                           │
│   Key: entitlements:{user_id}          │
└──────────────┬─────────────────────────┘
               │
         ┌─────┴─────┐
         │           │
      [Hit]       [Miss]
         │           │
         │           ▼
         │    ┌──────────────────────────┐
         │    │ Query PostgreSQL         │
         │    │ SELECT feature           │
         │    │ FROM entitlements        │
         │    │ WHERE user_id = ?        │
         │    └──────┬───────────────────┘
         │           │
         │           ▼
         │    ┌──────────────────────────┐
         │    │ Cache in Redis           │
         │    │ TTL: 5 minutes           │
         │    └──────┬───────────────────┘
         │           │
         └───────┬───┘
                 │
                 ▼
Return entitlements to Auth Service
         │
         ▼
Embed in JWT (valid for 15 minutes)
```

## Event-Driven Cache Invalidation

```
┌──────────────────────────────────────────────────────────────┐
│              Subscription Status Change Flow                  │
└──────────────────────────────────────────────────────────────┘

User cancels subscription
         │
         ▼
Stripe webhook triggered
         │
         ▼
┌────────────────────────────────────────┐
│ POST /api/v1/billing/webhook           │
│ Event: customer.subscription.deleted   │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Billing Service                        │
│ 1. Update subscription status          │
│ 2. Revoke all entitlements             │
│    DELETE FROM entitlements            │
└──────────────┬─────────────────────────┘
               │
               ├──────────────┬─────────────────┐
               │              │                 │
               ▼              ▼                 ▼
      ┌──────────────┐ ┌──────────┐   ┌──────────────┐
      │ Invalidate   │ │ Publish  │   │ Update       │
      │ Redis Cache  │ │ to NATS  │   │ Database     │
      └──────────────┘ └──────────┘   └──────────────┘
               │              │                 │
               └──────┬───────┴─────────────────┘
                      │
                      ▼
    All services notified of change
    (if they subscribe to events)
                      │
                      ▼
         Next login gets fresh JWT
         with empty entitlements array
```

## Multi-Service Feature Gating

```
┌──────────────────────────────────────────────────────────────┐
│           How Different Services Use Entitlements            │
└──────────────────────────────────────────────────────────────┘

                    ┌──────────┐
                    │   JWT    │
                    │with ents │
                    └────┬─────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
         ▼               ▼               ▼
    ┌─────────┐    ┌─────────┐    ┌──────────┐
    │  User   │    │Content  │    │Engagement│
    │ Service │    │ Service │    │ Service  │
    └────┬────┘    └────┬────┘    └────┬─────┘
         │              │              │
         ▼              ▼              ▼
┌─────────────────────────────────────────────┐
│ Get entitlements from context:              │
│ entitlements := utils.GetEntitlementsFrom   │
│                Context(c)                   │
└─────────────────────────────────────────────┘
         │              │              │
         ▼              ▼              ▼
┌─────────────┐  ┌───────────┐  ┌──────────────┐
│Check for:   │  │Check for: │  │Check for:    │
│PROFILE_BADGE│  │EXTENDED_  │  │ADVANCED_     │
│             │  │UPLOADS    │  │ANALYTICS     │
└─────┬───────┘  └─────┬─────┘  └──────┬───────┘
      │                │                │
      ▼                ▼                ▼
[Show badge]    [Allow 4 imgs]   [Show analytics]
```

## Token Refresh with Updated Entitlements

```
User token expires (after 15 minutes)
         │
         ▼
Client sends refresh token
         │
         ▼
┌────────────────────────────────────────┐
│ POST /api/auth/refresh                 │
│ {                                      │
│   "refresh_token": "eyJhbGci..."       │
│ }                                      │
└──────────────┬─────────────────────────┘
               │
               ▼
┌────────────────────────────────────────┐
│ Auth Service                           │
│ 1. Validate refresh token              │
│ 2. Get user ID                         │
└──────────────┬─────────────────────────┘
               │
               ▼
Fetch fresh entitlements from Billing Service
(in case subscription changed)
               │
               ▼
Generate new JWT with updated entitlements
               │
               ▼
┌────────────────────────────────────────┐
│ Return new access token                │
│ {                                      │
│   "access_token": "eyJhbGci...",       │
│   "expires_in": 900                    │
│ }                                      │
└────────────────────────────────────────┘

This ensures:
• Entitlements stay fresh
• Maximum staleness: 15 minutes (JWT expiry)
• No manual refresh needed
• Automatic on token refresh
```

## Summary

The Ka+ system uses a multi-layered approach to ensure:

1. **Performance**: JWT-based checks are <1ms
2. **Freshness**: Entitlements updated every 15 minutes (JWT expiry)
3. **Reliability**: Redis caching reduces database load
4. **Scalability**: Stateless design allows horizontal scaling
5. **Consistency**: Event-driven cache invalidation
6. **Security**: Cryptographically signed JWTs

This architecture supports millions of requests per second while maintaining data consistency and user experience.
