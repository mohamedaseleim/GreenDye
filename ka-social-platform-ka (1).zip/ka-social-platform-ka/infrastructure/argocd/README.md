# Argo CD Setup for Ka Platform

This directory contains the Argo CD configuration for the Ka Platform GitOps workflow.

## Installation

### 1. Install Argo CD

```bash
# Create the argocd namespace
kubectl create namespace argocd

# Install Argo CD
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for Argo CD to be ready
kubectl wait --for=condition=available --timeout=300s deployment/argocd-server -n argocd
```

### 2. Access Argo CD UI

```bash
# Port forward to access the UI
kubectl port-forward svc/argocd-server -n argocd 8080:443

# Get the admin password
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d && echo
```

Access the UI at: https://localhost:8080
- Username: `admin`
- Password: (from the command above)

### 3. Deploy Ka Platform Application

```bash
# Apply the Ka Platform Application manifest
kubectl apply -f ka-platform-application.yaml

# Watch the deployment
kubectl get application -n argocd
kubectl get pods -n ka-platform -w
```

## GitOps Workflow

1. **Code Changes**: Developers push code changes to the repository
2. **CI Pipeline**: GitHub Actions builds Docker images and pushes them to the registry
3. **Update Values**: CI pipeline updates `charts/ka-platform/values.yaml` with new image tags
4. **Auto Sync**: Argo CD detects changes and automatically syncs the cluster
5. **Deployment**: New pods are rolled out with zero downtime

## Argo CD CLI

Install the Argo CD CLI for advanced operations:

```bash
# Linux
curl -sSL -o /usr/local/bin/argocd https://github.com/argoproj/argo-cd/releases/latest/download/argocd-linux-amd64
chmod +x /usr/local/bin/argocd

# macOS
brew install argocd

# Login
argocd login localhost:8080 --username admin --password <password>

# List applications
argocd app list

# Sync application manually
argocd app sync ka-platform

# Get application status
argocd app get ka-platform

# View logs
argocd app logs ka-platform
```

## Troubleshooting

### Application is OutOfSync

```bash
# Check the diff
argocd app diff ka-platform

# Force sync
argocd app sync ka-platform --force

# Check sync status
argocd app get ka-platform --refresh
```

### Pods are not starting

```bash
# Check pods
kubectl get pods -n ka-platform

# Check events
kubectl get events -n ka-platform --sort-by='.lastTimestamp'

# Check logs
kubectl logs -n ka-platform deployment/auth-service
```

### Image pull errors

```bash
# Check image pull secrets
kubectl get secrets -n ka-platform

# Verify image exists
docker pull ghcr.io/mohamedaseleim/ka-social-platform/auth-service:latest
```

## Advanced Configuration

### Enable Notifications

Configure Argo CD notifications for Slack, email, etc:

```bash
kubectl apply -n argocd -f argocd-notifications-cm.yaml
```

### Enable SSO

Configure Dex for SSO with GitHub, Google, etc:

```bash
kubectl edit configmap argocd-cm -n argocd
```

### Resource Tracking

Argo CD tracks resources using labels and annotations. All deployed resources will have:

- Label: `app.kubernetes.io/instance=ka-platform`
- Annotation: `argocd.argoproj.io/tracking-id`

## Best Practices

1. **Version Control**: Always commit values.yaml changes
2. **Image Tags**: Use semantic versioning, not `latest`
3. **Secrets**: Use external secret management (Sealed Secrets, External Secrets Operator)
4. **Health Checks**: Define custom health checks for CRDs
5. **Sync Waves**: Use sync waves for ordered deployment
6. **Hooks**: Use hooks for pre/post sync operations

## References

- [Argo CD Documentation](https://argo-cd.readthedocs.io/)
- [Argo CD Best Practices](https://argo-cd.readthedocs.io/en/stable/user-guide/best_practices/)
- [GitOps Principles](https://www.gitops.tech/)
