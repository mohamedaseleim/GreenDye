-- Add media service columns to users table
-- These columns store the CDN-ready URLs for different image sizes

ALTER TABLE users 
ADD COLUMN IF NOT EXISTS avatar_url_medium TEXT,
ADD COLUMN IF NOT EXISTS avatar_url_thumb TEXT;

-- Add comments for documentation
COMMENT ON COLUMN users.profile_picture_url IS 'Original uploaded avatar URL';
COMMENT ON COLUMN users.avatar_url_medium IS 'Medium-sized avatar (600x600) in WebP format';
COMMENT ON COLUMN users.avatar_url_thumb IS 'Thumbnail avatar (150x150) in WebP format';
