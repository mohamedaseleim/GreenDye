package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"path/filepath"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
)

// Handler handles HTTP requests for the media service
type Handler struct {
	storage *StorageService
	config  *Config
}

// NewHandler creates a new handler
func NewHandler(storage *StorageService, config *Config) *Handler {
	return &Handler{
		storage: storage,
		config:  config,
	}
}

// UploadRequestBody represents the request body for upload request
type UploadRequestBody struct {
	Filename    string `json:"filename" binding:"required"`
	ContentType string `json:"content_type" binding:"required"`
}

// UploadRequestResponse represents the response for upload request
type UploadRequestResponse struct {
	UploadURL string `json:"upload_url"`
	ObjectKey string `json:"object_key"`
	ExpiresIn int    `json:"expires_in"`
}

// RequestUpload generates a presigned URL for direct upload
func (h *Handler) RequestUpload(c *gin.Context) {
	// Get user ID from context (set by auth middleware)
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	var req UploadRequestBody
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	// Validate content type (only images for now)
	if !isValidImageContentType(req.ContentType) {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_CONTENT_TYPE",
			"Only image files are supported",
			nil,
		))
		return
	}

	// Generate unique object key
	ext := filepath.Ext(req.Filename)
	objectKey := fmt.Sprintf("uploads/%s/%s%s", userIDStr, uuid.New().String(), ext)

	// Generate presigned URL
	presignedURL, err := h.storage.GeneratePresignedUploadURL(objectKey, req.ContentType)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"PRESIGNED_URL_ERROR",
			"Failed to generate upload URL",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(UploadRequestResponse{
		UploadURL: presignedURL,
		ObjectKey: objectKey,
		ExpiresIn: h.config.PresignedURLExpiry,
	}))
}

// UploadCompleteBody represents the request body for upload complete notification
type UploadCompleteBody struct {
	ObjectKey string `json:"object_key" binding:"required"`
}

// NotifyUploadComplete notifies the service that an upload is complete
func (h *Handler) NotifyUploadComplete(c *gin.Context) {
	// Get user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	var req UploadCompleteBody
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	// Verify the object key belongs to the user
	if !strings.HasPrefix(req.ObjectKey, fmt.Sprintf("uploads/%s/", userIDStr)) {
		c.JSON(http.StatusForbidden, models.ErrorResponse(
			"UNAUTHORIZED_OBJECT",
			"You don't have permission to process this object",
			nil,
		))
		return
	}

	// Publish media.processing.required event to NATS
	event := MediaProcessingEvent{
		ObjectKey:   req.ObjectKey,
		UserID:      userIDStr.(string),
		ContentType: "image/jpeg", // We'll detect this properly later
		UploadedAt:  time.Now().Unix(),
	}

	eventData, err := json.Marshal(event)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"EVENT_MARSHAL_ERROR",
			"Failed to create processing event",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	if err := h.config.NATSConn.Publish("media.processing.required", eventData); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"EVENT_PUBLISH_ERROR",
			"Failed to queue media processing",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(map[string]interface{}{
		"message":    "Media processing queued successfully",
		"object_key": req.ObjectKey,
	}))
}

// isValidImageContentType checks if the content type is a valid image type
func isValidImageContentType(contentType string) bool {
	validTypes := []string{
		"image/jpeg",
		"image/jpg",
		"image/png",
		"image/gif",
		"image/webp",
	}

	for _, validType := range validTypes {
		if strings.EqualFold(contentType, validType) {
			return true
		}
	}
	return false
}

// ValidateMediaRequest represents a media validation request
type ValidateMediaRequest struct {
	MediaKeys []string `json:"media_keys" binding:"required"`
	UserID    string   `json:"user_id" binding:"required"`
}

// ValidateMediaResponse represents a media validation response
type ValidateMediaResponse struct {
	Valid   bool     `json:"valid"`
	Message string   `json:"message,omitempty"`
	Invalid []string `json:"invalid,omitempty"`
}

// ValidateMedia validates that media keys exist and belong to the user
func (h *Handler) ValidateMedia(c *gin.Context) {
	var req ValidateMediaRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	// Validate each media key
	invalidKeys := []string{}
	for _, mediaKey := range req.MediaKeys {
		// Check ownership
		owned, err := h.storage.ValidateMediaOwnership(mediaKey, req.UserID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, models.ErrorResponse(
				"VALIDATION_ERROR",
				"Failed to validate media ownership",
				map[string]interface{}{"error": err.Error(), "media_key": mediaKey},
			))
			return
		}
		
		if !owned {
			invalidKeys = append(invalidKeys, mediaKey)
		}
	}

	// If any keys are invalid, return failure
	if len(invalidKeys) > 0 {
		c.JSON(http.StatusOK, models.SuccessResponse(ValidateMediaResponse{
			Valid:   false,
			Message: "Some media keys are invalid or not owned by user",
			Invalid: invalidKeys,
		}))
		return
	}

	// All valid
	c.JSON(http.StatusOK, models.SuccessResponse(ValidateMediaResponse{
		Valid:   true,
		Message: "All media keys are valid",
	}))
}

// GetMediaDetailsRequest represents a request to get media details
type GetMediaDetailsRequest struct {
	MediaKeys []string `json:"media_keys" binding:"required"`
}

// MediaDetail represents details about a media object
type MediaDetail struct {
	MediaKey string `json:"media_key"`
	URL      string `json:"url"`
	Exists   bool   `json:"exists"`
}

// GetMediaDetailsResponse represents media details response
type GetMediaDetailsResponse struct {
	Media []MediaDetail `json:"media"`
}

// GetMediaDetails returns URLs for media keys
func (h *Handler) GetMediaDetails(c *gin.Context) {
	var req GetMediaDetailsRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			map[string]interface{}{"error": err.Error()},
		))
		return
	}

	mediaDetails := make([]MediaDetail, 0, len(req.MediaKeys))
	for _, mediaKey := range req.MediaKeys {
		exists, err := h.storage.ObjectExists(mediaKey)
		if err != nil {
			// Log error but continue processing other keys
			exists = false
		}
		
		detail := MediaDetail{
			MediaKey: mediaKey,
			URL:      h.storage.GetObjectURL(mediaKey),
			Exists:   exists,
		}
		mediaDetails = append(mediaDetails, detail)
	}

	c.JSON(http.StatusOK, models.SuccessResponse(GetMediaDetailsResponse{
		Media: mediaDetails,
	}))
}
