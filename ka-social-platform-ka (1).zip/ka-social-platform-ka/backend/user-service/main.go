package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/database"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/trustsafety"
	"github.com/nats-io/nats.go"
)

func main() {
	// Get environment variables
	port := getEnv("PORT", "8002")
	dbHost := getEnv("DB_HOST", "localhost")
	dbPort := getEnv("DB_PORT", "5432")
	dbUser := getEnv("DB_USER", "ka_user")
	dbPassword := getEnv("DB_PASSWORD", "ka_password")
	dbName := getEnv("DB_NAME", "ka_db")
	redisHost := getEnv("REDIS_HOST", "localhost")
	redisPort := getEnv("REDIS_PORT", "6379")
	redisPassword := getEnv("REDIS_PASSWORD", "")
	jwtSecret := getEnv("JWT_SECRET", "your-super-secret-jwt-key-change-in-production")
	natsURL := getEnv("NATS_URL", "nats://localhost:4222")
	billingServiceURL := getEnv("BILLING_SERVICE_URL", "http://localhost:8009")

	// Initialize database connections
	db, err := database.NewPostgresConnection(database.PostgresConfig{
		Host:     dbHost,
		Port:     dbPort,
		User:     dbUser,
		Password: dbPassword,
		DBName:   dbName,
	})
	if err != nil {
		log.Fatalf("Failed to connect to PostgreSQL: %v", err)
	}
	defer db.Close()

	redisClient, err := database.NewRedisConnection(database.RedisConfig{
		Host:     redisHost,
		Port:     redisPort,
		Password: redisPassword,
		DB:       0,
	})
	if err != nil {
		log.Fatalf("Failed to connect to Redis: %v", err)
	}
	defer redisClient.Close()

	// Initialize NATS connection
	natsConn, err := nats.Connect(natsURL)
	if err != nil {
		log.Printf("Warning: Failed to connect to NATS: %v (continuing without event publishing)", err)
	} else {
		defer natsConn.Close()
		log.Println("Successfully connected to NATS")
	}

	// Initialize Gin router
	router := gin.Default()

	// Add middleware
	router.Use(middleware.CORSMiddleware())
	router.Use(middleware.LoggerMiddleware())

	// Create config
	config := &Config{
		DB:                db,
		Redis:             redisClient,
		JWTSecret:         jwtSecret,
		NATSConn:          natsConn,
		BillingServiceURL: billingServiceURL,
	}

	// Initialize repositories and handlers
	repo := NewRepository(db, redisClient)
	handler := NewHandler(repo, config)

	// Initialize and start media consumer
	if natsConn != nil {
		mediaConsumer := NewMediaConsumer(natsConn, repo)
		if err := mediaConsumer.Start(); err != nil {
			log.Printf("Warning: Failed to start media consumer: %v", err)
		}

		// Initialize Trust & Safety consumer
		tsConsumer := trustsafety.NewEventConsumer(natsConn, redisClient, "user-service")
		if err := tsConsumer.Start(); err != nil {
			log.Printf("Warning: Failed to start Trust & Safety consumer: %v", err)
		}
	}

	// Setup routes
	SetupRoutes(router, handler)

	// Health check endpoint
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"status":  "ok",
			"service": "user-service",
		})
	})

	// Start server
	log.Printf("User service starting on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}

func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if value == "" {
		return defaultValue
	}
	return value
}
