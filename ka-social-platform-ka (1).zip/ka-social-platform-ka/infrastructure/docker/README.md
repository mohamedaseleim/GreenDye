# Ka Infrastructure - Docker Setup

This directory contains Docker configuration for local development and testing.

## Services

- **PostgreSQL**: Primary relational database
- **Redis**: Caching layer
- **ScyllaDB**: NoSQL database for posts, timelines, and messages
- **All Backend Services**: Auth, User, Content, Feed, Interaction, Messaging, Notification, Discovery

## Quick Start

### 1. Start Infrastructure Only (Database Services)

```bash
docker-compose up -d postgres redis scylla
```

Wait for services to be healthy (especially ScyllaDB, which takes 1-2 minutes):

```bash
docker-compose ps
```

### 2. Start All Services (Including Application Services)

```bash
docker-compose up -d
```

### 3. View Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f auth-service
docker-compose logs -f postgres
```

### 4. Stop Services

```bash
# Stop all services
docker-compose down

# Stop and remove volumes (data will be lost)
docker-compose down -v
```

## Database Initialization

### PostgreSQL

The PostgreSQL database is automatically initialized with the schema defined in `init-scripts/postgres/01-init.sql`. This includes:

- Users table
- Follows table (social graph)
- Blocks table
- Conversations table
- Notification settings
- Refresh tokens
- Email verifications
- Password resets

### ScyllaDB

ScyllaDB is initialized with the schema defined in `init-scripts/scylla/01-init.cql`. This includes:

**Keyspaces:**
- `ka_content`: For echoes, stories, comments, likes, bookmarks, trending topics
- `ka_messages`: For messages and conversations
- `ka_notifications`: For notifications

**Note:** ScyllaDB initialization script needs to be run manually after the container starts:

```bash
# Wait for ScyllaDB to be ready (check health)
docker-compose exec scylla nodetool status

# Run initialization script
docker-compose exec scylla cqlsh -f /docker-entrypoint-initdb.d/01-init.cql
```

Or use the helper script:

```bash
cd ../scripts
./init-scylla.sh
```

### Redis

Redis doesn't require initialization. It's used for:
- Session caching
- User profile caching
- Feed caching
- Token blacklisting
- Online status tracking

## Accessing Services

### PostgreSQL

```bash
# Using docker-compose exec
docker-compose exec postgres psql -U ka_user -d ka_db

# Using psql client (if installed)
psql -h localhost -p 5432 -U ka_user -d ka_db
# Password: ka_password
```

Useful queries:

```sql
-- List all tables
\dt

-- Count users
SELECT COUNT(*) FROM users;

-- View recent users
SELECT id, username, email, created_at FROM users ORDER BY created_at DESC LIMIT 10;
```

### Redis

```bash
# Using docker-compose exec
docker-compose exec redis redis-cli -a ka_redis_password

# Using redis-cli (if installed)
redis-cli -h localhost -p 6379 -a ka_redis_password
```

Useful commands:

```bash
# Ping
PING

# List all keys
KEYS *

# Get a key
GET user:profile:uuid

# Check cache size
DBSIZE
```

### ScyllaDB

```bash
# Using docker-compose exec
docker-compose exec scylla cqlsh

# Using cqlsh (if installed)
cqlsh localhost 9042
```

Useful queries:

```cql
-- List keyspaces
DESCRIBE KEYSPACES;

-- Use a keyspace
USE ka_content;

-- List tables
DESCRIBE TABLES;

-- Count echoes
SELECT COUNT(*) FROM echoes;

-- View recent echoes
SELECT id, user_id, content, created_at FROM echoes LIMIT 10;
```

## Service Health Checks

```bash
# Check if all services are healthy
docker-compose ps

# Check specific service health
docker-compose exec postgres pg_isready -U ka_user
docker-compose exec redis redis-cli -a ka_redis_password ping
docker-compose exec scylla nodetool status
```

## Networking

All services are connected via the `ka-network` bridge network. This allows services to communicate with each other using service names as hostnames.

Example:
- Auth service can connect to PostgreSQL at `postgres:5432`
- Content service can connect to ScyllaDB at `scylla:9042`
- All services can connect to Redis at `redis:6379`

## Volumes

Data is persisted in Docker volumes:

- `postgres_data`: PostgreSQL data
- `redis_data`: Redis data (AOF persistence)
- `scylla_data`: ScyllaDB data

To view volumes:

```bash
docker volume ls | grep ka
```

To remove volumes (will delete all data):

```bash
docker-compose down -v
```

## Resource Limits

For development, the following resource limits are set:

- **ScyllaDB**: 512MB memory (can be increased in production)
- **PostgreSQL**: Default Docker limits
- **Redis**: Default Docker limits

For production deployment, increase these limits based on your needs.

## Troubleshooting

### ScyllaDB Won't Start

ScyllaDB requires more resources than other services. If it fails to start:

1. Check Docker resources (Settings → Resources)
2. Increase memory limit for ScyllaDB in `docker-compose.yml`
3. Wait longer for the health check (it can take 2-3 minutes)

```bash
# Check ScyllaDB logs
docker-compose logs scylla

# Check ScyllaDB status
docker-compose exec scylla nodetool status
```

### PostgreSQL Connection Refused

Wait for PostgreSQL to be fully ready:

```bash
# Check health
docker-compose ps postgres

# Check logs
docker-compose logs postgres

# Test connection
docker-compose exec postgres pg_isready -U ka_user
```

### Redis Connection Issues

Check if Redis is running with authentication:

```bash
# Check health
docker-compose ps redis

# Test connection
docker-compose exec redis redis-cli -a ka_redis_password ping
```

### Services Can't Connect to Databases

Ensure all infrastructure services are healthy before starting application services:

```bash
# Start infra only
docker-compose up -d postgres redis scylla

# Wait for health checks
docker-compose ps

# Then start app services
docker-compose up -d
```

## Environment Variables

You can override environment variables by creating a `.env` file:

```bash
# .env file example
DB_PASSWORD=your_secure_password
REDIS_PASSWORD=your_redis_password
JWT_SECRET=your_jwt_secret_key
```

## Production Notes

**Do NOT use these configurations in production!**

For production:
1. Use strong, unique passwords
2. Enable SSL/TLS for all connections
3. Set up proper networking and firewalls
4. Use managed database services or proper clustering
5. Implement proper backup strategies
6. Use Kubernetes with proper resource limits
7. Enable authentication for ScyllaDB
8. Set up monitoring and alerting

## Next Steps

1. Initialize ScyllaDB with the initialization script
2. Test services with sample data
3. Set up API Gateway (Nginx/Traefik)
4. Add monitoring (Prometheus + Grafana)
5. Add centralized logging (ELK stack or Loki)
