package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes configures the API routes
func SetupRoutes(router *gin.Engine, handler *Handler, jwtSecret string) {
	api := router.Group("/api")
	{
		v1 := api.Group("/v1")
		{
			// Feed endpoints (require authentication)
			feed := v1.Group("/feed")
			feed.Use(middleware.AuthMiddleware(jwtSecret))
			{
				feed.GET("/home", handler.GetHomeFeed)
			}
		}
	}
}
