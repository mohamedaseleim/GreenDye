package trustsafety

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
)

// Client provides high-level Trust & Safety checking with cache fallback
type Client struct {
	cacheManager          *CacheManager
	interactionServiceURL string
	httpClient            *http.Client
}

// NewClient creates a new Trust & Safety client
func NewClient(redis *redis.Client, interactionServiceURL string) *Client {
	return &Client{
		cacheManager:          NewCacheManager(redis, 0), // Use default TTL
		interactionServiceURL: interactionServiceURL,
		httpClient:            &http.Client{},
	}
}

// IsBlocked checks if there's a block relationship between two users
// Uses cache first, falls back to Interaction Service if cache miss
func (c *Client) IsBlocked(ctx context.Context, user1ID, user2ID uuid.UUID) (bool, error) {
	// Check cache first
	isBlocked, cacheHit, err := c.cacheManager.IsBlockedCached(ctx, user1ID, user2ID)
	if err != nil {
		// Log error but continue to check Interaction Service
		// This ensures we don't fail requests due to Redis issues
	}
	if cacheHit {
		return isBlocked, nil
	}

	// Cache miss - check Interaction Service
	isBlocked, err = c.checkBlockStatusFromService(user1ID, user2ID)
	if err != nil {
		return false, fmt.Errorf("failed to check block status from service: %w", err)
	}

	// Update cache with result
	_ = c.cacheManager.CacheBlockStatus(ctx, user1ID, user2ID, isBlocked)

	return isBlocked, nil
}

// IsMuted checks if user1 is muting user2
// Uses cache first, falls back to Interaction Service if cache miss
func (c *Client) IsMuted(ctx context.Context, muterID, mutedID uuid.UUID) (bool, error) {
	// Check cache first
	isMuted, cacheHit, err := c.cacheManager.IsMutedCached(ctx, muterID, mutedID)
	if err != nil {
		// Log error but continue to check Interaction Service
	}
	if cacheHit {
		return isMuted, nil
	}

	// Cache miss - check Interaction Service
	isMuted, err = c.checkMuteStatusFromService(muterID, mutedID)
	if err != nil {
		return false, fmt.Errorf("failed to check mute status from service: %w", err)
	}

	// Update cache with result
	_ = c.cacheManager.CacheMuteStatus(ctx, muterID, mutedID, isMuted)

	return isMuted, nil
}

// checkBlockStatusFromService checks block status from Interaction Service
func (c *Client) checkBlockStatusFromService(user1ID, user2ID uuid.UUID) (bool, error) {
	url := fmt.Sprintf("%s/api/internal/block-status?user1_id=%s&user2_id=%s",
		c.interactionServiceURL, user1ID.String(), user2ID.String())

	resp, err := c.httpClient.Get(url)
	if err != nil {
		return false, fmt.Errorf("failed to call interaction service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return false, fmt.Errorf("interaction service returned status %d: %s", resp.StatusCode, string(body))
	}

	var result struct {
		Success bool `json:"success"`
		Data    struct {
			Blocked bool `json:"blocked"`
		} `json:"data"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return false, fmt.Errorf("failed to decode response: %w", err)
	}

	return result.Data.Blocked, nil
}

// checkMuteStatusFromService checks mute status from Interaction Service
func (c *Client) checkMuteStatusFromService(muterID, mutedID uuid.UUID) (bool, error) {
	url := fmt.Sprintf("%s/api/internal/mute-status?muter_id=%s&muted_id=%s",
		c.interactionServiceURL, muterID.String(), mutedID.String())

	resp, err := c.httpClient.Get(url)
	if err != nil {
		return false, fmt.Errorf("failed to call interaction service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return false, fmt.Errorf("interaction service returned status %d: %s", resp.StatusCode, string(body))
	}

	var result struct {
		Success bool `json:"success"`
		Data    struct {
			Muted bool `json:"muted"`
		} `json:"data"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return false, fmt.Errorf("failed to decode response: %w", err)
	}

	return result.Data.Muted, nil
}
