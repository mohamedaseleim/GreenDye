package main

import (
	"encoding/json"
	"fmt"
	"log"

	"github.com/google/uuid"
	"github.com/meilisearch/meilisearch-go"
)

const (
	UsersIndexName  = "users"
	EchoesIndexName = "echoes"
)

// SearchService handles Meilisearch operations
type SearchService struct {
	client *meilisearch.Client
}

// NewSearchService creates a new search service
func NewSearchService(client *meilisearch.Client) *SearchService {
	return &SearchService{
		client: client,
	}
}

// UserDocument represents a user document in Meilisearch
type UserDocument struct {
	ID                string `json:"id"`
	Username          string `json:"username"`
	DisplayName       string `json:"display_name"`
	Bio               string `json:"bio"`
	FollowerCount     int    `json:"follower_count"`
	IsVerified        bool   `json:"is_verified"`
	ProfilePictureURL string `json:"profile_picture_url"`
	CreatedAt         int64  `json:"created_at"` // Unix timestamp for sorting
}

// EchoDocument represents an echo document in Meilisearch
type EchoDocument struct {
	ID          string   `json:"id"`
	UserID      string   `json:"user_id"`
	Content     string   `json:"content"`
	Hashtags    []string `json:"hashtags"`
	LikesCount  int      `json:"likes_count"`
	CreatedAt   int64    `json:"created_at"` // Unix timestamp for sorting
	Visibility  string   `json:"visibility"`
}

// InitializeIndexes creates and configures Meilisearch indexes
func (s *SearchService) InitializeIndexes() error {
	// Create users index
	usersIndex := s.client.Index(UsersIndexName)
	
	// Configure users index settings
	usersSettings := &meilisearch.Settings{
		RankingRules: []string{
			"words",
			"typo",
			"proximity",
			"attribute",
			"sort",
			"exactness",
			"follower_count:desc", // Custom ranking: more followers = higher rank
		},
		SearchableAttributes: []string{
			"username",
			"display_name",
			"bio",
		},
		FilterableAttributes: []string{
			"is_verified",
			"follower_count",
		},
		SortableAttributes: []string{
			"follower_count",
			"created_at",
		},
	}
	
	if _, err := usersIndex.UpdateSettings(usersSettings); err != nil {
		log.Printf("Warning: Failed to update users index settings: %v", err)
	}
	
	log.Println("Users index configured with follower_count ranking")

	// Create echoes index
	echoesIndex := s.client.Index(EchoesIndexName)
	
	// Configure echoes index settings
	echoesSettings := &meilisearch.Settings{
		RankingRules: []string{
			"words",
			"typo",
			"proximity",
			"attribute",
			"sort",
			"exactness",
			"likes_count:desc",  // Custom ranking: more likes = higher rank
			"created_at:desc",   // Secondary: more recent = higher rank
		},
		SearchableAttributes: []string{
			"content",
			"hashtags",
		},
		FilterableAttributes: []string{
			"user_id",
			"visibility",
			"hashtags",
			"likes_count",
			"created_at",
		},
		SortableAttributes: []string{
			"likes_count",
			"created_at",
		},
	}
	
	if _, err := echoesIndex.UpdateSettings(echoesSettings); err != nil {
		log.Printf("Warning: Failed to update echoes index settings: %v", err)
	}
	
	log.Println("Echoes index configured with likes_count and created_at ranking")
	
	return nil
}

// IndexUser indexes or updates a user document
func (s *SearchService) IndexUser(userDoc UserDocument) error {
	index := s.client.Index(UsersIndexName)
	
	documents := []UserDocument{userDoc}
	task, err := index.AddDocuments(documents)
	if err != nil {
		return fmt.Errorf("failed to index user: %w", err)
	}
	
	log.Printf("User indexed: %s (task: %d)", userDoc.ID, task.TaskUID)
	return nil
}

// IndexEcho indexes or updates an echo document
func (s *SearchService) IndexEcho(echoDoc EchoDocument) error {
	index := s.client.Index(EchoesIndexName)
	
	documents := []EchoDocument{echoDoc}
	task, err := index.AddDocuments(documents)
	if err != nil {
		return fmt.Errorf("failed to index echo: %w", err)
	}
	
	log.Printf("Echo indexed: %s (task: %d)", echoDoc.ID, task.TaskUID)
	return nil
}

// DeleteEcho removes an echo from the index
func (s *SearchService) DeleteEcho(echoID uuid.UUID) error {
	index := s.client.Index(EchoesIndexName)
	
	task, err := index.DeleteDocument(echoID.String())
	if err != nil {
		return fmt.Errorf("failed to delete echo from index: %w", err)
	}
	
	log.Printf("Echo deleted from index: %s (task: %d)", echoID, task.TaskUID)
	return nil
}

// SearchRequest represents a search query
type SearchRequest struct {
	Query  string
	Limit  int
	Offset int
}

// SearchResult represents search results
type SearchResult struct {
	Users  []UserDocument `json:"users"`
	Echoes []EchoDocument `json:"echoes"`
	Hits   int            `json:"hits"`
}

// Search performs a multi-index search
func (s *SearchService) Search(req SearchRequest) (*SearchResult, error) {
	if req.Limit == 0 {
		req.Limit = 20
	}

	result := &SearchResult{
		Users:  []UserDocument{},
		Echoes: []EchoDocument{},
	}

	// Search users
	usersIndex := s.client.Index(UsersIndexName)
	usersSearchRes, err := usersIndex.Search(req.Query, &meilisearch.SearchRequest{
		Limit:  int64(req.Limit),
		Offset: int64(req.Offset),
	})
	if err != nil {
		log.Printf("Warning: Users search failed: %v", err)
	} else {
		for _, hit := range usersSearchRes.Hits {
			var user UserDocument
			data, _ := json.Marshal(hit)
			if err := json.Unmarshal(data, &user); err == nil {
				result.Users = append(result.Users, user)
			}
		}
	}

	// Search echoes (only public visibility)
	echoesIndex := s.client.Index(EchoesIndexName)
	echoesSearchRes, err := echoesIndex.Search(req.Query, &meilisearch.SearchRequest{
		Limit:  int64(req.Limit),
		Offset: int64(req.Offset),
		Filter: "visibility = public",
	})
	if err != nil {
		log.Printf("Warning: Echoes search failed: %v", err)
	} else {
		for _, hit := range echoesSearchRes.Hits {
			var echo EchoDocument
			data, _ := json.Marshal(hit)
			if err := json.Unmarshal(data, &echo); err == nil {
				result.Echoes = append(result.Echoes, echo)
			}
		}
	}

	result.Hits = len(result.Users) + len(result.Echoes)
	return result, nil
}

// AutocompleteRequest represents an autocomplete query
type AutocompleteRequest struct {
	Query string
	Limit int
}

// AutocompleteResult represents autocomplete suggestions
type AutocompleteResult struct {
	Users  []UserDocument `json:"users"`
	Echoes []EchoDocument `json:"echoes"`
}

// Autocomplete provides type-ahead suggestions
func (s *SearchService) Autocomplete(req AutocompleteRequest) (*AutocompleteResult, error) {
	if req.Limit == 0 {
		req.Limit = 5
	}

	result := &AutocompleteResult{
		Users:  []UserDocument{},
		Echoes: []EchoDocument{},
	}

	// Get user suggestions
	usersIndex := s.client.Index(UsersIndexName)
	usersSearchRes, err := usersIndex.Search(req.Query, &meilisearch.SearchRequest{
		Limit: int64(req.Limit),
	})
	if err != nil {
		log.Printf("Warning: Users autocomplete failed: %v", err)
	} else {
		for _, hit := range usersSearchRes.Hits {
			var user UserDocument
			data, _ := json.Marshal(hit)
			if err := json.Unmarshal(data, &user); err == nil {
				result.Users = append(result.Users, user)
			}
		}
	}

	return result, nil
}

// UpdateEchoLikesCount updates the likes count for an echo in the index
func (s *SearchService) UpdateEchoLikesCount(echoID uuid.UUID, likesCount int) error {
	index := s.client.Index(EchoesIndexName)
	
	// Get the existing document first
	var docMap map[string]interface{}
	err := index.GetDocument(echoID.String(), nil, &docMap)
	if err != nil {
		return fmt.Errorf("failed to get echo document: %w", err)
	}
	
	// Update the likes count
	docMap["likes_count"] = likesCount
	
	// Re-index the document
	task, err := index.UpdateDocuments([]interface{}{docMap})
	if err != nil {
		return fmt.Errorf("failed to update echo likes count: %w", err)
	}
	
	log.Printf("Echo likes count updated: %s -> %d (task: %d)", echoID, likesCount, task.TaskUID)
	return nil
}
