package main

import (
	"github.com/gin-gonic/gin"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/middleware"
)

// SetupRoutes sets up the routes for the auth service
func SetupRoutes(router *gin.Engine, handler *Handler) {
	api := router.Group("/api/auth")
	{
		// Public routes (no authentication required)
		api.POST("/register", handler.Register)
		api.POST("/login", handler.Login)
		api.POST("/refresh", handler.RefreshToken)

		// Protected routes (authentication required)
		protected := api.Group("")
		protected.Use(middleware.AuthMiddleware(handler.config.JWTSecret))
		{
			protected.POST("/logout", handler.Logout)
		}
	}
}
