# Ka Platform - Google Cloud Deployment Guide

Complete guide to deploying the Ka Social Platform on Google Cloud Platform (GCP) with Google Kubernetes Engine (GKE).

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [GCP Project Setup](#gcp-project-setup)
3. [Quick Deployment](#quick-deployment)
4. [Detailed Deployment Steps](#detailed-deployment-steps)
5. [Post-Deployment Configuration](#post-deployment-configuration)
6. [Accessing the Application](#accessing-the-application)
7. [Monitoring and Observability](#monitoring-and-observability)
8. [Production Considerations](#production-considerations)
9. [Troubleshooting](#troubleshooting)
10. [Cost Estimation](#cost-estimation)

---

## Prerequisites

### Local Tools Required
- **Google Cloud SDK (gcloud CLI)**: [Install Guide](https://cloud.google.com/sdk/docs/install)
- **Terraform**: v1.5.0 or later [Install Guide](https://developer.hashicorp.com/terraform/downloads)
- **kubectl**: v1.28 or later [Install Guide](https://kubernetes.io/docs/tasks/tools/)
- **Helm**: v3.13 or later [Install Guide](https://helm.sh/docs/intro/install/)
- **Git**: For repository management

### GCP Account Requirements
- Active GCP account with billing enabled
- Project Owner or Editor role (or sufficient IAM permissions)
- Sufficient quota for:
  - Compute Engine instances (minimum 12 vCPUs)
  - Cloud SQL instances
  - VPC networks
  - Load Balancers

---

## GCP Project Setup

### Step 1: Create or Select a GCP Project

```bash
# Login to Google Cloud
gcloud auth login

# Create a new project (or use existing)
export PROJECT_ID="ka-platform-prod"  # Change to your preferred project ID
export PROJECT_NAME="Ka Social Platform"
gcloud projects create $PROJECT_ID --name="$PROJECT_NAME"

# Set as default project
gcloud config set project $PROJECT_ID

# Verify
gcloud config get-value project
```

### Step 2: Enable Billing

```bash
# List billing accounts
gcloud billing accounts list

# Link billing account to project (replace BILLING_ACCOUNT_ID with your ID)
export BILLING_ACCOUNT_ID="YOUR-BILLING-ACCOUNT-ID"
gcloud billing projects link $PROJECT_ID --billing-account=$BILLING_ACCOUNT_ID

# Verify billing is enabled
gcloud billing projects describe $PROJECT_ID
```

### Step 3: Enable Required APIs

```bash
# Enable all required GCP APIs
gcloud services enable \
  compute.googleapis.com \
  container.googleapis.com \
  sqladmin.googleapis.com \
  redis.googleapis.com \
  storage-api.googleapis.com \
  cloudresourcemanager.googleapis.com \
  servicenetworking.googleapis.com

# Verify APIs are enabled
gcloud services list --enabled
```

### Step 4: Set Up Application Default Credentials

```bash
# Create application default credentials for Terraform
gcloud auth application-default login

# Verify credentials
gcloud auth application-default print-access-token
```

### Step 5: Check Resource Quotas

```bash
# Check compute quotas in your region
gcloud compute project-info describe --project=$PROJECT_ID

# If you need quota increases, submit a request:
# https://console.cloud.google.com/iam-admin/quotas
```

---

## Quick Deployment

For experienced users, here's the fast track (15-20 minutes):

```bash
# 1. Clone repository
git clone https://github.com/mohamedaseleim/ka-social-platform.git
cd ka-social-platform

# 2. Set up GCP project (if not done already)
export PROJECT_ID="ka-platform-prod"
gcloud config set project $PROJECT_ID

# 3. Run deployment script
chmod +x infrastructure/scripts/deploy-gcp.sh
./infrastructure/scripts/deploy-gcp.sh

# 4. Follow the prompts and wait for completion
```

---

## Detailed Deployment Steps

### Step 1: Configure Terraform Variables

```bash
# Navigate to GCP terraform directory
cd terraform/gcp

# Copy example configuration
cp terraform.tfvars.example terraform.tfvars

# Edit configuration with your values
nano terraform.tfvars  # or use your preferred editor
```

**Recommended terraform.tfvars for Production:**

```hcl
# Required: Your GCP Project ID
project_id = "ka-platform-prod"  # REPLACE WITH YOUR PROJECT ID

# Cluster Configuration
cluster_name       = "ka-platform-prod"
region             = "us-central1"  # Choose region close to your users
node_zones         = ["us-central1-a", "us-central1-b", "us-central1-c"]
kubernetes_version = "1.28"
environment        = "production"

# Network Configuration
subnet_cidr    = "10.10.0.0/24"
pods_cidr      = "10.20.0.0/16"
services_cidr  = "10.30.0.0/16"

# Node Pool Configuration
node_machine_type   = "e2-standard-4"  # 4 vCPUs, 16 GB RAM per node
node_disk_size      = 100              # GB per node
node_count_per_zone = 1                # 3 nodes total (1 per zone)
min_node_count      = 1
max_node_count      = 3                # Max 9 nodes total with autoscaling

# Managed Databases (recommended for production)
use_managed_databases = true
db_tier              = "db-custom-2-7680"  # 2 vCPUs, 7.5 GB RAM
db_password          = "CHANGE_THIS_SECURE_PASSWORD_123!"
redis_memory_size_gb = 1

# Object Storage (optional - use Cloud Storage instead of MinIO)
use_cloud_storage = false  # Set to true for production at scale
```

**For Development/Staging (Cost-Optimized):**

```hcl
project_id = "ka-platform-dev"

cluster_name       = "ka-platform-dev"
region             = "us-central1"
node_zones         = ["us-central1-a"]
kubernetes_version = "1.28"
environment        = "development"

node_machine_type   = "e2-standard-2"  # 2 vCPUs, 8 GB RAM
node_disk_size      = 50
node_count_per_zone = 1
min_node_count      = 1
max_node_count      = 2

use_managed_databases = false  # Use in-cluster databases
db_password          = "dev_password_change_me"
redis_memory_size_gb = 1
use_cloud_storage    = false
```

### Step 2: Initialize and Apply Terraform

```bash
# Initialize Terraform (downloads providers)
terraform init

# Validate configuration
terraform validate

# Preview changes
terraform plan

# Apply configuration (provisions infrastructure)
terraform apply

# Type 'yes' when prompted
# ⏱️ This takes approximately 10-15 minutes
```

**What gets created:**
- GKE cluster (regional, 3 zones for HA)
- VPC network with subnets
- Node pool with autoscaling
- Cloud SQL PostgreSQL instance (if enabled)
- Cloud Memorystore Redis (if enabled)
- Cloud Storage bucket (if enabled)
- Static IP address for ingress
- IAM roles and service accounts

### Step 3: Configure kubectl

```bash
# Get cluster credentials
eval $(terraform output -raw kubeconfig_command)

# Verify cluster access
kubectl get nodes

# Expected output: 3 nodes in Ready state
kubectl get nodes -o wide
```

### Step 4: Save Important Outputs

```bash
# Save all Terraform outputs for reference
terraform output > ../../outputs.txt

# View specific outputs
terraform output cluster_name
terraform output ingress_ip
terraform output kubeconfig_command

# Save ingress IP for DNS configuration later
export INGRESS_IP=$(terraform output -raw ingress_ip)
echo "Ingress IP: $INGRESS_IP"
```

### Step 5: Install Argo CD

```bash
# Return to repository root
cd ../..

# Create Argo CD namespace
kubectl create namespace argocd

# Install Argo CD
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for Argo CD to be ready (2-3 minutes)
kubectl wait --for=condition=available --timeout=300s \
  deployment/argocd-server -n argocd

# Get Argo CD admin password
kubectl -n argocd get secret argocd-initial-admin-secret \
  -o jsonpath="{.data.password}" | base64 -d && echo

# Save this password - you'll need it to access Argo CD UI
```

### Step 6: Configure Secrets

Before deploying the application, you need to configure secrets:

```bash
# Edit the Helm values file
nano charts/ka-platform/values.yaml

# Update the following secrets (look for the 'secrets' section):
# - jwtSecret: Generate with: openssl rand -base64 32
# - postgresPassword: Your secure password
# - redisPassword: Your secure password
# - minioAccessKey: Generate with: openssl rand -base64 16
# - minioSecretKey: Generate with: openssl rand -base64 32
# - meilisearchApiKey: Generate with: openssl rand -base64 32
```

**Quick secret generation:**

```bash
# Generate all secrets at once
echo "JWT Secret: $(openssl rand -base64 32)"
echo "Postgres Password: $(openssl rand -base64 16)"
echo "Redis Password: $(openssl rand -base64 16)"
echo "MinIO Access Key: $(openssl rand -base64 16)"
echo "MinIO Secret Key: $(openssl rand -base64 32)"
echo "Meilisearch API Key: $(openssl rand -base64 32)"
```

**If using Cloud SQL (managed PostgreSQL):**

```bash
# Update database connection in values.yaml to use Cloud SQL
# Get the connection details:
cd terraform/gcp
terraform output postgres_connection_name
terraform output postgres_ip
cd ../..

# Update values.yaml:
# postgres:
#   host: "<postgres_ip_from_output>"
#   port: 5432
```

### Step 7: Deploy Ka Platform Application

```bash
# Make sure you're in the repository root
pwd  # Should show: /path/to/ka-social-platform

# Apply the Argo CD application manifest
kubectl apply -f infrastructure/argocd/ka-platform-application.yaml

# Verify application is created
kubectl get application -n argocd

# Watch the sync process
watch kubectl get application -n argocd
# Wait until STATUS shows: Healthy & Synced

# Watch pods being created
watch kubectl get pods -n ka-platform
# Wait until all pods show Running status
```

**What gets deployed:**
- All 9 microservices (auth, user, content, feed, etc.)
- PostgreSQL (or connection to Cloud SQL)
- Redis (or connection to Cloud Memorystore)
- ScyllaDB
- MinIO (object storage)
- Meilisearch (search engine)
- NATS (message queue)

This deployment takes approximately 5-10 minutes.

### Step 8: Deploy Observability Stack

```bash
# Deploy Prometheus for metrics
kubectl apply -f infrastructure/observability/prometheus/

# Deploy Grafana for dashboards
kubectl apply -f infrastructure/observability/grafana/

# Deploy Loki for logs
kubectl apply -f infrastructure/observability/loki/

# Wait for observability pods to be ready
kubectl wait --for=condition=ready pod \
  -l app=prometheus -n ka-platform --timeout=300s

kubectl wait --for=condition=ready pod \
  -l app=grafana -n ka-platform --timeout=300s

# Verify all monitoring components
kubectl get pods -n ka-platform | grep -E "prometheus|grafana|loki|promtail"
```

---

## Post-Deployment Configuration

### Configure DNS (Production)

1. **Get your Ingress IP:**
   ```bash
   echo $INGRESS_IP
   # Or: kubectl get ingress -n ka-platform
   ```

2. **Create DNS A records** in your domain provider:
   ```
   api.yourdomain.com     → <INGRESS_IP>
   grafana.yourdomain.com → <INGRESS_IP>
   ```

3. **Wait for DNS propagation** (5-30 minutes):
   ```bash
   nslookup api.yourdomain.com
   ```

### Configure SSL/TLS with Let's Encrypt

```bash
# Install cert-manager
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml

# Wait for cert-manager to be ready
kubectl wait --for=condition=available --timeout=300s \
  deployment/cert-manager -n cert-manager

# Create Let's Encrypt issuer (replace email)
cat <<EOF | kubectl apply -f -
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@yourdomain.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
EOF

# Update ingress in charts/ka-platform/values.yaml
# Add annotations:
#   cert-manager.io/cluster-issuer: "letsencrypt-prod"
# And add tls configuration
```

### Set Up CI/CD with GitHub Actions

The repository already has GitHub Actions configured. To enable it:

1. **No additional secrets needed** - the workflow uses `GITHUB_TOKEN` automatically
2. **Push to main branch** triggers build and deployment
3. **Argo CD auto-syncs** new images to the cluster

```bash
# Test the pipeline
git commit --allow-empty -m "Test CI/CD pipeline"
git push origin main

# Watch GitHub Actions: https://github.com/your-username/ka-social-platform/actions
# Watch Argo CD sync: kubectl get application -n argocd -w
```

---

## Accessing the Application

### Via Port Forwarding (Development)

```bash
# Auth Service
kubectl port-forward -n ka-platform svc/auth-service 8001:8001 &

# User Service
kubectl port-forward -n ka-platform svc/user-service 8002:8002 &

# Content Service
kubectl port-forward -n ka-platform svc/content-service 8003:8003 &

# Grafana Dashboard
kubectl port-forward -n ka-platform svc/grafana 3000:3000 &

# Argo CD UI
kubectl port-forward -n argocd svc/argocd-server 8080:443 &

# Test API endpoints
curl http://localhost:8001/health
curl http://localhost:8002/health
curl http://localhost:8003/health
```

### Via Public Endpoints (Production with DNS)

Once DNS is configured:

```bash
# API Endpoints
curl https://api.yourdomain.com/auth/health
curl https://api.yourdomain.com/user/health
curl https://api.yourdomain.com/content/health

# Grafana Dashboard
open https://grafana.yourdomain.com
```

---

## Monitoring and Observability

### Access Grafana

```bash
# Port forward Grafana
kubectl port-forward -n ka-platform svc/grafana 3000:3000

# Get admin password
kubectl get secret grafana-secrets -n ka-platform \
  -o jsonpath="{.data.admin-password}" | base64 -d && echo

# Open browser: http://localhost:3000
# Username: admin
# Password: <from above>
```

**Pre-configured Dashboards:**
- Cluster Overview
- Service Metrics
- Database Performance
- API Request Rates
- Error Rates and Latencies

### Access Prometheus

```bash
# Port forward Prometheus
kubectl port-forward -n ka-platform svc/prometheus 9090:9090

# Open browser: http://localhost:9090
```

### View Logs with Loki

Logs are accessible through Grafana:
1. Open Grafana
2. Go to Explore
3. Select Loki datasource
4. Query logs by service: `{app="auth-service"}`

### Verify Monitoring

```bash
# Check all monitoring pods are running
kubectl get pods -n ka-platform -l tier=monitoring

# Check Prometheus targets
kubectl port-forward -n ka-platform svc/prometheus 9090:9090
# Open http://localhost:9090/targets
# All targets should show "UP"

# Check service discovery
kubectl get servicemonitor -n ka-platform
```

---

## Production Considerations

### High Availability

The deployment is already configured for HA:
- ✅ Regional GKE cluster (spans 3 zones)
- ✅ Multiple replicas for each service
- ✅ Horizontal Pod Autoscaling (HPA)
- ✅ Node autoscaling

**To increase resilience:**

```bash
# Increase replica count for critical services
kubectl scale deployment/auth-service -n ka-platform --replicas=5
kubectl scale deployment/user-service -n ka-platform --replicas=5

# Or edit values.yaml and let Argo CD sync:
# services:
#   auth:
#     replicaCount: 5
```

### Backup Configuration

#### Database Backups (Cloud SQL)

Cloud SQL automatically creates backups if enabled (already configured in Terraform).

**Verify backup configuration:**
```bash
cd terraform/gcp
terraform output postgres_connection_name

gcloud sql instances describe <instance-name> --format="value(settings.backupConfiguration)"
```

#### Cluster Backups with Velero (Optional)

```bash
# Install Velero for cluster-level backups
# Follow: https://velero.io/docs/main/basic-install/
```

### Security Hardening

```bash
# 1. Update all default passwords in values.yaml
# 2. Enable Pod Security Standards
kubectl label namespace ka-platform \
  pod-security.kubernetes.io/enforce=restricted

# 3. Create Network Policies (already included in charts)
kubectl get networkpolicies -n ka-platform

# 4. Enable GKE Security features
# - Binary Authorization
# - Workload Identity (already enabled)
# - Private GKE cluster (update terraform.tfvars)

# 5. Regular security scanning
gcloud container images scan <image-name>
```

### Performance Tuning

```bash
# Monitor resource usage
kubectl top nodes
kubectl top pods -n ka-platform

# Adjust resource limits in values.yaml
# Based on actual usage patterns

# Enable caching for hot content
# Configure Redis cache properly in services
```

---

## Troubleshooting

### Pods Not Starting

**Check pod status:**
```bash
kubectl get pods -n ka-platform
kubectl describe pod <pod-name> -n ka-platform
kubectl logs <pod-name> -n ka-platform
```

**Common issues:**
- Image pull errors: Check if GitHub Container Registry is accessible
- Insufficient resources: Check node capacity with `kubectl describe nodes`
- Failed health checks: Check service logs for application errors

### Database Connection Issues

**Verify database connectivity:**
```bash
# Check database pod/service
kubectl get pods -n ka-platform | grep postgres
kubectl get svc -n ka-platform postgres-service

# Test connection from a pod
kubectl run -it --rm psql-test --image=postgres:15 -n ka-platform -- \
  psql -h postgres-service -U ka_user -d ka_db

# If using Cloud SQL, check connection:
kubectl run -it --rm psql-test --image=postgres:15 -n ka-platform -- \
  psql -h <CLOUD_SQL_IP> -U ka_user -d ka_db
```

### Argo CD Not Syncing

```bash
# Check application status
kubectl get application ka-platform -n argocd -o yaml

# Force sync
kubectl patch application ka-platform -n argocd \
  --type merge -p '{"operation":{"sync":{}}}'

# Check Argo CD logs
kubectl logs -n argocd deployment/argocd-application-controller -f
kubectl logs -n argocd deployment/argocd-repo-server -f
```

### Load Balancer Not Getting IP

```bash
# Check ingress status
kubectl get ingress -n ka-platform
kubectl describe ingress -n ka-platform

# Check GCP load balancer
gcloud compute forwarding-rules list
gcloud compute target-http-proxies list

# If stuck, delete and recreate ingress
kubectl delete ingress ka-platform-ingress -n ka-platform
# Argo CD will recreate it
```

### High Costs

**Monitor costs:**
```bash
# Check GCP billing
gcloud billing accounts list
# View costs in GCP Console: https://console.cloud.google.com/billing

# Optimize:
# 1. Reduce node count or machine type
# 2. Use preemptible nodes for non-critical workloads
# 3. Enable committed use discounts
# 4. Delete unused resources

# View resource usage
kubectl top nodes
kubectl top pods -n ka-platform

# Scale down during off-peak hours
kubectl scale deployment --all --replicas=1 -n ka-platform
```

### Terraform State Issues

```bash
# If terraform apply fails, check state
terraform show
terraform state list

# Fix state inconsistencies
terraform refresh

# If severely corrupted, reimport resources
terraform import <resource-type>.<name> <resource-id>
```

---

## Cost Estimation

### Monthly Costs (Approximate)

**Production Configuration (as configured):**
- GKE Cluster Management: **$75/month** (per cluster)
- Compute Engine Nodes: 
  - 3x e2-standard-4: **$175/month**
- Cloud SQL PostgreSQL: 
  - db-custom-2-7680: **$125/month**
- Cloud Memorystore Redis (1GB): **$50/month**
- Load Balancer: **$20/month**
- Network Egress: **~$50/month** (depends on traffic)
- Cloud Storage (if enabled): **~$20/month**

**Total: ~$515/month** (without reserved capacity discounts)

**Development Configuration:**
- GKE Cluster: **$75/month**
- 1x e2-standard-2 node: **$50/month**
- In-cluster databases: **$0** (included in node costs)
- Load Balancer: **$20/month**
- Network: **~$10/month**

**Total: ~$155/month**

**Cost Optimization Tips:**
1. Use Committed Use Discounts (up to 57% off)
2. Use Preemptible VMs for non-critical workloads (up to 80% off)
3. Enable autoscaling to scale down during low traffic
4. Use Spot VMs for batch workloads
5. Set up budget alerts in GCP Console

---

## Scaling the Platform

### Horizontal Scaling (More Pods)

```bash
# Scale individual services
kubectl scale deployment/auth-service -n ka-platform --replicas=10

# Or use HPA (already configured)
kubectl get hpa -n ka-platform
# HPA will automatically scale based on CPU/memory usage
```

### Vertical Scaling (Bigger Nodes)

```bash
# Update terraform.tfvars
# node_machine_type = "e2-standard-8"  # 8 vCPUs, 32 GB RAM

cd terraform/gcp
terraform apply
# Node pool will be recreated with new machine type
```

### Geographic Distribution

For global users, deploy in multiple regions:

```bash
# Create clusters in different regions
# - us-central1 (Iowa) - North America
# - europe-west1 (Belgium) - Europe
# - asia-southeast1 (Singapore) - Asia

# Use Cloud Load Balancing for multi-region routing
# Set up Cloud CDN for static content
```

---

## Cleanup (Delete Everything)

**⚠️ WARNING: This will delete ALL resources and data!**

```bash
# Delete Kubernetes resources first
kubectl delete namespace ka-platform
kubectl delete namespace argocd

# Destroy infrastructure with Terraform
cd terraform/gcp
terraform destroy
# Type 'yes' when prompted

# Delete the GCP project (optional - removes everything)
gcloud projects delete $PROJECT_ID
```

---

## Next Steps

1. **Configure Custom Domain**: Point your domain to the ingress IP
2. **Set Up SSL Certificates**: Use cert-manager with Let's Encrypt
3. **Configure Monitoring Alerts**: Set up alert rules in Prometheus/Grafana
4. **Enable Backups**: Configure automated backups for databases
5. **Load Testing**: Test the platform under expected load
6. **Security Audit**: Review security settings and network policies
7. **Documentation**: Update team documentation with access credentials
8. **Deploy Frontend**: Deploy the Flutter mobile app to app stores

---

## Support and Resources

- **Documentation**: [/docs](./docs)
- **Architecture**: [ARCHITECTURE_DIAGRAM.md](./ARCHITECTURE_DIAGRAM.md)
- **Platform Guide**: [PLATFORM_ENGINEERING.md](./PLATFORM_ENGINEERING.md)
- **Quick Reference**: [QUICK_REFERENCE.md](./QUICK_REFERENCE.md)
- **Deployment Checklist**: [DEPLOYMENT_CHECKLIST.md](./DEPLOYMENT_CHECKLIST.md)

### GCP Resources
- [GKE Documentation](https://cloud.google.com/kubernetes-engine/docs)
- [Cloud SQL Documentation](https://cloud.google.com/sql/docs)
- [GCP Free Tier](https://cloud.google.com/free)
- [GCP Pricing Calculator](https://cloud.google.com/products/calculator)

### Kubernetes Resources
- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Helm Documentation](https://helm.sh/docs/)
- [Argo CD Documentation](https://argo-cd.readthedocs.io/)

---

**Deployment Guide Version**: 1.0.0  
**Last Updated**: 2024  
**Tested With**: GKE 1.28, Terraform 1.5+, Helm 3.13+
