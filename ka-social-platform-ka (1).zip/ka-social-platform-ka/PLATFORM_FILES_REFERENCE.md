# Ka Platform - File Reference Guide

Complete reference of all platform engineering files and their purposes.

## Directory Structure

```
ka-social-platform/
├── charts/                          # Helm charts for Kubernetes deployment
├── terraform/                       # Infrastructure as Code
├── infrastructure/                  # Kubernetes manifests and configs
├── .github/workflows/              # CI/CD pipelines
└── backend/                        # Application code (existing)
```

---

## Helm Charts (`/charts`)

### Parent Chart (`/charts/ka-platform`)

| File | Purpose |
|------|---------|
| `Chart.yaml` | Chart metadata, dependencies, versioning |
| `values.yaml` | Global configuration for entire platform |
| `.helmignore` | Files to exclude from Helm package |
| `templates/secrets.yaml` | Kubernetes Secrets for platform-wide credentials |

### API Services Sub-Chart (`/charts/ka-platform/charts/api-services`)

| File | Purpose |
|------|---------|
| `Chart.yaml` | Sub-chart metadata |
| `values.yaml` | Default values for API services |
| `templates/_helpers.tpl` | Helm template helper functions |
| `templates/deployment.yaml` | Kubernetes Deployments for all 9 services |
| `templates/service.yaml` | Kubernetes Services for networking |
| `templates/ingress.yaml` | Ingress configuration for external access |
| `templates/hpa.yaml` | Horizontal Pod Autoscalers for scaling |

**Deployed Services**:
1. auth-service (Port 8001)
2. user-service (Port 8002)
3. content-service (Port 8003)
4. feed-service (Port 8004)
5. interaction-service (Port 8005)
6. engagement-service (Port 8007)
7. discovery-service (Port 8008)
8. media-service (Port 8009)
9. billing-service (Port 8010)

### Databases Sub-Chart (`/charts/ka-platform/charts/databases`)

| File | Purpose |
|------|---------|
| `Chart.yaml` | Sub-chart metadata |
| `values.yaml` | Default values for databases |
| `templates/_helpers.tpl` | Helm template helper functions |
| `templates/postgres.yaml` | PostgreSQL StatefulSet and Service |
| `templates/redis.yaml` | Redis StatefulSet and Service |
| `templates/scylla.yaml` | ScyllaDB StatefulSet and Service |
| `templates/nats.yaml` | NATS StatefulSet and Service |
| `templates/minio.yaml` | MinIO StatefulSet and Service |
| `templates/meilisearch.yaml` | Meilisearch StatefulSet and Service |

**Deployed Databases**:
1. PostgreSQL (Port 5432) - Relational data
2. Redis (Port 6379) - Caching
3. ScyllaDB (Port 9042) - NoSQL data
4. NATS (Port 4222) - Message broker
5. MinIO (Ports 9000/9001) - Object storage
6. Meilisearch (Port 7700) - Search engine

---

## Terraform (`/terraform`)

### DigitalOcean (`/terraform/digitalocean`)

| File | Purpose |
|------|---------|
| `main.tf` | DOKS cluster, VPC, databases, load balancer |
| `variables.tf` | Input variables with defaults |
| `outputs.tf` | Output values (IPs, hostnames, kubeconfig) |
| `terraform.tfvars.example` | Example configuration file |

**Resources Created**:
- Kubernetes cluster (DOKS)
- VPC network
- Managed PostgreSQL database (optional)
- Managed Redis database (optional)
- Load balancer
- Spaces bucket (optional)

**Estimated Cost**: $160-470/month

### Google Cloud Platform (`/terraform/gcp`)

| File | Purpose |
|------|---------|
| `main.tf` | GKE cluster, VPC, databases, networking |
| `variables.tf` | Input variables with defaults |
| `outputs.tf` | Output values (IPs, connection strings) |
| `terraform.tfvars.example` | Example configuration file |

**Resources Created**:
- GKE cluster (3 zones)
- VPC network with subnets
- Cloud SQL PostgreSQL (optional)
- Memorystore Redis (optional)
- Static IP for ingress
- Cloud Storage bucket (optional)

**Estimated Cost**: $300-1,070/month

### Common Files

| File | Purpose |
|------|---------|
| `README.md` | Comprehensive Terraform guide |

---

## Infrastructure (`/infrastructure`)

### Argo CD (`/infrastructure/argocd`)

| File | Purpose |
|------|---------|
| `argocd-install.yaml` | Instructions for Argo CD installation |
| `ka-platform-application.yaml` | Argo CD Application manifest |
| `README.md` | Argo CD setup and usage guide |

**What It Does**:
- Continuous deployment
- GitOps workflow
- Automatic sync from Git
- Self-healing deployments

### Observability (`/infrastructure/observability`)

#### Prometheus (`/infrastructure/observability/prometheus`)

| File | Purpose |
|------|---------|
| `prometheus-config.yaml` | Scrape configs, service discovery |
| `prometheus-deployment.yaml` | Deployment, RBAC, storage |

**Metrics Collected**:
- HTTP requests (rate, latency, errors)
- Database queries
- Cache hit/miss rates
- Pod resources (CPU, memory)
- Business metrics (posts, users)

#### Grafana (`/infrastructure/observability/grafana`)

| File | Purpose |
|------|---------|
| `grafana-deployment.yaml` | Deployment, datasources, storage |
| `dashboards-config.yaml` | Dashboard provisioning config |
| `ka-platform-dashboard.yaml` | Pre-configured dashboard |

**Dashboards**:
- API Gateway Traffic
- Service health
- Database performance
- Cache performance
- Pod resources

#### Loki (`/infrastructure/observability/loki`)

| File | Purpose |
|------|---------|
| `loki-deployment.yaml` | Loki StatefulSet for log storage |
| `promtail-deployment.yaml` | DaemonSet for log collection |

**What It Does**:
- Aggregates logs from all pods
- Provides log querying with LogQL
- Integrates with Grafana

#### Common Files

| File | Purpose |
|------|---------|
| `README.md` | Observability stack guide |

---

## GitHub Actions (`/.github/workflows`)

| File | Purpose |
|------|---------|
| `gitops-pipeline.yaml` | Complete CI/CD pipeline |

**Pipeline Stages**:

1. **Build and Push** (on push to main):
   - Build Docker images for all services
   - Tag with git SHA and semantic version
   - Push to GitHub Container Registry
   - Scan for vulnerabilities

2. **Update Helm Values**:
   - Update image tags in values.yaml
   - Commit changes back to repository
   - Trigger Argo CD sync

3. **Validate Helm**:
   - Lint Helm charts
   - Template and validate manifests
   - Package charts

4. **Security Scan** (on PR):
   - Trivy vulnerability scanning
   - Upload results to GitHub Security

5. **Notify**:
   - Deployment status notification

---

## Application Code (`/backend`)

### Shared Libraries (`/backend/shared`)

| Directory | Purpose |
|-----------|---------|
| `metrics/` | **NEW** Prometheus instrumentation |

**New File**:

| File | Purpose |
|------|---------|
| `metrics/prometheus.go` | Metrics collection, middleware, endpoints |

**Features**:
- HTTP request metrics (counter, histogram)
- Database query metrics
- Cache hit/miss tracking
- Business metrics (posts, users)
- `/metrics` endpoint for Prometheus scraping

**Usage in Services**:
```go
import "github.com/.../backend/shared/metrics"

router.Use(metrics.PrometheusMiddleware("auth-service"))
router.GET("/metrics", metrics.PrometheusHandler())
```

---

## Documentation

| File | Purpose |
|------|---------|
| `PLATFORM_ENGINEERING.md` | **NEW** Complete platform engineering guide (26KB) |
| `QUICK_START_PLATFORM.md` | **NEW** Quick start guide (7KB) |
| `PLATFORM_FILES_REFERENCE.md` | **NEW** This file - complete file reference |

### PLATFORM_ENGINEERING.md Contents

1. Overview and technologies
2. Architecture diagrams
3. Infrastructure as Code guide
4. Helm chart structure
5. GitOps workflow
6. Observability stack
7. Deployment guide
8. Operations procedures
9. Security best practices
10. Disaster recovery
11. Troubleshooting guide

### QUICK_START_PLATFORM.md Contents

1. Prerequisites
2. DigitalOcean quick start (20 min)
3. GCP quick start (30 min)
4. Post-deployment checklist
5. Common issues and solutions
6. Next steps
7. Useful commands

---

## Configuration Files

### Helm Values

**Global Configuration** (`charts/ka-platform/values.yaml`):
```yaml
global:
  domain: ka-platform.io
  environment: production
  imageRegistry: ghcr.io/...
  secrets: { ... }
  resources: { small, medium, large }
```

**Service Configuration**:
```yaml
api-services:
  services:
    auth:
      enabled: true
      port: 8001
      image: auth-service
      tag: latest
      resources: medium
```

**Database Configuration**:
```yaml
databases:
  postgres:
    enabled: true
    storage: 10Gi
    resources: { ... }
```

### Terraform Variables

**DigitalOcean** (`terraform/digitalocean/terraform.tfvars`):
```hcl
do_token = "your-token"
cluster_name = "ka-platform"
node_count = 3
enable_autoscaling = true
use_managed_databases = true
```

**GCP** (`terraform/gcp/terraform.tfvars`):
```hcl
project_id = "your-project"
cluster_name = "ka-platform"
region = "us-central1"
node_machine_type = "e2-standard-4"
```

---

## Deployment Flow

### 1. Infrastructure Provisioning

```
Terraform → Cloud Provider → Kubernetes Cluster + Network + Databases
```

Files involved:
- `terraform/*/main.tf`
- `terraform/*/variables.tf`
- `terraform/*.tfvars`

### 2. GitOps Setup

```
kubectl → Argo CD Installation → Watch Git Repository
```

Files involved:
- `infrastructure/argocd/argocd-install.yaml`
- `infrastructure/argocd/ka-platform-application.yaml`

### 3. Application Deployment

```
Git → Argo CD → Helm → Kubernetes → Pods
```

Files involved:
- `charts/ka-platform/`
- All sub-charts and templates

### 4. Observability Deployment

```
kubectl → Prometheus/Grafana/Loki → Scrape Metrics/Logs
```

Files involved:
- `infrastructure/observability/prometheus/`
- `infrastructure/observability/grafana/`
- `infrastructure/observability/loki/`

### 5. Continuous Deployment

```
Code Push → GitHub Actions → Build Images → Update Helm → Argo Sync
```

Files involved:
- `.github/workflows/gitops-pipeline.yaml`
- `charts/ka-platform/values.yaml` (updated)

---

## Resource Requirements

### Kubernetes Cluster

**Minimum**:
- 3 nodes
- 4 CPU / 8GB RAM per node
- 100GB disk per node

**Production**:
- 5-10 nodes (with autoscaling)
- 4-8 CPU / 8-16GB RAM per node
- 100GB+ disk per node

### Storage

**PersistentVolumes**:
- PostgreSQL: 10-50GB
- Redis: 5GB
- ScyllaDB: 50-100GB
- NATS: 10GB
- MinIO: 100-500GB
- Meilisearch: 20GB
- Prometheus: 50GB
- Grafana: 10GB
- Loki: 50GB

**Total**: ~305-825GB

---

## Monitoring Endpoints

| Service | Endpoint | Port |
|---------|----------|------|
| Auth Service | `/metrics` | 8001 |
| User Service | `/metrics` | 8002 |
| Content Service | `/metrics` | 8003 |
| Feed Service | `/metrics` | 8004 |
| Interaction Service | `/metrics` | 8005 |
| Engagement Service | `/metrics` | 8007 |
| Discovery Service | `/metrics` | 8008 |
| Media Service | `/metrics` | 8009 |
| Billing Service | `/metrics` | 8010 |
| Prometheus | `/metrics` | 9090 |
| Grafana | `/api/health` | 3000 |
| Loki | `/ready` | 3100 |

---

## Security Considerations

### Secrets Management

**Stored in**:
- `charts/ka-platform/templates/secrets.yaml`
- Kubernetes Secrets (base64 encoded)

**Contains**:
- JWT secret
- Database passwords
- Redis password
- MinIO credentials
- Meilisearch API key

**Best Practice**: Use external secret management:
- HashiCorp Vault
- AWS Secrets Manager
- Sealed Secrets

### Network Security

**Configured via**:
- Ingress rules (in `api-services/templates/ingress.yaml`)
- Network Policies (to be added)
- Service mesh (optional, Istio/Linkerd)

### Image Security

**Implemented in**:
- `.github/workflows/gitops-pipeline.yaml`
- Trivy vulnerability scanning
- Image signing (to be added)

---

## Scaling

### Horizontal Pod Autoscaling

**Configured in**: `charts/ka-platform/charts/api-services/templates/hpa.yaml`

**Metrics**:
- CPU utilization: 70%
- Memory utilization: 80%
- Min replicas: 2
- Max replicas: 10

**Scales**:
- All API services independently
- Based on real-time metrics

### Cluster Autoscaling

**Configured in**: Terraform files
- `enable_autoscaling = true`
- `min_nodes = 3`
- `max_nodes = 10`

**Scales**:
- Entire cluster based on pod resource requests
- Automatic node provisioning/deprovisioning

---

## Backup and Recovery

### What's Backed Up

1. **Configuration**: All in Git (declarative)
2. **PostgreSQL**: Daily automated backups (managed)
3. **Object Storage**: Versioning enabled
4. **Cluster State**: Via Terraform state

### Recovery Procedures

**Documented in**:
- `PLATFORM_ENGINEERING.md` - Disaster Recovery section
- Steps for complete cluster recreation
- Database restore procedures

---

## Maintenance

### Update Procedures

**Application Updates**:
```bash
# Automated via CI/CD
git push → GitHub Actions → Argo CD
```

**Infrastructure Updates**:
```bash
# Manual via Terraform
terraform apply
```

**Kubernetes Updates**:
```bash
# Update version in terraform.tfvars
terraform apply
```

### Monitoring Updates

**Check**:
- Prometheus metrics
- Grafana dashboards
- Loki logs
- Argo CD sync status

---

## Support Resources

### Internal Documentation

- [PLATFORM_ENGINEERING.md](./PLATFORM_ENGINEERING.md) - Complete guide
- [QUICK_START_PLATFORM.md](./QUICK_START_PLATFORM.md) - Quick start
- [terraform/README.md](./terraform/README.md) - Terraform guide
- [infrastructure/argocd/README.md](./infrastructure/argocd/README.md) - Argo CD guide
- [infrastructure/observability/README.md](./infrastructure/observability/README.md) - Monitoring guide

### External Resources

- Kubernetes: https://kubernetes.io/docs/
- Helm: https://helm.sh/docs/
- Argo CD: https://argo-cd.readthedocs.io/
- Terraform: https://www.terraform.io/docs
- Prometheus: https://prometheus.io/docs/
- Grafana: https://grafana.com/docs/

---

## Change Log

**Version 1.0.0** (2024):
- Initial platform engineering implementation
- Complete Helm chart structure
- Terraform for DigitalOcean and GCP
- GitOps with Argo CD
- Full observability stack
- CI/CD pipeline
- Comprehensive documentation

---

**Document**: Platform Files Reference  
**Version**: 1.0.0  
**Maintained By**: Ka Platform Team
