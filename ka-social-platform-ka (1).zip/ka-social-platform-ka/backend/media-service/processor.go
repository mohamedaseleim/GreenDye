package main

import (
	"fmt"
	"io"

	"github.com/google/uuid"
	"github.com/h2non/bimg"
)

// ImageProcessor handles image processing operations
type ImageProcessor struct {
	storage *StorageService
}

// NewImageProcessor creates a new image processor
func NewImageProcessor(storage *StorageService) *ImageProcessor {
	return &ImageProcessor{
		storage: storage,
	}
}

// ProcessedImages contains URLs for all processed image variants
type ProcessedImages struct {
	OriginalURL string `json:"original_url"`
	MediumURL   string `json:"medium_url"`
	ThumbURL    string `json:"thumb_url"`
}

// ProcessImage downloads an image, creates variants, and uploads them
func (p *ImageProcessor) ProcessImage(objectKey string) (*ProcessedImages, error) {
	// Download original image
	object, err := p.storage.GetObject(objectKey)
	if err != nil {
		return nil, fmt.Errorf("failed to download image: %w", err)
	}
	defer object.Close()

	// Read image data
	imageData, err := io.ReadAll(object)
	if err != nil {
		return nil, fmt.Errorf("failed to read image: %w", err)
	}

	// Generate unique IDs for processed images
	baseID := uuid.New().String()

	// Create thumbnail (150x150)
	thumbData, err := p.resizeAndConvert(imageData, 150, 150)
	if err != nil {
		return nil, fmt.Errorf("failed to create thumbnail: %w", err)
	}
	thumbKey := fmt.Sprintf("processed/thumb_%s.webp", baseID)
	if err := p.storage.PutObject(thumbKey, thumbData, "image/webp"); err != nil {
		return nil, fmt.Errorf("failed to upload thumbnail: %w", err)
	}

	// Create medium (600x600)
	mediumData, err := p.resizeAndConvert(imageData, 600, 600)
	if err != nil {
		return nil, fmt.Errorf("failed to create medium: %w", err)
	}
	mediumKey := fmt.Sprintf("processed/medium_%s.webp", baseID)
	if err := p.storage.PutObject(mediumKey, mediumData, "image/webp"); err != nil {
		return nil, fmt.Errorf("failed to upload medium: %w", err)
	}

	// Return URLs
	return &ProcessedImages{
		OriginalURL: p.storage.GetObjectURL(objectKey),
		MediumURL:   p.storage.GetObjectURL(mediumKey),
		ThumbURL:    p.storage.GetObjectURL(thumbKey),
	}, nil
}

// resizeAndConvert resizes an image and converts it to WebP
func (p *ImageProcessor) resizeAndConvert(imageData []byte, width, height int) ([]byte, error) {
	// Create bimg image
	image := bimg.NewImage(imageData)

	// Resize and convert to WebP
	options := bimg.Options{
		Width:   width,
		Height:  height,
		Crop:    true,
		Type:    bimg.WEBP,
		Quality: 85,
	}

	processed, err := image.Process(options)
	if err != nil {
		return nil, fmt.Errorf("failed to process image: %w", err)
	}

	return processed, nil
}
