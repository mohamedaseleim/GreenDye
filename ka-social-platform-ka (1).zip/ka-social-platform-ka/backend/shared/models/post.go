package models

import (
	"time"

	"github.com/google/uuid"
)

// MediaAttachment represents a media attachment with type and metadata
type MediaAttachment struct {
	MediaKey string `json:"media_key" binding:"required"`
	Type     string `json:"type" binding:"required,oneof=image video gif"`
	AltText  string `json:"alt_text,omitempty"`
	URL      string `json:"url,omitempty"` // Populated during hydration
}

// Echo represents a short-form post
type Echo struct {
	ID               uuid.UUID          `json:"id" db:"id"`
	UserID           uuid.UUID          `json:"user_id" db:"user_id"`
	Content          string             `json:"content" db:"content"`
	MediaURLs        []string           `json:"media_urls,omitempty" db:"media_urls"`           // Deprecated: kept for backward compatibility
	MediaAttachments []MediaAttachment  `json:"media_attachments,omitempty" db:"media_attachments"` // New: extensible media objects
	Hashtags         []string           `json:"hashtags,omitempty" db:"hashtags"`
	Mentions         []uuid.UUID        `json:"mentions,omitempty" db:"mentions"`
	ParentEchoID     *uuid.UUID         `json:"parent_echo_id,omitempty" db:"parent_echo_id"`
	Visibility       string             `json:"visibility" db:"visibility"`
	LikeCount        int                `json:"like_count" db:"like_count"`
	CommentCount     int                `json:"comment_count" db:"comment_count"`
	ShareCount       int                `json:"share_count" db:"share_count"`
	CreatedAt        time.Time          `json:"created_at" db:"created_at"`
	UpdatedAt        time.Time          `json:"updated_at" db:"updated_at"`
}

// Story represents a long-form post
type Story struct {
	ID           uuid.UUID   `json:"id" db:"id"`
	UserID       uuid.UUID   `json:"user_id" db:"user_id"`
	Title        string      `json:"title" db:"title"`
	Content      string      `json:"content" db:"content"`
	PhotoAlbum   []string    `json:"photo_album,omitempty" db:"photo_album"`
	TaggedUsers  []uuid.UUID `json:"tagged_users,omitempty" db:"tagged_users"`
	Visibility   string      `json:"visibility" db:"visibility"`
	LikeCount    int         `json:"like_count" db:"like_count"`
	CommentCount int         `json:"comment_count" db:"comment_count"`
	CreatedAt    time.Time   `json:"created_at" db:"created_at"`
	UpdatedAt    time.Time   `json:"updated_at" db:"updated_at"`
}

// PostShort represents a minimal post object for nested responses
type PostShort struct {
	ID           uuid.UUID `json:"id"`
	Content      string    `json:"content"`
	LikeCount    int       `json:"like_count"`
	CommentCount int       `json:"comment_count"`
	CreatedAt    time.Time `json:"created_at"`
}

// EchoWithUser represents an echo with user information
type EchoWithUser struct {
	Echo
	User         UserShort `json:"user"`
	IsLiked      bool      `json:"is_liked"`
	IsBookmarked bool      `json:"is_bookmarked"`
}

// StoryWithUser represents a story with user information
type StoryWithUser struct {
	Story
	User         UserShort   `json:"user"`
	TaggedUsers  []UserShort `json:"tagged_users,omitempty"`
	IsLiked      bool        `json:"is_liked"`
	IsBookmarked bool        `json:"is_bookmarked"`
}

// CreateEchoRequest represents a request to create an echo
type CreateEchoRequest struct {
	Content          string            `json:"content" binding:"required,max=500"`
	MediaURLs        []string          `json:"media_urls,omitempty"`        // Deprecated: kept for backward compatibility
	MediaAttachments []MediaAttachment `json:"media_attachments,omitempty"` // New: extensible media objects
	ParentEchoID     *uuid.UUID        `json:"parent_echo_id,omitempty"`
	Visibility       string            `json:"visibility" binding:"required,oneof=public friends private"`
	Mentions         []uuid.UUID       `json:"mentions,omitempty"`
}

// CreateStoryRequest represents a request to create a story
type CreateStoryRequest struct {
	Title       string      `json:"title" binding:"required,max=200"`
	Content     string      `json:"content" binding:"required"`
	PhotoAlbum  []string    `json:"photo_album,omitempty"`
	TaggedUsers []uuid.UUID `json:"tagged_users,omitempty"`
	Visibility  string      `json:"visibility" binding:"required,oneof=public friends private"`
}

// UpdateStoryRequest represents a request to update a story
type UpdateStoryRequest struct {
	Title   *string `json:"title,omitempty"`
	Content *string `json:"content,omitempty"`
}

// FeedItem represents an item in a feed
type FeedItem struct {
	Type   string      `json:"type"` // "echo" or "story"
	Post   interface{} `json:"post"` // EchoWithUser or StoryWithUser
	Reason string      `json:"reason,omitempty"`
}
