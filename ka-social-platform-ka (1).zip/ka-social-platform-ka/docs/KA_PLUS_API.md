# Ka+ API Documentation

Complete API documentation for Ka+ subscription and entitlements system.

## Table of Contents

- [Overview](#overview)
- [Authentication](#authentication)
- [Entitlements](#entitlements)
- [Billing Service APIs](#billing-service-apis)
- [Feature APIs](#feature-apis)
- [Error Handling](#error-handling)
- [Examples](#examples)

## Overview

Ka+ is the premium subscription tier that unlocks advanced features. The system uses JWT-based entitlements for stateless, zero-latency feature access control.

**Base URLs**:
- Auth Service: `http://localhost:8001`
- Billing Service: `http://localhost:8009`
- User Service: `http://localhost:8002`
- Content Service: `http://localhost:8003`
- Engagement Service: `http://localhost:8007`

## Authentication

All authenticated endpoints require a JWT token in the `Authorization` header:

```http
Authorization: Bearer <jwt_token>
```

### JWT Payload with Entitlements

```json
{
  "sub": "user_id",
  "username": "johndoe",
  "role": "user",
  "is_premium": true,
  "entitlements": [
    "PROFILE_BADGE",
    "EXTENDED_UPLOADS",
    "ADVANCED_ANALYTICS"
  ],
  "exp": 1234567890,
  "iat": 1234567890
}
```

## Entitlements

### Available Entitlements

| Entitlement | Description | Service |
|------------|-------------|---------|
| `PROFILE_BADGE` | Shows Ka+ badge on profile | User Service |
| `EXTENDED_UPLOADS` | Upload 4 images per echo (vs 1) | Content Service |
| `ADVANCED_ANALYTICS` | Access detailed engagement analytics | Engagement Service |

### Checking Entitlements

Feature access is determined by inspecting the JWT token's `entitlements` array. No additional API calls are needed.

## Billing Service APIs

### Create Checkout Session

Create a Stripe Checkout session to subscribe to Ka+.

**Endpoint**: `POST /api/v1/billing/checkout`

**Authentication**: Required (JWT)

**Request Body**:
```json
{
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "success_url": "https://app.ka.com/success",
  "cancel_url": "https://app.ka.com/cancel"
}
```

**Success Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "session_id": "cs_test_a1b2c3...",
    "session_url": "https://checkout.stripe.com/c/pay/cs_test_..."
  },
  "message": "Checkout session created successfully"
}
```

**Error Responses**:

401 Unauthorized - Missing or invalid JWT:
```json
{
  "success": false,
  "error": {
    "code": "AUTH_REQUIRED",
    "message": "User not authenticated"
  }
}
```

409 Conflict - User already has active subscription:
```json
{
  "success": false,
  "error": {
    "code": "SUBSCRIPTION_EXISTS",
    "message": "User already has an active subscription"
  }
}
```

**Example**:
```bash
curl -X POST http://localhost:8009/api/v1/billing/checkout \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "550e8400-e29b-41d4-a716-446655440000",
    "success_url": "https://app.ka.com/success",
    "cancel_url": "https://app.ka.com/cancel"
  }'
```

### Get User Subscription

Get the current user's subscription details.

**Endpoint**: `GET /api/v1/billing/subscription`

**Authentication**: Required (JWT)

**Success Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "user_id": "uuid",
    "stripe_customer_id": "cus_...",
    "stripe_subscription_id": "sub_...",
    "status": "active",
    "current_period_start": "2024-01-01T00:00:00Z",
    "current_period_end": "2024-02-01T00:00:00Z",
    "cancel_at_period_end": false,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  },
  "message": "Subscription retrieved successfully"
}
```

**No Subscription** (200 OK):
```json
{
  "success": true,
  "data": null,
  "message": "No active subscription"
}
```

**Example**:
```bash
curl http://localhost:8009/api/v1/billing/subscription \
  -H "Authorization: Bearer $JWT_TOKEN"
```

### Get User Entitlements (Internal)

Internal endpoint used by Auth Service to fetch entitlements.

**Endpoint**: `GET /api/internal/billing/entitlements/:userId`

**Authentication**: None (internal use only, protected by network)

**Success Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "user_id": "uuid",
    "entitlements": [
      "PROFILE_BADGE",
      "EXTENDED_UPLOADS",
      "ADVANCED_ANALYTICS"
    ],
    "subscription": {
      "id": "uuid",
      "status": "active",
      "current_period_end": "2024-02-01T00:00:00Z"
    }
  },
  "message": "Entitlements retrieved successfully"
}
```

**Example**:
```bash
curl http://localhost:8009/api/internal/billing/entitlements/550e8400-e29b-41d4-a716-446655440000
```

## Feature APIs

### User Service - Profile Badge

Get user profile with Ka+ badge indicator.

**Endpoint**: `GET /api/users/:username`

**Authentication**: Optional

**Success Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "username": "johndoe",
    "display_name": "John Doe",
    "bio": "Software Engineer",
    "profile_picture_url": "https://cdn.ka.com/...",
    "is_verified": true,
    "has_ka_plus": true,
    "follower_count": 1234,
    "following_count": 567,
    "echo_count": 89,
    "story_count": 12
  },
  "message": "Profile retrieved successfully"
}
```

**Example**:
```bash
curl http://localhost:8002/api/users/johndoe
```

### Content Service - Extended Uploads

Create echo with multiple images (Ka+ feature).

**Endpoint**: `POST /api/v1/echoes`

**Authentication**: Required (JWT)

**Request Body** (Ka+ user - 4 images allowed):
```json
{
  "content": "Beautiful sunset at the Nile! #egypt #travel",
  "media_attachments": [
    {
      "media_key": "uploads/user-id/image1.jpg",
      "type": "image",
      "alt_text": "Sunset over the Nile"
    },
    {
      "media_key": "uploads/user-id/image2.jpg",
      "type": "image",
      "alt_text": "Felucca boats"
    },
    {
      "media_key": "uploads/user-id/image3.jpg",
      "type": "image",
      "alt_text": "Riverside view"
    },
    {
      "media_key": "uploads/user-id/image4.jpg",
      "type": "image",
      "alt_text": "Local market"
    }
  ],
  "visibility": "public"
}
```

**Success Response** (201 Created):
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "user_id": "uuid",
    "content": "Beautiful sunset at the Nile! #egypt #travel",
    "media_attachments": [...],
    "hashtags": ["egypt", "travel"],
    "visibility": "public",
    "like_count": 0,
    "created_at": "2024-01-07T12:00:00Z"
  },
  "message": "Echo created successfully"
}
```

**Error Response** (Free user tries 4 images):
```json
{
  "success": false,
  "error": {
    "code": "MEDIA_LIMIT_EXCEEDED",
    "message": "Too many media attachments. Free users can attach 1 image, Ka+ users can attach 4 images.",
    "details": {
      "max_allowed": 1,
      "provided": 4
    }
  }
}
```

**Example**:
```bash
curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Great photo collection!",
    "media_attachments": [
      {"media_key": "uploads/user-id/1.jpg", "type": "image"},
      {"media_key": "uploads/user-id/2.jpg", "type": "image"},
      {"media_key": "uploads/user-id/3.jpg", "type": "image"},
      {"media_key": "uploads/user-id/4.jpg", "type": "image"}
    ]
  }'
```

### Engagement Service - Advanced Analytics

Get detailed engagement analytics for an echo (Ka+ exclusive).

**Endpoint**: `GET /api/v1/echoes/:echoId/analytics`

**Authentication**: Required (JWT with `ADVANCED_ANALYTICS` entitlement)

**Success Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "echo_id": "uuid",
    "total_likes": 142,
    "total_views": 1420,
    "engagement_rate": 10.0,
    "hourly_likes": {
      "0": 5, "1": 2, "2": 1, "3": 0, "4": 3,
      "5": 8, "6": 12, "7": 15, "8": 20, "9": 18,
      "10": 10, "11": 8, "12": 7, "13": 6, "14": 5,
      "15": 4, "16": 3, "17": 4, "18": 6, "19": 2,
      "20": 1, "21": 0, "22": 1, "23": 2
    },
    "daily_likes": {
      "2024-01-07": 45,
      "2024-01-06": 32,
      "2024-01-05": 28,
      "2024-01-04": 20,
      "2024-01-03": 10,
      "2024-01-02": 5,
      "2024-01-01": 2
    },
    "top_likers": [
      {"user_id": "uuid1", "liked_at": "2024-01-07T12:00:00Z"},
      {"user_id": "uuid2", "liked_at": "2024-01-07T11:30:00Z"},
      {"user_id": "uuid3", "liked_at": "2024-01-07T11:15:00Z"}
    ],
    "analytics_period": "last_7_days",
    "generated_at": "2024-01-07T15:30:00Z"
  },
  "message": "Analytics retrieved successfully"
}
```

**Error Response** (Non-Ka+ user):
```json
{
  "success": false,
  "error": {
    "code": "ENTITLEMENT_REQUIRED",
    "message": "This feature requires a Ka+ subscription",
    "details": {
      "required_entitlement": "ADVANCED_ANALYTICS",
      "upgrade_url": "/api/v1/billing/checkout"
    }
  }
}
```

**Example**:
```bash
curl http://localhost:8007/api/v1/echoes/550e8400-e29b-41d4-a716-446655440000/analytics \
  -H "Authorization: Bearer $JWT_TOKEN"
```

## Error Handling

### Standard Error Response Format

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {
      "additional": "context"
    }
  }
}
```

### Common Error Codes

| Code | Status | Description |
|------|--------|-------------|
| `AUTH_REQUIRED` | 401 | Missing or invalid JWT token |
| `AUTH_TOKEN_INVALID` | 401 | JWT token is expired or malformed |
| `ENTITLEMENT_REQUIRED` | 403 | Feature requires specific entitlement |
| `SUBSCRIPTION_EXISTS` | 409 | User already has active subscription |
| `MEDIA_LIMIT_EXCEEDED` | 400 | Too many media attachments for user tier |
| `INVALID_INPUT` | 400 | Request body validation failed |
| `SERVER_ERROR` | 500 | Internal server error |

## Examples

### Complete Ka+ Subscription Flow

#### 1. User Logs In (Gets JWT with Entitlements)

```bash
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123"
  }'
```

Response:
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "username": "johndoe"
    },
    "access_token": "eyJhbGciOiJIUzI1NiIs...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIs...",
    "expires_in": 900
  }
}
```

JWT contains:
```json
{
  "sub": "uuid",
  "username": "johndoe",
  "entitlements": []  // Empty for free user
}
```

#### 2. User Upgrades to Ka+

```bash
JWT_TOKEN="eyJhbGciOiJIUzI1NiIs..."

curl -X POST http://localhost:8009/api/v1/billing/checkout \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "uuid",
    "success_url": "https://app.ka.com/success",
    "cancel_url": "https://app.ka.com/cancel"
  }'
```

Response:
```json
{
  "success": true,
  "data": {
    "session_url": "https://checkout.stripe.com/c/pay/cs_test_..."
  }
}
```

#### 3. User Completes Payment on Stripe

Stripe webhook → Billing Service → Grant entitlements

#### 4. User Logs In Again (Gets New JWT with Entitlements)

```bash
curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123"
  }'
```

New JWT contains:
```json
{
  "sub": "uuid",
  "username": "johndoe",
  "entitlements": [
    "PROFILE_BADGE",
    "EXTENDED_UPLOADS",
    "ADVANCED_ANALYTICS"
  ]
}
```

#### 5. User Uses Ka+ Features

Create echo with 4 images:
```bash
curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Check out these photos!",
    "media_attachments": [
      {"media_key": "uploads/uuid/1.jpg", "type": "image"},
      {"media_key": "uploads/uuid/2.jpg", "type": "image"},
      {"media_key": "uploads/uuid/3.jpg", "type": "image"},
      {"media_key": "uploads/uuid/4.jpg", "type": "image"}
    ]
  }'
```

Get analytics:
```bash
curl http://localhost:8007/api/v1/echoes/echo-uuid/analytics \
  -H "Authorization: Bearer $JWT_TOKEN"
```

View profile with Ka+ badge:
```bash
curl http://localhost:8002/api/users/johndoe
```

Response includes `"has_ka_plus": true`

## Rate Limiting

All authenticated endpoints are subject to rate limiting:
- Free users: 100 requests/minute
- Ka+ users: 1000 requests/minute

Rate limit headers:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1234567890
```

## Webhooks

The Billing Service receives webhooks from Stripe to process subscription events. These webhooks are authenticated using Stripe's signature verification.

**Webhook URL**: `POST /api/v1/billing/webhook`

**Events Handled**:
- `checkout.session.completed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`

## Testing

### Stripe Test Mode

Use Stripe test keys for development:
- Secret Key: `sk_test_...`
- Webhook Secret: `whsec_...`
- Price ID: `price_...`

### Stripe CLI

Test webhooks locally:
```bash
stripe listen --forward-to localhost:8009/api/v1/billing/webhook
stripe trigger customer.subscription.created
```

### Test Cards

- Success: `4242 4242 4242 4242`
- Decline: `4000 0000 0000 0002`
- 3D Secure: `4000 0025 0000 3155`

## Support

For questions or issues:
- Documentation: https://docs.ka.com
- Email: support@ka.com
- GitHub: https://github.com/mohamedaseleim/ka-social-platform
