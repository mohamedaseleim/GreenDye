# Engagement Service - Quick Start Guide

Get the Engagement Service up and running in 5 minutes.

## Prerequisites

```bash
# Ensure you have these installed:
- Go 1.21+
- Docker & Docker Compose
- curl (for testing)
```

## Step 1: Start Infrastructure (1 min)

```bash
cd infrastructure/docker
docker-compose up -d postgres redis nats scylla

# Wait for services to be healthy
docker-compose ps

# Initialize ScyllaDB (if not already done)
docker-compose exec scylla cqlsh -e "SOURCE '/docker-entrypoint-initdb.d/01-init.cql'"
```

## Step 2: Start Required Services (2 min)

```bash
# Terminal 1: Start Auth Service
cd backend/auth-service
go run *.go

# Terminal 2: Start User Service
cd backend/user-service
go run *.go

# Terminal 3: Start Content Service
cd backend/content-service
go run *.go

# Terminal 4: Start Interaction Service
cd backend/interaction-service
go run *.go
```

## Step 3: Start Engagement Service (1 min)

```bash
# Terminal 5: Start Engagement Service
cd backend/engagement-service
go run *.go

# Expected output:
# Engagement service starting on port 8007
# WebSocket endpoint available at ws://localhost:8007/ws/v1/notifications
# NATS consumer started, subscribed to echo.liked and user.followed
```

## Step 4: Quick Test (1 min)

### Test Health Check
```bash
curl http://localhost:8007/health
# Should return:
# {
#   "status": "ok",
#   "service": "engagement-service",
#   "connected_users": 0,
#   "total_connections": 0
# }
```

### Test Like Operation

```bash
# 1. Register a user
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "TestPass123!",
    "display_name": "Test User"
  }'

# 2. Login and get token
TOKEN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPass123!"
  }' | jq -r '.data.access_token')

# 3. Create an echo
ECHO_ID=$(curl -s -X POST http://localhost:8003/api/v1/echoes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "content": "My first echo!",
    "visibility": "public"
  }' | jq -r '.data.id')

# 4. Like the echo
curl -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $TOKEN"

# Should return:
# {
#   "success": true,
#   "data": {
#     "liked": true,
#     "already_liked": false
#   }
# }

# 5. Check notifications
curl -X GET "http://localhost:8007/api/v1/notifications" \
  -H "Authorization: Bearer $TOKEN"
```

## Step 5: Test WebSocket (Optional)

### Using Browser Console
```javascript
// Open browser console and paste:
const token = 'YOUR_TOKEN_HERE'; // Replace with actual token
const ws = new WebSocket(`ws://localhost:8007/ws/v1/notifications?token=${token}`);

ws.onopen = () => console.log('✅ Connected to notifications');
ws.onmessage = (e) => console.log('📬 Notification:', JSON.parse(e.data));
ws.onerror = (e) => console.error('❌ Error:', e);
```

### Using websocat
```bash
# Install websocat: cargo install websocat
websocat "ws://localhost:8007/ws/v1/notifications?token=$TOKEN"

# Keep this running - you'll see notifications appear in real-time
```

## Common Issues

### Issue: "Failed to connect to PostgreSQL"
**Solution**: 
```bash
# Check if PostgreSQL is running
docker-compose ps postgres

# Check logs
docker-compose logs postgres
```

### Issue: "Failed to connect to NATS"
**Solution**:
```bash
# Check if NATS is running
docker-compose ps nats

# Restart NATS
docker-compose restart nats
```

### Issue: "Echo not found"
**Solution**: Make sure Content Service is running and ScyllaDB is initialized.

### Issue: "Invalid token"
**Solution**: Token may have expired. Login again to get a fresh token.

## Next Steps

- Read [TESTING.md](./TESTING.md) for comprehensive testing scenarios
- Read [README.md](./README.md) for complete API documentation
- Check [ENGAGEMENT_FLOW_DIAGRAM.md](../../ENGAGEMENT_FLOW_DIAGRAM.md) for architecture

## Quick Commands Reference

```bash
# Health checks
curl http://localhost:8001/health  # Auth
curl http://localhost:8002/health  # User
curl http://localhost:8003/health  # Content
curl http://localhost:8005/health  # Interaction
curl http://localhost:8007/health  # Engagement

# Stop all services
docker-compose down

# View logs
docker-compose logs -f engagement-service

# Rebuild and restart
docker-compose up -d --build engagement-service
```

## Environment Variables

For local development, defaults are fine. For production:

```bash
export PORT=8007
export DB_HOST=postgres
export DB_PORT=5432
export DB_USER=ka_user
export DB_PASSWORD=ka_password
export DB_NAME=ka_db
export REDIS_HOST=redis
export REDIS_PORT=6379
export REDIS_PASSWORD=ka_redis_password
export JWT_SECRET=your-secret-key
export NATS_URL=nats://nats:4222
export CONTENT_SERVICE_URL=http://content-service:8003
```

## Success Indicators

✅ Service starts without errors
✅ Health check returns "ok"
✅ Can like an echo
✅ Notifications are created
✅ WebSocket connects successfully
✅ Real-time notifications arrive

You're ready to go! 🚀
