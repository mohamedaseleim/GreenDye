package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
)

// MediaClient handles communication with the Media Service
type MediaClient struct {
	baseURL string
	client  *http.Client
}

// NewMediaClient creates a new media client
func NewMediaClient(baseURL string) *MediaClient {
	return &MediaClient{
		baseURL: baseURL,
		client:  &http.Client{Timeout: 10 * time.Second},
	}
}

// ValidateMediaRequest represents a media validation request
type ValidateMediaRequest struct {
	MediaKeys []string `json:"media_keys"`
	UserID    string   `json:"user_id"`
}

// ValidateMediaResponse represents a media validation response
type ValidateMediaResponse struct {
	Valid   bool     `json:"valid"`
	Message string   `json:"message,omitempty"`
	Invalid []string `json:"invalid,omitempty"`
}

// ValidateMedia validates media keys with the Media Service
func (c *MediaClient) ValidateMedia(mediaKeys []string, userID string) (*ValidateMediaResponse, error) {
	if len(mediaKeys) == 0 {
		return &ValidateMediaResponse{Valid: true, Message: "No media to validate"}, nil
	}

	reqBody := ValidateMediaRequest{
		MediaKeys: mediaKeys,
		UserID:    userID,
	}

	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	url := fmt.Sprintf("%s/api/internal/media/validate", c.baseURL)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call media service: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("media service returned status %d: %s", resp.StatusCode, string(body))
	}

	// Parse response
	var apiResp struct {
		Success bool                  `json:"success"`
		Data    ValidateMediaResponse `json:"data"`
	}

	if err := json.Unmarshal(body, &apiResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %w", err)
	}

	if !apiResp.Success {
		return nil, fmt.Errorf("media service returned success=false")
	}

	return &apiResp.Data, nil
}

// GetMediaDetailsRequest represents a request to get media details
type GetMediaDetailsRequest struct {
	MediaKeys []string `json:"media_keys"`
}

// MediaDetail represents details about a media object
type MediaDetail struct {
	MediaKey string `json:"media_key"`
	URL      string `json:"url"`
	Exists   bool   `json:"exists"`
}

// GetMediaDetailsResponse represents media details response
type GetMediaDetailsResponse struct {
	Media []MediaDetail `json:"media"`
}

// GetMediaDetails retrieves media details from the Media Service
func (c *MediaClient) GetMediaDetails(mediaKeys []string) (map[string]string, error) {
	if len(mediaKeys) == 0 {
		return map[string]string{}, nil
	}

	reqBody := GetMediaDetailsRequest{
		MediaKeys: mediaKeys,
	}

	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	url := fmt.Sprintf("%s/api/internal/media/details", c.baseURL)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to call media service: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("media service returned status %d: %s", resp.StatusCode, string(body))
	}

	// Parse response
	var apiResp struct {
		Success bool                    `json:"success"`
		Data    GetMediaDetailsResponse `json:"data"`
	}

	if err := json.Unmarshal(body, &apiResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %w", err)
	}

	if !apiResp.Success {
		return nil, fmt.Errorf("media service returned success=false")
	}

	// Convert to map
	mediaURLs := make(map[string]string)
	for _, detail := range apiResp.Data.Media {
		if detail.Exists {
			mediaURLs[detail.MediaKey] = detail.URL
		}
	}

	return mediaURLs, nil
}

// HydrateMediaAttachments adds URLs to media attachments
func (c *MediaClient) HydrateMediaAttachments(attachments []models.MediaAttachment) ([]models.MediaAttachment, error) {
	if len(attachments) == 0 {
		return attachments, nil
	}

	// Extract media keys
	mediaKeys := make([]string, len(attachments))
	for i, attachment := range attachments {
		mediaKeys[i] = attachment.MediaKey
	}

	// Get URLs from Media Service
	mediaURLs, err := c.GetMediaDetails(mediaKeys)
	if err != nil {
		return nil, err
	}

	// Populate URLs in attachments
	hydratedAttachments := make([]models.MediaAttachment, len(attachments))
	for i, attachment := range attachments {
		hydratedAttachments[i] = attachment
		if url, found := mediaURLs[attachment.MediaKey]; found {
			hydratedAttachments[i].URL = url
		}
	}

	return hydratedAttachments, nil
}
