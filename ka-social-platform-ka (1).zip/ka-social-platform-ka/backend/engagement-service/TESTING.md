# Engagement Service Testing Guide

This document provides comprehensive testing instructions for the Engagement Service.

## Prerequisites

Ensure all infrastructure services are running:
```bash
cd infrastructure/docker
docker-compose up -d postgres redis nats scylla
```

Wait for services to be healthy (especially ScyllaDB takes ~60 seconds):
```bash
docker-compose ps
```

## Running the Services

### 1. Start Content Service
```bash
cd backend/content-service
go run *.go
```

### 2. Start Interaction Service
```bash
cd backend/interaction-service
go run *.go
```

### 3. Start Engagement Service
```bash
cd backend/engagement-service
go run *.go
```

### 4. Start Auth Service (for authentication)
```bash
cd backend/auth-service
go run *.go
```

### 5. Start User Service
```bash
cd backend/user-service
go run *.go
```

## Test Scenarios

### Scenario 1: Like/Unlike Flow

#### Step 1: Register and Login
```bash
# Register a user
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser1",
    "email": "test1@example.com",
    "password": "TestPass123!",
    "display_name": "Test User 1"
  }'

# Register another user
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser2",
    "email": "test2@example.com",
    "password": "TestPass123!",
    "display_name": "Test User 2"
  }'

# Login as user1
USER1_TOKEN=$(curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test1@example.com",
    "password": "TestPass123!"
  }' | jq -r '.data.access_token')

# Login as user2
USER2_TOKEN=$(curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test2@example.com",
    "password": "TestPass123!"
  }' | jq -r '.data.access_token')
```

#### Step 2: Create an Echo
```bash
# User1 creates an echo
ECHO_RESPONSE=$(curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  -d '{
    "content": "This is my first echo! #testing",
    "visibility": "public"
  }')

echo "$ECHO_RESPONSE" | jq .

# Extract echo ID
ECHO_ID=$(echo "$ECHO_RESPONSE" | jq -r '.data.id')
echo "Echo ID: $ECHO_ID"
```

#### Step 3: Like the Echo
```bash
# User2 likes User1's echo
curl -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $USER2_TOKEN" \
  | jq .

# Expected response:
# {
#   "success": true,
#   "data": {
#     "liked": true,
#     "already_liked": false
#   }
# }
```

#### Step 4: Verify Like Count Update
```bash
# Check the echo has like_count = 1
curl -X POST http://localhost:8003/api/internal/echoes/batch \
  -H "Content-Type: application/json" \
  -d "{\"echo_ids\": [\"$ECHO_ID\"]}" \
  | jq '.data[0].like_count'

# Expected: 1
```

#### Step 5: Check Notifications
```bash
# User1 checks their notifications
curl -X GET "http://localhost:8007/api/v1/notifications?page=1&per_page=20" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  | jq .

# Expected: One notification of type "like"
```

#### Step 6: Unlike the Echo
```bash
# User2 unlikes the echo
curl -X DELETE "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $USER2_TOKEN" \
  | jq .

# Verify like count is back to 0
curl -X POST http://localhost:8003/api/internal/echoes/batch \
  -H "Content-Type: application/json" \
  -d "{\"echo_ids\": [\"$ECHO_ID\"]}" \
  | jq '.data[0].like_count'

# Expected: 0
```

### Scenario 2: WebSocket Real-Time Notifications

This test requires a WebSocket client. You can use `websocat` or a browser-based test.

#### Using websocat (Install: `cargo install websocat`)

```bash
# Terminal 1: Connect to WebSocket as User1
websocat "ws://localhost:8007/ws/v1/notifications?token=$USER1_TOKEN"

# Keep this terminal open - you'll see notifications appear here in real-time
```

```bash
# Terminal 2: Have User2 like User1's echo
curl -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $USER2_TOKEN"
```

You should see a notification appear instantly in Terminal 1:
```json
{
  "id": "...",
  "user_id": "...",
  "type": "like",
  "actor_id": "...",
  "echo_id": "...",
  "content": "liked your echo",
  "is_read": false,
  "created_at": "...",
  "actor_count": 1,
  "actor_ids": ["..."]
}
```

#### Using Browser JavaScript

Create an HTML file and open it in a browser:

```html
<!DOCTYPE html>
<html>
<head>
    <title>WebSocket Test</title>
</head>
<body>
    <h1>WebSocket Notification Test</h1>
    <div id="output"></div>
    
    <script>
        const token = 'YOUR_JWT_TOKEN_HERE'; // Replace with actual token
        const ws = new WebSocket(`ws://localhost:8007/ws/v1/notifications?token=${token}`);
        
        ws.onopen = () => {
            console.log('Connected to notifications stream');
            document.getElementById('output').innerHTML += '<p>✓ Connected</p>';
        };
        
        ws.onmessage = (event) => {
            console.log('Notification received:', event.data);
            const notification = JSON.parse(event.data);
            document.getElementById('output').innerHTML += 
                `<p>📬 ${notification.type}: ${notification.content}</p>`;
        };
        
        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            document.getElementById('output').innerHTML += '<p>❌ Error</p>';
        };
        
        ws.onclose = () => {
            console.log('Disconnected');
            document.getElementById('output').innerHTML += '<p>❌ Disconnected</p>';
        };
    </script>
</body>
</html>
```

### Scenario 3: Notification Aggregation

Test that multiple likes on the same echo aggregate into one notification:

```bash
# Register multiple users
for i in {3..5}; do
  curl -X POST http://localhost:8001/api/auth/register \
    -H "Content-Type: application/json" \
    -d "{
      \"username\": \"testuser$i\",
      \"email\": \"test$i@example.com\",
      \"password\": \"TestPass123!\",
      \"display_name\": \"Test User $i\"
    }"
done

# Login all users and store tokens
USER3_TOKEN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "test3@example.com", "password": "TestPass123!"}' \
  | jq -r '.data.access_token')

USER4_TOKEN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "test4@example.com", "password": "TestPass123!"}' \
  | jq -r '.data.access_token')

USER5_TOKEN=$(curl -s -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "test5@example.com", "password": "TestPass123!"}' \
  | jq -r '.data.access_token')

# Have all users like the same echo
curl -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $USER3_TOKEN"

curl -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $USER4_TOKEN"

curl -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
  -H "Authorization: Bearer $USER5_TOKEN"

# Check User1's notifications - should show aggregated notification
curl -X GET "http://localhost:8007/api/v1/notifications?page=1&per_page=20" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  | jq '.data[] | select(.type == "like")'

# Expected: Single notification with actor_count=3 and actor_ids containing all 3 users
```

### Scenario 4: Follow Notifications

```bash
# User2 follows User1
curl -X POST "http://localhost:8005/api/users/$(curl -s http://localhost:8002/api/users/testuser1 | jq -r '.data.id')/follow" \
  -H "Authorization: Bearer $USER2_TOKEN"

# User1 should receive a follow notification
curl -X GET "http://localhost:8007/api/v1/notifications?page=1&per_page=20" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  | jq '.data[] | select(.type == "follow")'
```

## Health Checks

Check service health:
```bash
# Engagement Service
curl http://localhost:8007/health | jq .

# Expected output includes:
# {
#   "status": "ok",
#   "service": "engagement-service",
#   "connected_users": 0,
#   "total_connections": 0
# }
```

## Performance Testing

### Load Test WebSocket Connections

```bash
# Create a simple load test with multiple concurrent connections
# This requires websocat or a similar tool

# Open 10 concurrent WebSocket connections
for i in {1..10}; do
  websocat "ws://localhost:8007/ws/v1/notifications?token=$USER1_TOKEN" &
done

# Check health endpoint to see connection count
curl http://localhost:8007/health | jq '.total_connections'

# Clean up
pkill websocat
```

### Stress Test Like Operations

```bash
# Rapid fire likes (requires Apache Bench or similar)
ab -n 1000 -c 10 \
  -H "Authorization: Bearer $USER2_TOKEN" \
  -p /tmp/empty.json \
  -T "application/json" \
  "http://localhost:8007/api/v1/echoes/$ECHO_ID/like"
```

## Debugging

### Check NATS Events

Install NATS CLI:
```bash
# macOS
brew install nats-io/nats-tools/nats

# Linux
curl -sf https://binaries.nats.dev/nats-io/natscli/nats@latest | sh
```

Subscribe to events:
```bash
# Subscribe to all events
nats sub ">"

# Subscribe to specific events
nats sub "echo.liked"
nats sub "user.followed"
```

### Database Inspection

```bash
# Connect to PostgreSQL
docker exec -it ka-postgres psql -U ka_user -d ka_db

# Check likes
SELECT * FROM likes;

# Check notifications
SELECT id, user_id, type, actor_count, is_read, created_at FROM notifications;

# Check notification actors
SELECT id, type, actor_count, actor_ids FROM notifications WHERE type = 'like';
```

### Redis Inspection

```bash
# Connect to Redis
docker exec -it ka-redis redis-cli -a ka_redis_password

# Check if any caching is being used
KEYS *
```

## Common Issues

### 1. WebSocket Connection Refused
- Check that the engagement service is running
- Verify the JWT token is valid and not expired
- Check CORS settings if connecting from browser

### 2. Notifications Not Appearing
- Verify NATS is running: `docker-compose ps nats`
- Check NATS subscriptions: `nats sub "echo.liked"`
- Verify the event is being published from Engagement Service logs

### 3. Like Count Not Updating
- Check Content Service logs for errors
- Verify the internal API is accessible: 
  ```bash
  curl -X PATCH http://localhost:8003/api/internal/echoes/$ECHO_ID/likes \
    -H "Content-Type: application/json" \
    -d '{"delta": 1}'
  ```

### 4. No Follow Notifications
- Check Interaction Service logs for NATS connection
- Verify user.followed events are being published
- Check Engagement Service consumer logs

## Automated Testing

Run the full integration test suite:

```bash
# Create a test script
cat > /tmp/test-engagement.sh << 'EOF'
#!/bin/bash
set -e

echo "Starting engagement service integration tests..."

# Test 1: Health check
echo "Test 1: Health check"
curl -s http://localhost:8007/health | jq -e '.status == "ok"' > /dev/null
echo "✓ Health check passed"

# Test 2: Like/Unlike (requires tokens from previous tests)
if [ -n "$USER1_TOKEN" ] && [ -n "$USER2_TOKEN" ] && [ -n "$ECHO_ID" ]; then
  echo "Test 2: Like/Unlike"
  
  # Like
  curl -s -X POST "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
    -H "Authorization: Bearer $USER2_TOKEN" \
    | jq -e '.success == true' > /dev/null
  echo "✓ Like passed"
  
  # Unlike
  curl -s -X DELETE "http://localhost:8007/api/v1/echoes/$ECHO_ID/like" \
    -H "Authorization: Bearer $USER2_TOKEN" \
    | jq -e '.success == true' > /dev/null
  echo "✓ Unlike passed"
else
  echo "⚠ Skipping Test 2: Missing tokens or echo ID"
fi

echo "All tests passed!"
EOF

chmod +x /tmp/test-engagement.sh
/tmp/test-engagement.sh
```

## Monitoring

Track key metrics:
- Number of active WebSocket connections
- Notification delivery latency
- Like/unlike operation throughput
- Database query performance
- NATS event processing lag

Use the health endpoint for basic monitoring:
```bash
watch -n 5 'curl -s http://localhost:8007/health | jq .'
```
