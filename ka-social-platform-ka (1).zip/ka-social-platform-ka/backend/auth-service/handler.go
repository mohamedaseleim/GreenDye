package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/utils"
)

// Handler handles HTTP requests for auth
type Handler struct {
	repo          *Repository
	config        *Config
	billingClient *utils.BillingClient
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	return &Handler{
		repo:          repo,
		config:        config,
		billingClient: utils.NewBillingClient(config.BillingServiceURL),
	}
}

// Register handles user registration
func (h *Handler) Register(c *gin.Context) {
	var req models.RegisterRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Validate email
	if !utils.IsValidEmail(req.Email) {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_EMAIL",
			"Invalid email format",
			nil,
		))
		return
	}

	// Validate username
	if !utils.IsValidUsername(req.Username) {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USERNAME",
			"Username must be 3-50 characters and contain only letters, numbers, and underscores",
			nil,
		))
		return
	}

	// Check if email already exists
	if _, err := h.repo.GetUserByEmail(req.Email); err == nil {
		c.JSON(http.StatusConflict, models.ErrorResponse(
			"USER_ALREADY_EXISTS",
			"Email already registered",
			nil,
		))
		return
	}

	// Check if username already exists
	if _, err := h.repo.GetUserByUsername(req.Username); err == nil {
		c.JSON(http.StatusConflict, models.ErrorResponse(
			"USER_ALREADY_EXISTS",
			"Username already taken",
			nil,
		))
		return
	}

	// Hash password
	passwordHash, err := utils.HashPassword(req.Password)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to process password",
			nil,
		))
		return
	}

	// Create user
	user := &models.User{
		ID:           uuid.New(),
		Username:     req.Username,
		Email:        req.Email,
		Phone:        req.Phone,
		PasswordHash: passwordHash,
		DisplayName:  req.DisplayName,
		Language:     "en",
	}

	if err := h.repo.CreateUser(user); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to create user",
			err.Error(),
		))
		return
	}

	// Publish user.created event to NATS
	if h.config.NATSConn != nil {
		h.publishUserCreatedEvent(user)
	}

	c.JSON(http.StatusCreated, models.SuccessResponse(
		gin.H{
			"user_id":               user.ID,
			"username":              user.Username,
			"email":                 user.Email,
			"verification_required": true,
		},
		"Account created successfully",
	))
}

// Login handles user login
func (h *Handler) Login(c *gin.Context) {
	var req models.LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	// Get user by email
	user, err := h.repo.GetUserByEmail(req.Email)
	if err != nil {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_INVALID_CREDENTIALS",
			"Invalid email or password",
			nil,
		))
		return
	}

	// Check password
	if err := utils.CheckPassword(user.PasswordHash, req.Password); err != nil {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_INVALID_CREDENTIALS",
			"Invalid email or password",
			nil,
		))
		return
	}

	// Fetch user entitlements from billing service
	ctx := c.Request.Context()
	entitlements, err := h.billingClient.GetUserEntitlements(ctx, user.ID)
	if err != nil {
		log.Printf("Warning: Failed to fetch entitlements for user %s: %v", user.ID, err)
		entitlements = []string{} // Continue with empty entitlements
	}

	// Generate tokens
	jwtExpiry, _ := strconv.Atoi(h.config.JWTExpiry)
	accessToken, err := utils.GenerateAccessTokenWithEntitlements(
		user.ID,
		user.Username,
		user.IsPremium,
		entitlements,
		h.config.JWTSecret,
		jwtExpiry,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to generate access token",
			nil,
		))
		return
	}

	refreshExpiry, _ := strconv.Atoi(h.config.RefreshTokenExpiry)
	refreshToken, err := utils.GenerateRefreshToken(
		user.ID,
		h.config.JWTSecret,
		refreshExpiry,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to generate refresh token",
			nil,
		))
		return
	}

	// Save refresh token
	tokenHash := hashToken(refreshToken)
	expiresAt := time.Now().Add(time.Duration(refreshExpiry) * time.Second)
	if err := h.repo.SaveRefreshToken(user.ID, tokenHash, expiresAt); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to save refresh token",
			nil,
		))
		return
	}

	// Create user short response
	userShort := models.UserShort{
		ID:                user.ID,
		Username:          user.Username,
		DisplayName:       user.DisplayName,
		ProfilePictureURL: user.ProfilePictureURL,
		IsVerified:        user.IsVerified,
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		models.AuthResponse{
			User:         userShort,
			AccessToken:  accessToken,
			RefreshToken: refreshToken,
			ExpiresIn:    jwtExpiry,
		},
		"Login successful",
	))
}

// RefreshToken handles token refresh
func (h *Handler) RefreshToken(c *gin.Context) {
	var req struct {
		RefreshToken string `json:"refresh_token" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_INPUT",
			"Refresh token is required",
			nil,
		))
		return
	}

	// Validate refresh token
	tokenHash := hashToken(req.RefreshToken)
	userID, err := h.repo.ValidateRefreshToken(tokenHash)
	if err != nil {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_INVALID",
			"Invalid or expired refresh token",
			nil,
		))
		return
	}

	// Get user
	user, err := h.repo.GetUserByID(userID)
	if err != nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"USER_NOT_FOUND",
			"User not found",
			nil,
		))
		return
	}

	// Fetch user entitlements from billing service
	ctx := c.Request.Context()
	entitlements, err := h.billingClient.GetUserEntitlements(ctx, user.ID)
	if err != nil {
		log.Printf("Warning: Failed to fetch entitlements for user %s: %v", user.ID, err)
		entitlements = []string{} // Continue with empty entitlements
	}

	// Generate new access token
	jwtExpiry, _ := strconv.Atoi(h.config.JWTExpiry)
	accessToken, err := utils.GenerateAccessTokenWithEntitlements(
		user.ID,
		user.Username,
		user.IsPremium,
		entitlements,
		h.config.JWTSecret,
		jwtExpiry,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to generate access token",
			nil,
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		models.TokenResponse{
			AccessToken: accessToken,
			ExpiresIn:   jwtExpiry,
		},
		"Token refreshed successfully",
	))
}

// Logout handles user logout
func (h *Handler) Logout(c *gin.Context) {
	// Get user ID from context (set by auth middleware)
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"AUTH_TOKEN_MISSING",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Revoke all user tokens
	if err := h.repo.RevokeAllUserTokens(userID); err != nil {
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"SERVER_ERROR",
			"Failed to revoke tokens",
			nil,
		))
		return
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		nil,
		"Logged out successfully",
	))
}

// hashToken creates a SHA256 hash of a token
func hashToken(token string) string {
	hash := sha256.Sum256([]byte(token))
	return hex.EncodeToString(hash[:])
}

// publishUserCreatedEvent publishes a user.created event to NATS
func (h *Handler) publishUserCreatedEvent(user *models.User) {
	event := map[string]interface{}{
		"user_id":             user.ID.String(),
		"username":            user.Username,
		"display_name":        user.DisplayName,
		"bio":                 user.Bio,
		"profile_picture_url": user.ProfilePictureURL,
		"is_verified":         user.IsVerified,
		"timestamp":           time.Now().UTC().Format(time.RFC3339),
	}

	data, err := json.Marshal(event)
	if err != nil {
		log.Printf("Warning: Failed to marshal user.created event: %v", err)
		return
	}

	if err := h.config.NATSConn.Publish("user.created", data); err != nil {
		log.Printf("Warning: Failed to publish user.created event: %v", err)
	} else {
		log.Printf("Published user.created event for user %s", user.ID)
	}
}
