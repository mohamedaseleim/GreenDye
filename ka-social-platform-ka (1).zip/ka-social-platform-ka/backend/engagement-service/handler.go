package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/models"
	"github.com/mohamedaseleim/ka-social-platform/backend/shared/utils"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		// In production, implement proper origin checking
		return true
	},
}

// Handler handles HTTP requests for the engagement service
type Handler struct {
	repo   *Repository
	config *Config
}

// NewHandler creates a new handler
func NewHandler(repo *Repository, config *Config) *Handler {
	return &Handler{
		repo:   repo,
		config: config,
	}
}

// LikeEcho handles POST /api/v1/echoes/:echoId/like
func (h *Handler) LikeEcho(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse echo ID from URL
	echoIDStr := c.Param("echoId")
	echoID, err := uuid.Parse(echoIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID",
			nil,
		))
		return
	}

	// Get echo details from Content Service to find owner
	echo, err := h.getEchoFromContentService(echoID)
	if err != nil {
		log.Printf("Error fetching echo from content service: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to retrieve echo information",
			nil,
		))
		return
	}

	if echo == nil {
		c.JSON(http.StatusNotFound, models.ErrorResponse(
			"ECHO_NOT_FOUND",
			"Echo not found",
			nil,
		))
		return
	}

	echoOwner := echo.UserID

	// Like the echo (idempotent)
	isNew, err := h.repo.LikeEcho(userID, echoID)
	if err != nil {
		log.Printf("Error liking echo: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to like echo",
			nil,
		))
		return
	}

	// Only publish event and update counts if this is a new like
	if isNew {
		// Publish echo.liked event to NATS for notification generation
		if err := h.config.NATSConn.Publish("echo.liked", mustMarshalJSON(EchoLikedEvent{
			EchoID:    echoID.String(),
			UserID:    userID.String(),
			EchoOwner: echoOwner.String(),
			Timestamp: time.Now().UTC().Format(time.RFC3339),
		})); err != nil {
			log.Printf("Warning: Failed to publish echo.liked event: %v", err)
		}

		// Update like count in Content Service
		if err := h.updateContentServiceLikeCount(echoID, 1); err != nil {
			log.Printf("Warning: Failed to update like count in Content Service: %v", err)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"liked":        true,
			"already_liked": !isNew,
		},
		"Echo liked successfully",
	))
}

// UnlikeEcho handles DELETE /api/v1/echoes/:echoId/like
func (h *Handler) UnlikeEcho(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse echo ID from URL
	echoIDStr := c.Param("echoId")
	echoID, err := uuid.Parse(echoIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID",
			nil,
		))
		return
	}

	// Unlike the echo (idempotent)
	wasLiked, err := h.repo.UnlikeEcho(userID, echoID)
	if err != nil {
		log.Printf("Error unliking echo: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to unlike echo",
			nil,
		))
		return
	}

	// Only update count if there was actually a like to remove
	if wasLiked {
		// Update like count in Content Service
		if err := h.updateContentServiceLikeCount(echoID, -1); err != nil {
			log.Printf("Warning: Failed to update like count in Content Service: %v", err)
		}
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{
			"liked":      false,
			"was_liked": wasLiked,
		},
		"Echo unliked successfully",
	))
}

// GetNotifications handles GET /api/v1/notifications
func (h *Handler) GetNotifications(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	perPage, _ := strconv.Atoi(c.DefaultQuery("per_page", "20"))

	if page < 1 {
		page = 1
	}
	if perPage < 1 || perPage > 100 {
		perPage = 20
	}

	offset := (page - 1) * perPage

	// Get notifications
	notifications, err := h.repo.GetUserNotifications(userID, perPage, offset)
	if err != nil {
		log.Printf("Error getting notifications: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to retrieve notifications",
			nil,
		))
		return
	}

	// Get total count
	total, err := h.repo.CountUserNotifications(userID)
	if err != nil {
		log.Printf("Error counting notifications: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to count notifications",
			nil,
		))
		return
	}

	// Build pagination info
	totalPages := int(total) / perPage
	if int(total)%perPage > 0 {
		totalPages++
	}

	pagination := models.PaginationInfo{
		Page:       page,
		PerPage:    perPage,
		Total:      total,
		TotalPages: totalPages,
	}

	c.JSON(http.StatusOK, models.PaginatedSuccessResponse(notifications, pagination))
}

// HandleWebSocket handles WebSocket connections for real-time notifications
func (h *Handler) HandleWebSocket(c *gin.Context) {
	// Get token from query parameter
	token := c.Query("token")
	if token == "" {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"MISSING_TOKEN",
			"Authentication token required",
			nil,
		))
		return
	}

	// Validate JWT token
	claims, err := utils.ValidateToken(token, h.config.JWTSecret)
	if err != nil {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"INVALID_TOKEN",
			"Invalid authentication token",
			err.Error(),
		))
		return
	}

	userID, err := uuid.Parse(claims.UserID)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID in token",
			nil,
		))
		return
	}

	// Upgrade connection to WebSocket
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("Failed to upgrade connection: %v", err)
		return
	}

	// Create client and register with hub
	client := &Client{
		hub:    h.config.WSHub,
		conn:   conn,
		send:   make(chan []byte, 256),
		userID: userID,
	}

	client.hub.register <- client

	log.Printf("WebSocket connection established for user %s", userID)

	// Start goroutines for reading and writing
	go client.writePump()
	go client.readPump()
}

// getEchoFromContentService fetches echo details from Content Service
func (h *Handler) getEchoFromContentService(echoID uuid.UUID) (*models.Echo, error) {
	url := fmt.Sprintf("%s/api/internal/echoes/batch", h.config.ContentServiceURL)

	payload := map[string][]string{
		"echo_ids": {echoID.String()},
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal request: %w", err)
	}

	resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to call content service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("content service returned status: %d", resp.StatusCode)
	}

	var result struct {
		Success bool          `json:"success"`
		Data    []models.Echo `json:"data"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	if len(result.Data) == 0 {
		return nil, nil
	}

	return &result.Data[0], nil
}

// updateContentServiceLikeCount updates the like count in Content Service
func (h *Handler) updateContentServiceLikeCount(echoID uuid.UUID, delta int) error {
	url := fmt.Sprintf("%s/api/internal/echoes/%s/likes", h.config.ContentServiceURL, echoID.String())

	payload := map[string]int{
		"delta": delta,
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal request: %w", err)
	}

	req, err := http.NewRequest("PATCH", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to call content service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("content service returned status: %d", resp.StatusCode)
	}

	return nil
}

// mustMarshalJSON marshals data to JSON or panics
func mustMarshalJSON(v interface{}) []byte {
	data, err := json.Marshal(v)
	if err != nil {
		panic(err)
	}
	return data
}

// GetEchoAnalytics handles GET /api/v1/echoes/:echoId/analytics
// This endpoint is only accessible to Ka+ users with ADVANCED_ANALYTICS entitlement
func (h *Handler) GetEchoAnalytics(c *gin.Context) {
	// Get authenticated user ID from context
	userIDStr, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, models.ErrorResponse(
			"UNAUTHORIZED",
			"User not authenticated",
			nil,
		))
		return
	}

	userID, err := uuid.Parse(userIDStr.(string))
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Check if user has ADVANCED_ANALYTICS entitlement
	entitlements := utils.GetEntitlementsFromContext(c)
	if !utils.HasEntitlement(entitlements, utils.EntitlementAdvancedAnalytics) {
		c.JSON(http.StatusForbidden, models.ErrorResponse(
			"ENTITLEMENT_REQUIRED",
			"This feature requires a Ka+ subscription",
			gin.H{
				"required_entitlement": utils.EntitlementAdvancedAnalytics,
				"upgrade_url": "/api/v1/billing/checkout",
			},
		))
		return
	}

	// Parse echo ID
	echoIDParam := c.Param("echoId")
	echoID, err := uuid.Parse(echoIDParam)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_ECHO_ID",
			"Invalid echo ID format",
			nil,
		))
		return
	}

	// Calculate analytics
	// In a real implementation, you would query various metrics from the database
	// For now, we'll return placeholder analytics
	analytics := h.calculateAnalytics(echoID, userID)

	c.JSON(http.StatusOK, models.SuccessResponse(
		analytics,
		"Analytics retrieved successfully",
	))
}

// calculateAnalytics calculates detailed analytics for an echo
func (h *Handler) calculateAnalytics(echoID, ownerID uuid.UUID) gin.H {
	// In a real production implementation, you would:
	// 1. Query the likes table with GROUP BY and aggregations for hourly/daily stats
	// 2. Query a separate views/impressions table for view counts
	// 3. Join with users table to get top likers
	// 4. Use a time-series database for efficient analytics queries
	
	// For this implementation, we'll return placeholder analytics structure
	// to demonstrate the API design and entitlement checking
	
	// Placeholder hourly distribution (would come from database aggregation)
	hourlyLikes := make(map[int]int)
	for i := 0; i < 24; i++ {
		// Simulate some activity pattern
		hourlyLikes[i] = i * 2
	}

	// Placeholder daily distribution for last 7 days
	dailyLikes := make(map[string]int)
	now := time.Now()
	for i := 0; i < 7; i++ {
		day := now.AddDate(0, 0, -i).Format("2006-01-02")
		dailyLikes[day] = 45 - (i * 5) // Simulated declining pattern
	}

	// Placeholder metrics
	totalLikes := 142
	totalViews := 1420
	engagementRate := float64(totalLikes) / float64(totalViews) * 100

	// Placeholder top likers
	topLikers := []gin.H{
		{
			"user_id":  uuid.New().String(),
			"liked_at": time.Now().Add(-1 * time.Hour).Format(time.RFC3339),
		},
		{
			"user_id":  uuid.New().String(),
			"liked_at": time.Now().Add(-2 * time.Hour).Format(time.RFC3339),
		},
		{
			"user_id":  uuid.New().String(),
			"liked_at": time.Now().Add(-3 * time.Hour).Format(time.RFC3339),
		},
	}

	return gin.H{
		"echo_id":          echoID.String(),
		"total_likes":      totalLikes,
		"total_views":      totalViews,
		"engagement_rate":  engagementRate,
		"hourly_likes":     hourlyLikes,
		"daily_likes":      dailyLikes,
		"top_likers":       topLikers,
		"analytics_period": "last_7_days",
		"generated_at":     time.Now().Format(time.RFC3339),
		"note":             "This is a placeholder implementation. In production, these metrics would come from database queries and analytics systems.",
	}
}

// GetBatchLikeStatus handles POST /api/internal/likes/batch-status (internal endpoint)
func (h *Handler) GetBatchLikeStatus(c *gin.Context) {
	var req struct {
		UserID  string   `json:"user_id" binding:"required"`
		EchoIDs []string `json:"echo_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_REQUEST",
			"Invalid request body",
			err.Error(),
		))
		return
	}

	userID, err := uuid.Parse(req.UserID)
	if err != nil {
		c.JSON(http.StatusBadRequest, models.ErrorResponse(
			"INVALID_USER_ID",
			"Invalid user ID",
			nil,
		))
		return
	}

	// Parse echo IDs
	echoIDs := make([]uuid.UUID, 0, len(req.EchoIDs))
	for _, idStr := range req.EchoIDs {
		echoID, err := uuid.Parse(idStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, models.ErrorResponse(
				"INVALID_ECHO_ID",
				"Invalid echo ID format",
				idStr,
			))
			return
		}
		echoIDs = append(echoIDs, echoID)
	}

	// Get like status from repository
	likeStatus, err := h.repo.GetBatchLikeStatus(userID, echoIDs)
	if err != nil {
		log.Printf("Error fetching batch like status: %v", err)
		c.JSON(http.StatusInternalServerError, models.ErrorResponse(
			"INTERNAL_ERROR",
			"Failed to fetch like status",
			nil,
		))
		return
	}

	// Convert to string map for response
	likeStatusStr := make(map[string]bool)
	for echoID, isLiked := range likeStatus {
		likeStatusStr[echoID.String()] = isLiked
	}

	c.JSON(http.StatusOK, models.SuccessResponse(
		gin.H{"like_status": likeStatusStr},
		"Like status retrieved successfully",
	))
}
