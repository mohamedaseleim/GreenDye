# Discovery Service Testing Guide

This guide explains how to test the Discovery Service functionality.

## Prerequisites

1. All services running via docker-compose
2. `curl` and `jq` installed
3. Sample data in the database (users and echoes)

## Starting the Services

```bash
cd infrastructure/docker
docker compose up -d
```

Wait for all services to be healthy:
```bash
docker compose ps
```

## Manual Testing

### 1. Health Check

```bash
curl http://localhost:8008/health | jq '.'
```

Expected response:
```json
{
  "status": "healthy",
  "service": "discovery-service"
}
```

### 2. Trending Hashtags

```bash
curl "http://localhost:8008/api/v1/discover/trending?limit=10" | jq '.'
```

Expected response:
```json
{
  "success": true,
  "message": "Trending hashtags retrieved successfully",
  "data": {
    "trending_hashtags": [
      {
        "tag": "tech",
        "count": 42
      },
      {
        "tag": "ai",
        "count": 28
      }
    ]
  }
}
```

**Note**: Initially, the trending hashtags list will be empty until echoes with hashtags are created.

### 3. Search

Search for users and echoes:

```bash
curl "http://localhost:8008/api/v1/search?q=john&limit=5" | jq '.'
```

Expected response:
```json
{
  "success": true,
  "message": "Search completed successfully",
  "data": {
    "users": [
      {
        "id": "uuid",
        "username": "johndoe",
        "display_name": "John Doe",
        "bio": "Software Engineer",
        "follower_count": 123,
        "is_verified": false,
        "profile_picture_url": "",
        "created_at": 1234567890
      }
    ],
    "echoes": [
      {
        "id": "uuid",
        "user_id": "uuid",
        "content": "Hello from John!",
        "hashtags": ["tech"],
        "likes_count": 5,
        "created_at": 1234567890,
        "visibility": "public"
      }
    ],
    "hits": 2
  }
}
```

### 4. Autocomplete

Get type-ahead suggestions:

```bash
curl "http://localhost:8008/api/v1/search/suggest?q=jo&limit=3" | jq '.'
```

Expected response:
```json
{
  "success": true,
  "message": "Suggestions retrieved successfully",
  "data": {
    "users": [
      {
        "id": "uuid",
        "username": "johndoe",
        "display_name": "John Doe",
        "bio": "Software Engineer",
        "follower_count": 123,
        "is_verified": false,
        "profile_picture_url": "",
        "created_at": 1234567890
      }
    ],
    "echoes": []
  }
}
```

## Integration Testing

### Test Event-Driven Indexing

#### 1. Create a User (triggers user.created event)

```bash
curl -X POST http://localhost:8001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "testpass123",
    "display_name": "Test User"
  }' | jq '.'
```

Wait 2-3 seconds for indexing, then search:

```bash
curl "http://localhost:8008/api/v1/search?q=testuser" | jq '.data.users'
```

You should see the newly created user in search results.

#### 2. Create an Echo with Hashtags (triggers echo.created event)

First, login to get a JWT token:

```bash
TOKEN=$(curl -X POST http://localhost:8001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "testpass123"
  }' | jq -r '.data.access_token')
```

Create an echo:

```bash
curl -X POST http://localhost:8003/api/v1/echoes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "content": "Testing the discovery service with #meilisearch and #trending hashtags!",
    "visibility": "public"
  }' | jq '.'
```

Wait 2-3 seconds, then check:

1. Search for the echo:
```bash
curl "http://localhost:8008/api/v1/search?q=meilisearch" | jq '.data.echoes'
```

2. Check trending hashtags:
```bash
curl "http://localhost:8008/api/v1/discover/trending" | jq '.data.trending_hashtags'
```

You should see "meilisearch" and "trending" in the trending list.

#### 3. Like an Echo (triggers echo.updated event)

```bash
curl -X POST "http://localhost:8007/api/v1/echoes/{ECHO_ID}/like" \
  -H "Authorization: Bearer $TOKEN" | jq '.'
```

Wait 2-3 seconds, then search for the echo again. The likes_count should be updated in search results.

#### 4. Update User Profile (triggers user.updated event)

```bash
curl -X PUT http://localhost:8002/api/profile/me \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "display_name": "Updated Test User",
    "bio": "Testing search updates"
  }' | jq '.'
```

Wait 2-3 seconds, then search:

```bash
curl "http://localhost:8008/api/v1/search?q=testuser" | jq '.data.users[0]'
```

The display_name and bio should be updated in search results.

## Automated Test Script

Run the provided test script:

```bash
cd backend/discovery-service
./test_discovery.sh
```

## Performance Testing

### Search Latency

Test search response time:

```bash
time curl -s "http://localhost:8008/api/v1/search?q=test" > /dev/null
```

Expected: <100ms

### Autocomplete Latency

Test autocomplete response time:

```bash
time curl -s "http://localhost:8008/api/v1/search/suggest?q=jo" > /dev/null
```

Expected: <50ms

### Trending Hashtags Calculation

Test trending hashtags response time:

```bash
time curl -s "http://localhost:8008/api/v1/discover/trending" > /dev/null
```

Expected: <10ms

## Monitoring

### Check Service Logs

```bash
docker compose logs -f discovery-service
```

Look for:
- Event consumption messages
- Indexing confirmations
- Error messages

### Check Meilisearch

Access Meilisearch directly:

```bash
# List indexes
curl "http://localhost:7700/indexes" \
  -H "Authorization: Bearer masterKey123" | jq '.'

# Check users index stats
curl "http://localhost:7700/indexes/users/stats" \
  -H "Authorization: Bearer masterKey123" | jq '.'

# Check echoes index stats
curl "http://localhost:7700/indexes/echoes/stats" \
  -H "Authorization: Bearer masterKey123" | jq '.'
```

### Check Redis Trending Data

```bash
docker compose exec redis redis-cli -a ka_redis_password

# View trending hashtags
ZREVRANGE trending:hashtags 0 10 WITHSCORES

# View timestamps for a specific hashtag
ZRANGE trending:hashtag:tech:timestamps 0 -1 WITHSCORES
```

## Troubleshooting

### No Search Results

1. Check if Meilisearch is running:
   ```bash
   curl http://localhost:7700/health
   ```

2. Check if indexes exist:
   ```bash
   curl "http://localhost:7700/indexes" \
     -H "Authorization: Bearer masterKey123" | jq '.'
   ```

3. Check Discovery Service logs:
   ```bash
   docker compose logs discovery-service | grep -i error
   ```

### Events Not Being Indexed

1. Check NATS connectivity:
   ```bash
   docker compose logs discovery-service | grep -i nats
   ```

2. Verify event publishers are sending events:
   ```bash
   docker compose logs content-service | grep "Published"
   docker compose logs user-service | grep "Published"
   docker compose logs auth-service | grep "Published"
   ```

3. Check NATS monitoring:
   ```bash
   curl http://localhost:8222/varz | jq '.'
   ```

### Trending Hashtags Not Updating

1. Check Redis connection:
   ```bash
   docker compose logs discovery-service | grep -i redis
   ```

2. Verify hashtags are being extracted:
   ```bash
   docker compose logs discovery-service | grep "Incremented"
   ```

3. Check Redis data:
   ```bash
   docker compose exec redis redis-cli -a ka_redis_password ZREVRANGE trending:hashtags 0 -1 WITHSCORES
   ```

## Clean Up

To reset the Discovery Service data:

```bash
# Stop services
docker compose down

# Remove Meilisearch volume
docker volume rm docker_meilisearch_data

# Remove Redis data (will clear all Redis data)
docker volume rm docker_redis_data

# Start services
docker compose up -d
```
